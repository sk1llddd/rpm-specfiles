#!/bin/sh
# Local stand-in for Oreon's package build service: builds every spec in packaging/ into RPMs inside a clean,
# minimal Oreon 11 build root (like mock), so specs can be tested before they go to Oreon's spec repository.
#
# Runs as root in the builder container (os/respin.sh calls it; RPM_ONLY=1 there builds just the packages).
#   SRC          the repo (default /src)
#   OUT          scratch space
#   CACHE        kept between builds: the pristine build root and the dnf package cache
#   RESULT_DIR   RPMs and SRPMs go to RESULT_DIR/rpms
#   OREON_ROOT   an unpacked, chroot-ready stock Oreon 11 root; only needed to create the build root the first time
#   RELEASE=1    build like Oreon's servers do: use the tarball next to the spec (packaging/make-tarball.sh makes it),
#                or download Source0 if there is none. Without it, the working tree is packed as Source0.
#   SPECS        specs to build (default: packaging/*.spec)

set -eu

src=${SRC:-/src}
out=${OUT:-$src/os/out}
cache=${CACHE:-}
rpm_out=${RESULT_DIR:-$out}/rpms
specs=${SPECS:-$(ls "$src"/packaging/*.spec)}
br=$out/buildroot
pristine=${cache:+$cache/buildroot}
pristine=${pristine:-$out/buildroot.pristine}

log() { printf '\033[1mbuild-service:\033[0m %s\n' "$*"; }

mounted=""
unmount() {
  for m in $mounted; do umount "$m" 2>/dev/null || true; done
  mounted=""
}
trap unmount EXIT
bind() { mkdir -p "$2" && mount --bind "$1" "$2" && mounted="$2 $mounted"; }

if [ ! -f "$pristine/.ready" ]; then
  [ -n "${OREON_ROOT:-}" ] || { echo "build-service: no cached build root; pass OREON_ROOT to create one" >&2; exit 1; }
  log "creating a minimal Oreon 11 build root (once)"
  rm -rf "$pristine"
  mkdir -p "$pristine"
  bind "$pristine" "$OREON_ROOT/mnt/buildroot"
  chroot "$OREON_ROOT" dnf5 -y -q --installroot=/mnt/buildroot --use-host-config --releasever=11 \
    --setopt=install_weak_deps=False --setopt=tsflags=nodocs --setopt=keepcache=0 \
    install oreon-release oreon-repos oreon-gpg-keys rpm-build dnf5 dnf5-plugins shadow-utils tar gzip
  unmount
  rm -rf "$pristine"/var/cache/libdnf5/*
  touch "$pristine/.ready"
fi

log "fresh build root"
rm -rf "$br"
cp -a "$pristine" "$br"
for m in proc dev sys; do bind "/$m" "$br/$m"; done
rm -f "$br/etc/resolv.conf"
cp /etc/resolv.conf "$br/etc/resolv.conf"
keep=0
if [ -n "$cache" ]; then
  mkdir -p "$cache/dnf"
  bind "$cache/dnf" "$br/var/cache/libdnf5"
  keep=1
fi
# Oreon's dist tag (.or11) comes from its build system; set it the same way here
dist=.or$(. "$br/usr/lib/os-release"; echo "${VERSION_ID%%.*}")
mkdir -p "$rpm_out"

for spec in $specs; do
  name=$(sed -n 's/^Name:[[:space:]]*//p' "$spec")
  ver=$(sed -n 's/^Version:[[:space:]]*//p' "$spec")
  top=/root/rpmbuild
  rm -rf "$br$top"
  mkdir -p "$br$top/SOURCES" "$br$top/SPECS"
  cp "$spec" "$br$top/SPECS/"
  s=$top/SPECS/$(basename "$spec")
  # local files next to the specs (patches, uploaded tarballs) are sources too
  find "$(dirname "$spec")" -maxdepth 1 -type f ! -name '*.spec' ! -name '*.sh' -exec cp {} "$br$top/SOURCES/" \;
  for url in $(chroot "$br" rpmspec -P "$s" | sed -n 's/^Source[0-9]*:[[:space:]]*//p'); do
    file=$(basename "${url##*#/}")
    if [ -z "${RELEASE:-}" ] && [ "$file" = "$name-$ver.tar.gz" ]; then
      log "$name: packing the working tree as $file"
      tar -C "$src" --exclude=./.git --exclude=./os/out --exclude=.DS_Store --exclude='*.o' --exclude='./packaging/*.tar.gz' \
        --exclude=./shell/oreonvr-shell --exclude=./shell/bridge/oreonvr-desktop-bridge --exclude=./shell/bridge/proto \
        --exclude='./shell/src/proto/xdg-*' --exclude='./shell/src/proto/text-input-*' --exclude=./shell/res/sky.ppm \
        --exclude=./shell/tests/wlclient --transform "s,^\.,$name-$ver," -czf "$br$top/SOURCES/$file" .
      continue
    fi
    if [ -f "$br$top/SOURCES/$file" ]; then
      log "$name: using $file from $(basename "$(dirname "$spec")")/"
      continue
    fi
    case "$url" in
    http://* | https://*)
      log "$name: downloading $url"
      curl -fsSL --retry 3 -o "$br$top/SOURCES/$file" "${url%%#/*}"
      ;;
    *) echo "build-service: $name: missing source $file" >&2; exit 1 ;;
    esac
  done
  log "$name $ver: installing build dependencies"
  chroot "$br" dnf5 -y -q --setopt=install_weak_deps=False --setopt=keepcache=$keep builddep "$s"
  log "$name $ver: rpmbuild"
  chroot "$br" rpmbuild -ba --quiet --define "dist $dist" "$s"
  rm -f "$rpm_out/$name"-*.rpm
  cp "$br$top"/RPMS/*/*.rpm "$br$top"/SRPMS/*.src.rpm "$rpm_out/"
done

unmount
rm -rf "$br"
log "built: $(cd "$rpm_out" && ls *.rpm | tr '\n' ' ')"
