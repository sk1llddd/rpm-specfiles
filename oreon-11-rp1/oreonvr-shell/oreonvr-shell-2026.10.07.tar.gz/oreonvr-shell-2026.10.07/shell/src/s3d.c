#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "s3d.h"

#define GW 96
#define MW 192
#define MAXGH 160
#define MAXMH 320
#define BS 8

struct S3D {
  int gh, mh, have_prev, w, h;
  float lum[MAXGH * GW], sat[MAXGH * GW], blu[MAXGH * GW], sharp[MAXGH * GW], motion[MAXGH * GW];
  float depth[MAXGH * GW], tmp[MAXGH * GW];
  unsigned char cur[MAXMH * MW], prev[MAXMH * MW];
  float *row;
  int rowcap;
};

S3D *s3d_new(void) { return calloc(1, sizeof(S3D)); }

void s3d_free(S3D *s) {
  if (!s) return;
  free(s->row);
  free(s);
}

void s3d_reset(S3D *s) {
  if (s) s->have_prev = 0;
}

static inline float clampf(float v, float a, float b) { return v < a ? a : v > b ? b : v; }

static int cmpf(const void *a, const void *b) {
  float x = *(const float *)a, y = *(const float *)b;
  return x < y ? -1 : x > y;
}

static void normalize(float *v, int n, float lo_q, float hi_q) {
  static float sorted[MAXGH * GW];
  memcpy(sorted, v, sizeof(float) * (size_t)n);
  qsort(sorted, (size_t)n, sizeof(float), cmpf);
  float lo = sorted[(int)(lo_q * (n - 1))], hi = sorted[(int)(hi_q * (n - 1))];
  float k = hi - lo > 1e-6f ? 1.f / (hi - lo) : 0.f;
  for (int i = 0; i < n; i++) v[i] = k ? clampf((v[i] - lo) * k, 0.f, 1.f) : 0.5f;
}

static void blur(float *v, float *tmp, int w, int h, int r) {
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      float s = 0;
      int n = 0;
      for (int k = -r; k <= r; k++) {
        int xx = x + k;
        if (xx < 0 || xx >= w) continue;
        s += v[y * w + xx], n++;
      }
      tmp[y * w + x] = s / n;
    }
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      float s = 0;
      int n = 0;
      for (int k = -r; k <= r; k++) {
        int yy = y + k;
        if (yy < 0 || yy >= h) continue;
        s += tmp[yy * w + x], n++;
      }
      v[y * w + x] = s / n;
    }
}

static void joint_bilateral(float *d, float *tmp, const float *g, int w, int h) {
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      float c = g[y * w + x], s = 0, ws = 0;
      for (int dy = -2; dy <= 2; dy++)
        for (int dx = -2; dx <= 2; dx++) {
          int xx = x + dx, yy = y + dy;
          if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
          float dl = g[yy * w + xx] - c;
          float wt = expf(-(dl * dl) * 60.f - (dx * dx + dy * dy) * 0.18f);
          s += d[yy * w + xx] * wt, ws += wt;
        }
      tmp[y * w + x] = s / ws;
    }
  memcpy(d, tmp, sizeof(float) * (size_t)w * h);
}

static void sample(S3D *s, const uint32_t *px, int w, int h) {
  int gh = s->gh, mh = s->mh;
  for (int gy = 0; gy < gh; gy++)
    for (int gx = 0; gx < GW; gx++) {
      int x0 = gx * w / GW, x1 = (gx + 1) * w / GW, y0 = gy * h / gh, y1 = (gy + 1) * h / gh;
      float r = 0, g = 0, b = 0;
      int n = 0;
      for (int y = y0; y < y1; y += 2)
        for (int x = x0; x < x1; x += 2) {
          uint32_t p = px[(size_t)y * w + x];
          r += (p >> 16) & 255, g += (p >> 8) & 255, b += p & 255, n++;
        }
      if (!n) n = 1;
      r /= n * 255.f, g /= n * 255.f, b /= n * 255.f;
      float mx = fmaxf(r, fmaxf(g, b)), mn = fminf(r, fminf(g, b));
      int i = gy * GW + gx;
      s->lum[i] = 0.299f * r + 0.587f * g + 0.114f * b;
      s->sat[i] = mx > 1e-3f ? (mx - mn) / mx : 0.f;
      s->blu[i] = b - 0.5f * (r + g);
    }
  for (int my = 0; my < mh; my++) {
    int y = my * h / mh;
    for (int mx = 0; mx < MW; mx++) {
      uint32_t p = px[(size_t)y * w + mx * w / MW];
      s->cur[my * MW + mx] = (unsigned char)((((p >> 16) & 255) * 77 + ((p >> 8) & 255) * 150 + (p & 255) * 29) >> 8);
    }
  }
}

static void sharpness(S3D *s) {
  int gh = s->gh, mh = s->mh;
  memset(s->sharp, 0, sizeof(float) * (size_t)gh * GW);
  for (int my = 1; my < mh - 1; my++)
    for (int mx = 1; mx < MW - 1; mx++) {
      const unsigned char *c = s->cur + my * MW + mx;
      int lap = 4 * c[0] - c[-1] - c[1] - c[-MW] - c[MW];
      int gy = my * gh / mh, gx = mx * GW / MW;
      s->sharp[gy * GW + gx] += (float)(lap * lap);
    }
  for (int i = 0; i < gh * GW; i++) s->sharp[i] = sqrtf(s->sharp[i]);
  blur(s->sharp, s->tmp, GW, gh, 2);
  normalize(s->sharp, gh * GW, 0.1f, 0.97f);
}

static int sad(const unsigned char *a, const unsigned char *b) {
  int t = 0;
  for (int y = 0; y < BS; y++, a += MW, b += MW)
    for (int x = 0; x < BS; x++) t += abs(a[x] - b[x]);
  return t;
}

static float motion(S3D *s) {
  int gh = s->gh, mh = s->mh, bw = MW / BS, bh = mh / BS, R = 6;
  static short vx[64 * 64], vy[64 * 64];
  float diff = 0;
  for (int i = 0; i < MW * mh; i++) diff += (float)abs(s->cur[i] - s->prev[i]);
  diff /= (float)(MW * mh) * 255.f;
  for (int by = 0; by < bh; by++)
    for (int bx = 0; bx < bw; bx++) {
      int ox = bx * BS, oy = by * BS, best = 1 << 30, bxv = 0, byv = 0;
      const unsigned char *c = s->cur + oy * MW + ox;
      for (int dy = -R; dy <= R; dy++)
        for (int dx = -R; dx <= R; dx++) {
          int px = ox + dx, py = oy + dy;
          if (px < 0 || py < 0 || px + BS > MW || py + BS > mh) continue;
          int v = sad(c, s->prev + py * MW + px) + (abs(dx) + abs(dy)) * 4;
          if (v < best) best = v, bxv = dx, byv = dy;
        }
      vx[by * bw + bx] = (short)bxv, vy[by * bw + bx] = (short)byv;
    }
  int n = bw * bh;
  static float sx[64 * 64], sy[64 * 64];
  for (int i = 0; i < n; i++) sx[i] = vx[i], sy[i] = vy[i];
  qsort(sx, (size_t)n, sizeof(float), cmpf);
  qsort(sy, (size_t)n, sizeof(float), cmpf);
  float gx = sx[n / 2], gy = sy[n / 2];
  for (int y = 0; y < gh; y++)
    for (int x = 0; x < GW; x++) {
      int bx = x * bw / GW, by = y * bh / gh;
      if (by >= bh) by = bh - 1;
      float dx = vx[by * bw + bx] - gx, dy = vy[by * bw + bx] - gy;
      s->motion[y * GW + x] = sqrtf(dx * dx + dy * dy);
    }
  blur(s->motion, s->tmp, GW, gh, 2);
  return diff;
}

void s3d_depth(S3D *s, const uint32_t *px, int w, int h) {
  int gh = (int)((float)GW * h / w + 0.5f), mh = (int)((float)MW * h / w + 0.5f);
  if (gh < 4) gh = 4;
  if (gh > MAXGH) gh = MAXGH;
  if (mh < BS * 2) mh = BS * 2;
  if (mh > MAXMH) mh = MAXMH;
  if (gh != s->gh || mh != s->mh || w != s->w || h != s->h) s->have_prev = 0;
  s->gh = gh, s->mh = mh, s->w = w, s->h = h;
  int n = gh * GW;
  sample(s, px, w, h);
  sharpness(s);
  float cut = 0;
  int has_motion = 0;
  if (s->have_prev) {
    cut = motion(s);
    float mmax = 0;
    for (int i = 0; i < n; i++) mmax = fmaxf(mmax, s->motion[i]);
    if (mmax > 0.75f && cut < 0.22f) {
      normalize(s->motion, n, 0.2f, 0.98f);
      has_motion = 1;
    }
  }
  float wp = 0.42f, ws = 0.24f, wm = has_motion ? 0.2f : 0.f, wc = 0.14f;
  float tot = wp + ws + wm + wc;
  for (int y = 0; y < gh; y++) {
    float pos = (float)y / (gh - 1);
    pos = pos * pos * (3.f - 2.f * pos);
    for (int x = 0; x < GW; x++) {
      int i = y * GW + x;
      float haze = (1.f - s->sat[i]) * (0.4f + 0.6f * s->lum[i]) + clampf(s->blu[i], 0.f, 0.5f);
      float sky = (y < gh / 2 && s->blu[i] > 0.05f && s->lum[i] > 0.45f && s->sharp[i] < 0.25f) ? 1.f : 0.f;
      float color = clampf(1.f - haze, 0.f, 1.f) * (1.f - sky);
      float d = (wp * pos + ws * s->sharp[i] + wm * (has_motion ? s->motion[i] : 0.f) + wc * color) / tot;
      s->tmp[i] = d * (1.f - 0.6f * sky);
    }
  }
  float *dn = s->tmp;
  static float fresh[MAXGH * GW];
  memcpy(fresh, dn, sizeof(float) * (size_t)n);
  normalize(fresh, n, 0.03f, 0.97f);
  blur(fresh, s->tmp, GW, gh, 1);
  joint_bilateral(fresh, s->tmp, s->lum, GW, gh);
  joint_bilateral(fresh, s->tmp, s->lum, GW, gh);
  int reset = !s->have_prev || cut >= 0.22f;
  float a = reset ? 1.f : 0.22f;
  for (int i = 0; i < n; i++) s->depth[i] = reset ? fresh[i] : s->depth[i] + (fresh[i] - s->depth[i]) * a;
  memcpy(s->prev, s->cur, (size_t)MW * mh);
  s->have_prev = 1;
}

float s3d_depth_at(const S3D *s, float u, float v) {
  float fx = clampf(u * GW - 0.5f, 0.f, GW - 1.001f), fy = clampf(v * s->gh - 0.5f, 0.f, s->gh - 1.001f);
  int x0 = (int)fx, y0 = (int)fy;
  float ax = fx - x0, ay = fy - y0;
  const float *d = s->depth;
  float top = d[y0 * GW + x0] * (1 - ax) + d[y0 * GW + x0 + 1] * ax;
  float bot = d[(y0 + 1) * GW + x0] * (1 - ax) + d[(y0 + 1) * GW + x0 + 1] * ax;
  return top * (1 - ay) + bot * ay;
}

static inline uint32_t lerp_px(uint32_t a, uint32_t b, unsigned t) {
  uint32_t rb = (((a & 0xff00ff) * (256 - t) + (b & 0xff00ff) * t) >> 8) & 0xff00ff;
  uint32_t g = (((a & 0x00ff00) * (256 - t) + (b & 0x00ff00) * t) >> 8) & 0x00ff00;
  return 0xff000000u | rb | g;
}

void s3d_views(S3D *s, const uint32_t *src, int w, int h, uint32_t *left, uint32_t *right, float strength) {
  if (s->rowcap < w) {
    free(s->row);
    s->row = malloc(sizeof(float) * (size_t)w);
    s->rowcap = w;
  }
  float maxd = strength * 0.014f * w, conv = 0.42f;
  for (int y = 0; y < h; y++) {
    const uint32_t *in = src + (size_t)y * w;
    uint32_t *L = left + (size_t)y * w, *Rr = right + (size_t)y * w;
    float v = (y + 0.5f) / h;
    for (int x = 0; x < w; x++) s->row[x] = maxd * (s3d_depth_at(s, (x + 0.5f) / w, v) - conv) * 0.5f;
    for (int x = 0; x < w; x++) {
      float d = s->row[x];
      for (int e = 0; e < 2; e++) {
        float sx = e ? x + d : x - d;
        if (sx < 0) sx = 0;
        if (sx > w - 1.001f) sx = w - 1.001f;
        int i = (int)sx;
        uint32_t p = lerp_px(in[i], in[i + 1], (unsigned)((sx - i) * 256.f));
        if (e) Rr[x] = p;
        else L[x] = p;
      }
    }
  }
}

void s3d_depth_image(const S3D *s, uint32_t *out, int w, int h) {
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      int g = (int)(s3d_depth_at(s, (x + 0.5f) / w, (y + 0.5f) / h) * 255.f);
      out[(size_t)y * w + x] = 0xff000000u | (uint32_t)g << 16 | (uint32_t)g << 8 | (uint32_t)g;
    }
}
