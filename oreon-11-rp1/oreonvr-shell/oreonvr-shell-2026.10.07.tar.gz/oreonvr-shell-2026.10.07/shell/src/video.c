#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <linux/input.h>
#include <math.h>
#include <pthread.h>
#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "oreonvr.h"
#include "office.h"
#include "s3d.h"

#ifdef HAVE_AV
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
#endif

#define VW 1040
#define VH (585 + BAR_H)
#define QN 6
#define MAXW 1280
#define MAXH 720
#define TW 320
#define TH 180
#define MAXLIB 200
#define A_RATE 48000
#define A_LAT 0.08
#define CTRL_H 96

enum {
  Z_VIDEO = 1, Z_PLAY, Z_BACK10, Z_FWD10, Z_SEEK, Z_MUTE, Z_VOL, Z_LIB, Z_REPLAY,
  Z_OPENFILES, Z_CARD = 100
};

static const char *const EXTS[] = {".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".ogv", ".wmv", ".flv", ".mpg", ".mpeg", ".ts", ".3gp", NULL};

int video_is_file(const char *name) {
  const char *d = strrchr(name, '.');
  if (!d) return 0;
  for (int i = 0; EXTS[i]; i++)
    if (!strcasecmp(d, EXTS[i])) return 1;
  return 0;
}

typedef struct {
  double pts;
  int w, h, stereo, gen;
  uint32_t *px, *l, *r;
} VFrame;

typedef struct {
  char path[1024], name[128];
  time_t mtime;
  double dur;
  uint32_t *thumb;
  int tw, th, done;
} Item;

typedef struct {
  pthread_t th;
  int started;
  pthread_mutex_t mu;
  volatile int stop, paused, seek_req, eof, ready;
  volatile double seek_to;
  volatile int gen, wall_sync;
  int work_gen;
  double duration;
  int vw, vh, has_audio;
  char err[160];
  VFrame q[QN];
  int qh, qn;
  int afd;
  pid_t apid;
  volatile int audio_ok;
  volatile double a_end;
  volatile float volume;
  volatile int muted;
  double wall_base, wall_at;
  int wall_run;
  char path[1024];
} Player;

typedef struct {
  int mode;
  Item items[MAXLIB];
  int nitems, scroll;
  pthread_t thumb_th;
  int thumb_started;
  volatile int thumb_stop;
  Player *pl;
  VFrame cur;
  int has_cur, shown, need_frame, ended, done_seen, was_shown;
  char title[128];
  uint32_t last_move, last_frame_at;
  float last_hs, last_ht;
  float volume;
  int muted;
} VState;

static VState *live;
static int frames_shown;

int video_frames_shown(void) { return frames_shown; }

static double mono_s(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return t.tv_sec + t.tv_nsec / 1e9;
}

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static int hot_of(Panel *p) { return (W.hover == (int)(p - P) && p->zone >= 100) ? p->zone - 100 : 0; }

static void fmt_time(double t, char *o, size_t n) {
  if (t < 0 || t != t) t = 0;
  int s = (int)t, h = s / 3600, m = s / 60 % 60;
  if (h) snprintf(o, n, "%d:%02d:%02d", h, m, s % 60);
  else snprintf(o, n, "%d:%02d", m, s % 60);
}

static void fit_rect(int fw, int fh, float bw, float bh, float *x, float *y, float *w, float *h) {
  float a = fw > 0 && fh > 0 ? (float)fw / fh : 16.f / 9.f;
  *w = bw, *h = bw / a;
  if (*h > bh) *h = bh, *w = bh * a;
  *x = (bw - *w) * 0.5f, *y = (bh - *h) * 0.5f;
}

static void drop_privs(void) {
  const char *user = getenv("OREONVR_USER");
  struct passwd *pw = NULL;
  if (getuid() == 0 && user && *user && (pw = getpwnam(user))) {
    if (initgroups(pw->pw_name, pw->pw_gid) || setgid(pw->pw_gid) || setuid(pw->pw_uid)) _exit(126);
    char rt[64];
    snprintf(rt, sizeof rt, "/run/user/%u", (unsigned)pw->pw_uid);
    setenv("XDG_RUNTIME_DIR", rt, 1);
    setenv("HOME", pw->pw_dir, 1);
    unsetenv("PULSE_SERVER");
  }
}

static int audio_open(Player *pl) {
  if (getenv("OREONVR_NO_AUDIO")) return 0;
  int fds[2];
  if (pipe(fds)) return 0;
  pid_t pid = fork();
  if (pid < 0) {
    close(fds[0]), close(fds[1]);
    return 0;
  }
  if (pid == 0) {
    dup2(fds[0], 0);
    int nul = open("/dev/null", O_WRONLY);
    if (nul >= 0) dup2(nul, 1), dup2(nul, 2);
    for (int fd = 3; fd < 256; fd++) close(fd);
    signal(SIGPIPE, SIG_DFL);
    drop_privs();
    execlp("pw-cat", "pw-cat", "--playback", "--rate", "48000", "--channels", "2", "--format", "s16", "--latency", "40ms", "-", (char *)NULL);
    execlp("paplay", "paplay", "--raw", "--rate=48000", "--channels=2", "--format=s16le", "--latency-msec=40", (char *)NULL);
    execlp("aplay", "aplay", "-q", "-t", "raw", "-f", "S16_LE", "-r", "48000", "-c", "2", (char *)NULL);
    _exit(127);
  }
  close(fds[0]);
  fcntl(fds[1], F_SETFD, FD_CLOEXEC);
  fcntl(fds[1], F_SETPIPE_SZ, 16384);
  pl->afd = fds[1], pl->apid = pid;
  return 1;
}

static void audio_close(Player *pl) {
  if (pl->afd >= 0) close(pl->afd);
  pl->afd = -1;
  if (pl->apid > 0) {
    kill(pl->apid, SIGTERM);
    waitpid(pl->apid, NULL, 0);
  }
  pl->apid = 0;
}

static double player_clock(Player *pl) {
  if (pl->audio_ok && pl->afd >= 0) {
    int fill = 0;
    if (ioctl(pl->afd, FIONREAD, &fill)) fill = 0;
    double t = pl->a_end - fill / (double)(A_RATE * 4) - A_LAT;
    return t;
  }
  return pl->wall_run ? pl->wall_base + (mono_s() - pl->wall_at) : pl->wall_base;
}

static void wall_set(Player *pl, double t, int run) {
  pl->wall_base = t, pl->wall_at = mono_s(), pl->wall_run = run;
}

#ifdef HAVE_AV

static void scaled_size(int w, int h, int *ow, int *oh) {
  double k = 1.0;
  if (w > MAXW) k = (double)MAXW / w;
  if (h * k > MAXH) k = (double)MAXH / h;
  *ow = ((int)(w * k)) & ~1, *oh = ((int)(h * k)) & ~1;
  if (*ow < 2) *ow = 2;
  if (*oh < 2) *oh = 2;
}

static void push_frame(Player *pl, S3D *s3d, const uint32_t *px, int w, int h, double pts) {
  for (;;) {
    pthread_mutex_lock(&pl->mu);
    int full = pl->qn >= QN;
    pthread_mutex_unlock(&pl->mu);
    if (!full || pl->stop || pl->seek_req) break;
    usleep(3000);
  }
  if (pl->stop || pl->seek_req) return;
  pthread_mutex_lock(&pl->mu);
  VFrame *f = &pl->q[(pl->qh + pl->qn) % QN];
  pthread_mutex_unlock(&pl->mu);
  size_t n = (size_t)w * h;
  if (!f->px || f->w * f->h < (int)n) {
    free(f->px), free(f->l), free(f->r);
    f->px = malloc(n * 4), f->l = malloc(n * 4), f->r = malloc(n * 4);
  }
  f->w = w, f->h = h, f->pts = pts, f->gen = pl->work_gen;
  if (pl->wall_sync && !pl->audio_ok) {
    wall_set(pl, pts, !pl->paused);
    pl->wall_sync = 0;
  }
  memcpy(f->px, px, n * 4);
  f->stereo = 0;
  if (W.vr && f->l && f->r) {
    s3d_depth(s3d, px, w, h);
    s3d_views(s3d, px, w, h, f->l, f->r, 1.f);
    f->stereo = 1;
  }
  pthread_mutex_lock(&pl->mu);
  pl->qn++;
  pthread_mutex_unlock(&pl->mu);
}

static void clear_queue(Player *pl) {
  pthread_mutex_lock(&pl->mu);
  pl->qh = pl->qn = 0;
  pthread_mutex_unlock(&pl->mu);
}

static void write_audio(Player *pl, const int16_t *s, int frames, double pts) {
  static int16_t buf[16384];
  if (!pl->audio_ok || pl->afd < 0) return;
  float v = pl->muted ? 0.f : pl->volume;
  while (frames > 0) {
    int n = frames > 8192 ? 8192 : frames;
    for (int i = 0; i < n * 2; i++) {
      int x = (int)(s[i] * v);
      buf[i] = (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x);
    }
    const char *b = (const char *)buf;
    size_t left = (size_t)n * 4;
    while (left) {
      ssize_t w = write(pl->afd, b, left);
      if (w < 0 && errno == EINTR) continue;
      if (w <= 0) {
        double t = player_clock(pl);
        pl->audio_ok = 0;
        wall_set(pl, t, !pl->paused);
        return;
      }
      b += w, left -= (size_t)w;
    }
    pl->a_end = pts + (double)n / A_RATE;
    pts += (double)n / A_RATE;
    s += n * 2, frames -= n;
  }
}

static void *player_run(void *arg) {
  Player *pl = arg;
  AVFormatContext *fmt = NULL;
  AVCodecContext *vc = NULL, *ac = NULL;
  struct SwsContext *sws = NULL;
  SwrContext *swr = NULL;
  AVPacket *pkt = av_packet_alloc();
  AVFrame *fr = av_frame_alloc();
  S3D *s3d = s3d_new();
  uint32_t *rgb = NULL;
  int16_t *pcm = NULL;
  int pcm_cap = 0, vs = -1, as = -1, ow = 0, oh = 0, sw_w = 0, sw_h = 0, sw_f = -1;
  double skip_until = -1;
  if (avformat_open_input(&fmt, pl->path, NULL, NULL) < 0 || avformat_find_stream_info(fmt, NULL) < 0) {
    snprintf(pl->err, sizeof pl->err, "This file could not be opened.");
    goto done;
  }
  const AVCodec *vcod = NULL, *acod = NULL;
  vs = av_find_best_stream(fmt, AVMEDIA_TYPE_VIDEO, -1, -1, &vcod, 0);
  as = av_find_best_stream(fmt, AVMEDIA_TYPE_AUDIO, -1, vs, &acod, 0);
  if (vs < 0 || !vcod) {
    snprintf(pl->err, sizeof pl->err, vs == AVERROR_DECODER_NOT_FOUND ? "This video uses a format the player cannot decode." : "This file has no video.");
    goto done;
  }
  vc = avcodec_alloc_context3(vcod);
  avcodec_parameters_to_context(vc, fmt->streams[vs]->codecpar);
  vc->thread_count = 0;
  if (avcodec_open2(vc, vcod, NULL) < 0) {
    snprintf(pl->err, sizeof pl->err, "This video uses a format the player cannot decode.");
    goto done;
  }
  if (as >= 0 && acod) {
    ac = avcodec_alloc_context3(acod);
    avcodec_parameters_to_context(ac, fmt->streams[as]->codecpar);
    if (avcodec_open2(ac, acod, NULL) < 0) avcodec_free_context(&ac), as = -1;
  } else as = -1;
  pl->has_audio = as >= 0;
  pl->duration = fmt->duration > 0 ? fmt->duration / (double)AV_TIME_BASE : 0;
  scaled_size(vc->width, vc->height, &ow, &oh);
  pl->vw = ow, pl->vh = oh;
  rgb = malloc((size_t)ow * oh * 4);
  if (as >= 0) {
    AVChannelLayout stereo = AV_CHANNEL_LAYOUT_STEREO;
    if (swr_alloc_set_opts2(&swr, &stereo, AV_SAMPLE_FMT_S16, A_RATE, &ac->ch_layout, ac->sample_fmt, ac->sample_rate, 0, NULL) < 0 || swr_init(swr) < 0) {
      swr_free(&swr);
      as = -1, pl->has_audio = 0;
    }
  }
  pl->audio_ok = pl->has_audio && audio_open(pl);
  pl->a_end = 0;
  wall_set(pl, 0, !pl->paused);
  pl->wall_sync = 1;
  pl->ready = 1;
  double vtb = av_q2d(fmt->streams[vs]->time_base), atb = as >= 0 ? av_q2d(fmt->streams[as]->time_base) : 0;
  while (!pl->stop) {
    if (pl->seek_req) {
      double t = pl->seek_to;
      if (pl->duration > 0 && t > pl->duration - 0.5) t = pl->duration - 0.5;
      if (t < 0) t = 0;
      pl->work_gen = pl->gen;
      pl->seek_req = 0;
      avformat_seek_file(fmt, -1, INT64_MIN, (int64_t)(t * AV_TIME_BASE), (int64_t)(t * AV_TIME_BASE), 0);
      avcodec_flush_buffers(vc);
      if (ac) avcodec_flush_buffers(ac);
      clear_queue(pl);
      if (pl->audio_ok) {
        audio_close(pl);
        pl->audio_ok = audio_open(pl);
      }
      pl->a_end = t;
      wall_set(pl, t, !pl->paused);
      pl->wall_sync = 1;
      skip_until = t;
      s3d_reset(s3d);
      pl->eof = 0;
    }
    if (pl->paused) {
      pthread_mutex_lock(&pl->mu);
      int have = pl->qn > 0;
      pthread_mutex_unlock(&pl->mu);
      if (have || pl->eof) {
        usleep(10000);
        continue;
      }
    }
    if (pl->eof) {
      if (pl->audio_ok && pl->afd >= 0) {
        int fill = 0;
        if (ioctl(pl->afd, FIONREAD, &fill)) fill = 0;
        if (!fill) {
          double t = player_clock(pl);
          pl->audio_ok = 0;
          wall_set(pl, t, !pl->paused);
        }
      }
      usleep(20000);
      continue;
    }
    int r = av_read_frame(fmt, pkt);
    if (r < 0) {
      avcodec_send_packet(vc, NULL);
      while (avcodec_receive_frame(vc, fr) >= 0) {
      }
      pl->eof = 1;
      continue;
    }
    if (pkt->stream_index == vs && avcodec_send_packet(vc, pkt) >= 0) {
      while (!pl->stop && !pl->seek_req && avcodec_receive_frame(vc, fr) >= 0) {
        int64_t ts = fr->best_effort_timestamp != AV_NOPTS_VALUE ? fr->best_effort_timestamp : fr->pts;
        double pts = ts != AV_NOPTS_VALUE ? ts * vtb : 0;
        if (fmt->start_time != AV_NOPTS_VALUE) pts -= fmt->start_time / (double)AV_TIME_BASE;
        if (skip_until >= 0 && pts < skip_until - 0.02) continue;
        if (!sws || sw_w != fr->width || sw_h != fr->height || sw_f != fr->format) {
          sws_freeContext(sws);
          sws = sws_getContext(fr->width, fr->height, fr->format, ow, oh, AV_PIX_FMT_BGRA, SWS_BILINEAR, NULL, NULL, NULL);
          sw_w = fr->width, sw_h = fr->height, sw_f = fr->format;
        }
        if (!sws) continue;
        uint8_t *dst[4] = {(uint8_t *)rgb};
        int ls[4] = {ow * 4};
        sws_scale(sws, (const uint8_t *const *)fr->data, fr->linesize, 0, fr->height, dst, ls);
        for (int i = 0; i < ow * oh; i++) rgb[i] |= 0xff000000u;
        push_frame(pl, s3d, rgb, ow, oh, pts);
      }
      if (skip_until >= 0 && !pl->seek_req) {
        pthread_mutex_lock(&pl->mu);
        int got = pl->qn > 0;
        pthread_mutex_unlock(&pl->mu);
        if (got) skip_until = -1;
      }
    } else if (pkt->stream_index == as && ac && avcodec_send_packet(ac, pkt) >= 0) {
      while (!pl->stop && !pl->seek_req && avcodec_receive_frame(ac, fr) >= 0) {
        int64_t ts = fr->best_effort_timestamp != AV_NOPTS_VALUE ? fr->best_effort_timestamp : fr->pts;
        double pts = ts != AV_NOPTS_VALUE ? ts * atb : pl->a_end;
        if (fmt->start_time != AV_NOPTS_VALUE) pts -= fmt->start_time / (double)AV_TIME_BASE;
        int out = swr_get_out_samples(swr, fr->nb_samples);
        if (out > pcm_cap) {
          free(pcm);
          pcm_cap = out + 1024;
          pcm = malloc((size_t)pcm_cap * 4);
        }
        uint8_t *o[1] = {(uint8_t *)pcm};
        int n = swr_convert(swr, o, out, (const uint8_t **)fr->extended_data, fr->nb_samples);
        if (n <= 0) continue;
        if (skip_until >= 0 && pts + (double)n / A_RATE < skip_until) continue;
        write_audio(pl, pcm, n, pts);
      }
    }
    av_packet_unref(pkt);
  }
done:
  pl->ready = 1;
  audio_close(pl);
  av_packet_free(&pkt);
  av_frame_free(&fr);
  sws_freeContext(sws);
  swr_free(&swr);
  avcodec_free_context(&vc);
  avcodec_free_context(&ac);
  avformat_close_input(&fmt);
  s3d_free(s3d);
  free(rgb);
  free(pcm);
  return NULL;
}

static int probe_thumb(Item *it) {
  AVFormatContext *fmt = NULL;
  int ok = 0;
  if (avformat_open_input(&fmt, it->path, NULL, NULL) < 0) return 0;
  if (avformat_find_stream_info(fmt, NULL) < 0) goto out;
  it->dur = fmt->duration > 0 ? fmt->duration / (double)AV_TIME_BASE : 0;
  const AVCodec *cod = NULL;
  int vs = av_find_best_stream(fmt, AVMEDIA_TYPE_VIDEO, -1, -1, &cod, 0);
  if (vs < 0 || !cod) goto out;
  AVCodecContext *c = avcodec_alloc_context3(cod);
  avcodec_parameters_to_context(c, fmt->streams[vs]->codecpar);
  if (avcodec_open2(c, cod, NULL) < 0) {
    avcodec_free_context(&c);
    goto out;
  }
  double at = it->dur > 4 ? fmin(it->dur * 0.1, 30.0) : 0;
  if (at > 0) avformat_seek_file(fmt, -1, INT64_MIN, (int64_t)(at * AV_TIME_BASE), (int64_t)(at * AV_TIME_BASE), 0);
  AVPacket *pkt = av_packet_alloc();
  AVFrame *fr = av_frame_alloc();
  for (int tries = 0; tries < 400 && !ok && av_read_frame(fmt, pkt) >= 0; tries++) {
    if (pkt->stream_index == vs && avcodec_send_packet(c, pkt) >= 0 && avcodec_receive_frame(c, fr) >= 0) {
      float a = (float)fr->width / (fr->height ? fr->height : 1);
      int tw = TW, th = (int)(TW / a);
      if (th > TH) th = TH, tw = (int)(TH * a);
      tw &= ~1, th &= ~1;
      struct SwsContext *s = sws_getContext(fr->width, fr->height, fr->format, tw, th, AV_PIX_FMT_BGRA, SWS_BILINEAR, NULL, NULL, NULL);
      if (s) {
        uint32_t *px = malloc((size_t)tw * th * 4);
        uint8_t *dst[4] = {(uint8_t *)px};
        int ls[4] = {tw * 4};
        sws_scale(s, (const uint8_t *const *)fr->data, fr->linesize, 0, fr->height, dst, ls);
        for (int i = 0; i < tw * th; i++) px[i] |= 0xff000000u;
        sws_freeContext(s);
        it->tw = tw, it->th = th;
        it->thumb = px;
        ok = 1;
      }
    }
    av_packet_unref(pkt);
  }
  av_packet_free(&pkt);
  av_frame_free(&fr);
  avcodec_free_context(&c);
out:
  avformat_close_input(&fmt);
  return ok;
}

#endif

static void *thumb_run(void *arg) {
  VState *st = arg;
  for (int i = 0; i < st->nitems && !st->thumb_stop; i++) {
#ifdef HAVE_AV
    probe_thumb(&st->items[i]);
#endif
    st->items[i].done = 1;
  }
  return NULL;
}

static Player *player_start(const char *path, float vol, int muted) {
#ifdef HAVE_AV
  Player *pl = calloc(1, sizeof *pl);
  pthread_mutex_init(&pl->mu, NULL);
  snprintf(pl->path, sizeof pl->path, "%s", path);
  pl->afd = -1;
  pl->volume = vol, pl->muted = muted;
  av_log_set_level(AV_LOG_QUIET);
  pl->started = pthread_create(&pl->th, NULL, player_run, pl) == 0;
  if (!pl->started) snprintf(pl->err, sizeof pl->err, "Could not start playback."), pl->ready = 1;
  return pl;
#else
  (void)path, (void)vol, (void)muted;
  return NULL;
#endif
}

static void player_stop(Player *pl) {
  if (!pl) return;
  pl->stop = 1;
  if (pl->afd >= 0 && pl->apid > 0) kill(pl->apid, SIGTERM);
  if (pl->started) pthread_join(pl->th, NULL);
  for (int i = 0; i < QN; i++) free(pl->q[i].px), free(pl->q[i].l), free(pl->q[i].r);
  pthread_mutex_destroy(&pl->mu);
  free(pl);
}

static int item_cmp(const void *a, const void *b) {
  const Item *x = a, *y = b;
  return x->mtime < y->mtime ? 1 : x->mtime > y->mtime ? -1 : strcasecmp(x->name, y->name);
}

static void scan_dir(VState *st, const char *dir, int depth) {
  DIR *d = opendir(dir);
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d)) && st->nitems < MAXLIB) {
    if (e->d_name[0] == '.') continue;
    char p[1024];
    snprintf(p, sizeof p, "%s/%s", dir, e->d_name);
    struct stat sb;
    if (stat(p, &sb)) continue;
    if (S_ISDIR(sb.st_mode)) {
      if (depth > 0) scan_dir(st, p, depth - 1);
      continue;
    }
    if (!S_ISREG(sb.st_mode) || !video_is_file(e->d_name)) continue;
    int dup = 0;
    for (int i = 0; i < st->nitems && !dup; i++) dup = !strcmp(st->items[i].path, p);
    if (dup) continue;
    Item *it = &st->items[st->nitems++];
    memset(it, 0, sizeof *it);
    snprintf(it->path, sizeof it->path, "%s", p);
    snprintf(it->name, sizeof it->name, "%.127s", e->d_name);
    char *dot = strrchr(it->name, '.');
    if (dot && dot != it->name) *dot = 0;
    it->mtime = sb.st_mtime;
  }
  closedir(d);
}

static void lib_free(VState *st) {
  st->thumb_stop = 1;
  if (st->thumb_started) pthread_join(st->thumb_th, NULL);
  st->thumb_started = 0;
  for (int i = 0; i < st->nitems; i++) free(st->items[i].thumb);
  st->nitems = 0;
}

static void lib_load(VState *st) {
  lib_free(st);
  const char *h = user_home();
  static const char *const sub[] = {"Videos", "Movies", "Downloads", "Desktop", NULL};
  char p[700];
  for (int i = 0; sub[i]; i++) {
    snprintf(p, sizeof p, "%s/%s", h, sub[i]);
    scan_dir(st, p, i == 0 ? 2 : 1);
  }
  scan_dir(st, h, 0);
  qsort(st->items, (size_t)st->nitems, sizeof *st->items, item_cmp);
  st->scroll = 0;
  st->thumb_stop = 0;
  st->thumb_started = st->nitems && pthread_create(&st->thumb_th, NULL, thumb_run, st) == 0;
}

static void play_path(Panel *p, VState *st, const char *path) {
  player_stop(st->pl);
  st->pl = NULL;
  st->has_cur = 0;
  free(st->cur.px), free(st->cur.l), free(st->cur.r);
  memset(&st->cur, 0, sizeof st->cur);
  const char *b = strrchr(path, '/');
  snprintf(st->title, sizeof st->title, "%s", b ? b + 1 : path);
  char *dot = strrchr(st->title, '.');
  if (dot && dot != st->title) *dot = 0;
  snprintf(p->title, sizeof p->title, "%.63s", st->title);
  st->mode = 1;
  st->pl = player_start(path, st->volume, st->muted);
  st->last_move = now_ms();
  p->dirty = 1;
}

static void to_library(Panel *p, VState *st) {
  player_stop(st->pl);
  st->pl = NULL;
  st->has_cur = 0;
  st->mode = 0;
  p->stereo = 0;
  snprintf(p->title, sizeof p->title, "Videos");
  lib_load(st);
  p->dirty = 1;
}

static void v_open(Panel *p) {
  VState *st = calloc(1, sizeof *st);
  p->state = st;
  st->volume = 1.f;
  live = st;
  lib_load(st);
}

static void v_close(Panel *p) {
  VState *st = p->state;
  if (!st) return;
  player_stop(st->pl);
  st->pl = NULL;
  lib_free(st);
  free(st->cur.px), free(st->cur.l), free(st->cur.r);
  if (live == st) live = NULL;
}

static int controls_shown(Panel *p, VState *st) {
  Player *pl = st->pl;
  if (!pl || pl->paused || st->ended || pl->err[0] || !st->has_cur) return 1;
  return now_ms() - st->last_move < 2600 || hot_of(p) >= Z_PLAY;
}

static float seek_x0(void) { return 24.f; }
static float seek_w(void) { return VW - 48.f; }

static void draw_icon_play(Surface *s, float cx, float cy, float r, int playing, uint32_t c) {
  if (playing) {
    gfx_rrect(s, cx - r * 0.55f, cy - r * 0.7f, r * 0.4f, r * 1.4f, r * 0.12f, c);
    gfx_rrect(s, cx + r * 0.15f, cy - r * 0.7f, r * 0.4f, r * 1.4f, r * 0.12f, c);
  } else
    gfx_tri(s, cx - r * 0.45f, cy - r * 0.75f, cx - r * 0.45f, cy + r * 0.75f, cx + r * 0.8f, cy, c);
}

static void draw_skip(Surface *s, float cx, float cy, int fwd, uint32_t c) {
  float d = fwd ? 1.f : -1.f;
  gfx_ring(s, cx, cy, 11, 2.f, c);
  gfx_tri(s, cx + d * 2, cy - 15, cx + d * 2, cy - 7, cx + d * 8, cy - 11, c);
  gfx_text_c(s, F_SMALL, cx, cy - line_h(F_SMALL) * 0.5f, "10", c);
}

static void draw_speaker(Surface *s, float cx, float cy, int muted, float vol, uint32_t c) {
  gfx_rect(s, cx - 10, cy - 4, 5, 8, c);
  gfx_tri(s, cx - 6, cy - 4, cx + 1, cy - 10, cx + 1, cy + 10, c);
  gfx_tri(s, cx - 6, cy - 4, cx + 1, cy + 10, cx - 6, cy + 4, c);
  if (muted) {
    gfx_line(s, cx + 5, cy - 5, cx + 13, cy + 5, 2.f, c);
    gfx_line(s, cx + 13, cy - 5, cx + 5, cy + 5, 2.f, c);
  } else {
    if (vol > 0.01f) gfx_line(s, cx + 5, cy - 4, cx + 5, cy + 4, 2.f, c);
    if (vol > 0.5f) gfx_line(s, cx + 9, cy - 7, cx + 9, cy + 7, 2.f, c);
  }
}

typedef struct {
  float play_x, b10_x, f10_x, mute_x, vol_x, vol_w, row_y, seek_y;
} Layout;

static Layout layout(void) {
  Layout L;
  float H = VH - BAR_H;
  L.seek_y = H - 70;
  L.row_y = H - 32;
  L.play_x = 46, L.b10_x = 98, L.f10_x = 144, L.mute_x = 196, L.vol_x = 218, L.vol_w = 96;
  return L;
}

static int v_zone(Panel *p, float x, float y) {
  VState *st = p->state;
  float H = VH - BAR_H;
  if (!st->mode) {
    if (!st->nitems) return x > VW / 2.f - 80 && x < VW / 2.f + 80 && y > H / 2 + 50 && y < H / 2 + 90 ? Z_OPENFILES : 0;
    float cw = (VW - 24 * 2 - 20 * 2) / 3.f, ch = cw * 9 / 16 + 54;
    for (int i = 0; i < st->nitems; i++) {
      float cx = 24 + (i % 3) * (cw + 20), cy = 64 + (i / 3) * (ch + 18) - st->scroll;
      if (x >= cx && x < cx + cw && y >= cy && y < cy + ch && y > 50) return Z_CARD + i;
    }
    return 0;
  }
  Player *pl = st->pl;
  if (y < 52 && x < 150) return Z_LIB;
  if (!controls_shown(p, st)) return Z_VIDEO;
  Layout L = layout();
  if (pl && st->ended && fabsf(x - VW / 2.f) < 46 && fabsf(y - H / 2) < 46) return Z_REPLAY;
  if (y >= L.seek_y - 12 && y < L.seek_y + 14 && x >= seek_x0() - 6 && x < seek_x0() + seek_w() + 6) return Z_SEEK;
  if (fabsf(y - L.row_y) < 20) {
    if (fabsf(x - L.play_x) < 20) return Z_PLAY;
    if (fabsf(x - L.b10_x) < 18) return Z_BACK10;
    if (fabsf(x - L.f10_x) < 18) return Z_FWD10;
    if (fabsf(x - L.mute_x) < 16) return Z_MUTE;
    if (x >= L.vol_x - 4 && x < L.vol_x + L.vol_w + 6) return Z_VOL;
  }
  return Z_VIDEO;
}

static void draw_library(Panel *p, VState *st, Surface *s, float ox, float oy) {
  int hot = hot_of(p);
  float H = VH - BAR_H;
  uint32_t bg = THEME(RGB(246, 247, 250), RGB(24, 26, 30)), fg = THEME(RGB(28, 32, 38), RGB(236, 239, 244)), dim = THEME(RGB(110, 118, 130), RGB(150, 158, 170));
  gfx_rect(s, ox, oy, VW, H, bg);
#ifndef HAVE_AV
  gfx_text_c(s, F_H1, ox + VW / 2.f, oy + H / 2 - 40, "Video playback is not available", fg);
  gfx_text_c(s, F_UI, ox + VW / 2.f, oy + H / 2 + 6, "This build of Oreon VR was made without FFmpeg.", dim);
  return;
#endif
  if (!st->nitems) {
    gfx_icon(s, IC_VIDEO, ox + VW / 2.f - 32, oy + H / 2 - 120, 64);
    gfx_text_c(s, F_H1, ox + VW / 2.f, oy + H / 2 - 36, "No videos yet", fg);
    gfx_text_c(s, F_UI, ox + VW / 2.f, oy + H / 2 + 6, "Videos in your Videos, Downloads or Desktop folder show up here.", dim);
    gfx_rrect(s, ox + VW / 2.f - 80, oy + H / 2 + 50, 160, 40, 20, hot == Z_OPENFILES ? RGB(40, 96, 236) : C_ACCENT);
    gfx_text_c(s, F_UI_MED, ox + VW / 2.f, oy + H / 2 + 70 - line_h(F_UI_MED) * 0.5f, "Open Files", RGB(255, 255, 255));
    return;
  }
  float cw = (VW - 24 * 2 - 20 * 2) / 3.f, th = cw * 9 / 16, ch = th + 54;
  gfx_clip(s, ox, oy + 50, VW, H - 50);
  for (int i = 0; i < st->nitems; i++) {
    Item *it = &st->items[i];
    float cx = ox + 24 + (i % 3) * (cw + 20), cy = oy + 64 + (i / 3) * (ch + 18) - st->scroll;
    if (cy > oy + H || cy + ch < oy + 50) continue;
    int h = hot == Z_CARD + i;
    if (h) gfx_rrect(s, cx - 6, cy - 6, cw + 12, ch + 8, 16, THEME(RGB(232, 236, 244), RGB(38, 42, 50)));
    gfx_rrect(s, cx, cy, cw, th, 12, RGB(14, 16, 20));
    if (it->thumb) {
      float x, y, w, hh;
      fit_rect(it->tw, it->th, cw, th, &x, &y, &w, &hh);
      gfx_blit_bilinear(s, it->thumb, it->tw, it->th, cx + x, cy + y, w, hh, 0);
    } else
      gfx_icon(s, IC_VIDEO, cx + cw / 2 - 18, cy + th / 2 - 18, 36);
    if (h) {
      gfx_disc(s, cx + cw / 2, cy + th / 2, 26, RGBA(0, 0, 0, 150));
      draw_icon_play(s, cx + cw / 2 + 3, cy + th / 2, 13, 0, RGB(255, 255, 255));
    }
    if (it->dur > 0) {
      char t[24];
      fmt_time(it->dur, t, sizeof t);
      float tw = gfx_text_w(F_SMALL, t) + 14;
      gfx_rrect(s, cx + cw - tw - 8, cy + th - 30, tw, 22, 6, RGBA(0, 0, 0, 170));
      gfx_text(s, F_SMALL, cx + cw - tw - 1, cy + th - 30 + (22 - line_h(F_SMALL)) * 0.5f, t, RGB(255, 255, 255));
    }
    gfx_text_fit(s, F_UI_MED, cx + 4, cy + th + 12, cw - 8, it->name, fg);
    const char *d = strrchr(it->path, '/');
    char folder[96] = "";
    if (d) {
      const char *b = d;
      while (b > it->path && b[-1] != '/') b--;
      snprintf(folder, sizeof folder, "%.*s", (int)(d - b), b);
    }
    gfx_text_fit(s, F_SMALL, cx + 4, cy + th + 34, cw - 8, folder, dim);
  }
  gfx_noclip(s);
  gfx_rect(s, ox, oy, VW, 50, bg);
  gfx_text(s, F_H1, ox + 24, oy + 12, "Videos", fg);
  char n[48];
  snprintf(n, sizeof n, "%d video%s", st->nitems, st->nitems == 1 ? "" : "s");
  gfx_text(s, F_SMALL, ox + 24 + gfx_text_w(F_H1, "Videos") + 12, oy + 22, n, dim);
}

static void draw_frame(Panel *p, VState *st, Surface *s, float ox, float oy, int eye) {
  (void)p;
  float H = VH - BAR_H;
  gfx_rect(s, ox, oy, VW, H, RGB(0, 0, 0));
  if (!st->has_cur) return;
  VFrame *f = &st->cur;
  const uint32_t *px = f->stereo && eye >= 0 ? (eye ? f->r : f->l) : f->px;
  float x, y, w, h;
  fit_rect(f->w, f->h, VW, H, &x, &y, &w, &h);
  gfx_blit_bilinear(s, px, f->w, f->h, ox + x, oy + y, w, h, 0);
}

static void draw_controls(Panel *p, VState *st, Surface *s, float ox, float oy) {
  Player *pl = st->pl;
  int hot = hot_of(p);
  float H = VH - BAR_H;
  Layout L = layout();
  if (!pl) {
    gfx_text_c(s, F_UI, ox + VW / 2.f, oy + H / 2, "Video playback is not available in this build.", RGB(220, 224, 230));
    return;
  }
  if (pl->err[0]) {
    gfx_text_c(s, F_H1, ox + VW / 2.f, oy + H / 2 - 30, "Can't play this video", RGB(240, 242, 246));
    gfx_text_c(s, F_UI, ox + VW / 2.f, oy + H / 2 + 12, pl->err, RGB(170, 176, 186));
  } else if (!st->has_cur) {
    gfx_text_c(s, F_UI, ox + VW / 2.f, oy + H / 2 - 8, "Loading...", RGB(200, 204, 212));
  }
  if (!controls_shown(p, st)) return;
  for (int i = 0; i < 70; i++) gfx_rect(s, ox, oy + i, VW, 1, RGBA(0, 0, 0, (int)(150 * (1 - i / 70.f))));
  for (int i = 0; i < CTRL_H + 30; i++) gfx_rect(s, ox, oy + H - i - 1, VW, 1, RGBA(0, 0, 0, (int)(190 * (1 - i / (float)(CTRL_H + 30)))));
  uint32_t wht = RGB(255, 255, 255), soft = RGBA(255, 255, 255, 200);
  if (hot == Z_LIB) gfx_rrect(s, ox + 12, oy + 10, 120, 32, 16, RGBA(255, 255, 255, 46));
  gfx_line(s, ox + 30, oy + 20, ox + 24, oy + 26, 2.f, wht);
  gfx_line(s, ox + 24, oy + 26, ox + 30, oy + 32, 2.f, wht);
  gfx_text(s, F_UI_MED, ox + 40, oy + 26 - line_h(F_UI_MED) * 0.5f, "Library", wht);
  gfx_text_fit(s, F_UI_MED, ox + 160, oy + 26 - line_h(F_UI_MED) * 0.5f, VW - 320, st->title, soft);
  if (st->has_cur && st->cur.stereo) {
    float bw = gfx_text_w(F_SMALL, "3D") + 16;
    gfx_rrect(s, ox + VW - 24 - bw, oy + 14, bw, 24, 12, RGBA(47, 107, 255, 220));
    gfx_text_c(s, F_SMALL, ox + VW - 24 - bw / 2, oy + 26 - line_h(F_SMALL) * 0.5f, "3D", wht);
  }
  double pos = st->has_cur ? st->cur.pts : 0, dur = pl->duration;
  if (st->ended && dur > 0) pos = dur;
  float frac = dur > 0 ? (float)fmin(1.0, fmax(0.0, pos / dur)) : 0.f;
  float sx = ox + seek_x0(), sw = seek_w(), sy = oy + L.seek_y;
  int sh = hot == Z_SEEK;
  gfx_rrect(s, sx, sy - (sh ? 3 : 2), sw, sh ? 6 : 4, 3, RGBA(255, 255, 255, 70));
  gfx_rrect(s, sx, sy - (sh ? 3 : 2), sw * frac, sh ? 6 : 4, 3, C_ACCENT);
  gfx_disc(s, sx + sw * frac, sy, sh ? 8 : 6, wht);
  if (sh && dur > 0) {
    float hx = W.hs - MARGIN;
    double t = fmax(0, fmin(1, (hx - seek_x0()) / sw)) * dur;
    char b[24];
    fmt_time(t, b, sizeof b);
    float bw = gfx_text_w(F_SMALL, b) + 14, bx = ox + fmaxf(seek_x0(), fminf(hx - bw / 2, VW - 24 - bw));
    gfx_rrect(s, bx, sy - 38, bw, 24, 8, RGBA(20, 22, 26, 230));
    gfx_text_c(s, F_SMALL, bx + bw / 2, sy - 26 - line_h(F_SMALL) * 0.5f, b, wht);
  }
  float ry = oy + L.row_y;
  if (hot == Z_PLAY) gfx_disc(s, ox + L.play_x, ry, 20, RGBA(255, 255, 255, 46));
  draw_icon_play(s, ox + L.play_x, ry, 12, !pl->paused && !st->ended, wht);
  if (hot == Z_BACK10) gfx_disc(s, ox + L.b10_x, ry, 18, RGBA(255, 255, 255, 46));
  draw_skip(s, ox + L.b10_x, ry, 0, wht);
  if (hot == Z_FWD10) gfx_disc(s, ox + L.f10_x, ry, 18, RGBA(255, 255, 255, 46));
  draw_skip(s, ox + L.f10_x, ry, 1, wht);
  if (hot == Z_MUTE) gfx_disc(s, ox + L.mute_x + 2, ry, 16, RGBA(255, 255, 255, 46));
  draw_speaker(s, ox + L.mute_x, ry, st->muted, st->volume, wht);
  float vol = st->muted ? 0 : st->volume;
  gfx_rrect(s, ox + L.vol_x, ry - 2, L.vol_w, 4, 2, RGBA(255, 255, 255, 70));
  gfx_rrect(s, ox + L.vol_x, ry - 2, L.vol_w * vol, 4, 2, wht);
  gfx_disc(s, ox + L.vol_x + L.vol_w * vol, ry, hot == Z_VOL ? 7 : 5, wht);
  char t1[24], t2[24], tt[64];
  fmt_time(pos, t1, sizeof t1);
  fmt_time(dur, t2, sizeof t2);
  snprintf(tt, sizeof tt, "%s / %s", t1, t2);
  gfx_text(s, F_UI, ox + L.vol_x + L.vol_w + 22, ry - line_h(F_UI) * 0.5f, tt, soft);
  if (st->ended) {
    gfx_disc(s, ox + VW / 2.f, oy + H / 2, 40, hot == Z_REPLAY ? RGBA(47, 107, 255, 240) : RGBA(0, 0, 0, 170));
    gfx_ring(s, ox + VW / 2.f, oy + H / 2, 13, 2.6f, wht);
    gfx_tri(s, ox + VW / 2.f + 6, oy + H / 2 - 19, ox + VW / 2.f + 6, oy + H / 2 - 7, ox + VW / 2.f + 15, oy + H / 2 - 13, wht);
  } else if (pl->paused && st->has_cur) {
    gfx_disc(s, ox + VW / 2.f, oy + H / 2, 38, RGBA(0, 0, 0, 140));
    draw_icon_play(s, ox + VW / 2.f + 4, oy + H / 2, 18, 0, wht);
  }
}

static void v_draw(Panel *p, Surface *s, float ox, float oy) {
  VState *st = p->state;
  if (!st->mode) {
    p->stereo = 0;
    draw_library(p, st, s, ox, oy);
    return;
  }
  p->stereo = st->has_cur && st->cur.stereo && W.vr;
  draw_frame(p, st, s, ox, oy, p->stereo ? 0 : -1);
  draw_controls(p, st, s, ox, oy);
}

static void v_draw_right(Panel *p, Surface *s, float ox, float oy) {
  VState *st = p->state;
  if (!st->mode || !st->has_cur || !st->cur.stereo) return;
  draw_frame(p, st, s, ox, oy, 1);
  draw_controls(p, st, s, ox, oy);
}

static void take_frame(VState *st, VFrame *f) {
  size_t n = (size_t)f->w * f->h;
  if (!st->cur.px || st->cur.w * st->cur.h < (int)n) {
    free(st->cur.px), free(st->cur.l), free(st->cur.r);
    st->cur.px = malloc(n * 4), st->cur.l = malloc(n * 4), st->cur.r = malloc(n * 4);
  }
  st->cur.w = f->w, st->cur.h = f->h, st->cur.pts = f->pts, st->cur.stereo = f->stereo;
  memcpy(st->cur.px, f->px, n * 4);
  if (f->stereo) memcpy(st->cur.l, f->l, n * 4), memcpy(st->cur.r, f->r, n * 4);
  st->has_cur = 1;
  frames_shown++;
}

static int v_tick(Panel *p, uint32_t now) {
  VState *st = p->state;
  int dirty = 0;
  if (W.hover == (int)(p - P) && (W.hs != st->last_hs || W.ht != st->last_ht)) {
    st->last_hs = W.hs, st->last_ht = W.ht;
    if (st->mode && !controls_shown(p, st)) dirty = 1;
    st->last_move = now;
  }
  if (!st->mode) {
    int d = 0;
    for (int i = 0; i < st->nitems; i++) d += st->items[i].done;
    if (d != st->done_seen) st->done_seen = d, dirty = 1;
    return dirty;
  }
  Player *pl = st->pl;
  if (!pl) return dirty;
  int shown = controls_shown(p, st);
  if (shown != st->was_shown) st->was_shown = shown, dirty = 1;
  if (!pl->ready) return dirty;
  double t = player_clock(pl);
  pthread_mutex_lock(&pl->mu);
  while (pl->qn > 0) {
    VFrame *f = &pl->q[pl->qh];
    if (f->gen != pl->gen) {
      pl->qh = (pl->qh + 1) % QN, pl->qn--;
      continue;
    }
    int first = !st->has_cur || st->need_frame;
    if (!first && (pl->paused || f->pts > t)) break;
    VFrame *nx = pl->qn > 1 ? &pl->q[(pl->qh + 1) % QN] : NULL;
    if (!first && nx && nx->gen == pl->gen && nx->pts <= t) {
      pl->qh = (pl->qh + 1) % QN, pl->qn--;
      continue;
    }
    take_frame(st, f);
    st->need_frame = 0;
    pl->qh = (pl->qh + 1) % QN, pl->qn--;
    dirty = 1;
    if (pl->paused) break;
  }
  int ended = pl->eof && pl->qn == 0;
  pthread_mutex_unlock(&pl->mu);
  if (ended != st->ended) st->ended = ended, dirty = 1;
  if (pl->err[0] && !st->shown) st->shown = 1, dirty = 1;
  return dirty;
}

static void set_paused(Player *pl, int on) {
  if (!pl) return;
  if (!pl->audio_ok) wall_set(pl, player_clock(pl), !on);
  pl->paused = on;
}

static void seek_to(VState *st, double t) {
  Player *pl = st->pl;
  if (!pl) return;
  if (pl->duration > 0 && t > pl->duration) t = pl->duration;
  if (t < 0) t = 0;
  pl->seek_to = t;
  pl->seek_req = 1;
  pl->eof = 0;
  pl->gen++;
  st->need_frame = 1;
  st->ended = 0;
}

static void v_click(Panel *p, float x, float y) {
  VState *st = p->state;
  int z = v_zone(p, x, y);
  st->last_move = now_ms();
  p->dirty = 1;
  if (!st->mode) {
    if (z >= Z_CARD && z - Z_CARD < st->nitems) play_path(p, st, st->items[z - Z_CARD].path);
    else if (z == Z_OPENFILES) {
      char v[700];
      snprintf(v, sizeof v, "%s/Videos", user_home());
      struct stat sb;
      files_open_path(!stat(v, &sb) && S_ISDIR(sb.st_mode) ? v : user_home());
    }
    return;
  }
  Player *pl = st->pl;
  Layout L = layout();
  switch (z) {
  case Z_LIB: to_library(p, st); break;
  case Z_VIDEO:
    if (pl && !st->ended) set_paused(pl, !pl->paused);
    break;
  case Z_PLAY:
    if (pl && st->ended) seek_to(st, 0), set_paused(pl, 0);
    else if (pl) set_paused(pl, !pl->paused);
    break;
  case Z_REPLAY:
    seek_to(st, 0), set_paused(pl, 0);
    break;
  case Z_BACK10:
  case Z_FWD10:
    if (pl && st->has_cur) seek_to(st, st->cur.pts + (z == Z_FWD10 ? 10 : -10));
    break;
  case Z_SEEK:
    if (pl && pl->duration > 0) seek_to(st, fmax(0, fmin(1, (x - seek_x0()) / seek_w())) * pl->duration);
    break;
  case Z_MUTE:
    st->muted = !st->muted;
    if (pl) pl->muted = st->muted;
    break;
  case Z_VOL:
    st->volume = (float)fmax(0, fmin(1, (x - L.vol_x) / L.vol_w));
    st->muted = 0;
    if (pl) pl->volume = st->volume, pl->muted = 0;
    break;
  }
}

static void v_scroll(Panel *p, float x, float y, int steps) {
  (void)x, (void)y;
  VState *st = p->state;
  if (!st->mode) {
    float cw = (VW - 24 * 2 - 20 * 2) / 3.f, ch = cw * 9 / 16 + 54;
    int rows = (st->nitems + 2) / 3;
    float maxs = rows * (ch + 18) + 64 - (VH - BAR_H) + 10;
    st->scroll -= steps * 60;
    if (st->scroll > maxs) st->scroll = (int)maxs;
    if (st->scroll < 0) st->scroll = 0;
  } else {
    st->volume = (float)fmax(0, fmin(1, st->volume + steps * 0.05f));
    st->muted = 0;
    if (st->pl) st->pl->volume = st->volume, st->pl->muted = 0;
    st->last_move = now_ms();
  }
  p->dirty = 1;
}

static void v_key(Panel *p, int code, int mods) {
  (void)mods;
  VState *st = p->state;
  Player *pl = st->pl;
  st->last_move = now_ms();
  p->dirty = 1;
  if (!st->mode) return;
  switch (code) {
  case KEY_SPACE:
  case KEY_K:
  case KEY_PLAYPAUSE:
    if (pl && st->ended) seek_to(st, 0), set_paused(pl, 0);
    else set_paused(pl, pl && !pl->paused);
    break;
  case KEY_LEFT:
  case KEY_J:
    if (pl && st->has_cur) seek_to(st, st->cur.pts - (code == KEY_J ? 10 : 5));
    break;
  case KEY_RIGHT:
  case KEY_L:
    if (pl && st->has_cur) seek_to(st, st->cur.pts + (code == KEY_L ? 10 : 5));
    break;
  case KEY_UP:
  case KEY_DOWN:
    v_scroll(p, 0, 0, code == KEY_UP ? 2 : -2);
    break;
  case KEY_M:
    st->muted = !st->muted;
    if (pl) pl->muted = st->muted;
    break;
  case KEY_HOME:
    seek_to(st, 0);
    break;
  case KEY_ESC:
  case KEY_BACKSPACE:
    to_library(p, st);
    break;
  }
}

App video_app = {"videos", "Videos", IC_VIDEO, VW, VH, v_open, v_draw, v_click, v_scroll, v_key, v_zone, v_tick, v_close,
                 NULL, NULL, NULL, v_draw_right};

void video_open_file(const char *path) {
  int i = panel_open_app("videos");
  if (i < 0 || !P[i].state) return;
  play_path(&P[i], P[i].state, path);
}
