#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "oreonvr.h"
#include "office.h"

#ifdef HAVE_HUNSPELL
#include <hunspell.h>
#endif

#define WMAX 32
#define LEARN_MAX 2000

static const char COMMON[] =
    "the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an "
    "will my one all would there their what so up out if about who get which go me when make can like time no just him know "
    "take people into year your good some could them see other than then now look only come its over think also back after "
    "use two how our work first well way even new want because any these give day most us is are was were been has had did "
    "does am hello hi hey thanks thank please yes okay ok sure great nice cool love really very much more many need help "
    "here where why going doing done got made said tell told ask asked feel find found keep let put seem show try call "
    "today tomorrow tonight yesterday morning night week month later soon again always never sometimes maybe still already "
    "home house school work office meeting email message phone game play music video movie watch read write open close save "
    "file folder document picture photo settings search browser window screen keyboard desktop app apps download update "
    "install system network internet wifi password account name address number friend family mom dad brother sister "
    "something anything nothing everything someone anyone everyone thing things place world life hand part child eye woman "
    "man men women problem question answer idea point fact case group company right left high low long little big small "
    "large old young next last early late important different same able bad best better sorry happy fine free full sure "
    "should must might shall may cannot can't don't won't isn't it's i'm you're that's what's let's didn't doesn't "
    "before between under while during without within around through against among until since though although however "
    "about above across after along also another away each every few both either neither own such those whether why "
    "start stop turn move live believe bring happen hold stand lose pay meet include continue set learn change lead "
    "understand follow create speak spend grow offer remember consider appear buy wait serve die send expect build stay "
    "fall cut reach kill remain suggest raise pass sell require report decide pull check fix test run walk talk eat drink "
    "sleep drive ride fly swim cook clean wash wear sit lie sing dance draw paint learn teach study listen hear smell "
    "food water coffee lunch dinner breakfast car bus train plane city country street room door table chair bed book "
    "paper money price shop store market business job team project plan goal result reason story news information "
    "service minute hour second moment weekend holiday birthday party weather rain snow sun cold hot warm cool";

static const char NEXT[] =
    "i:am,have,think,will,can,don't,was,just,need,want|thank:you|thanks:for,so|how:are,about,do,is,much,many|what:is,are,do,about,time|"
    "good:morning,night,luck,job,idea|see:you,the,it|talk:to,about,later|want:to,a,it|going:to,on,out|need:to,a,the,help|have:a,to,been,the,you,fun|"
    "are:you,we,the,there,not|you:are,can,have,know,want,for|it:is,was,will,would|this:is,was,will,one|the:best,same,first,other,next|"
    "of:the,course,my,it|in:the,a,my,an|to:the,be,do,get,go,see,make|for:the,a,your,me,you|on:the,my,a,it|at:the,home,work,least|"
    "is:a,the,not,it,that|let:me,us,it|do:you,not,it,this|can:you,i,we,be|will:be,you,it|would:be,you,like,love|please:let,send,check|"
    "love:you,it|let's:go,do,see|i'm:going,not,sure,so|don't:know,have,think,want|we:are,can,have,will,need|they:are,were,have,will|"
    "my:name,phone,computer|and:the,i,then|be:a,able,there|so:much,i,that|no:problem,one|of:course|happy:birthday|see:you|talk:soon|"
    "how's:it|on:my|just:a,wanted|could:you,be|should:be,i|very:much,good|right:now|by:the|with:the,a,my,you|from:the|about:the,it,to";

typedef struct {
  char w[WMAX];
  int n;
} Learned;

typedef struct {
  char a[WMAX], b[WMAX];
  int n;
} Pair;

static Pair *pairs;
static int npairs, cap_pairs;
static const char *ctx;

static Learned *learned;
static int nlearned, cap_learned, loaded, dirty;
static char **stems;
static int nstems;
#ifdef HAVE_HUNSPELL
static Hunhandle *hun;
#endif

static const char *words_path(void) {
  static char p[600];
  const char *e = getenv("OREONVR_WORDS_FILE");
  if (e && *e) return e;
  snprintf(p, sizeof p, "%s/.config/oreonvr/words", user_home());
  return p;
}

static Learned *find_learned(const char *w) {
  for (int i = 0; i < nlearned; i++)
    if (!strcmp(learned[i].w, w)) return &learned[i];
  return NULL;
}

static Learned *add_learned(const char *w, int n) {
  Learned *l = find_learned(w);
  if (l) {
    l->n += n;
    return l;
  }
  if (nlearned >= LEARN_MAX) {
    int lo = 0;
    for (int i = 1; i < nlearned; i++)
      if (learned[i].n < learned[lo].n) lo = i;
    learned[lo] = learned[--nlearned];
  }
  if (nlearned == cap_learned) {
    cap_learned = cap_learned ? cap_learned * 2 : 128;
    learned = realloc(learned, sizeof *learned * (size_t)cap_learned);
  }
  l = &learned[nlearned++];
  snprintf(l->w, sizeof l->w, "%s", w);
  l->n = n;
  return l;
}

static Pair *find_pair(const char *a, const char *b) {
  for (int i = 0; i < npairs; i++)
    if (!strcmp(pairs[i].a, a) && !strcmp(pairs[i].b, b)) return &pairs[i];
  return NULL;
}

static void add_pair(const char *a, const char *b, int n) {
  Pair *p = find_pair(a, b);
  if (p) {
    p->n += n;
    return;
  }
  if (npairs >= LEARN_MAX * 2) {
    int lo = 0;
    for (int i = 1; i < npairs; i++)
      if (pairs[i].n < pairs[lo].n) lo = i;
    pairs[lo] = pairs[--npairs];
  }
  if (npairs == cap_pairs) {
    cap_pairs = cap_pairs ? cap_pairs * 2 : 128;
    pairs = realloc(pairs, sizeof *pairs * (size_t)cap_pairs);
  }
  p = &pairs[npairs++];
  snprintf(p->a, sizeof p->a, "%s", a);
  snprintf(p->b, sizeof p->b, "%s", b);
  p->n = n;
}

static const char *next_list(const char *a) {
  size_t n = strlen(a);
  for (const char *s = NEXT; s && *s; s = strchr(s, '|') ? strchr(s, '|') + 1 : NULL)
    if (!strncmp(s, a, n) && s[n] == ':') return s + n + 1;
  return NULL;
}

static int next_rank(const char *a, const char *b) {
  const char *l = next_list(a);
  size_t n = strlen(b);
  for (int r = 0; l && *l && *l != '|'; r++) {
    size_t k = strcspn(l, ",|");
    if (k == n && !strncmp(l, b, n)) return r;
    l += k;
    if (*l == ',') l++;
  }
  return -1;
}

static int ctx_bonus(const char *w) {
  if (!ctx || !*ctx) return 0;
  char lw[WMAX];
  size_t i = 0;
  for (; w[i] && i + 1 < sizeof lw; i++) lw[i] = (char)tolower((unsigned char)w[i]);
  lw[i] = 0;
  Pair *p = find_pair(ctx, lw);
  int r = next_rank(ctx, lw);
  return (p ? 1500 + p->n * 150 : 0) + (r >= 0 ? 900 - r * 40 : 0);
}

static int ascii_word(const char *w) {
  if (!*w) return 0;
  for (; *w; w++)
    if (!isalpha((unsigned char)*w) && *w != '\'' && *w != '-') return 0;
  return 1;
}

static void load_stems(const char *dic) {
  FILE *f = fopen(dic, "r");
  if (!f) return;
  char line[256];
  int cap = 0;
  if (!fgets(line, sizeof line, f)) {
    fclose(f);
    return;
  }
  while (fgets(line, sizeof line, f)) {
    line[strcspn(line, "/\t\r\n")] = 0;
    size_t n = strlen(line);
    if (n < 2 || n >= WMAX || !ascii_word(line)) continue;
    if (nstems == cap) {
      cap = cap ? cap * 2 : 65536;
      stems = realloc(stems, sizeof *stems * (size_t)cap);
    }
    stems[nstems++] = strdup(line);
  }
  fclose(f);
}

static int find_dict(char *aff, char *dic, size_t n) {
  const char *env = getenv("OREONVR_DICT");
  char lang[16] = "en_US";
  const char *l = getenv("LC_ALL");
  if (!l || !*l) l = getenv("LANG");
  if (l && strlen(l) >= 5 && l[2] == '_') snprintf(lang, sizeof lang, "%.5s", l);
  const char *dirs[] = {"/usr/share/hunspell", "/usr/share/myspell", "/usr/share/myspell/dicts", NULL};
  const char *langs[] = {lang, "en_US", "en_GB", NULL};
  if (env && *env) {
    snprintf(aff, n, "%s.aff", env);
    snprintf(dic, n, "%s.dic", env);
    return 1;
  }
  for (int a = 0; langs[a]; a++)
    for (int d = 0; dirs[d]; d++) {
      snprintf(aff, n, "%s/%s.aff", dirs[d], langs[a]);
      snprintf(dic, n, "%s/%s.dic", dirs[d], langs[a]);
      FILE *f = fopen(dic, "r");
      if (f) {
        fclose(f);
        return 1;
      }
    }
  return 0;
}

static void load(void) {
  if (loaded) return;
  loaded = 1;
  FILE *f = fopen(words_path(), "r");
  if (f) {
    char line[160], a[64], b[64];
    int n;
    while (fgets(line, sizeof line, f)) {
      if (sscanf(line, "%63s %63s %d", a, b, &n) == 3) {
        if (strlen(a) < WMAX && strlen(b) < WMAX && ascii_word(a) && ascii_word(b)) add_pair(a, b, n);
      } else if (sscanf(line, "%63s %d", a, &n) == 2 && strlen(a) < WMAX && ascii_word(a))
        add_learned(a, n);
    }
    fclose(f);
  }
  char aff[600], dic[600];
  if (!find_dict(aff, dic, sizeof aff)) return;
#ifdef HAVE_HUNSPELL
  hun = Hunspell_create(aff, dic);
#endif
  load_stems(dic);
}

void predict_save(void) {
  if (!dirty) return;
  char dir[600];
  snprintf(dir, sizeof dir, "%s", words_path());
  char *sl = strrchr(dir, '/');
  if (sl) {
    *sl = 0;
    office_mkdirs(dir);
  }
  FILE *f = fopen(words_path(), "w");
  if (!f) return;
  for (int i = 0; i < nlearned; i++) fprintf(f, "%s %d\n", learned[i].w, learned[i].n);
  for (int i = 0; i < npairs; i++) fprintf(f, "%s %s %d\n", pairs[i].a, pairs[i].b, pairs[i].n);
  fclose(f);
  dirty = 0;
}

static void lower(char *d, const char *s, size_t n) {
  size_t i = 0;
  for (; s[i] && i + 1 < n; i++) d[i] = (char)tolower((unsigned char)s[i]);
  d[i] = 0;
}

static int in_common(const char *w) {
  size_t n = strlen(w);
  for (const char *s = strstr(COMMON, w); s; s = strstr(s + 1, w))
    if ((s == COMMON || s[-1] == ' ') && (s[n] == ' ' || !s[n])) return 1;
  return 0;
}

void predict_learn(const char *word, const char *prev, int sure) {
  char w[WMAX], pw[WMAX];
  if (strlen(word) < 1 || strlen(word) >= WMAX || !ascii_word(word)) return;
  load();
  lower(w, word, sizeof w);
  if (strlen(w) >= 2) {
    int known = sure || in_common(w) || find_learned(w);
    for (int i = 0; i < nstems && !known; i++) known = !strcasecmp(stems[i], w);
#ifdef HAVE_HUNSPELL
    if (hun && !known) known = Hunspell_spell(hun, word) != 0;
#endif
    add_learned(w, known ? 1 : 0);
  }
  if (prev && *prev && strlen(prev) < WMAX && ascii_word(prev)) {
    lower(pw, prev, sizeof pw);
    add_pair(pw, w, 1);
  }
  dirty = 1;
}

typedef struct {
  char w[WMAX];
  int score;
} Cand;

static void offer(Cand *c, int *nc, int max, const char *w, int score) {
  score += ctx_bonus(w);
  for (int i = 0; i < *nc; i++)
    if (!strcasecmp(c[i].w, w)) {
      if (score > c[i].score) c[i].score = score;
      return;
    }
  if (*nc < max) {
    snprintf(c[*nc].w, WMAX, "%s", w);
    c[(*nc)++].score = score;
    return;
  }
  int lo = 0;
  for (int i = 1; i < *nc; i++)
    if (c[i].score < c[lo].score) lo = i;
  if (score > c[lo].score) {
    snprintf(c[lo].w, WMAX, "%s", w);
    c[lo].score = score;
  }
}

static int edits(const char *a, const char *b) {
  int la = (int)strlen(a), lb = (int)strlen(b), d[WMAX + 1][WMAX + 1];
  if (la > WMAX || lb > WMAX) return 99;
  for (int i = 0; i <= la; i++) d[i][0] = i;
  for (int j = 0; j <= lb; j++) d[0][j] = j;
  for (int i = 1; i <= la; i++)
    for (int j = 1; j <= lb; j++) {
      int cost = tolower((unsigned char)a[i - 1]) != tolower((unsigned char)b[j - 1]);
      int v = d[i - 1][j] + 1;
      if (d[i][j - 1] + 1 < v) v = d[i][j - 1] + 1;
      if (d[i - 1][j - 1] + cost < v) v = d[i - 1][j - 1] + cost;
      if (i > 1 && j > 1 && tolower((unsigned char)a[i - 1]) == tolower((unsigned char)b[j - 2]) &&
          tolower((unsigned char)a[i - 2]) == tolower((unsigned char)b[j - 1]) && d[i - 2][j - 2] + 1 < v)
        v = d[i - 2][j - 2] + 1;
      d[i][j] = v;
    }
  return d[la][lb];
}

static int cand_cmp(const void *a, const void *b) {
  const Cand *x = a, *y = b;
  return y->score != x->score ? y->score - x->score : strcmp(x->w, y->w);
}

#ifdef HAVE_HUNSPELL
static void forms(Cand *c, int *nc, const char *pre, size_t pl) {
  static const char *const suf[] = {"s", "es", "ed", "d", "ing", "er", "ers", "est", "ly", "ness", "ment", "ments", "able", "ful", "ation", "ations", "ies", "ied", NULL};
  int tried = 0;
  for (int i = 0; i < nstems && tried < 400; i++) {
    const char *st = stems[i];
    size_t n = strlen(st);
    if (n < 2 || n + 6 < pl || isupper((unsigned char)st[0])) continue;
    size_t m = n < pl ? n : pl;
    if (strncasecmp(st, pre, m > 1 ? m - 1 : m)) continue;
    tried++;
    char base[3][WMAX];
    int nb = 0;
    snprintf(base[nb++], WMAX, "%s", st);
    if (n > 2 && st[n - 1] == 'e') snprintf(base[nb++], WMAX, "%.*s", (int)(n - 1), st);
    if (n > 2 && st[n - 1] == 'y') snprintf(base[nb++], WMAX, "%.*s", (int)(n - 1), st);
    else if (n > 2 && !strchr("aeiouwxy", st[n - 1]) && strchr("aeiou", st[n - 2]) && !strchr("aeiou", st[n - 3]))
      snprintf(base[nb++], WMAX, "%s%c", st, st[n - 1]);
    for (int b = 0; b < nb; b++)
      for (int k = 0; suf[k]; k++) {
        char w[128];
        snprintf(w, sizeof w, "%s%s", base[b], suf[k]);
        size_t wl = strlen(w);
        if (wl <= pl || wl >= WMAX || strncasecmp(w, pre, pl)) continue;
        if (Hunspell_spell(hun, w)) offer(c, nc, 24, w, 990 - (int)wl * 25);
      }
  }
}
#endif

int predict_next(const char *prev, char out[][32], int max) {
  char pw[WMAX];
  if (!prev || !*prev || strlen(prev) >= WMAX || !ascii_word(prev)) return 0;
  load();
  lower(pw, prev, sizeof pw);
  Cand c[24];
  int nc = 0;
  ctx = NULL;
  for (int i = 0; i < npairs; i++)
    if (!strcmp(pairs[i].a, pw)) offer(c, &nc, 24, pairs[i].b, 1500 + pairs[i].n * 150);
  const char *l = next_list(pw);
  for (int r = 0; l && *l && *l != '|'; r++) {
    size_t k = strcspn(l, ",|");
    char w[WMAX];
    snprintf(w, sizeof w, "%.*s", (int)(k < WMAX ? k : WMAX - 1), l);
    offer(c, &nc, 24, w, 900 - r * 40);
    l += k;
    if (*l == ',') l++;
  }
  qsort(c, (size_t)nc, sizeof *c, cand_cmp);
  int n = 0;
  for (int i = 0; i < nc && n < max; i++, n++) {
    memcpy(out[n], c[i].w, WMAX);
    out[n][WMAX - 1] = 0;
    if (!strcmp(out[n], "i") || !strncmp(out[n], "i'", 2)) out[n][0] = 'I';
  }
  return n;
}

int predict_words(const char *typed, const char *prev, char out[][32], int max, int *fix) {
  char pre[WMAX], pw[WMAX] = "";
  if (prev && strlen(prev) < WMAX) lower(pw, prev, sizeof pw);
  size_t pl = strlen(typed);
  *fix = 0;
  if (!pl || pl >= WMAX || !ascii_word(typed)) return 0;
  load();
  lower(pre, typed, sizeof pre);
  ctx = pw;
  Cand c[24];
  int nc = 0;
  for (int i = 0; i < nlearned; i++)
    if (learned[i].n > 0 && !strncmp(learned[i].w, pre, pl) && strlen(learned[i].w) > pl)
      offer(c, &nc, 24, learned[i].w, 3000 + learned[i].n * 40);
  int rank = 0;
  for (const char *s = COMMON; *s;) {
    const char *e = strchr(s, ' ');
    size_t n = e ? (size_t)(e - s) : strlen(s);
    if (n > pl && n < WMAX && !strncmp(s, pre, pl)) {
      char w[WMAX];
      memcpy(w, s, n);
      w[n] = 0;
      offer(c, &nc, 24, w, 2000 - rank);
    }
    rank++;
    s += n;
    while (*s == ' ') s++;
  }
  int good = 0;
  for (int i = 0; i < nstems; i++) {
    const char *w = stems[i];
    size_t n = strlen(w);
    if (n <= pl || strncasecmp(w, pre, pl)) continue;
    int proper = isupper((unsigned char)w[0]) && !isupper((unsigned char)typed[0]);
    if (proper && isupper((unsigned char)w[1])) continue;
    offer(c, &nc, 24, w, 1000 - (int)n * 20 - (proper ? 400 : 0));
    good |= !proper;
  }
#ifdef HAVE_HUNSPELL
  if (hun && pl >= 3) forms(c, &nc, pre, pl);
#endif
  int valid = 1;
  for (int i = 0; i < nc; i++) good |= c[i].score >= 1800;
#ifdef HAVE_HUNSPELL
  if (hun && pl >= 2) {
    valid = Hunspell_spell(hun, typed) != 0 || find_learned(pre) != NULL;
    if (!valid) {
      char **sl = NULL;
      int ns = Hunspell_suggest(hun, &sl, typed);
      for (int i = 0, k = 0; i < ns && k < 6; i++)
        if (ascii_word(sl[i]) && !strchr(sl[i], '-') && strlen(sl[i]) < WMAX && strncasecmp(sl[i], typed, strlen(sl[i]))) offer(c, &nc, 24, sl[i], (good ? 700 : 5000) + (in_common(sl[i]) || find_learned(sl[i]) ? 300 : 0) - k++ * 10);
      if (ns) Hunspell_free_list(hun, &sl, ns);
    }
  }
#endif
  qsort(c, (size_t)nc, sizeof *c, cand_cmp);
  int n = 0;
  for (int i = 0; i < nc && n < max; i++) {
    memcpy(out[n], c[i].w, WMAX);
    out[n][WMAX - 1] = 0;
    if (isupper((unsigned char)typed[0])) out[n][0] = (char)toupper((unsigned char)out[n][0]);
    n++;
  }
  *fix = 0;
  if (!valid && n && c[0].score >= 4900) {
    int e = edits(typed, c[0].w);
    *fix = pl >= 3 && ((c[0].score >= 5250 && e <= 2) || (pl >= 4 && e <= 1)) ? 2 : 1;
  }
  ctx = NULL;
  return n;
}
