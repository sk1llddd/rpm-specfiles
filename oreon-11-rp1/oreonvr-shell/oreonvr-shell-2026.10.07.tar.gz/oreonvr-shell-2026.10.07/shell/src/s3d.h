#ifndef OREONVR_S3D_H
#define OREONVR_S3D_H

#include <stdint.h>

typedef struct S3D S3D;

S3D *s3d_new(void);
void s3d_free(S3D *s);
void s3d_reset(S3D *s);
void s3d_depth(S3D *s, const uint32_t *px, int w, int h);
float s3d_depth_at(const S3D *s, float u, float v);
void s3d_views(S3D *s, const uint32_t *src, int w, int h, uint32_t *left, uint32_t *right, float strength);
void s3d_depth_image(const S3D *s, uint32_t *out, int w, int h);

#endif
