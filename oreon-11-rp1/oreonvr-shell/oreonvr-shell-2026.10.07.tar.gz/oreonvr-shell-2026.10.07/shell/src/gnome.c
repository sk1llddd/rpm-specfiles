#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <math.h>
#include <pwd.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>

#include "oreonvr.h"
#include "../bridge/bridge.h"

#define GN_SCALE 0.5f
#define RAISE_WAIT 180

static struct {
  pid_t pid;
  int ctl, evt;
  void *pool;
  char buf[32768];
  int blen;
  int ready, dead;
  uint32_t restart_at;
} B = {.ctl = -1, .evt = -1};

static GApp *apps;
static int napps, capps;
int gnome_apps_changed;
static DSet *dsets;
static int ndsets, cdsets, dsets_done;
int desk_settings_changed;

typedef struct {
  int used;
  uint64_t id, parent;
  int child;
  int x, y, w, h;
  char title[128], app[128];
  int panel;
  uint32_t seq;
} GWin;

static GWin wins[BRIDGE_SLOTS];
static uint64_t last_raised;
static int desktop_on;
static int last_mx = -1, last_my = -1;
static int overview;

static void P_dirty_desktop(void);
App gwin_app, gchild_app;

typedef struct {
  char line[96];
  int len;
  uint32_t at;
} Cmd;

static Cmd q[512];
static int qh, qn;
static uint32_t gate;

static void qsend(const char *fmt, ...) {
  if (B.ctl < 0) return;
  if (qn == 512) qh = (qh + 1) % 512, qn--;
  Cmd *c = &q[(qh + qn) % 512];
  va_list ap;
  va_start(ap, fmt);
  c->len = vsnprintf(c->line, sizeof c->line, fmt, ap);
  va_end(ap);
  if (c->len >= (int)sizeof c->line) c->len = (int)sizeof c->line - 1;
  uint32_t now = now_ms();
  c->at = (int32_t)(gate - now) > 0 ? gate : now;
  qn++;
}

static void qflush(uint32_t now) {
  while (qn && (int32_t)(q[qh].at - now) <= 0 && B.ctl >= 0) {
    ssize_t w = write(B.ctl, q[qh].line, (size_t)q[qh].len);
    if (w < 0 && errno == EAGAIN) return;
    qh = (qh + 1) % 512, qn--;
  }
}

static int app_cmp(const void *a, const void *b) { return strcasecmp(((const GApp *)a)->name, ((const GApp *)b)->name); }

int gnome_app_count(void) { return napps; }
GApp *gnome_app(int i) { return i >= 0 && i < napps ? &apps[i] : NULL; }

GApp *gnome_app_by_id(const char *id) {
  for (int i = 0; i < napps; i++)
    if (!strcmp(apps[i].id, id)) return &apps[i];
  return NULL;
}

static int load_rgba(const char *path, uint32_t **out, int *ow, int *oh) {
  FILE *f = path && *path ? fopen(path, "rb") : NULL;
  if (!f) return 0;
  uint32_t wh[2];
  int ok = 0;
  if (fread(wh, 4, 2, f) == 2 && wh[0] && wh[1] && wh[0] <= 512 && wh[1] <= 512) {
    size_t n = (size_t)wh[0] * wh[1];
    unsigned char *rgba = malloc(n * 4);
    uint32_t *px = malloc(n * 4);
    if (rgba && px && fread(rgba, 4, n, f) == n) {
      for (size_t i = 0; i < n; i++) {
        uint32_t al = rgba[i * 4 + 3];
        uint32_t r = rgba[i * 4] * al / 255, g = rgba[i * 4 + 1] * al / 255, b = rgba[i * 4 + 2] * al / 255;
        px[i] = (al << 24) | (r << 16) | (g << 8) | b;
      }
      *out = px, *ow = (int)wh[0], *oh = (int)wh[1];
      ok = 1;
    } else free(px);
    free(rgba);
  }
  fclose(f);
  return ok;
}

static void load_icon(GApp *a, const char *path) { load_rgba(path, &a->icon, &a->iw, &a->ih); }

static int dset_cmp(const void *a, const void *b) {
  const DSet *x = a, *y = b;
  if (x->gw != y->gw) return x->gw - y->gw;
  int g = strcmp(x->group, y->group);
  if (g) return g;
  return strcasecmp(x->name, y->name);
}

static void add_setting(char **f, int n) {
  if (n < 9) return;
  if (dsets_done) {
    for (int i = 0; i < ndsets; i++) free(dsets[i].icon);
    ndsets = 0, dsets_done = 0;
  }
  if (ndsets == cdsets) {
    cdsets = cdsets ? cdsets * 2 : 128;
    dsets = realloc(dsets, sizeof(DSet) * (size_t)cdsets);
  }
  DSet *d = &dsets[ndsets++];
  memset(d, 0, sizeof *d);
  snprintf(d->id, sizeof d->id, "%s", f[1]);
  snprintf(d->name, sizeof d->name, "%s", f[2]);
  snprintf(d->desc, sizeof d->desc, "%s", f[4]);
  snprintf(d->group, sizeof d->group, "%s", f[5]);
  d->gw = atoi(f[6]), d->weight = atoi(f[7]);
  d->info = !strcmp(f[8], "info");
  load_rgba(f[3], &d->icon, &d->iw, &d->ih);
}

int desk_settings_count(void) { return ndsets; }

int desk_settings_ready(void) { return dsets_done; }

const DSet *desk_setting(int i) { return i >= 0 && i < ndsets ? &dsets[i] : NULL; }

void desk_setting_open(int i) {
  if (i < 0 || i >= ndsets) return;
  qsend("kcm %s\n", dsets[i].id);
  qflush(now_ms());
}

static void add_app(char **f, int n) {
  if (n < 4 || gnome_app_by_id(f[1])) return;
  if (napps == capps) {
    capps = capps ? capps * 2 : 64;
    apps = realloc(apps, sizeof(GApp) * (size_t)capps);
  }
  GApp *a = &apps[napps++];
  memset(a, 0, sizeof *a);
  snprintf(a->id, sizeof a->id, "%s", f[1]);
  snprintf(a->name, sizeof a->name, "%s", f[2]);
  if (n >= 5) snprintf(a->path, sizeof a->path, "%s", f[4]);
  load_icon(a, f[3]);
}


int gnome_app_running(const char *id) {
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (wins[i].used && !wins[i].child && !strcmp(wins[i].app, id)) return 1;
  return 0;
}

static void panel_dims(GWin *g, int *lw, int *lh) {
  *lw = (int)lroundf(g->w * GN_SCALE);
  *lh = (int)lroundf(g->h * GN_SCALE) + (g->child ? 0 : BAR_H);
  if (*lw < 24) *lw = 24;
  if (*lh < (g->child ? 12 : BAR_H + 24)) *lh = g->child ? 12 : BAR_H + 24;
}

static int find_win(uint64_t id) {
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (wins[i].used && wins[i].id == id) return i;
  return -1;
}

static void place_child(GWin *g) {
  int pi = find_win(g->parent);
  if (pi < 0 || wins[pi].panel < 0 || g->panel < 0) return;
  GWin *pg = &wins[pi];
  Panel *pp = &P[pg->panel], *c = &P[g->panel];
  float ca = cosf(pp->yaw), sa = sinf(pp->yaw), ct = cosf(pp->tilt), st = sinf(pp->tilt);
  float pr[3] = {ca, 0, sa}, pu[3] = {-sa * st, ct, ca * st};
  float n[3] = {pr[1] * pu[2] - pr[2] * pu[1], pr[2] * pu[0] - pr[0] * pu[2], pr[0] * pu[1] - pr[1] * pu[0]};
  float sw = pp->lw + 2.f * MARGIN, sh = pp->lh + 2.f * MARGIN;
  float bx = MARGIN + (g->x - pg->x) * GN_SCALE + c->lw * 0.5f;
  float by = MARGIN + BAR_H + (g->y - pg->y) * GN_SCALE + c->lh * 0.5f;
  float ox = bx - sw * 0.5f, oy = by - sh * 0.5f;
  c->x = pp->x + pr[0] * ox - pu[0] * oy + n[0] * 4.f;
  c->y = pp->y + pr[1] * ox - pu[1] * oy + n[1] * 4.f;
  c->z = pp->z + pr[2] * ox - pu[2] * oy + n[2] * 4.f;
  c->yaw = pp->yaw, c->tilt = pp->tilt;
  c->visible = pp->visible;
  c->parent = pg->panel;
}

static void show_win(int slot) {
  GWin *g = &wins[slot];
  int lw, lh;
  panel_dims(g, &lw, &lh);
  if (g->panel >= 0) {
    Panel *p = &P[g->panel];
    if (p->lw != lw || p->lh != lh) panel_resize(g->panel, lw, lh);
    if (!g->child && strcmp(p->title, g->title)) {
      snprintf(p->title, sizeof p->title, "%s", g->title);
      p->chrome_key = -1;
    }
    p->dirty = 1;
    return;
  }
  if (g->child && (find_win(g->parent) < 0 || wins[find_win(g->parent)].panel < 0)) return;
  int i = panel_create(g->child ? PK_CHILD : PK_WINDOW, lw, lh, g->title[0] ? g->title : "Window",
                       g->child ? &gchild_app : &gwin_app);
  if (i < 0) return;
  int *st = malloc(sizeof(int));
  *st = slot;
  P[i].state = st;
  g->panel = i;
  if (g->child) {
    P[i].appear = 1.f;
    place_child(g);
  } else {
    panel_place_new(i);
    W.focus = i;
  }
  gnome_apps_changed = 1;
  P_dirty_desktop();
}

static void drop_win(int slot) {
  GWin *g = &wins[slot];
  if (g->panel >= 0 && P[g->panel].used) panel_close(g->panel);
  g->panel = -1;
  g->used = 0;
  if (last_raised == g->id) last_raised = 0;
  gnome_apps_changed = 1;
  P_dirty_desktop();
}

int gnome_focus_app(const char *id) {
  for (int i = 1; i < BRIDGE_SLOTS; i++) {
    GWin *g = &wins[i];
    if (g->used && !g->child && g->panel >= 0 && !strcmp(g->app, id)) {
      scene_place_in_view(&P[g->panel], fmaxf(640.f, fmaxf(P[g->panel].lw * 1.22f, P[g->panel].lh * 1.3f)), 0.f);
      panel_raise(g->panel);
      W.focus = g->panel;
      return 1;
    }
  }
  return 0;
}

void gnome_launch(const char *id) {
  if (gnome_focus_app(id)) return;
  qsend("launch %s\n", id);
}

void gnome_desktop(int on) {
  desktop_on = on;
  qsend("desktop %d\n", on);
}

static uint32_t *plate;
static int plate_w, plate_h;
static uint32_t plate_at;

static int hidden_win(const GWin *g) { return g->used && g->panel >= 0 && !overview; }

static int any_hidden(void) {
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (hidden_win(&wins[i])) return 1;
  return 0;
}

static void P_dirty_desktop(void) {
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app == &desktop_app) P[i].dirty = 1;
}

static int in_hidden_win(int mx, int my) {
  for (int i = 1; i < BRIDGE_SLOTS; i++) {
    const GWin *g = &wins[i];
    if (hidden_win(g) && mx >= g->x && my >= g->y && mx < g->x + g->w && my < g->y + g->h) return 1;
  }
  return 0;
}

static void keep_plate(const BridgeHeader *hd, uint32_t now) {
  if (any_hidden() || overview || (plate && (int32_t)(now - plate_at) < 1000)) return;
  size_t n = (size_t)hd->w * hd->h;
  if (!plate || plate_w != (int)hd->w || plate_h != (int)hd->h) {
    free(plate);
    plate = malloc(n * 4);
    plate_w = (int)hd->w, plate_h = (int)hd->h;
  }
  if (plate) memcpy(plate, hd + 1, n * 4);
  plate_at = now;
}

static const uint32_t *desktop_view(const BridgeHeader *hd) {
  if (!any_hidden()) return NULL;
  static uint32_t *comp;
  static size_t cap;
  int fw = (int)hd->w, fh = (int)hd->h;
  size_t n = (size_t)fw * fh;
  if (n > cap) {
    free(comp);
    comp = malloc(n * 4);
    cap = comp ? n : 0;
  }
  if (!comp) return NULL;
  const uint32_t *src = (const uint32_t *)(hd + 1);
  memcpy(comp, src, n * 4);
  int have = plate && plate_w == fw && plate_h == fh;
  for (int i = 1; i < BRIDGE_SLOTS; i++) {
    const GWin *g = &wins[i];
    if (!hidden_win(g)) continue;
    int x0 = g->x < 0 ? 0 : g->x, y0 = g->y < 0 ? 0 : g->y;
    int x1 = g->x + g->w > fw ? fw : g->x + g->w, y1 = g->y + g->h > fh ? fh : g->y + g->h;
    for (int y = y0; y < y1 && x1 > x0; y++) {
      uint32_t *row = comp + (size_t)y * fw;
      if (have) memcpy(row + x0, plate + (size_t)y * fw + x0, (size_t)(x1 - x0) * 4);
      else
        for (int x = x0; x < x1; x++) row[x] = RGB(36, 14, 52);
    }
  }
  return comp;
}

static void event(char *line) {
  char *f[12];
  int n = 0;
  for (char *s = line; n < 12;) {
    f[n++] = s;
    char *t = strchr(s, '\t');
    if (!t) break;
    *t = 0;
    s = t + 1;
  }
  if (!strcmp(f[0], "app")) {
    add_app(f, n);
  } else if (!strcmp(f[0], "setting")) {
    add_setting(f, n);
  } else if (!strcmp(f[0], "settings-done")) {
    qsort(dsets, (size_t)ndsets, sizeof(DSet), dset_cmp);
    dsets_done = 1;
    desk_settings_changed = 1;
  } else if (!strcmp(f[0], "apps-done")) {
    qsort(apps, (size_t)napps, sizeof(GApp), app_cmp);
    gnome_apps_changed = 1;
  } else if (!strcmp(f[0], "ready")) {
    B.ready = 1;
  } else if (!strcmp(f[0], "overview") && n >= 2) {
    overview = atoi(f[1]) != 0;
    P_dirty_desktop();
  } else if (!strcmp(f[0], "win") && n >= 11) {
    int slot = atoi(f[1]);
    if (slot <= 0 || slot >= BRIDGE_SLOTS) return;
    GWin *g = &wins[slot];
    if (!g->used || g->id != strtoull(f[2], NULL, 10)) {
      if (g->used) drop_win(slot);
      memset(g, 0, sizeof *g);
      g->used = 1, g->panel = -1;
    }
    g->id = strtoull(f[2], NULL, 10);
    g->parent = strtoull(f[3], NULL, 10);
    g->child = !strcmp(f[4], "child");
    g->x = atoi(f[5]), g->y = atoi(f[6]), g->w = atoi(f[7]), g->h = atoi(f[8]);
    snprintf(g->title, sizeof g->title, "%s", f[9]);
    snprintf(g->app, sizeof g->app, "%s", f[10]);
    show_win(slot);
  } else if (!strcmp(f[0], "gone") && n >= 2) {
    int slot = atoi(f[1]);
    if (slot > 0 && slot < BRIDGE_SLOTS && wins[slot].used) drop_win(slot);
  }
}

static const char *bridge_path(void) {
  static char buf[600];
  const char *e = getenv("OREONVR_BRIDGE");
  if (e && *e) return access(e, X_OK) ? NULL : e;
  if (!access("/usr/libexec/oreonvr-desktop-bridge", X_OK)) return "/usr/libexec/oreonvr-desktop-bridge";
  ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 64);
  if (n > 0) {
    buf[n] = 0;
    char *sl = strrchr(buf, '/');
    if (sl) {
      strcpy(sl, "/bridge/oreonvr-desktop-bridge");
      if (!access(buf, X_OK)) return buf;
    }
  }
  return NULL;
}

static void spawn(void) {
  const char *bin = bridge_path();
  if (!bin) {
    B.dead = 1;
    return;
  }
  static int shm_fd = -1;
  if (!B.pool) {
    shm_fd = memfd_create("oreonvr-gnome", MFD_CLOEXEC);
    if (shm_fd < 0 || ftruncate(shm_fd, (off_t)BRIDGE_SHM_SIZE)) return;
    B.pool = mmap(NULL, BRIDGE_SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (B.pool == MAP_FAILED) {
      B.pool = NULL;
      return;
    }
  }
  for (int i = 0; i < BRIDGE_SLOTS; i++) {
    BridgeHeader *h = bridge_slot(B.pool, i);
    memset(h, 0, sizeof *h);
    h->magic = BRIDGE_MAGIC;
  }
  for (int i = 0; i < napps; i++) free(apps[i].icon);
  napps = 0;
  int in[2], out[2];
  if (pipe2(in, O_CLOEXEC) || pipe2(out, O_CLOEXEC)) return;
  pid_t pid = fork();
  if (pid < 0) return;
  if (pid == 0) {
    dup2(in[0], 0);
    dup2(out[1], 1);
    if (shm_fd == 3) fcntl(3, F_SETFD, 0);
    else dup2(shm_fd, 3);
    for (int fd = 4; fd < 256; fd++) close(fd);
    signal(SIGPIPE, SIG_DFL);

    const char *user = getenv("OREONVR_USER");
    struct passwd *pw = NULL;
    if (getuid() == 0 && user && *user && (pw = getpwnam(user))) {
      if (initgroups(pw->pw_name, pw->pw_gid) || setgid(pw->pw_gid) || setuid(pw->pw_uid)) _exit(126);
    } else {
      pw = getpwuid(getuid());
    }
    if (pw) {
      char rt[64], bus[96];
      snprintf(rt, sizeof rt, "/run/user/%u", (unsigned)pw->pw_uid);
      snprintf(bus, sizeof bus, "unix:path=%s/bus", rt);
      setenv("XDG_RUNTIME_DIR", rt, 1);
      if (!getenv("OREONVR_BRIDGE")) setenv("DBUS_SESSION_BUS_ADDRESS", bus, 1);
      setenv("HOME", pw->pw_dir, 1);
      setenv("USER", pw->pw_name, 1);
    }
    execl(bin, "oreonvr-desktop-bridge", (char *)NULL);
    _exit(127);
  }
  close(in[0]), close(out[1]);
  fcntl(in[1], F_SETFL, O_NONBLOCK);
  fcntl(out[0], F_SETFL, O_NONBLOCK);
  B.ctl = in[1], B.evt = out[0], B.pid = pid, B.dead = 0, B.blen = 0, B.ready = 0;
  qh = qn = 0;
  if (desktop_on) qsend("desktop 1\n");
}

void gnome_init(void) {
  for (int i = 0; i < BRIDGE_SLOTS; i++) wins[i].panel = -1;
  spawn();

  if (!access("/run/user", F_OK)) qsend("attach\n");
}

static void bridge_died(void) {
  if (B.ctl >= 0) close(B.ctl);
  if (B.evt >= 0) close(B.evt);
  B.ctl = B.evt = -1, B.pid = 0, B.ready = 0;
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (wins[i].used) drop_win(i);
  B.restart_at = now_ms() + 3000;
  fprintf(stderr, "oreonvr: desktop bridge stopped, restarting\n");
}

static int to_monitor(Panel *p, float x, float y, int *mx, int *my) {
  if (p->app == &desktop_app) {
    BridgeHeader *h = B.pool ? bridge_slot(B.pool, 0) : NULL;
    int w = h && h->w ? (int)h->w : 1280, hh = h && h->h ? (int)h->h : 800;
    *mx = (int)(x / p->lw * w), *my = (int)(y / (p->lh - BAR_H) * hh);
    return 1;
  }
  if (p->app != &gwin_app && p->app != &gchild_app) return 0;
  GWin *g = &wins[*(int *)p->state];
  float bw = (float)p->lw, bh = (float)(p->lh - (p->kind == PK_WINDOW ? BAR_H : 0));
  *mx = g->x + (int)(x / bw * g->w), *my = g->y + (int)(y / bh * g->h);
  return 1;
}

void gnome_poll(uint32_t now) {
  if (!B.pid && !B.dead && B.restart_at && (int32_t)(now - B.restart_at) >= 0) {
    B.restart_at = 0;
    spawn();
  }
  if (B.pid > 0) {
    int st;
    if (waitpid(B.pid, &st, WNOHANG) == B.pid) bridge_died();
  }
  while (B.evt >= 0) {
    if (B.blen < 0 || B.blen > 16384) B.blen = 0;
    ssize_t n = read(B.evt, B.buf + B.blen, 16384);
    if (n <= 0) break;
    B.blen += (int)n;
    B.buf[B.blen] = 0;
    char *start = B.buf, *nl;
    while ((nl = strchr(start, '\n'))) {
      *nl = 0;
      event(start);
      start = nl + 1;
    }
    B.blen -= (int)(start - B.buf);
    memmove(B.buf, start, (size_t)B.blen);
    if (B.blen >= (int)sizeof B.buf - 1) B.blen = 0;
  }

  for (int i = 1; i < BRIDGE_SLOTS; i++) {
    GWin *g = &wins[i];
    if (!g->used) continue;
    if (g->panel < 0) show_win(i);
    if (g->panel < 0) continue;
    BridgeHeader *h = bridge_slot(B.pool, i);
    if (h->seq != g->seq) g->seq = h->seq, P[g->panel].dirty = 1;
    if (g->child) place_child(g);
  }

  int hv = W.hover;
  if (hv >= 0 && P[hv].used && P[hv].app && B.ready) {
    Panel *p = &P[hv];
    float by = p->kind == PK_WINDOW ? W.ht - BAR_H : W.ht;
    int mx, my;
    if (by >= 0 && to_monitor(p, W.hs, by, &mx, &my) && (mx != last_mx || my != last_my)) {
      qsend("m %d %d\n", mx, my);
      last_mx = mx, last_my = my;
    }
  }
  qflush(now);
}

static void press_at(Panel *p, float x, float y, int button, int down, uint64_t raise) {
  int mx, my, code = button == 1 ? 272 : button == 3 ? 273 : 274;
  if (!to_monitor(p, x, y, &mx, &my)) return;
  if (down && raise && raise != last_raised) {
    qsend("raise %llu\n", (unsigned long long)raise);
    last_raised = raise;
    gate = now_ms() + RAISE_WAIT;
  }
  qsend("m %d %d\n", mx, my);
  last_mx = mx, last_my = my;
  qsend("b %d %d\n", code, down);
}

static void any_rawkey(Panel *p, int code, int down) {

  if (p->app == &gwin_app && down) {
    GWin *g = &wins[*(int *)p->state];
    if (g->id != last_raised) {
      qsend("raise %llu\n", (unsigned long long)g->id);
      last_raised = g->id;
      gate = now_ms() + RAISE_WAIT;
    }
  }
  qsend("k %d %d\n", code, down);
}

static void any_scroll(Panel *p, float x, float y, int steps) {
  int mx, my;
  if (to_monitor(p, x, y, &mx, &my)) qsend("m %d %d\n", mx, my);
  qsend("a %d\n", -steps);
}

static uint32_t *crop_buf;
static size_t crop_cap;

static void draw_frame(Surface *s, int slot, float x, float y, float w, float h, float r) {
  BridgeHeader *hd = B.pool ? bridge_slot(B.pool, slot) : NULL;
  if (!hd || !hd->seq || !hd->w || !hd->h) return;
  const uint32_t *px = (const uint32_t *)(hd + 1);
  int fw = (int)hd->w, fh = (int)hd->h;
  GWin *g = slot ? &wins[slot] : NULL;
  if (g && g->w > 0 && g->h > 0 && (fw > g->w + 2 || fh > g->h + 2)) {
    int cx = g->x, cy = g->y, cw = g->w, ch = g->h;
    if (cx < 0) cw += cx, cx = 0;
    if (cy < 0) ch += cy, cy = 0;
    if (cx + cw > fw) cw = fw - cx;
    if (cy + ch > fh) ch = fh - cy;
    if (cw > 0 && ch > 0) {
      size_t need = (size_t)cw * ch;
      if (need > crop_cap) {
        free(crop_buf);
        crop_buf = malloc(need * 4);
        crop_cap = crop_buf ? need : 0;
      }
      if (crop_buf) {
        for (int yy = 0; yy < ch; yy++) memcpy(crop_buf + (size_t)yy * cw, px + (size_t)(cy + yy) * fw + cx, (size_t)cw * 4);
        px = crop_buf, fw = cw, fh = ch;
      }
    }
  }
  if (slot && hd->pad[0]) gfx_blit_premul(s, px, fw, fh, x, y, w, h);
  else gfx_blit_bilinear(s, px, fw, fh, x, y, w, h, r);
}

static void gwin_draw(Panel *p, Surface *s, float ox, float oy) {
  int slot = *(int *)p->state;
  BridgeHeader *hd = B.pool ? bridge_slot(B.pool, slot) : NULL;
  float bw = (float)p->lw, bh = (float)(p->lh - BAR_H);
  if (!hd || !hd->seq) {
    gfx_text_c(s, F_UI, ox + bw * 0.5f, oy + bh * 0.5f - 10, "Opening...", C_MUTED);
    return;
  }
  draw_frame(s, slot, ox, oy, bw, bh, 10);
}

static void gwin_press(Panel *p, float x, float y, int button, int down) {
  press_at(p, x, y, button, down, wins[*(int *)p->state].id);
}

static int gwin_close_request(Panel *p) {
  qsend("close %llu\n", (unsigned long long)wins[*(int *)p->state].id);
  return 1;
}

App gwin_app = {"gnome-window", "Desktop window", IC_DESKTOP, 0, 0, NULL, gwin_draw, NULL, any_scroll, NULL, NULL,
                NULL, NULL, gwin_press, any_rawkey, gwin_close_request};

static void gchild_draw(Panel *p, Surface *s, float ox, float oy) {
  draw_frame(s, *(int *)p->state, ox, oy, (float)p->lw, (float)p->lh, 0);
}

static void gchild_press(Panel *p, float x, float y, int button, int down) { press_at(p, x, y, button, down, 0); }

App gchild_app = {"gnome-child", "", IC_DESKTOP, 0, 0, NULL, gchild_draw, NULL, any_scroll, NULL, NULL,
                  NULL, NULL, gchild_press, any_rawkey, NULL};

static void desk_open(Panel *p) {
  (void)p;
  gnome_desktop(1);
}

static void desk_close(Panel *p) {
  (void)p;
  gnome_desktop(0);
}

static void desk_draw(Panel *p, Surface *s, float ox, float oy) {
  float bw = (float)p->lw, bh = (float)(p->lh - BAR_H);
  BridgeHeader *hd = B.pool ? bridge_slot(B.pool, 0) : NULL;
  if (hd && hd->seq && hd->w && hd->h) {
    const uint32_t *view = desktop_view(hd);
    gfx_blit_bilinear(s, view ? view : (const uint32_t *)(hd + 1), (int)hd->w, (int)hd->h, ox, oy, bw, bh, 10);
    return;
  }
  gfx_rrect_band(s, ox, oy - BAR_H, bw, (float)p->lh, 10, oy, oy + bh, RGB(36, 14, 52));
  gfx_icon(s, IC_DESKTOP, ox + bw * 0.5f - 36, oy + bh * 0.5f - 96, 72);
  const char *t = B.dead ? "The Oreon desktop is not installed" : "Starting the Oreon desktop...";
  gfx_text_c(s, F_H1, ox + bw * 0.5f, oy + bh * 0.5f - 6, t, RGB(244, 240, 250));
  if (!B.dead)
    gfx_text_c(s, F_UI, ox + bw * 0.5f, oy + bh * 0.5f + 42,
               "The desktop starts in the background. The first start takes a while.", RGB(200, 190, 214));
}

static int desk_tick(Panel *p, uint32_t now) {
  (void)now;
  static uint32_t seen;
  BridgeHeader *hd = B.pool ? bridge_slot(B.pool, 0) : NULL;
  if (hd && hd->seq && hd->w && hd->h) keep_plate(hd, now);
  if (hd && hd->seq != seen) {
    seen = hd->seq;
    return 1;
  }
  (void)p;
  return 0;
}

static int desk_blocked;

static void desk_press(Panel *p, float x, float y, int button, int down) {
  int mx, my;
  if (down) {
    desk_blocked = to_monitor(p, x, y, &mx, &my) && in_hidden_win(mx, my);
    if (desk_blocked) return;
  } else if (desk_blocked) {
    desk_blocked = 0;
    return;
  }
  press_at(p, x, y, button, down, 0);
}

App desktop_app = {"desktop", "Oreon Desktop", IC_DESKTOP, 880, 590, desk_open, desk_draw, NULL, any_scroll, NULL,
                   NULL, desk_tick, desk_close, desk_press, any_rawkey, NULL};
