#include <fcntl.h>
#include <linux/input.h>
#include <linux/kd.h>
#include <math.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include "oreonvr.h"

int g_running = 1;
int g_dev;
static int tty_fd = -1;
static int headless;

uint32_t now_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint32_t)(ts.tv_sec * 1000u + ts.tv_nsec / 1000000u);
}

static void on_signal(int s) {
  (void)s;
  g_running = 0;
}

static void restore_tty(void) {
  if (tty_fd >= 0) {
    ioctl(tty_fd, KDSETMODE, KD_TEXT);
    tty_fd = -1;
  }
}

static char *script;
static int script_fail;

static Panel *panel_by_app(const char *id) {
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app && !strcmp(P[i].app->id, id)) return &P[i];
  return NULL;
}
static int script_wait;
static uint32_t script_until;
static int frame_no;

static int char_to_key(char c, int *shift) {
  static const char lo[] = "\0\0331234567890-=\0\0qwertyuiop[]\0\0asdfghjkl;'`\0\\zxcvbnm,./";
  static const char hi[] = "\0\0!@#$%^&*()_+\0\0QWERTYUIOP{}\0\0ASDFGHJKL:\"~\0|ZXCVBNM<>?";
  if (c == ' ') return *shift = 0, KEY_SPACE;
  if (c == '\n') return *shift = 0, KEY_ENTER;
  for (int i = 2; i < (int)sizeof lo - 1; i++) {
    if (lo[i] && lo[i] == c) return *shift = 0, i;
    if (hi[i] && hi[i] == c) return *shift = 1, i;
  }
  return 0;
}

static void script_step(void) {
  if (!script || script_wait-- > 0) return;
  if (script_until && (int32_t)(now_ms() - script_until) < 0) return;
  script_until = 0;
  while (script && *script) {
    char *end = strchr(script, ';');
    char cmd[512];
    int n = end ? (int)(end - script) : (int)strlen(script);
    if (n > 511) n = 511;
    memcpy(cmd, script, (size_t)n);
    cmd[n] = 0;
    script = end ? end + 1 : NULL;
    char *c = cmd;
    while (*c == ' ' || *c == '\n' || *c == '\t') c++;
    int a = 0, b = 0;
    char arg[480];
    if (sscanf(c, "move %d %d", &a, &b) == 2) input_pointer_move(a, b);
    else if (sscanf(c, "click %d %d", &a, &b) == 2) {
      input_pointer_move(a, b);
      input_button(1, 1);
      input_button(1, 0);
    } else if (sscanf(c, "down %d", &a) == 1) input_button(a, 1);
    else if (sscanf(c, "up %d", &a) == 1) input_button(a, 0);
    else if (sscanf(c, "wheel %d", &a) == 1) input_wheel(a);
    else if (sscanf(c, "keydown %d", &a) == 1) input_key(a, 1, 0);
    else if (sscanf(c, "keyup %d", &a) == 1) input_key(a, 0, 0);
    else if (sscanf(c, "key %d", &a) == 1) input_key(a, 1, 0), input_key(a, 0, 0);
    else if (!strncmp(c, "type ", 5)) {
      for (char *t = c + 5; *t; t++) {
        int sh = 0, k = char_to_key(*t == '|' && t[1] == 'n' ? (t++, '\n') : *t, &sh);
        if (!k) continue;
        if (sh) input_key(KEY_LEFTSHIFT, 1, 0);
        input_key(k, 1, 0), input_key(k, 0, 0);
        if (sh) input_key(KEY_LEFTSHIFT, 0, 0);
      }
    } else if (sscanf(c, "waitms %d", &a) == 1) {
      script_until = now_ms() + (uint32_t)a;
      return;
    } else if (sscanf(c, "wait %d", &a) == 1) {
      script_wait = a;
      return;
    } else if (!strncmp(c, "panels", 6)) {
      for (int i = 0; i < MAXP; i++)
        if (P[i].used)
          fprintf(stderr, "panel %d kind %d app %s vis %d pos %.0f %.0f %.0f yaw %.2f size %dx%d surf %dx%d\n", i,
                  P[i].kind, P[i].app ? P[i].app->id : "-", P[i].visible, P[i].x, P[i].y, P[i].z, P[i].yaw, P[i].lw,
                  P[i].lh, P[i].surf.w, P[i].surf.h);
    } else if (sscanf(c, "pshotr %63s %415s", arg, arg + 64) == 2) {
      Panel *p = panel_by_app(arg);
      FILE *f = p && p->surf_r.px ? fopen(arg + 64, "wb") : NULL;
      if (f) {
        fprintf(f, "P6\n%d %d\n255\n", p->surf_r.w, p->surf_r.h);
        for (int i = 0; i < p->surf_r.w * p->surf_r.h; i++) {
          uint32_t v = p->surf_r.px[i];
          unsigned char rgb[3] = {(unsigned char)(v >> 16), (unsigned char)(v >> 8), (unsigned char)v};
          fwrite(rgb, 1, 3, f);
        }
        fclose(f);
      }
    } else if (sscanf(c, "pshot %63s %415s", arg, arg + 64) == 2) {
      Panel *p = panel_by_app(arg);
      FILE *f = p ? fopen(arg + 64, "wb") : NULL;
      if (f) {
        if (p->dirty) panel_redraw(p);
        fprintf(f, "P6\n%d %d\n255\n", p->surf.w, p->surf.h);
        for (int i = 0; i < p->surf.w * p->surf.h; i++) {
          uint32_t v = p->surf.px[i], al = v >> 24;
          unsigned char rgb[3] = {(unsigned char)((v >> 16 & 255) + (255 - al) * 30 / 255), (unsigned char)((v >> 8 & 255) + (255 - al) * 34 / 255),
                                  (unsigned char)((v & 255) + (255 - al) * 40 / 255)};
          fwrite(rgb, 1, 3, f);
        }
        fclose(f);
      }
    } else if (sscanf(c, "shot %479s", arg) == 1) {
      out_headless_shot(arg);
      fprintf(stderr, "oreonvr: frame %d -> %s\n", frame_no, arg);
    } else if (!strncmp(c, "launch ", 7)) wl_launch(c + 7);
    else if (!strncmp(c, "play ", 5)) video_open_file(c + 5);
    else if (!strcmp(c, "lock")) lock_start();
    else if (sscanf(c, "vr %d", &a) == 1) W.vr = a;
    else if (sscanf(c, "lens %d", &a) == 1) W.lens = a;
    else if (sscanf(c, "open %479s", arg) == 1) panel_open_app(arg);
    else if (sscanf(c, "look %d %d", &a, &b) == 2) W.gyaw += a * 0.01f, W.gpitch += b * 0.01f;
    else if (sscanf(c, "tap %63s %d %d", arg, &a, &b) == 3) {
      Panel *p = panel_by_app(arg);
      int sx, sy;
      if (p && scene_panel_point(p, (float)a, (float)b, &sx, &sy)) {
        input_pointer_move(sx, sy);
        if (getenv("OREONVR_DEBUG")) {
          float d[3], s, t, dist;
          scene_pointer_ray(&d[0], &d[1], &d[2]);
          int hit = scene_pick(d[0], d[1], d[2], &s, &t, &dist);
          fprintf(stderr, "tap %s -> %d,%d hit %d (%s) at %.0f,%.0f\n", arg, sx, sy, hit, hit >= 0 ? P[hit].title : "-", s, t);
        }
        input_button(1, 1);
        input_button(1, 0);
      } else {
        fprintf(stderr, "oreonvr: tap: %s not visible\n", arg);
        script_fail = 1;
      }
    } else if (sscanf(c, "rtap %63s %d %d", arg, &a, &b) == 3) {
      Panel *p = panel_by_app(arg);
      int sx, sy;
      if (p && scene_panel_point(p, (float)a, (float)b, &sx, &sy)) {
        input_pointer_move(sx, sy);
        input_button(3, 1);
        input_button(3, 0);
      } else script_fail = 1;
    } else if (sscanf(c, "point %63s %d %d", arg, &a, &b) == 3) {
      Panel *p = panel_by_app(arg);
      int sx, sy;
      if (p && scene_panel_point(p, (float)a, (float)b, &sx, &sy)) input_pointer_move(sx, sy);
      else script_fail = 1;
    } else if (!strncmp(c, "grab ", 5)) {
      int dx = 0, dy = 0;
      Panel *p = sscanf(c, "grab %63s %d %d %d %d", arg, &a, &b, &dx, &dy) == 5 ? panel_by_app(arg) : NULL;
      int sx, sy;
      if (p && scene_panel_point(p, (float)a, (float)b, &sx, &sy)) {
        input_pointer_move(sx, sy);
        input_button(1, 1);
        for (int k = 1; k <= 8; k++) input_pointer_move(sx + dx * k / 8, sy + dy * k / 8);
        input_button(1, 0);
      } else script_fail = 1;
    } else if (!strncmp(c, "assert ", 7)) {
      int ok = 1;
      if (sscanf(c, "assert vr %d", &a) == 1) ok = W.vr == a;
      else if (sscanf(c, "assert lens %d", &a) == 1) ok = W.lens == a;
      else if (sscanf(c, "assert gnome %d", &a) == 1) ok = gnome_app_count() == a;
      else if (sscanf(c, "assert width %63s %d", arg, &a) == 2) {
        Panel *p = panel_by_app(arg);
        ok = p && p->lw == a;
      }
      else if (sscanf(c, "assert wedit %d", &a) == 1) ok = widgets_editing() == a;
      else if (sscanf(c, "assert wpage %d", &a) == 1) ok = widgets_page() == a;
      else if (sscanf(c, "assert locked %d", &a) == 1) ok = lock_active() == a;
      else if (sscanf(c, "assert wl %d", &a) == 1) ok = wl_surface_count() == a;
      else if (sscanf(c, "assert vframes %d", &a) == 1) ok = video_frames_shown() >= a;
      else if (sscanf(c, "assert open %63s %d", arg, &a) == 2) ok = (panel_by_app(arg) != NULL) == a;
      else if (sscanf(c, "assert focus %63s", arg) == 1)
        ok = W.focus >= 0 && P[W.focus].app && !strcmp(P[W.focus].app->id, arg);
      else if (sscanf(c, "assert near %63s %d", arg, &a) == 2) {
        Panel *p = panel_by_app(arg);
        ok = p && hypotf(hypotf(p->x - W.gx, p->y - W.gy), p->z - W.gz) <= a;
      } else if (sscanf(c, "assert far %63s %d", arg, &a) == 2) {
        Panel *p = panel_by_app(arg);
        ok = p && hypotf(hypotf(p->x - W.gx, p->y - W.gy), p->z - W.gz) >= a;
      }
      if (!ok) {
        fprintf(stderr, "oreonvr: FAILED %s\n", c);
        script_fail = 1;
      }
    } else if (!strncmp(c, "quit", 4)) g_running = 0;
  }
}

static void load_sky(const char *arg) {
  char exe[512] = {0}, buf[700];
  ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
  if (n > 0) {
    char *sl = strrchr(exe, '/');
    if (sl) *sl = 0;
  }
  const char *cand[8] = {arg, getenv("OREONVR_SKY"), "/usr/share/oreonvr/sky.ppm", "/usr/share/oreonvr/sky.jpg"};
  int k = 4;
  static char p1[700], p2[700];
  snprintf(p1, sizeof p1, "%s/res/sky.ppm", exe);
  snprintf(p2, sizeof p2, "%s/res/sky.jpg", exe);
  cand[k++] = p1, cand[k++] = p2;
  for (int i = 0; i < k; i++) {
    if (!cand[i] || !*cand[i]) continue;
    snprintf(buf, sizeof buf, "%s", cand[i]);
    if (access(buf, R_OK)) continue;
    if (scene_load_sky(buf)) {
      fprintf(stderr, "oreonvr: sky %s\n", buf);
      return;
    }
  }
  fprintf(stderr, "oreonvr: no sky image, using plain backdrop\n");
}

static void update_hover(void) {
  float d[3], s = 0, t = 0, dist;
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  int i = scene_pick(d[0], d[1], d[2], &s, &t, &dist);
  int zone = i >= 0 ? panel_zone(&P[i], s, t) : 0;
  int old = W.hover;
  if (old != i || (i >= 0 && P[i].zone != zone)) {
    if (old >= 0 && P[old].used) P[old].dirty = 1;
    if (i >= 0) P[i].dirty = 1;
  }
  W.hover = i, W.hs = s, W.ht = t, W.hdist = dist;
  if (i >= 0) P[i].zone = zone;
}

static int settled(void) {
  return fabsf(W.gyaw - W.yaw) < 1e-4f && fabsf(W.gpitch - W.pitch) < 1e-4f && fabsf(W.gx - W.cx) < 0.05f &&
         fabsf(W.gy - W.cy) < 0.05f && fabsf(W.gz - W.cz) < 0.05f;
}

int main(int argc, char **argv) {
  int ww = 1280, wh = 800, window = 0, vr = 0;
  const char *sky_arg = NULL;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--window") || !strcmp(argv[i], "--headless")) {
      if (!strcmp(argv[i], "--window")) window = 1;
      else headless = 1;
      if (i + 1 < argc && sscanf(argv[i + 1], "%dx%d", &ww, &wh) == 2) i++;
    } else if (!strcmp(argv[i], "--script") && i + 1 < argc) script = argv[++i];
    else if (!strcmp(argv[i], "--vr")) vr = 1;
    else if (!strcmp(argv[i], "--sky") && i + 1 < argc) sky_arg = argv[++i];
    else {
      fprintf(stderr, "usage: %s [--window WxH | --headless WxH [--script CMDS]] [--vr] [--sky FILE]\n", argv[0]);
      return 2;
    }
  }
  g_dev = window || headless;
  signal(SIGINT, on_signal);
  signal(SIGTERM, on_signal);
  signal(SIGPIPE, SIG_IGN);

  Output out = {0};
  int ok = 0;
  if (headless) ok = out_headless(&out, ww, wh);
  else if (window) ok = out_sdl(&out, ww, wh);
  else ok = out_drm(&out) || out_fbdev(&out);
  if (!ok) {
    fprintf(stderr, "oreonvr: no display (%s)\n", window ? "SDL" : "DRM/fbdev");
    return 1;
  }
  if (!g_dev) {
    tty_fd = isatty(0) ? 0 : open("/dev/tty1", O_RDWR | O_CLOEXEC);
    if (tty_fd >= 0 && ioctl(tty_fd, KDSETMODE, KD_GRAPHICS)) tty_fd = -1;
    atexit(restore_tty);
    evdev_open_all();
    fprintf(stderr, "oreonvr: %d input devices\n", evdev_fd_count());
  }

  scene_init();

  const char *ev = getenv("OREONVR_VR"), *el = getenv("OREONVR_LENS"), *ei = getenv("OREONVR_IPD");
  W.vr = vr || (ev && atoi(ev));
  if (el) W.lens = atoi(el) != 0;
  if (ei && atof(ei) > 40 && atof(ei) < 90) W.ipd = (float)atof(ei);
  W.backend = out.name;
  W.out_w = out.w, W.out_h = out.h;
  W.mx = out.w / 2, W.my = out.h / 2;
  load_sky(sky_arg);
  bg_restore();
  dock_init();

  widgets_init();
  const char *ew = getenv("OREONVR_WELCOME");
  int a = (ew && atoi(ew)) || !widgets_enabled_count() ? panel_open_app("welcome") : -1;
  if (a >= 0) P[a].x = 0, P[a].y = 96, P[a].z = -20, P[a].yaw = 0, P[a].tilt = 0, P[a].appear = 1;
  gnome_init();
  wl_init();
  W.focus = -1;

  uint32_t last = now_ms(), fps_t = last;
  int frames = 0, need = 1;
  int last_mx = -1, last_my = -1, last_vr = -1, last_lens = -1, last_sky = -1, last_bg = -1;
  while (g_running) {
    if (!out.pump()) break;
    if (!g_dev) evdev_poll();
    if (headless) script_step();
    uint32_t now = now_ms();
    float dt = headless ? 1.f / 60.f : (now - last) / 1000.f;
    if (dt > 0.1f) dt = 0.1f;
    last = now;

    scene_tick(dt);
    dock_follow(dt, 0);
    update_hover();
    gnome_poll(now);
    wl_poll(now);
    widgets_tick(now);

    for (int i = 0; i < MAXP; i++) {
      Panel *p = &P[i];
      if (p->used && p->app && p->app->tick && p->app->tick(p, now)) p->dirty = 1;
    }
    for (int i = 0; i < MAXP; i++) {
      Panel *p = &P[i];
      if (p->used && p->dirty) {
        panel_redraw(p);
        need = 1;
      }
      if (p->used && p->appear < 1.f) need = 1;
    }
    if (widgets_animating()) need = 1;
    if (OV.draw && OV.dirty) need = 1, OV.dirty = 0;
    if (W.mx != last_mx || W.my != last_my || W.vr != last_vr || W.lens != last_lens || W.sky_on != last_sky || W.bg_gen != last_bg ||
        !settled())
      need = 1;
    last_mx = W.mx, last_my = W.my, last_vr = W.vr, last_lens = W.lens, last_sky = W.sky_on, last_bg = W.bg_gen;

    if (need || headless) {
      int stride;
      uint32_t *px = out.begin(&stride);
      Surface s;
      surf_wrap(&s, px, out.w, out.h, stride);
      scene_render(&s);
      out.end();
      frames++;
      need = 0;
    } else {
      usleep(8000);
    }
    if (now - fps_t >= 1000) {
      W.fps = frames * 1000.f / (now - fps_t);
      frames = 0, fps_t = now;
    }
    frame_no++;
    if (headless && !script) break;
  }
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].kind == PK_WINDOW) panel_close(i);
  out.shutdown();
  restore_tty();
  return script_fail;
}
