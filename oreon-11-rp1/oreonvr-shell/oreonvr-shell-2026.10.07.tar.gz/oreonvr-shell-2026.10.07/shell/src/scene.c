#include <math.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "oreonvr.h"
#include "store.h"

World W;
Panel P[MAXP];
Overlay OV;

static uint32_t *sky;
static int skw, skh;
static int bg_kind; /* 0 sky image, 1 flat colour, 2 vertical gradient */
static uint32_t bg_c1, bg_c2;
static char sky_boot[700];

#define START_Y 36.f
#define START_Z 880.f
#define FLAT_VFOV (48.f * PI_F / 180.f)
#define NEAR_Z 12.f

typedef struct {
  float ex, ey, ez;
  float f[3], r[3], u[3];
  float foc, cx, cy;
  int eye;
} View;

static Surface eye[2];
static int *lens_lut;
static int lut_w, lut_h, lut_on;

void scene_basis(float yaw, float pitch, float *f, float *r, float *u) {
  float cp = cosf(pitch), sp = sinf(pitch), cy = cosf(yaw), sy = sinf(yaw);
  f[0] = sy * cp, f[1] = sp, f[2] = -cy * cp;
  r[0] = cy, r[1] = 0, r[2] = sy;
  u[0] = -sy * sp, u[1] = cp, u[2] = cy * sp;
}

static inline float dot3(const float *a, const float *b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

void scene_recenter(void) {
  W.gx = 0, W.gy = START_Y, W.gz = START_Z;
  W.gyaw = 0, W.gpitch = -0.032f;
}

void scene_init(void) {
  memset(&W, 0, sizeof W);
  memset(P, 0, sizeof P);
  scene_recenter();
  W.cx = W.gx, W.cy = W.gy, W.cz = W.gz, W.yaw = W.gyaw, W.pitch = W.gpitch;
  W.ipd = 64.f;
  W.sens = 1.f;
  W.lens = 1;
  W.sky_on = 1;
  W.sky_yaw = 0.62f;
  W.hover = -1;
  W.focus = -1;
}

static float aces_fit(float v) {
  float a = v * (v + 0.0245786f) - 0.000090537f;
  float b = v * (0.983729f * v + 0.4329510f) + 0.238081f;
  return a / b;
}

static void tonemap(const unsigned char *rgb, uint32_t *px, int n) {
  float lin[256];
  for (int i = 0; i < 256; i++) {
    float c = i / 255.f;
    lin[i] = c <= 0.04045f ? c / 12.92f : powf((c + 0.055f) / 1.055f, 2.4f);
  }
  enum { ENC = 4096 };
  static unsigned char enc[ENC + 1];
  for (int i = 0; i <= ENC; i++) {
    float c = (float)i / ENC;
    c = c <= 0.0031308f ? c * 12.92f : 1.055f * powf(c, 1.f / 2.4f) - 0.055f;
    enc[i] = (unsigned char)(c * 255.f + 0.5f);
  }
  const float ex = 0.8f / 0.6f;
  for (int i = 0; i < n; i++) {
    float r = lin[rgb[i * 3]] * ex, g = lin[rgb[i * 3 + 1]] * ex, b = lin[rgb[i * 3 + 2]] * ex;
    float r1 = 0.59719f * r + 0.35458f * g + 0.04823f * b;
    float g1 = 0.07600f * r + 0.90834f * g + 0.01566f * b;
    float b1 = 0.02840f * r + 0.13383f * g + 0.83777f * b;
    r1 = aces_fit(r1), g1 = aces_fit(g1), b1 = aces_fit(b1);
    float o[3] = {1.60475f * r1 - 0.53108f * g1 - 0.07367f * b1, -0.10208f * r1 + 1.10813f * g1 - 0.00605f * b1,
                  -0.00327f * r1 - 0.07276f * g1 + 1.07602f * b1};
    int q[3];
    for (int k = 0; k < 3; k++) {
      float v = o[k] < 0.f ? 0.f : o[k] > 1.f ? 1.f : o[k];
      q[k] = enc[(int)(v * ENC + 0.5f)];
    }
    px[i] = RGB(q[0], q[1], q[2]);
  }
}

static int read_ppm(FILE *f) {
  char magic[3] = {0};
  int w, h, maxv;
  if (fscanf(f, "%2s", magic) != 1 || strcmp(magic, "P6")) return 0;

  int c;
  int vals[3], nv = 0;
  while (nv < 3) {
    c = fgetc(f);
    if (c == EOF) return 0;
    if (c == '#') {
      while ((c = fgetc(f)) != '\n' && c != EOF) {
      }
      continue;
    }
    if (c >= '0' && c <= '9') {
      ungetc(c, f);
      if (fscanf(f, "%d", &vals[nv]) != 1) return 0;
      nv++;
    }
  }
  w = vals[0], h = vals[1], maxv = vals[2];
  fgetc(f);
  if (w <= 0 || h <= 0 || maxv != 255) return 0;
  unsigned char *rgb = malloc((size_t)w * h * 3);
  uint32_t *px = malloc((size_t)w * h * 4);
  if (!rgb || !px || fread(rgb, 3, (size_t)w * h, f) != (size_t)w * h) {
    free(rgb);
    free(px);
    return 0;
  }
  tonemap(rgb, px, w * h);
  free(rgb);
  free(sky);
  sky = px, skw = w, skh = h;
  return 1;
}

int scene_load_sky(const char *path) {
  if (!path) return 0;
  size_t n = strlen(path);
  int ok = 0;
  if (n > 4 && (!strcmp(path + n - 4, ".jpg") || !strcmp(path + n - 5, ".jpeg"))) {

    char cmd[1024];
    snprintf(cmd, sizeof cmd, "djpeg -pnm '%s' 2>/dev/null", path);
    FILE *f = popen(cmd, "r");
    if (f) {
      ok = read_ppm(f);
      pclose(f);
    }
  } else {
    FILE *f = fopen(path, "rb");
    if (f) {
      ok = read_ppm(f);
      fclose(f);
    }
  }
  if (ok) {
    bg_kind = 0;
    W.sky_yaw = 0.62f;
    if (!sky_boot[0]) snprintf(sky_boot, sizeof sky_boot, "%s", path);
    W.bg_gen++;
  }
  return ok;
}

const char *scene_sky_path(void) { return sky_boot; }

void scene_bg_solid(uint32_t c) {
  bg_kind = 1, bg_c1 = c;
  W.bg_gen++;
}

void scene_bg_gradient(uint32_t top, uint32_t bottom) {
  bg_kind = 2, bg_c1 = top, bg_c2 = bottom;
  W.bg_gen++;
}

static inline float fatan2(float y, float x) {
  float ax = fabsf(x), ay = fabsf(y);
  float mn = ax < ay ? ax : ay, mx = ax < ay ? ay : ax;
  float a = mn / (mx + 1e-20f), s = a * a;
  float r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a;
  if (ay > ax) r = 1.57079637f - r;
  if (x < 0) r = 3.14159274f - r;
  if (y < 0) r = -r;
  return r;
}

static inline uint32_t lerp_px(uint32_t a, uint32_t b, uint32_t w) {
  uint32_t rb = ((((a & 0xff00ff) * (256 - w)) + ((b & 0xff00ff) * w)) >> 8) & 0xff00ff;
  uint32_t g = ((((a & 0x00ff00) * (256 - w)) + ((b & 0x00ff00) * w)) >> 8) & 0x00ff00;
  return rb | g;
}

#define PANO_W 2048
#define PANO_H 1024

static uint32_t bilerp(const uint32_t *s, int w, int h, float fx, float fy) {
  int x0 = (int)fx, y0 = (int)fy, x1 = x0 + 1 < w ? x0 + 1 : x0, y1 = y0 + 1 < h ? y0 + 1 : y0;
  uint32_t wx = (uint32_t)((fx - x0) * 255.f), wy = (uint32_t)((fy - y0) * 255.f);
  return lerp_px(lerp_px(s[y0 * w + x0], s[y0 * w + x1], wx), lerp_px(s[y1 * w + x0], s[y1 * w + x1], wx), wy) | 0xff000000u;
}

/* A normal photo is not a 360 panorama, so lay it out as three mirrored tiles around the viewer, with the
   edges faded into a flat colour above and below. The middle tile faces the viewer (sky_yaw 0). */
static uint32_t *flat_to_pano(uint32_t *src, int w, int h) {
  const int tw = PANO_W / 3;
  float sc = fminf((float)tw / w, PANO_H * 0.8f / h);
  int iw = (int)(w * sc), ih = (int)(h * sc);
  if (iw < 1 || ih < 1) return NULL;
  uint32_t *tmp = NULL;
  if (iw * 2 < w && ih * 2 < h) {
    tmp = img_shrink(src, w, h, iw * 2, ih * 2);
    if (!tmp) return NULL;
    src = tmp, w = iw * 2, h = ih * 2;
  }
  uint32_t *tile = malloc((size_t)iw * ih * 4), *out = malloc((size_t)PANO_W * PANO_H * 4);
  if (!tile || !out) {
    free(tile), free(out), free(tmp);
    return NULL;
  }
  for (int y = 0; y < ih; y++) {
    float fy = (y + 0.5f) * h / ih - 0.5f;
    for (int x = 0; x < iw; x++) {
      float fx = (x + 0.5f) * w / iw - 0.5f;
      tile[y * iw + x] = bilerp(src, w, h, fx < 0 ? 0 : fx, fy < 0 ? 0 : fy);
    }
  }
  uint32_t ar = 0, ag = 0, ab = 0, br = 0, bg = 0, bb = 0;
  for (int x = 0; x < iw; x++) {
    uint32_t a = tile[x], b = tile[(ih - 1) * iw + x];
    ar += a >> 16 & 255, ag += a >> 8 & 255, ab += a & 255, br += b >> 16 & 255, bg += b >> 8 & 255, bb += b & 255;
  }
  uint32_t top = RGB(ar / iw, ag / iw, ab / iw), bot = RGB(br / iw, bg / iw, bb / iw);
  const int y0 = (PANO_H - ih) / 2;
  for (int cx = 0; cx < PANO_W; cx++) {
    int k = cx / tw > 2 ? 2 : cx / tw, lx = cx - k * tw;
    if (k != 1) lx = tw - 1 - lx;
    int tx = lx - (tw - iw) / 2;
    tx = tx < 0 ? 0 : tx >= iw ? iw - 1 : tx;
    for (int cy = 0; cy < PANO_H; cy++) {
      uint32_t c;
      if (cy < y0) c = lerp_px(tile[tx], top, cy > y0 - 90 ? (uint32_t)((y0 - cy) * 255 / 90 > 255 ? 255 : (y0 - cy) * 255 / 90) : 255);
      else if (cy >= y0 + ih) c = lerp_px(tile[(ih - 1) * iw + tx], bot, cy < y0 + ih + 90 ? (uint32_t)((cy - y0 - ih + 1) * 255 / 90) : 255);
      else c = tile[(cy - y0) * iw + tx];
      out[(size_t)cy * PANO_W + cx] = c | 0xff000000u;
    }
  }
  free(tile), free(tmp);
  return out;
}

/* Load a wallpaper (JPEG or PNG). Wide 2:1 images are treated as 360 panoramas, anything else as a flat picture. */
int scene_load_image(const char *path) {
  int w = 0, h = 0;
  uint32_t *px = img_decode_file(path, &w, &h);
  if (!px || w < 2 || h < 2) {
    free(px);
    return 0;
  }
  float yaw = 0.62f;
  if (w * 10 < h * 19) {
    uint32_t *p2 = flat_to_pano(px, w, h);
    free(px);
    if (!p2) return 0;
    px = p2, w = PANO_W, h = PANO_H, yaw = 0.f;
  } else if (w > 4096) {
    int nh = (int)((int64_t)h * 4096 / w);
    uint32_t *p2 = img_shrink(px, w, h, 4096, nh > 0 ? nh : 1);
    free(px);
    if (!p2) return 0;
    px = p2, w = 4096, h = nh > 0 ? nh : 1;
  }
  free(sky);
  sky = px, skw = w, skh = h;
  W.sky_yaw = yaw;
  bg_kind = 0;
  W.bg_gen++;
  return 1;
}

static void draw_sky(Surface *s, const View *v, int ya, int yb) {
  if (bg_kind) {
    for (int y = ya; y < yb; y++) {
      uint32_t c = bg_c1;
      if (bg_kind == 2) {
        float k = ((v->cy - (y + 0.5f)) / v->foc) * v->u[1] + v->f[1];
        int w = (int)((k * 0.8f + 0.5f) * 255.f);
        c = lerp_px(bg_c2, bg_c1, w < 0 ? 0 : w > 255 ? 255 : (uint32_t)w) | 0xff000000u;
      }
      uint32_t *row = s->px + (size_t)y * s->stride;
      for (int x = 0; x < s->w; x++) row[x] = c;
    }
    return;
  }
  if (!sky || !W.sky_on) {

    for (int y = ya; y < yb; y++) {
      float dy = ((v->cy - (y + 0.5f)) / v->foc);
      float k = dy * v->u[1] + v->f[1];
      int t = (int)(k * 60.f);
      uint32_t c = RGB(138 + t / 3, 163 + t / 4, 176 + t / 5);
      uint32_t *row = s->px + (size_t)y * s->stride;
      for (int x = 0; x < s->w; x++) row[x] = c;
    }
    return;
  }
  const float iu = (float)skw / (2.f * PI_F), iv = (float)skh / PI_F;
  const float yaw0 = W.sky_yaw * (float)skw;
  enum { STEP = 4 };
  for (int y = ya; y < yb; y++) {
    float ny = (v->cy - (y + 0.5f)) / v->foc;
    float bx = v->f[0] + ny * v->u[0], by = v->f[1] + ny * v->u[1], bz = v->f[2] + ny * v->u[2];
    uint32_t *row = s->px + (size_t)y * s->stride;
    float pu = 0, pv = 0;
    for (int x = 0; x <= s->w; x += STEP) {
      float nx = ((x + 0.5f) - v->cx) / v->foc;
      float dx = bx + nx * v->r[0], dy = by, dz = bz + nx * v->r[2];
      float uu = fatan2(dx, -dz) * iu + skw * 0.5f + yaw0;
      float vv = (skh * 0.5f) - fatan2(dy, sqrtf(dx * dx + dz * dz)) * iv;
      if (x > 0) {
        float du = uu - pu;
        if (du > skw * 0.5f) uu -= skw;
        else if (du < -skw * 0.5f) uu += skw;
        float su = (uu - pu) / STEP, sv = (vv - pv) / STEP;
        float cu = pu, cv = pv;
        int xe = x < s->w ? x : s->w;
        for (int i = x - STEP; i < xe; i++) {
          int iu8 = (int)(cu * 256.f), iv8 = (int)(cv * 256.f);
          int x0 = iu8 >> 8, y0 = iv8 >> 8;
          uint32_t fx = (uint32_t)(iu8 & 255), fy = (uint32_t)(iv8 & 255);
          x0 %= skw;
          if (x0 < 0) x0 += skw;
          int x1 = x0 + 1 == skw ? 0 : x0 + 1;
          if (y0 < 0) y0 = 0, fy = 0;
          if (y0 >= skh - 1) y0 = skh - 2, fy = 255;
          const uint32_t *r0 = sky + (size_t)y0 * skw, *r1 = r0 + skw;
          uint32_t a = lerp_px(r0[x0], r0[x1], fx), b = lerp_px(r1[x0], r1[x1], fx);
          row[i] = 0xff000000u | lerp_px(a, b, fy);
          cu += su, cv += sv;
        }
      }
      pu = uu, pv = vv;
    }
  }
}

static void panel_size(const Panel *p, float *pw, float *ph) {
  float a = p->appear;
  float k = 0.94f + 0.06f * a;
  *pw = (float)p->surf.w / SCALE * WORLD_PER_PX * k;
  *ph = (float)p->surf.h / SCALE * WORLD_PER_PX * k;
}

static void panel_axes(const Panel *p, float *pr, float *pu, float *n) {
  float ca = cosf(p->yaw), sa = sinf(p->yaw), ct = cosf(p->tilt), st = sinf(p->tilt);
  pr[0] = ca, pr[1] = 0, pr[2] = sa;
  pu[0] = -sa * st, pu[1] = ct, pu[2] = ca * st;
  n[0] = pr[1] * pu[2] - pr[2] * pu[1];
  n[1] = pr[2] * pu[0] - pr[0] * pu[2];
  n[2] = pr[0] * pu[1] - pr[1] * pu[0];
}

static int project(const View *v, const float *pt, float *sx, float *sy) {
  float d[3] = {pt[0] - v->ex, pt[1] - v->ey, pt[2] - v->ez};
  float z = dot3(d, v->f);
  if (z < NEAR_Z) return 0;
  *sx = v->cx + dot3(d, v->r) * v->foc / z;
  *sy = v->cy - dot3(d, v->u) * v->foc / z;
  return 1;
}

static void draw_panel(Surface *dst, const View *v, Panel *p, int ya, int yb) {
  if (!p->surf.px) return;
  float pw, ph, pr[3], pu[3], n[3];
  panel_size(p, &pw, &ph);
  panel_axes(p, pr, pu, n);
  float O[3], ex[3], ey[3];
  for (int i = 0; i < 3; i++) {
    O[i] = (i == 0 ? p->x : i == 1 ? p->y : p->z) - pr[i] * pw * 0.5f + pu[i] * ph * 0.5f;
    ex[i] = pr[i] * pw / (float)p->surf.w;
    ey[i] = -pu[i] * ph / (float)p->surf.h;
  }
  float EO[3] = {v->ex - O[0], v->ey - O[1], v->ez - O[2]};
  float N = -dot3(n, EO);
  if (N >= 0.f) return;

  float bx0 = 1e9f, by0 = 1e9f, bx1 = -1e9f, by1 = -1e9f;
  int all = 1;
  for (int c = 0; c < 4; c++) {
    float pt[3], sx, sy;
    float a = (c & 1) ? (float)p->surf.w : 0.f, b = (c & 2) ? (float)p->surf.h : 0.f;
    for (int i = 0; i < 3; i++) pt[i] = O[i] + ex[i] * a + ey[i] * b;
    if (!project(v, pt, &sx, &sy)) {
      all = 0;
      break;
    }
    bx0 = fminf(bx0, sx), by0 = fminf(by0, sy), bx1 = fmaxf(bx1, sx), by1 = fmaxf(by1, sy);
  }
  int X0 = 0, Y0 = ya, X1 = dst->w, Y1 = yb;
  if (all) {
    X0 = (int)floorf(bx0) - 1, Y0 = (int)floorf(by0) - 1, X1 = (int)ceilf(bx1) + 1, Y1 = (int)ceilf(by1) + 1;
    if (X0 < 0) X0 = 0;
    if (Y0 < ya) Y0 = ya;
    if (X1 > dst->w) X1 = dst->w;
    if (Y1 > yb) Y1 = yb;
  }
  if (X0 >= X1 || Y0 >= Y1) return;

  float iF = 1.f / v->foc;
  float nf = dot3(n, v->f), nr = dot3(n, v->r), nu = dot3(n, v->u);
  float xf = dot3(ex, v->f), xr = dot3(ex, v->r), xu = dot3(ex, v->u);
  float yf = dot3(ey, v->f), yr = dot3(ey, v->r), yu = dot3(ey, v->u);
  float ex2 = dot3(ex, ex), ey2 = dot3(ey, ey);
  float eox = dot3(EO, ex), eoy = dot3(EO, ey);

#define LIN(cf, cr, cu, A, Bx, By)                \
  float A = (cf) - ((v->cx) * iF) * (cr) + ((v->cy) * iF) * (cu); \
  float Bx = iF * (cr), By = -iF * (cu);
  LIN(nf, nr, nu, D0, Dx, Dy)
  LIN(xf, xr, xu, X0c, Xx, Xy)
  LIN(yf, yr, yu, Y0c, Yx, Yy)
#undef LIN
  float S0 = (eox * D0 + N * X0c) / ex2, Sx = (eox * Dx + N * Xx) / ex2, Sy = (eox * Dy + N * Xy) / ex2;
  float T0 = (eoy * D0 + N * Y0c) / ey2, Tx = (eoy * Dx + N * Yx) / ey2, Ty = (eoy * Dy + N * Yy) / ey2;

  const Surface *S = v->eye && p->surf_r.px && p->surf_r.w == p->surf.w && p->surf_r.h == p->surf.h ? &p->surf_r : &p->surf;
  const int sw = S->w, sh = S->h, ss = S->stride;
  const uint32_t *src = S->px;
  const uint32_t ga = (uint32_t)(p->appear * 256.f);
  for (int y = Y0; y < Y1; y++) {
    float fy = y + 0.5f, fx = X0 + 0.5f;
    float D = D0 + Dx * fx + Dy * fy, S = S0 + Sx * fx + Sy * fy, T = T0 + Tx * fx + Ty * fy;
    uint32_t *row = dst->px + (size_t)y * dst->stride;
    for (int x = X0; x < X1; x++, D += Dx, S += Sx, T += Tx) {
      if (D > -1e-6f) continue;
      float id = 1.f / D;
      float s = S * id - 0.5f, t = T * id - 0.5f;
      if (s < -1.f || t < -1.f || s >= sw || t >= sh) continue;
      int si = (int)((s + 1.f) * 256.f) - 256, ti = (int)((t + 1.f) * 256.f) - 256;
      int x0 = si >> 8, y0 = ti >> 8;
      uint32_t fxw = (uint32_t)(si & 255), fyw = (uint32_t)(ti & 255);
      int x1 = x0 + 1, y1 = y0 + 1;
      if (x0 < 0) x0 = 0;
      if (y0 < 0) y0 = 0;
      if (x1 >= sw) x1 = sw - 1;
      if (y1 >= sh) y1 = sh - 1;
      const uint32_t *r0 = src + (size_t)y0 * ss, *r1 = src + (size_t)y1 * ss;
      uint32_t a = r0[x0], b = r0[x1], c = r1[x0], d = r1[x1];
      if (!(a | b | c | d)) continue;

      uint32_t w00 = (256 - fxw) * (256 - fyw) >> 8, w10 = fxw * (256 - fyw) >> 8;
      uint32_t w01 = (256 - fxw) * fyw >> 8, w11 = fxw * fyw >> 8;
      uint32_t ag = (((a >> 8) & 0xff00ff) * w00 + ((b >> 8) & 0xff00ff) * w10 + ((c >> 8) & 0xff00ff) * w01 +
                     ((d >> 8) & 0xff00ff) * w11) >> 8;
      uint32_t rb = ((a & 0xff00ff) * w00 + (b & 0xff00ff) * w10 + (c & 0xff00ff) * w01 + (d & 0xff00ff) * w11) >> 8;
      ag &= 0xff00ff, rb &= 0xff00ff;
      if (ga < 256) {
        ag = ((ag * ga) >> 8) & 0xff00ff;
        rb = ((rb * ga) >> 8) & 0xff00ff;
      }
      uint32_t sa = ag >> 16;
      if (!sa) continue;
      uint32_t o = row[x];
      uint32_t ia = 256 - sa - (sa >> 7);
      uint32_t orb = ((o & 0xff00ff) * ia >> 8) & 0xff00ff, og = ((o & 0x00ff00) * ia >> 8) & 0x00ff00;
      uint32_t r = (orb >> 16) + (rb >> 16), g = (og >> 8) + (ag & 255), bb = (orb & 255) + (rb & 255);
      if (r > 255) r = 255;
      if (g > 255) g = 255;
      if (bb > 255) bb = 255;
      row[x] = 0xff000000u | (r << 16) | (g << 8) | bb;
    }
  }
}

static int draw_order(float ex, float ey, float ez, int *order) {
  int n = 0;
  float dist[MAXP];
  for (int i = 0; i < MAXP; i++) {
    if (!P[i].used || !P[i].visible) continue;
    float dx = P[i].x - ex, dy = P[i].y - ey, dz = P[i].z - ez;

    dist[i] = P[i].kind == PK_DOCK ? -1.f : dx * dx + dy * dy + dz * dz;
    order[n++] = i;
  }

  for (int k = 0; k < n; k++) {
    Panel *c = &P[order[k]];
    if (c->kind == PK_CHILD && c->parent >= 0 && c->parent < MAXP && P[c->parent].used)
      dist[order[k]] = dist[c->parent];
  }
  for (int a = 1; a < n; a++)
    for (int b = a; b > 0; b--) {
      int i = order[b - 1], j = order[b];
      float di = dist[i], dj = dist[j];

      int cj = P[j].kind == PK_CHILD, ci = P[i].kind == PK_CHILD;
      int tie = fabsf(dj - di) <= di * 0.02f;
      int swap = dj > di * 1.02f || (tie && (cj < ci || (cj == ci && P[j].seq < P[i].seq)));
      if (!swap) break;
      order[b - 1] = j, order[b] = i;
    }
  return n;
}

static float eye_hfov(void) { return (W.lens ? 100.f : 80.f) * PI_F / 180.f; }

void scene_pointer_ray(float *dx, float *dy, float *dz) {
  float f[3], r[3], u[3];
  scene_basis(W.yaw, W.pitch, f, r, u);
  float nx, ny;
  if (!W.vr) {
    float foc = (W.out_h * 0.5f) / tanf(FLAT_VFOV * 0.5f);
    nx = (W.mx + 0.5f - W.out_w * 0.5f) / foc;
    ny = (W.out_h * 0.5f - (W.my + 0.5f)) / foc;
  } else {
    float ew = W.out_w * 0.5f, eh = (float)W.out_h;
    float t = tanf(eye_hfov() * 0.5f);
    nx = ((W.mx + 0.5f) / W.out_w * 2.f - 1.f) * t;
    ny = (1.f - (W.my + 0.5f) / W.out_h * 2.f) * t * (eh / ew);
  }
  float d[3];
  for (int i = 0; i < 3; i++) d[i] = f[i] + nx * r[i] + ny * u[i];
  float l = sqrtf(dot3(d, d));
  *dx = d[0] / l, *dy = d[1] / l, *dz = d[2] / l;
}

int scene_pick(float dx, float dy, float dz, float *s, float *t, float *dist) {
  float best = 1e30f;
  int hit = -1;
  float d[3] = {dx, dy, dz}, E[3] = {W.cx, W.cy, W.cz};
  int order[MAXP], n = draw_order(W.cx, W.cy, W.cz, order);
  for (int k = n - 1; k >= 0 && hit < 0; k--) {
    int i = order[k];
    Panel *p = &P[i];
    if (p->appear < 0.3f) continue;
    float pw, ph, pr[3], pu[3], n[3];
    panel_size(p, &pw, &ph);
    panel_axes(p, pr, pu, n);
    float C[3] = {p->x, p->y, p->z};
    float dn = dot3(d, n);
    if (dn > -1e-5f) continue;
    float CE[3] = {C[0] - E[0], C[1] - E[1], C[2] - E[2]};
    float lam = dot3(CE, n) / dn;
    if (lam <= NEAR_Z) continue;
    float H[3] = {E[0] + d[0] * lam - C[0], E[1] + d[1] * lam - C[1], E[2] + d[2] * lam - C[2]};
    float ls = (dot3(H, pr) / pw + 0.5f) * (p->surf.w / (float)SCALE) - MARGIN;
    float lt = (0.5f - dot3(H, pu) / ph) * (p->surf.h / (float)SCALE) - MARGIN;
    if (ls < 0 || lt < 0 || ls >= p->lw || lt >= p->lh) continue;
    best = lam, hit = i, *s = ls, *t = lt;
  }
  if (dist) *dist = hit >= 0 ? best : 1600.f;
  return hit;
}

static void make_view(View *v, int w, int h, float foc, float eye_off);
static float eye_hfov(void);

int scene_panel_point(const Panel *p, float lx, float ly, int *sx, int *sy) {
  float pw, ph, pr[3], pu[3], n[3];
  panel_size(p, &pw, &ph);
  panel_axes(p, pr, pu, n);
  float u = (lx + MARGIN) / (p->surf.w / (float)SCALE) - 0.5f, v = (ly + MARGIN) / (p->surf.h / (float)SCALE) - 0.5f;
  float pt[3];
  pt[0] = p->x + pr[0] * u * pw - pu[0] * v * ph;
  pt[1] = p->y + pr[1] * u * pw - pu[1] * v * ph;
  pt[2] = p->z + pr[2] * u * pw - pu[2] * v * ph;
  View vw;
  make_view(&vw, W.out_w, W.out_h, (W.out_h * 0.5f) / tanf(FLAT_VFOV * 0.5f), 0.f);
  float fx, fy;
  if (!project(&vw, pt, &fx, &fy)) return 0;
  if (W.vr) {
    float t = tanf(eye_hfov() * 0.5f), asp = (float)W.out_h / (W.out_w * 0.5f);
    float nx = (fx - vw.cx) / vw.foc / t, ny = (vw.cy - fy) / vw.foc / (t * asp);
    fx = (nx + 1.f) * 0.5f * W.out_w, fy = (1.f - ny) * 0.5f * W.out_h;
  }
  *sx = (int)fx, *sy = (int)fy;
  return 1;
}

void scene_face_head(Panel *p) {
  float vx = W.gx - p->x, vy = W.gy - p->y, vz = W.gz - p->z;
  float l = sqrtf(vx * vx + vy * vy + vz * vz);
  if (l < 1e-3f) return;
  p->yaw = atan2f(-vx, vz);
  p->tilt = -asinf(vy / l);
}

void scene_place_in_view(Panel *p, float dist, float side) {
  float f[3], r[3], u[3];
  scene_basis(W.gyaw, W.gpitch * 0.5f, f, r, u);
  p->x = W.gx + f[0] * dist + r[0] * side;
  p->y = W.gy + f[1] * dist + 8.f;
  p->z = W.gz + f[2] * dist + r[2] * side;
  scene_face_head(p);
}

void scene_tick(float dt) {
  float k = 1.f - expf(-dt * 14.f), m = 1.f - expf(-dt * 10.f);
  W.yaw += (W.gyaw - W.yaw) * k;
  W.pitch += (W.gpitch - W.pitch) * k;
  W.cx += (W.gx - W.cx) * m;
  W.cy += (W.gy - W.cy) * m;
  W.cz += (W.gz - W.cz) * m;
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].visible && P[i].appear < 1.f) {
      P[i].appear += dt * 6.f;
      if (P[i].appear > 1.f) P[i].appear = 1.f;
    }
}

typedef struct {
  Surface *s;
  const View *v;
  const int *order;
  int n, ya, yb;
} Band;

static void *band_run(void *arg) {
  Band *b = arg;
  draw_sky(b->s, b->v, b->ya, b->yb);
  for (int k = 0; k < b->n; k++) draw_panel(b->s, b->v, &P[b->order[k]], b->ya, b->yb);
  return NULL;
}

static int nthreads(void) {
  static int n;
  if (!n) {
    const char *e = getenv("OREONVR_THREADS");
    n = e ? atoi(e) : (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (n < 1) n = 1;
    if (n > 16) n = 16;
  }
  return n;
}

static void render_view(Surface *s, const View *v) {
  int order[MAXP], n = draw_order(v->ex, v->ey, v->ez, order);
  int nt = nthreads();
  Band band[16];
  pthread_t th[16];
  int started[16] = {0};
  for (int t = 0; t < nt; t++) {
    band[t] = (Band){s, v, order, n, s->h * t / nt, s->h * (t + 1) / nt};
    if (t > 0) started[t] = pthread_create(&th[t], NULL, band_run, &band[t]) == 0;
  }
  band_run(&band[0]);
  for (int t = 1; t < nt; t++) {
    if (started[t]) pthread_join(th[t], NULL);
    else band_run(&band[t]);
  }
}

static void make_view(View *v, int w, int h, float foc, float eye_off) {
  scene_basis(W.yaw, W.pitch, v->f, v->r, v->u);
  v->ex = W.cx + v->r[0] * eye_off;
  v->ey = W.cy;
  v->ez = W.cz + v->r[2] * eye_off;
  v->foc = foc;
  v->eye = eye_off > 0.f;
  v->cx = w * 0.5f;
  v->cy = h * 0.5f;
}

static void draw_arrow(Surface *s, float x, float y) {
  gfx_tri(s, x, y, x, y + 18.f, x + 12.5f, y + 13.5f, RGBA(15, 18, 22, 235));
  gfx_tri(s, x + 1.4f, y + 3.f, x + 1.4f, y + 14.6f, x + 9.6f, y + 12.2f, RGB(255, 255, 255));
}

static void draw_reticle(Surface *s, const View *v) {
  float d[3], st, tt, dist;
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  scene_pick(d[0], d[1], d[2], &st, &tt, &dist);
  float pt[3] = {W.cx + d[0] * dist, W.cy + d[1] * dist, W.cz + d[2] * dist}, sx, sy;
  if (!project(v, pt, &sx, &sy)) return;
  float r = 7.f * fmaxf(0.6f, fminf(1.6f, 700.f / dist));
  gfx_ring(s, sx, sy, r, 2.6f, RGBA(15, 18, 22, 140));
  gfx_ring(s, sx, sy, r, 1.6f, RGB(255, 255, 255));
  gfx_disc(s, sx, sy, 1.6f, RGB(255, 255, 255));
}

static void build_lut(int ew, int eh) {
  free(lens_lut);
  lens_lut = malloc(sizeof(int) * (size_t)ew * eh);
  lut_w = ew, lut_h = eh, lut_on = W.lens;
  const float k1 = 0.22f, k2 = 0.24f, norm = 1.f / (1.f + k1 + k2);
  float hx = ew * 0.5f;
  for (int y = 0; y < eh; y++)
    for (int x = 0; x < ew; x++) {
      float nx = (x + 0.5f - hx) / hx, ny = (y + 0.5f - eh * 0.5f) / hx;
      float r2 = nx * nx + ny * ny;
      float k = (1.f + k1 * r2 + k2 * r2 * r2) * norm * 1.12f;
      float sx = hx + nx * k * hx, sy = eh * 0.5f + ny * k * hx;
      int idx = -1;
      if (r2 <= 1.25f && sx >= 0 && sy >= 0 && sx < ew && sy < eh) idx = (int)sy * ew + (int)sx;
      lens_lut[(size_t)y * ew + x] = idx;
    }
}

void scene_render(Surface *out) {
  W.out_w = out->w, W.out_h = out->h;
  if (OV.draw) {
    if (!W.vr) {
      OV.w = (float)out->w, OV.h = (float)out->h;
      OV.draw(out, 0, 0, OV.w, OV.h, (float)W.mx, (float)W.my);
      draw_arrow(out, (float)W.mx, (float)W.my);
      return;
    }
    int ew = out->w / 2, eh = out->h;
    if (eye[0].w != ew || eye[0].h != eh) {
      surf_free(&eye[0]);
      surf_init(&eye[0], ew, eh, 1);
    }
    float ix = ew * 0.08f, iy = eh * 0.08f;
    OV.w = ew - 2 * ix, OV.h = eh - 2 * iy;
    float mx = (float)W.mx / out->w * ew - ix, my = (float)W.my / out->h * eh - iy;
    surf_clear(&eye[0], 0xff000000u);
    gfx_clip(&eye[0], ix, iy, OV.w, OV.h);
    OV.draw(&eye[0], ix, iy, OV.w, OV.h, mx, my);
    gfx_noclip(&eye[0]);
    draw_arrow(&eye[0], mx + ix, my + iy);
    for (int e = 0; e < 2; e++)
      for (int y = 0; y < eh; y++) memcpy(out->px + (size_t)y * out->stride + e * ew, eye[0].px + (size_t)y * ew, (size_t)ew * 4);
    return;
  }
  if (!W.vr) {
    View v;
    make_view(&v, out->w, out->h, (out->h * 0.5f) / tanf(FLAT_VFOV * 0.5f), 0.f);
    render_view(out, &v);
    draw_arrow(out, (float)W.mx, (float)W.my);
    return;
  }
  int ew = out->w / 2, eh = out->h;
  for (int e = 0; e < 2; e++)
    if (eye[e].w != ew || eye[e].h != eh) {
      surf_free(&eye[e]);
      surf_init(&eye[e], ew, eh, 1);
    }
  if (W.lens && (lut_w != ew || lut_h != eh || !lut_on)) build_lut(ew, eh);
  float foc = (ew * 0.5f) / tanf(eye_hfov() * 0.5f);
  for (int e = 0; e < 2; e++) {
    View v;
    make_view(&v, ew, eh, foc, (e ? 0.5f : -0.5f) * W.ipd);
    render_view(&eye[e], &v);
    draw_reticle(&eye[e], &v);
    for (int y = 0; y < eh; y++) {
      uint32_t *dst = out->px + (size_t)y * out->stride + e * ew;
      if (!W.lens) {
        memcpy(dst, eye[e].px + (size_t)y * ew, (size_t)ew * 4);
        continue;
      }
      const int *lut = lens_lut + (size_t)y * ew;
      for (int x = 0; x < ew; x++) dst[x] = lut[x] >= 0 ? eye[e].px[lut[x]] : 0xff000000u;
    }
  }
  if (!W.lens) lut_on = 0;
}
