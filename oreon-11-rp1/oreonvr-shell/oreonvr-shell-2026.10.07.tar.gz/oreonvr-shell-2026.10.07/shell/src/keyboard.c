#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>

#include "oreonvr.h"

#define PAD 14
#define KB_W 490
#define GRAB_H 18
#define STRIP_Y 20
#define STRIP_H 36
#define SUG_Y (STRIP_Y + STRIP_H + 6)
#define SUG_H 34
#define NSUG 3
#define KY (SUG_Y + SUG_H + 8)
#define KH 37
#define KS 41
#define KSY 42
#define KB_H (KY + 4 * KSY + KH + 12)
#define W_SIDE 48
#define HOLD_MS 420

#define C_KBG THEME(RGB(247, 248, 250), RGB(30, 32, 36))
#define C_KEDGE THEME(RGB(212, 216, 222), RGB(70, 74, 82))
#define C_KEY THEME(RGB(232, 236, 242), RGB(54, 57, 63))
#define C_KEY_HOT THEME(RGB(214, 220, 230), RGB(72, 76, 85))
#define C_KEY_DOWN THEME(RGB(184, 192, 206), RGB(108, 114, 126))
#define C_KTEXT THEME(RGB(42, 47, 54), RGB(236, 238, 242))
#define C_KHINT THEME(RGB(120, 127, 138), RGB(146, 152, 164))
#define C_KSTRIP THEME(RGB(236, 239, 244), RGB(22, 24, 27))
#define C_KGRAB THEME(RGB(190, 197, 208), RGB(88, 93, 104))
#define C_KENTER THEME(RGB(34, 38, 46), RGB(244, 245, 247))
#define C_KENTER_DOWN THEME(RGB(70, 76, 90), RGB(190, 196, 206))
#define C_KENTER_ICON THEME(RGB(255, 255, 255), RGB(30, 32, 36))
#define C_KCARET THEME(RGB(47, 107, 255), RGB(120, 190, 255))

enum { Z_SHIFT = 1, Z_BACK, Z_ENTER, Z_SPACE, Z_PAGE, Z_HIDE, Z_GRAB, Z_SUG = 20, Z_KEY = 100 };

typedef struct {
  float x, y, w;
  int zone;
  char label[8];
} Key;

static char echo[96];
static int elen, shift, symbols, pressed;
static uint32_t press_at;
enum { S_NONE, S_WORD, S_CORR, S_FIX, S_KEEP, S_NEXT };

typedef struct {
  char t[32];
  int kind;
} Slot;

static Slot slot[NSUG];
static char typed[32];
static char undo_from[32], undo_to[32];
static int undo_on;

static int word_char(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '\''; }

static int word_start(void) {
  int i = elen;
  while (i > 0 && word_char(echo[i - 1])) i--;
  return i;
}

static const char *prev_word(int pos) {
  static char w[32];
  int e = pos;
  w[0] = 0;
  while (e > 0 && echo[e - 1] == ' ') e--;
  int b = e;
  while (b > 0 && word_char(echo[b - 1])) b--;
  if (e > b && e - b < (int)sizeof w) {
    memcpy(w, echo + b, (size_t)(e - b));
    w[e - b] = 0;
  }
  return w;
}

static int in_terminal(void) {
  return W.focus >= 0 && P[W.focus].used && P[W.focus].app && !strcmp(P[W.focus].app->id, "terminal");
}

static void put(int at, const char *t, int kind) {
  snprintf(slot[at].t, sizeof slot[at].t, "%.31s", t);
  slot[at].kind = kind;
}

static void refresh_sug(void) {
  memset(slot, 0, sizeof slot);
  typed[0] = 0;
  if (symbols) return;
  int ws = word_start();
  char out[NSUG][32];
  if (ws < elen) {
    snprintf(typed, sizeof typed, "%s", echo + ws);
    int fix = 0, n = predict_words(typed, prev_word(ws), out, NSUG, &fix);
    if (fix == 2 && !in_terminal()) {
      put(1, out[0], S_FIX);
      put(0, typed, S_KEEP);
      if (n > 1) put(2, out[1], S_WORD);
      return;
    }
    static const int order[NSUG] = {1, 0, 2};
    for (int i = 0; i < n; i++) put(order[i], out[i], !i && fix ? S_CORR : S_WORD);
    return;
  }
  if (elen && echo[elen - 1] == ' ') {
    int n = predict_next(prev_word(elen), out, NSUG);
    static const int order[NSUG] = {1, 0, 2};
    for (int i = 0; i < n; i++) put(order[i], out[i], S_NEXT);
  }
}

static void learn_word(void) {
  int ws = word_start();
  if (elen - ws >= 1) predict_learn(echo + ws, prev_word(ws), 0);
}

static float sug_w(void) { return (KB_W - 2 * PAD) / (float)NSUG; }

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static char hint_of(char c) {
  static const char from[] = "qwertyuiopasdfghjklzxcvbnm,.";
  static const char to[] = "1234567890@#$&*()'\"%-+=/;:!?";
  const char *f = strchr(from, c);
  return f && c ? to[f - from] : 0;
}

static Key mk(float x, float y, float w, int zone, const char *label) {
  Key k = {x, y, w, zone, {0}};
  snprintf(k.label, sizeof k.label, "%s", label);
  return k;
}

static int layout(Key *k) {
  static const char *letters[3] = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
  static const char *syms[4] = {"1234567890", "!@#$%^&*()", "-_=+[]{}/\\", "`~|;:'\"<>?"};
  int n = 0;
  float y = KY;
  int rowsn = symbols ? 4 : 3;
  for (int r = 0; r < rowsn; r++) {
    const char *row = symbols ? syms[r] : letters[r];
    int cnt = (int)strlen(row);
    int left = !symbols && r == 2;
    int right = symbols ? (r == 0 || r == 2) : (r == 0 || r == 1 || r == 2);
    float w = cnt * KS - 4 + (left ? W_SIDE + 4 : 0) + (right ? W_SIDE + 4 : 0);
    float x = PAD + (KB_W - 2 * PAD - w) * 0.5f;
    if (left) {
      k[n++] = mk(x, y, W_SIDE, Z_SHIFT, "");
      x += W_SIDE + 4;
    }
    for (int i = 0; i < cnt; i++) {
      char lab[2] = {row[i], 0};
      k[n++] = mk(x + i * KS, y, 37, Z_KEY + (unsigned char)row[i], lab);
    }
    if (right) {
      int z = (!symbols && r == 2) ? Z_SHIFT : ((symbols ? r == 0 : r == 0) ? Z_BACK : Z_ENTER);
      k[n++] = mk(x + cnt * KS, y, W_SIDE, z, "");
    }
    y += KSY;
  }
  if (symbols) y = KY + 4 * KSY;
  else y = KY + 3 * KSY;
  float x = PAD + (KB_W - 2 * PAD - 416.f) * 0.5f;
  k[n++] = mk(x, y, 56, Z_PAGE, symbols ? "abc" : "!123");
  k[n++] = mk(x + 60, y, 220, Z_SPACE, "");
  k[n++] = mk(x + 284, y, 36, Z_KEY + ',', ",");
  k[n++] = mk(x + 324, y, 36, Z_KEY + '.', ".");
  k[n++] = mk(x + 364, y, 52, Z_HIDE, "");
  return n;
}

static int kb_height(void) { return symbols ? KB_H : KB_H - KSY; }

static int kb_zone(Panel *p, float x, float y) {
  (void)p;
  if (y < GRAB_H) return Z_GRAB;
  if (y >= SUG_Y && y < SUG_Y + SUG_H && x >= PAD && x < KB_W - PAD) {
    int i = (int)((x - PAD) / sug_w());
    return i < NSUG && slot[i].kind ? Z_SUG + i : 0;
  }
  Key k[64];
  int n = layout(k);
  for (int i = 0; i < n; i++)
    if (x >= k[i].x && x < k[i].x + k[i].w && y >= k[i].y && y < k[i].y + KH) return k[i].zone;
  return 0;
}

static void send(char c, int with_shift) {
  int sh = 0, code = key_from_char(c, &sh);
  if (!code) return;
  if (with_shift && c >= 'a' && c <= 'z') sh = 1;
  if (sh) input_key(KEY_LEFTSHIFT, 1, 0);
  input_key(code, 1, 0);
  input_key(code, 0, 0);
  if (sh) input_key(KEY_LEFTSHIFT, 0, 0);
}

static void echo_add(char c) {
  if (elen < (int)sizeof echo - 1) {
    echo[elen++] = c;
    echo[elen] = 0;
  }
}

static void type_str(const char *t) {
  for (; *t; t++) {
    send(*t, 0);
    echo_add(*t);
  }
}

static void replace_word(const char *with) {
  int ws = word_start();
  for (int k = ws; k < elen; k++) send(127, 0);
  elen = ws;
  echo[elen] = 0;
  type_str(with);
}

static void take_sug(int i) {
  Slot sl = slot[i];
  int ws = word_start();
  char prev[32];
  snprintf(prev, sizeof prev, "%s", prev_word(ws));
  if (sl.kind == S_KEEP) predict_learn(sl.t, prev, 1);
  else {
    replace_word(sl.t);
    predict_learn(sl.t, prev, 0);
  }
  send(' ', 0);
  echo_add(' ');
  shift = 0;
}

static int autocorrect(void) {
  if (slot[1].kind != S_FIX) return 0;
  int ws = word_start();
  char prev[32];
  snprintf(prev, sizeof prev, "%s", prev_word(ws));
  snprintf(undo_from, sizeof undo_from, "%s", typed);
  snprintf(undo_to, sizeof undo_to, "%s", slot[1].t);
  replace_word(slot[1].t);
  predict_learn(slot[1].t, prev, 0);
  return 1;
}

static int undo_correction(void) {
  size_t tl = strlen(undo_to);
  if (!undo_on || elen < (int)tl + 1 || strncmp(echo + elen - tl - 1, undo_to, tl)) return 0;
  for (size_t k = 0; k <= tl; k++) send(127, 0);
  elen -= (int)tl + 1;
  echo[elen] = 0;
  type_str(undo_from);
  predict_learn(undo_from, prev_word(word_start()), 1);
  return 1;
}

static void fire_key(Panel *p, int z, int held);

static void fire(Panel *p, int z, int held) {
  int was_undo = undo_on;
  undo_on = 0;
  if (z == Z_BACK && was_undo) undo_on = 1;
  fire_key(p, z, held);
  if (z == Z_BACK && was_undo) undo_on = 0;
  refresh_sug();
}

static void fire_key(Panel *p, int z, int held) {
  if (z >= Z_SUG && z < Z_SUG + NSUG) {
    take_sug(z - Z_SUG);
    return;
  }
  if (z == Z_HIDE) {
    panel_close((int)(p - P));
    return;
  }
  if (z == Z_SHIFT) {
    shift = !shift;
    return;
  }
  if (z == Z_PAGE) {
    symbols = !symbols;
    shift = 0;
    panel_resize((int)(p - P), KB_W, kb_height());
    return;
  }
  if (z == Z_BACK) {
    if (undo_correction()) return;
    send(127, 0);
    if (elen) echo[--elen] = 0;
    return;
  }
  if (z == Z_ENTER) {
    if (!autocorrect()) learn_word();
    send('\r', 0);
    memset(echo, 0, sizeof echo);
    elen = 0;
    return;
  }
  char c = z == Z_SPACE ? ' ' : (char)(z - Z_KEY);
  char h = symbols ? 0 : hint_of(c);
  char out = held && h ? h : c;
  if (c == ' ' && !in_terminal() && elen >= 2 && echo[elen - 1] == ' ' && word_char(echo[elen - 2])) {
    send(127, 0);
    echo[--elen] = 0;
    send('.', 0);
    echo_add('.');
    send(' ', 0);
    echo_add(' ');
    shift = 1;
    return;
  }
  if (!word_char(out)) {
    if (strchr(" .,!?;:", out) && autocorrect()) undo_on = 1;
    else learn_word();
  }
  if (held && h) {
    send(h, 0);
    echo_add(h);
  } else {
    send(c, shift);
    echo_add(shift && c >= 'a' && c <= 'z' ? (char)(c - 32) : c);
  }
  shift = 0;
}

static void kb_press(Panel *p, float x, float y, int button, int down) {
  if (button != 1) return;
  if (down) {
    int z = kb_zone(p, x, y);
    if (z == Z_GRAB) {
      input_begin_drag((int)(p - P));
      return;
    }
    pressed = z;
    press_at = now_ms();
    p->dirty = 1;
    return;
  }
  int z = kb_zone(p, x, y), was = pressed;
  int held = now_ms() - press_at >= HOLD_MS;
  pressed = 0;
  p->dirty = 1;
  if (was && z == was) fire(p, was, held);
}

static int kb_tick(Panel *p, uint32_t now) {
  (void)p;
  static int lastfocus = -2;
  int focus_changed = W.focus != lastfocus;
  lastfocus = W.focus;
  static int lastheld;
  int held = pressed && now - press_at >= HOLD_MS;
  int changed = held != lastheld;
  lastheld = held;
  return changed || focus_changed;
}

static void dock_show(int on) {
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].kind == PK_DOCK) P[i].visible = on;
}

static void kb_close(Panel *p) {
  (void)p;
  predict_save();
  dock_show(1);
}

static void kb_open(Panel *p) {
  dock_show(0);
  p->nobar = 1;
  if (W.focus >= 0 && P[W.focus].used) P[W.focus].dirty = 1;
  memset(echo, 0, sizeof echo);
  elen = 0;
  shift = 0;
  symbols = 0;
  pressed = 0;
  memset(slot, 0, sizeof slot);
  undo_on = 0;
  panel_resize((int)(p - P), KB_W, kb_height());
}

static void icon_back(Surface *s, float cx, float cy, uint32_t c) {
  gfx_line(s, cx - 10, cy, cx - 4, cy - 7, 1.8f, c);
  gfx_line(s, cx - 10, cy, cx - 4, cy + 7, 1.8f, c);
  gfx_line(s, cx - 4, cy - 7, cx + 10, cy - 7, 1.8f, c);
  gfx_line(s, cx - 4, cy + 7, cx + 10, cy + 7, 1.8f, c);
  gfx_line(s, cx + 10, cy - 7, cx + 10, cy + 7, 1.8f, c);
  gfx_line(s, cx - 1, cy - 3, cx + 6, cy + 3, 1.6f, c);
  gfx_line(s, cx + 6, cy - 3, cx - 1, cy + 3, 1.6f, c);
}

static void icon_shift(Surface *s, float cx, float cy, int on, uint32_t c) {
  gfx_tri(s, cx - 9, cy + 1, cx + 9, cy + 1, cx, cy - 9, c);
  gfx_rect(s, cx - 4, cy + 1, 8, 8, c);
  if (!on) {
    gfx_tri(s, cx - 5, cy + 1, cx + 5, cy + 1, cx, cy - 5, C_KEY);
    gfx_rect(s, cx - 2, cy + 1, 4, 6, C_KEY);
  }
}

static void icon_enter(Surface *s, float cx, float cy, uint32_t c) {
  gfx_line(s, cx + 9, cy - 8, cx + 9, cy + 2, 2.f, c);
  gfx_line(s, cx + 9, cy + 2, cx - 8, cy + 2, 2.f, c);
  gfx_line(s, cx - 8, cy + 2, cx - 3, cy - 3, 2.f, c);
  gfx_line(s, cx - 8, cy + 2, cx - 3, cy + 7, 2.f, c);
}

static void icon_close(Surface *s, float cx, float cy, uint32_t c) {
  gfx_line(s, cx - 7, cy - 7, cx + 7, cy + 7, 2.f, c);
  gfx_line(s, cx + 7, cy - 7, cx - 7, cy + 7, 2.f, c);
}

static void draw_key(Surface *s, const Key *k, float ox, float oy, int hot, int down) {
  int enter = k->zone == Z_ENTER, on = k->zone == Z_SHIFT && shift;
  uint32_t bg = enter ? (down ? C_KENTER_DOWN : C_KENTER) : on ? C_ACCENT : down ? C_KEY_DOWN : hot ? C_KEY_HOT : C_KEY;
  float x = ox + k->x, y = oy + k->y;
  gfx_rrect(s, x, y, k->w, KH, 10, bg);
  float cx = x + k->w * 0.5f, cy = y + KH * 0.5f;
  if (k->zone == Z_BACK) icon_back(s, cx, cy, C_KTEXT);
  else if (k->zone == Z_SHIFT) icon_shift(s, cx, cy, on, on ? RGB(255, 255, 255) : C_KTEXT);
  else if (enter) icon_enter(s, cx, cy, C_KENTER_ICON);
  else if (k->zone == Z_HIDE) icon_close(s, cx, cy, C_KTEXT);
  else if (k->zone == Z_SPACE) gfx_rrect(s, cx - 28, cy + 2, 56, 3, 1.5f, C_KHINT);
  else {
    char label[8];
    snprintf(label, sizeof label, "%s", k->label);
    int letter = label[0] >= 'a' && label[0] <= 'z' && !label[1];
    if (shift && letter && !symbols) label[0] = (char)(label[0] - 32);
    char h = symbols ? 0 : hint_of(k->label[0]);
    int held = down && now_ms() - press_at >= HOLD_MS;
    if (held && h) {
      char hs[2] = {h, 0};
      gfx_text_c(s, F_UI_MED, cx, cy - line_h(F_UI_MED) * 0.5f, hs, RGB(255, 255, 255));
    } else {
      gfx_text_c(s, F_UI_MED, cx, cy - line_h(F_UI_MED) * 0.5f + (h ? 2.f : 0.f), label, C_KTEXT);
      if (h) {
        char hs[2] = {h, 0};
        gfx_text(s, F_SMALL, x + k->w - 11, y + 2, hs, C_KHINT);
      }
    }
  }
}

static void fit(const Font *f, char *t, float maxw) {
  size_t n = strlen(t);
  while (n > 3 && gfx_text_w(f, t) > maxw) {
    t[--n] = 0;
    memcpy(t + n - 2, "..", 2);
  }
}

static void draw_sug(Surface *s, float ox, float oy, int hot) {
  float cw = sug_w(), y = oy + SUG_Y;
  for (int i = 0; i < NSUG; i++) {
    Slot *sl = &slot[i];
    if (!sl->kind) continue;
    float x = ox + PAD + i * cw;
    int z = Z_SUG + i, fix = sl->kind == S_FIX, mid = i == 1;
    uint32_t bg = 0;
    if (fix) bg = pressed == z ? RGB(32, 84, 214) : hot == z ? RGB(40, 96, 236) : C_ACCENT;
    else if (pressed == z) bg = C_KEY_DOWN;
    else if (hot == z) bg = C_KEY_HOT;
    else if (mid) bg = C_KEY;
    if (bg) gfx_rrect(s, x + 4, y, cw - 8, SUG_H, SUG_H * 0.5f, bg);
    const Font *f = mid ? F_UI_MED : F_UI;
    char t[40];
    if (sl->kind == S_KEEP) snprintf(t, sizeof t, "\"%.30s\"", sl->t);
    else snprintf(t, sizeof t, "%.31s", sl->t);
    fit(f, t, cw - 26);
    float ty = y + (SUG_H - line_h(f)) * 0.5f, tw = gfx_text_w(f, t), tx = x + (cw - tw) * 0.5f;
    size_t pl = strlen(typed);
    if (fix) gfx_text(s, f, tx, ty, t, RGB(255, 255, 255));
    else if (sl->kind == S_CORR) gfx_text(s, f, tx, ty, t, C_KCARET);
    else if (sl->kind == S_WORD && pl && pl < strlen(t) && !strncasecmp(t, typed, pl)) {
      char head[32];
      snprintf(head, sizeof head, "%.*s", (int)pl, t);
      gfx_text(s, f, tx, ty, head, C_KHINT);
      gfx_text(s, f, tx + gfx_text_w(f, head), ty, t + pl, C_KTEXT);
    } else gfx_text(s, f, tx, ty, t, sl->kind == S_KEEP ? C_KHINT : C_KTEXT);
  }
}

static void kb_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  float bh = (float)kb_height();
  gfx_rrect(s, ox - 1, oy - 1, KB_W + 2, bh + 2, 19, C_KEDGE);
  gfx_rrect(s, ox, oy, KB_W, bh, 18, C_KBG);
  gfx_rrect(s, ox + KB_W * 0.5f - 24, oy + 6, 48, 5, 2.5f, hot == Z_GRAB ? C_ACCENT : C_KGRAB);
  gfx_rrect(s, ox + PAD, oy + STRIP_Y, KB_W - 2 * PAD, STRIP_H, 12, C_KSTRIP);
  float ty = oy + STRIP_Y + (STRIP_H - line_h(F_UI)) * 0.5f;
  Panel *tg = W.focus >= 0 && P[W.focus].used && P[W.focus].app != &keyboard_app ? &P[W.focus] : NULL;
  char chip[80];
  if (tg) snprintf(chip, sizeof chip, "%s", tg->title);
  else snprintf(chip, sizeof chip, "No input");
  float cw = gfx_text_w(F_SMALL, chip) + 24.f;
  if (cw > 150.f) cw = 150.f;
  float cx0 = ox + KB_W - PAD - cw - 5;
  gfx_rrect(s, cx0, oy + STRIP_Y + 5, cw, STRIP_H - 10, (STRIP_H - 10) * 0.5f, tg ? THEME(RGB(206, 224, 255), RGB(36, 84, 190)) : THEME(RGB(255, 232, 196), RGB(86, 62, 30)));
  gfx_text_c(s, F_SMALL, cx0 + cw * 0.5f, oy + STRIP_Y + (STRIP_H - line_h(F_SMALL)) * 0.5f, chip, THEME(RGB(30, 50, 100), RGB(236, 240, 248)));
  const char *t = echo;
  while (*t && gfx_text_w(F_UI, t) > KB_W - 2 * PAD - 48 - cw) t++;
  if (*t) {
    gfx_text(s, F_UI, ox + PAD + 14, ty, t, C_KTEXT);
    gfx_rect(s, ox + PAD + 16 + gfx_text_w(F_UI, t), ty + 2, 1.5f, line_h(F_UI) - 4, C_KCARET);
  } else {
    gfx_text(s, F_UI, ox + PAD + 14, ty, "Typing", C_KHINT);
  }
  draw_sug(s, ox, oy, hot);
  Key k[64];
  int n = layout(k);
  for (int i = 0; i < n; i++) draw_key(s, &k[i], ox, oy, hot == k[i].zone, pressed == k[i].zone);
}

void keyboard_clear_echo(void) {
  memset(echo, 0, sizeof echo);
  elen = 0;
  memset(slot, 0, sizeof slot);
  undo_on = 0;
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app == &keyboard_app) P[i].dirty = 1;
}

void keyboard_place(int ki) {
  Panel *kb = &P[ki];
  Panel *t = W.focus >= 0 && P[W.focus].used && P[W.focus].kind == PK_WINDOW && P[W.focus].app != &keyboard_app ? &P[W.focus] : NULL;
  if (!t) {
    scene_place_in_view(kb, 560.f, 0.f);
    kb->y -= 120.f;
    scene_face_head(kb);
    return;
  }
  float dx = t->x - W.gx, dz = t->z - W.gz, d1 = hypotf(dx, dz);
  float edge = (t->y - t->lh * 0.5f - 24.f - W.gy) / d1;
  float near = 1.0f;
  kb->x = W.gx + dx * near;
  kb->z = W.gz + dz * near;
  kb->y = W.gy + edge * d1 * near - kb->lh * 0.5f - 14.f;
  scene_face_head(kb);
  W.gpitch -= 0.13f;
}

App keyboard_app = {"keyboard", "Keyboard", IC_KEYBOARD, KB_W, KB_H - KSY, kb_open, kb_draw, NULL, NULL, NULL, kb_zone, kb_tick, kb_close,
                    kb_press};
