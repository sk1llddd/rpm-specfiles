#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <poll.h>
#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#include "oreonvr.h"

#define SB_LINES 1000
#define NPAR 16
#define DEF 255

typedef struct {
  unsigned char ch, fg, bg, attr;
} Cell;

enum { A_BOLD = 1, A_INV = 2, A_UL = 4 };

struct Term {
  int fd;
  pid_t pid;
  int alive;
  int cols, rows;
  Cell *scr, *alt;
  int alt_on;
  Cell *sb;
  int sb_n, sb_head;
  int view;
  int cx, cy, scx, scy, wrapnext;
  int top, bot;
  Cell pen;

  int st;
  int par[NPAR], np, priv;
  int utf_skip;
};

static const uint32_t PAL[16] = {
    RGB(31, 35, 41),   RGB(239, 91, 107), RGB(94, 233, 160), RGB(245, 195, 90),
    RGB(91, 157, 255), RGB(196, 140, 255), RGB(79, 209, 217), RGB(201, 209, 217),
    RGB(107, 115, 128), RGB(255, 125, 140), RGB(140, 245, 190), RGB(255, 215, 130),
    RGB(140, 190, 255), RGB(215, 175, 255), RGB(130, 230, 235), RGB(240, 244, 248),
};

static Cell blank(Term *t) {
  Cell c = {' ', DEF, t->pen.bg, 0};
  return c;
}

static Cell *row(Term *t, int y) { return t->scr + (size_t)y * t->cols; }

static void clear_cells(Term *t, int y, int x0, int x1) {
  Cell b = blank(t);
  Cell *r = row(t, y);
  for (int x = x0; x < x1 && x < t->cols; x++) r[x] = b;
}

static void sb_push(Term *t, const Cell *line) {
  if (t->alt_on) return;
  int slot = (t->sb_head + t->sb_n) % SB_LINES;
  if (t->sb_n == SB_LINES) t->sb_head = (t->sb_head + 1) % SB_LINES;
  else t->sb_n++;
  memcpy(t->sb + (size_t)slot * t->cols, line, sizeof(Cell) * t->cols);
}

static void scroll_up(Term *t, int top, int bot, int n) {
  for (; n > 0; n--) {
    if (top == 0) sb_push(t, row(t, 0));
    memmove(row(t, top), row(t, top + 1), sizeof(Cell) * t->cols * (size_t)(bot - top));
    clear_cells(t, bot, 0, t->cols);
  }
}

static void scroll_down(Term *t, int top, int bot, int n) {
  for (; n > 0; n--) {
    memmove(row(t, top + 1), row(t, top), sizeof(Cell) * t->cols * (size_t)(bot - top));
    clear_cells(t, top, 0, t->cols);
  }
}

static void newline(Term *t) {
  if (t->cy == t->bot) scroll_up(t, t->top, t->bot, 1);
  else if (t->cy < t->rows - 1) t->cy++;
}

static void put(Term *t, unsigned char c) {
  if (t->wrapnext) {
    t->cx = 0;
    newline(t);
    t->wrapnext = 0;
  }
  Cell *r = row(t, t->cy);
  r[t->cx] = t->pen;
  r[t->cx].ch = c;
  if (t->cx == t->cols - 1) t->wrapnext = 1;
  else t->cx++;
}

static void clamp_cursor(Term *t) {
  if (t->cx < 0) t->cx = 0;
  if (t->cy < 0) t->cy = 0;
  if (t->cx >= t->cols) t->cx = t->cols - 1;
  if (t->cy >= t->rows) t->cy = t->rows - 1;
  t->wrapnext = 0;
}

static void reply(Term *t, const char *s) { term_write(t, s, (int)strlen(s)); }

static void sgr(Term *t) {
  if (t->np == 0) t->np = 1, t->par[0] = 0;
  for (int i = 0; i < t->np; i++) {
    int p = t->par[i];
    if (p == 0) t->pen.fg = t->pen.bg = DEF, t->pen.attr = 0;
    else if (p == 1) t->pen.attr |= A_BOLD;
    else if (p == 4) t->pen.attr |= A_UL;
    else if (p == 7) t->pen.attr |= A_INV;
    else if (p == 22) t->pen.attr &= ~A_BOLD;
    else if (p == 24) t->pen.attr &= ~A_UL;
    else if (p == 27) t->pen.attr &= ~A_INV;
    else if (p >= 30 && p <= 37) t->pen.fg = (unsigned char)(p - 30);
    else if (p == 39) t->pen.fg = DEF;
    else if (p >= 40 && p <= 47) t->pen.bg = (unsigned char)(p - 40);
    else if (p == 49) t->pen.bg = DEF;
    else if (p >= 90 && p <= 97) t->pen.fg = (unsigned char)(p - 90 + 8);
    else if (p >= 100 && p <= 107) t->pen.bg = (unsigned char)(p - 100 + 8);
    else if ((p == 38 || p == 48) && i + 2 < t->np && t->par[i + 1] == 5) {
      int c = t->par[i + 2];
      unsigned char v = c < 16 ? (unsigned char)c : (c >= 232 ? (c > 243 ? 15 : 8) : 7);
      if (p == 38) t->pen.fg = v;
      else t->pen.bg = v;
      i += 2;
    } else if ((p == 38 || p == 48) && i + 4 < t->np && t->par[i + 1] == 2) {
      i += 4;
    }
  }
}

static void set_alt(Term *t, int on) {
  if (on == t->alt_on) return;
  size_t n = sizeof(Cell) * t->cols * (size_t)t->rows;
  if (on) {
    memcpy(t->alt, t->scr, n);
    for (int y = 0; y < t->rows; y++) clear_cells(t, y, 0, t->cols);
    t->scx = t->cx, t->scy = t->cy;
  } else {
    memcpy(t->scr, t->alt, n);
    t->cx = t->scx, t->cy = t->scy;
  }
  t->alt_on = on;
}

static void csi(Term *t, unsigned char c) {
  int a = t->np > 0 && t->par[0] ? t->par[0] : 1;
  int b = t->np > 1 && t->par[1] ? t->par[1] : 1;
  int p0 = t->np > 0 ? t->par[0] : 0;
  if (t->priv) {
    if (c == 'h' || c == 'l')
      for (int i = 0; i < t->np; i++)
        if (t->par[i] == 1049 || t->par[i] == 47 || t->par[i] == 1047) set_alt(t, c == 'h');
    return;
  }
  switch (c) {
  case 'A': t->cy -= a; clamp_cursor(t); break;
  case 'B': case 'e': t->cy += a; clamp_cursor(t); break;
  case 'C': case 'a': t->cx += a; clamp_cursor(t); break;
  case 'D': t->cx -= a; clamp_cursor(t); break;
  case 'E': t->cx = 0, t->cy += a; clamp_cursor(t); break;
  case 'F': t->cx = 0, t->cy -= a; clamp_cursor(t); break;
  case 'G': case '`': t->cx = a - 1; clamp_cursor(t); break;
  case 'd': t->cy = a - 1; clamp_cursor(t); break;
  case 'H': case 'f': t->cy = a - 1, t->cx = b - 1; clamp_cursor(t); break;
  case 'J':
    if (p0 == 0) {
      clear_cells(t, t->cy, t->cx, t->cols);
      for (int y = t->cy + 1; y < t->rows; y++) clear_cells(t, y, 0, t->cols);
    } else if (p0 == 1) {
      clear_cells(t, t->cy, 0, t->cx + 1);
      for (int y = 0; y < t->cy; y++) clear_cells(t, y, 0, t->cols);
    } else {
      for (int y = 0; y < t->rows; y++) clear_cells(t, y, 0, t->cols);
    }
    break;
  case 'K':
    if (p0 == 0) clear_cells(t, t->cy, t->cx, t->cols);
    else if (p0 == 1) clear_cells(t, t->cy, 0, t->cx + 1);
    else clear_cells(t, t->cy, 0, t->cols);
    break;
  case 'X': clear_cells(t, t->cy, t->cx, t->cx + a); break;
  case '@': {
    Cell *r = row(t, t->cy);
    if (a > t->cols - t->cx) a = t->cols - t->cx;
    memmove(r + t->cx + a, r + t->cx, sizeof(Cell) * (size_t)(t->cols - t->cx - a));
    clear_cells(t, t->cy, t->cx, t->cx + a);
    break;
  }
  case 'P': {
    Cell *r = row(t, t->cy);
    if (a > t->cols - t->cx) a = t->cols - t->cx;
    memmove(r + t->cx, r + t->cx + a, sizeof(Cell) * (size_t)(t->cols - t->cx - a));
    clear_cells(t, t->cy, t->cols - a, t->cols);
    break;
  }
  case 'L': if (t->cy >= t->top && t->cy <= t->bot) scroll_down(t, t->cy, t->bot, a); break;
  case 'M': if (t->cy >= t->top && t->cy <= t->bot) scroll_up(t, t->cy, t->bot, a); break;
  case 'S': scroll_up(t, t->top, t->bot, a); break;
  case 'T': scroll_down(t, t->top, t->bot, a); break;
  case 'm': sgr(t); break;
  case 'r':
    t->top = (t->np > 0 && t->par[0] ? t->par[0] : 1) - 1;
    t->bot = (t->np > 1 && t->par[1] ? t->par[1] : t->rows) - 1;
    if (t->top < 0) t->top = 0;
    if (t->bot >= t->rows) t->bot = t->rows - 1;
    if (t->top >= t->bot) t->top = 0, t->bot = t->rows - 1;
    t->cx = t->cy = 0;
    break;
  case 's': t->scx = t->cx, t->scy = t->cy; break;
  case 'u': t->cx = t->scx, t->cy = t->scy; clamp_cursor(t); break;
  case 'n':
    if (p0 == 6) {
      char b[32];
      snprintf(b, sizeof b, "\x1b[%d;%dR", t->cy + 1, t->cx + 1);
      reply(t, b);
    } else if (p0 == 5) reply(t, "\x1b[0n");
    break;
  case 'c': reply(t, "\x1b[?6c"); break;
  }
}

void term_feed(Term *t, const char *buf, int n) {
  for (int i = 0; i < n; i++) {
    unsigned char c = (unsigned char)buf[i];
    if (t->st == 3 || t->st == 5) {
      if (c == 7) t->st = 0;
      else if (c == 27) t->st = 5;
      else if (t->st == 5) t->st = c == '\\' ? 0 : 3;
      continue;
    }
    if (c == 27) {
      t->st = 1;
      continue;
    }
    if (c < 32 || c == 127) {
      switch (c) {
      case '\r': t->cx = 0, t->wrapnext = 0; break;
      case '\n': case 11: case 12: newline(t); t->wrapnext = 0; break;
      case '\b': if (t->cx > 0) t->cx--; t->wrapnext = 0; break;
      case '\t': t->cx = (t->cx + 8) & ~7; if (t->cx >= t->cols) t->cx = t->cols - 1; break;
      case 24: case 26: t->st = 0; break;
      }
      continue;
    }
    if (t->st == 1) {
      t->st = 0;
      if (c == '[') {
        t->st = 2, t->np = 0, t->priv = 0;
        memset(t->par, 0, sizeof t->par);
      } else if (c == ']') t->st = 3;
      else if (c == '(' || c == ')' || c == '#') t->st = 4;
      else if (c == '7') t->scx = t->cx, t->scy = t->cy;
      else if (c == '8') t->cx = t->scx, t->cy = t->scy, clamp_cursor(t);
      else if (c == 'D') newline(t);
      else if (c == 'E') t->cx = 0, newline(t);
      else if (c == 'M') {
        if (t->cy == t->top) scroll_down(t, t->top, t->bot, 1);
        else if (t->cy > 0) t->cy--;
      } else if (c == 'c') {
        t->pen = (Cell){' ', DEF, DEF, 0};
        for (int y = 0; y < t->rows; y++) clear_cells(t, y, 0, t->cols);
        t->cx = t->cy = 0, t->top = 0, t->bot = t->rows - 1;
      }
      continue;
    }
    if (t->st == 4) {
      t->st = 0;
      continue;
    }
    if (t->st == 2) {
      if (c >= '0' && c <= '9') {
        if (t->np == 0) t->np = 1;
        t->par[t->np - 1] = t->par[t->np - 1] * 10 + (c - '0');
      } else if (c == ';' || c == ':') {
        if (t->np == 0) t->np = 1;
        if (t->np < NPAR) t->np++;
      } else if (c == '?' || c == '>' || c == '=') {
        t->priv = 1;
      } else if (c >= 0x40 && c <= 0x7e) {
        csi(t, c);
        t->st = 0;
      }
      continue;
    }

    if (c >= 0x80) {
      if (c >= 0xc0) put(t, '?');
      continue;
    }
    put(t, c);
  }
}

static void child_exec(void) {
  const char *user = getenv("OREONVR_USER");
  struct passwd *pw = NULL;
  if (getuid() == 0 && user && *user && (pw = getpwnam(user))) {
    if (initgroups(pw->pw_name, pw->pw_gid) || setgid(pw->pw_gid) || setuid(pw->pw_uid)) _exit(126);
  } else {
    pw = getpwuid(getuid());
  }
  const char *sh = pw && pw->pw_shell && *pw->pw_shell ? pw->pw_shell : NULL;
  if (!sh || access(sh, X_OK)) sh = getenv("SHELL");
  if (!sh || access(sh, X_OK)) sh = "/bin/sh";
  if (pw) {
    setenv("HOME", pw->pw_dir, 1);
    setenv("USER", pw->pw_name, 1);
    setenv("LOGNAME", pw->pw_name, 1);
    if (chdir(pw->pw_dir)) {
      if (chdir("/")) {
      }
    }
  }
  setenv("SHELL", sh, 1);
  setenv("TERM", "linux", 1);
  setenv("LANG", "C", 1);
  unsetenv("LC_ALL");
  unsetenv("COLUMNS");
  unsetenv("LINES");
  const char *base = strrchr(sh, '/');
  char argv0[64];
  snprintf(argv0, sizeof argv0, "-%s", base ? base + 1 : sh);
  execl(sh, argv0, (char *)NULL);
  _exit(127);
}

Term *term_new(int cols, int rows) {
  Term *t = calloc(1, sizeof *t);
  if (!t) return NULL;
  t->cols = cols, t->rows = rows;
  t->scr = calloc((size_t)cols * rows, sizeof(Cell));
  t->alt = calloc((size_t)cols * rows, sizeof(Cell));
  t->sb = calloc((size_t)cols * SB_LINES, sizeof(Cell));
  t->pen = (Cell){' ', DEF, DEF, 0};
  t->bot = rows - 1;
  t->fd = -1;
  for (int y = 0; y < rows; y++) clear_cells(t, y, 0, cols);
  if (getenv("OREONVR_NO_PTY")) return t;
  int m = posix_openpt(O_RDWR | O_NOCTTY);
  if (m < 0 || grantpt(m) || unlockpt(m)) {
    if (m >= 0) close(m);
    return t;
  }
  struct winsize ws = {(unsigned short)rows, (unsigned short)cols, 0, 0};
  char *sname = ptsname(m);
  pid_t pid = fork();
  if (pid < 0) {
    close(m);
    return t;
  }
  if (pid == 0) {
    setsid();
    int s = open(sname, O_RDWR);
    if (s < 0) _exit(1);
    ioctl(s, TIOCSCTTY, 0);
    ioctl(s, TIOCSWINSZ, &ws);
    dup2(s, 0), dup2(s, 1), dup2(s, 2);
    if (s > 2) close(s);
    close(m);
    for (int fd = 3; fd < 256; fd++) close(fd);
    signal(SIGCHLD, SIG_DFL);
    signal(SIGPIPE, SIG_DFL);
    child_exec();
  }
  ioctl(m, TIOCSWINSZ, &ws);
  fcntl(m, F_SETFL, O_NONBLOCK);
  fcntl(m, F_SETFD, FD_CLOEXEC);
  t->fd = m, t->pid = pid, t->alive = 1;
  return t;
}

void term_free(Term *t) {
  if (!t) return;
  if (t->fd >= 0) close(t->fd);
  if (t->pid > 0) {
    kill(t->pid, SIGHUP);
    waitpid(t->pid, NULL, WNOHANG);
  }
  free(t->scr);
  free(t->alt);
  free(t->sb);
  free(t);
}

int term_alive(Term *t) { return getenv("OREONVR_NO_PTY") ? 1 : t->alive; }

int term_poll(Term *t) {
  if (t->fd < 0) return 0;
  char buf[8192];
  int changed = 0;
  for (int k = 0; k < 16; k++) {
    ssize_t n = read(t->fd, buf, sizeof buf);
    if (n > 0) {
      term_feed(t, buf, (int)n);
      changed = 1;
      continue;
    }
    if (n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR)) {

      int st;
      if (t->pid > 0 && waitpid(t->pid, &st, WNOHANG) == t->pid) t->alive = 0;
      else if (n == 0 || errno == EIO) t->alive = 0;
    }
    break;
  }
  if (changed && t->view) t->view = 0;
  return changed;
}

void term_write(Term *t, const char *b, int n) {
  while (t->fd >= 0 && n > 0) {
    ssize_t w = write(t->fd, b, (size_t)n);
    if (w <= 0) {
      if (w < 0 && errno == EAGAIN) {
        struct pollfd p = {t->fd, POLLOUT, 0};
        poll(&p, 1, 50);
        continue;
      }
      return;
    }
    b += w, n -= (int)w;
  }
}

void term_scroll(Term *t, int lines) {
  t->view += lines;
  if (t->view > t->sb_n) t->view = t->sb_n;
  if (t->view < 0) t->view = 0;
}

void term_draw(Term *t, Surface *s, float x, float y, float cw, float ch, int cursor_on) {
  char g[2] = {0, 0};
  for (int r = 0; r < t->rows; r++) {
    const Cell *line;
    int src = r - t->view;
    if (src >= 0) line = row(t, src);
    else {
      int k = t->sb_n + src;
      if (k < 0) continue;
      line = t->sb + (size_t)((t->sb_head + k) % SB_LINES) * t->cols;
    }
    float ly = y + r * ch;
    for (int c = 0; c < t->cols; c++) {
      Cell cell = line[c];
      int inv = (cell.attr & A_INV) != 0;
      int cur = cursor_on && t->view == 0 && src == t->cy && c == t->cx;
      uint32_t fg = cell.fg == DEF ? C_TERM_FG : PAL[(cell.attr & A_BOLD) && cell.fg < 8 ? cell.fg + 8 : cell.fg];
      uint32_t bg = cell.bg == DEF ? 0 : PAL[cell.bg];
      if (inv) {
        uint32_t tmp = fg;
        fg = bg ? bg : C_TERM_BG;
        bg = tmp;
      }
      if (cur) {
        bg = C_TERM_FG;
        fg = C_TERM_BG;
      }
      float lx = x + c * cw;
      if (bg) gfx_rect(s, lx, ly, cw + 0.5f, ch, bg);
      if (cell.ch > ' ') {
        g[0] = (char)cell.ch;
        gfx_text(s, F_MONO, lx, ly, g, fg);
      }
      if (cell.attr & A_UL) gfx_rect(s, lx, ly + ch - 2, cw, 1, fg);
    }
  }
  if (t->view) {
    char b[48];
    snprintf(b, sizeof b, "scrollback -%d", t->view);
    gfx_text(s, F_SMALL, x + t->cols * cw - gfx_text_w(F_SMALL, b) - 4, y, b, RGB(130, 140, 155));
  }
}

void term_label(Term *t, char *out, int n) {
  snprintf(out, (size_t)n, "Shell");
  if (!t || t->fd < 0 || t->pid <= 0) return;
  char path[64], buf[512];
  pid_t pg = tcgetpgrp(t->fd);
  if (pg > 0 && pg != t->pid) {
    snprintf(path, sizeof path, "/proc/%d/comm", (int)pg);
    FILE *f = fopen(path, "r");
    if (f) {
      if (fgets(buf, sizeof buf, f)) {
        buf[strcspn(buf, "\n")] = 0;
        if (*buf) snprintf(out, (size_t)n, "%s", buf);
      }
      fclose(f);
      return;
    }
  }
  snprintf(path, sizeof path, "/proc/%d/cwd", (int)t->pid);
  ssize_t k = readlink(path, buf, sizeof buf - 1);
  if (k <= 0) return;
  buf[k] = 0;
  const char *home = getenv("HOME");
  struct passwd *pw = getpwuid(getuid());
  const char *user = getenv("OREONVR_USER");
  if (getuid() == 0 && user && *user) pw = getpwnam(user);
  if (pw && pw->pw_dir) home = pw->pw_dir;
  if (home && !strcmp(buf, home)) snprintf(out, (size_t)n, "~");
  else {
    const char *b = strrchr(buf, '/');
    snprintf(out, (size_t)n, "%s", b && b[1] ? b + 1 : "/");
  }
}
