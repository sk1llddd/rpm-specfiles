#!/usr/bin/env python3
# Drives the desktop bridge against a running headless KWin and checks that a launched app shows up as a
# window with live pixels. Run through tests/kde-bridge.sh (starts dbus, pipewire and kwin first).
import ctypes, mmap, os, select, struct, subprocess, sys, time

SLOT = 16 * 4 + 1920 * 1200 * 4
SLOTS = 24
APP = sys.argv[1] if len(sys.argv) > 1 else "org.kde.kcalc.desktop"
bridge = os.environ.get("BRIDGE", "/src/shell/bridge/oreonvr-desktop-bridge")

libc = ctypes.CDLL(None, use_errno=True)
fd = libc.memfd_create(b"t", 0)
os.ftruncate(fd, SLOT * SLOTS)
mm = mmap.mmap(fd, SLOT * SLOTS)
if fd != 3:
    os.dup2(fd, 3)
p = subprocess.Popen([bridge], stdin=subprocess.PIPE, stdout=subprocess.PIPE, pass_fds=(3,), text=True)
os.set_blocking(p.stdout.fileno(), False)
lines = []

def pump(secs):
    end = time.time() + secs
    while time.time() < end:
        if select.select([p.stdout], [], [], 0.2)[0]:
            for l in p.stdout.read().splitlines():
                lines.append(l)

def hdr(i):
    return struct.unpack_from("IIII", mm, SLOT * i)[1:]  # w,h,seq

def send(s):
    p.stdin.write(s + "\n"); p.stdin.flush()

pump(2)
send("desktop 1"); pump(8)
send(("kcm " if APP.startswith("kcm") else "launch ") + APP); pump(25)
wins = [l for l in lines if l.startswith("win\t")]
print("ready:", "ready" in lines, " apps:", sum(l.startswith("app\t") for l in lines))
print("windows:", wins[-3:])
for i in (0, 1):
    w, h, seq = hdr(i)
    print("slot", i, "w", w, "h", h, "seq", seq)
w0, h0, _ = hdr(0)
px = mm[16:16 + w0 * h0 * 4] if w0 and h0 else b""
print("desktop non-black pixels: %d%%" % (100 * sum(1 for i in range(0, len(px), 4 * 97) if px[i:i + 3] != b"\0\0\0") // max(1, len(px) // (4 * 97))))
if os.environ.get("DUMP") and w0 and h0:  # DUMP=/tmp/x.ppm: slot 0 at quarter size, to look at the desktop
    with open(os.environ["DUMP"], "wb") as f:
        f.write(b"P6 %d %d 255\n" % (w0 // 4, h0 // 4))
        for y in range(0, h0 - 3, 4):
            row = px[y * w0 * 4:(y + 1) * w0 * 4]
            f.write(b"".join(bytes((row[x * 4 + 2], row[x * 4 + 1], row[x * 4])) for x in range(0, w0 - 3, 4)))
print("bridge rc:", p.poll())
if p.poll() is None:
    send("m 200 200"); send("b 272 1"); send("b 272 0"); pump(2)
ok = bool(wins) and (os.environ.get("NOCAPTURE") or (hdr(0)[2] > 0 and hdr(1)[2] > 0))  # NOCAPTURE=1: no GL, windows only
print("PASS" if ok else "FAIL")
p.terminate()
sys.exit(0 if ok else 1)
