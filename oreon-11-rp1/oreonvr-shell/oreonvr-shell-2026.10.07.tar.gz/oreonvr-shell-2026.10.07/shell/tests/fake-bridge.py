#!/usr/bin/env python3
import mmap, os, struct, sys, tempfile

SLOT = 64 + 1920 * 1200 * 4
pool = mmap.mmap(3, SLOT * 24)
log = open(os.environ.get("FAKE_LOG", os.devnull), "a", buffering=1)
icons = tempfile.mkdtemp()

def say(*f):
    print("\t".join(str(x) for x in f), flush=True)

def frame(slot, w, h, rgb):
    off = SLOT * slot
    px = bytes((rgb[2], rgb[1], rgb[0], 255)) * w
    for y in range(h):
        pool[off + 64 + y * w * 4: off + 64 + (y + 1) * w * 4] = px
    seq = struct.unpack_from("<I", pool, off + 12)[0]
    struct.pack_into("<4I", pool, off, 0x4F565244, w, h, seq + 1)
    struct.pack_into("<I", pool, off + 16, 1)

for app, name, rgb in (("org.test.Calc.desktop", "Calculator", (40, 160, 90)),
                       ("org.test.Edit.desktop", "Text Editor", (200, 120, 40))):
    path = os.path.join(icons, app + ".rgba")
    with open(path, "wb") as f:
        f.write(struct.pack("<2I", 32, 32) + bytes(rgb + (255,)) * 1024)
    say("app", app, name, path)
say("apps-done")

sets = os.environ.get("FAKE_SETTINGS")
if sets:
    with open(sets) as f:
        for line in f:
            print(line.rstrip("\n"), flush=True)
else:
    for sid, name, desc, group, gw in (("kcm_kscreen", "Display Configuration", "Manage and configure monitors and displays", "Input & Output", 10),
                                       ("kcm_pulseaudio", "Sound", "Configure audio devices", "Input & Output", 10),
                                       ("kcm_lookandfeel", "Global Theme", "Choose the overall look of the desktop", "Appearance & Style", 40)):
        say("setting", sid, name, "", desc, group, gw, 100, "settings", "")
    say("settings-done", 3)

for line in sys.stdin:
    line = line.strip()
    log.write(line + "\n")
    if line == "launch org.test.Calc.desktop":
        say("ready")
        frame(1, 1280, 752, (230, 236, 244))
        say("win", 1, 101, 0, "normal", 0, 0, 1280, 752, "Calculator", "org.test.Calc.desktop")
    elif line == "b 273 1":
        frame(2, 200, 160, (60, 60, 70))
        say("win", 2, 102, 101, "child", 300, 200, 200, 160, "", "org.test.Calc.desktop")
    elif line == "close 101":
        say("gone", 2)
        say("gone", 1)
