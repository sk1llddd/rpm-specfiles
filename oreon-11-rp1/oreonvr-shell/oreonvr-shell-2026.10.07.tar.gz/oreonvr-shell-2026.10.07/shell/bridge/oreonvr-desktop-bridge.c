#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gio/gio.h>
#include <gio/gdesktopappinfo.h>
#include <glib-unix.h>
#include <pipewire/pipewire.h>
#include <spa/debug/types.h>
#include <spa/param/buffers.h>
#include <spa/param/video/format-utils.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <wayland-client.h>

#include "bridge.h"
#include "fake-input-client-protocol.h"
#include "plasma-window-management-client-protocol.h"
#include "zkde-screencast-unstable-v1-client-protocol.h"

#define KDE_UNIT "oreonvr-kde.service"
#define KDE_SOCKET "oreonvr-kde"

typedef struct {
  int used;
  guint64 win;
  struct zkde_screencast_stream_unstable_v1 *cast;
  struct pw_stream *stream;
  struct spa_hook listener;
  struct spa_video_info_raw fmt;
  BridgeHeader *hdr;
  int copy;
} Slot;

typedef struct Win {
  struct org_kde_plasma_window *pw;
  guint64 id, parent;
  char uuid[64];
  char *title, *app_id;
  int x, y, w, h;
  int mapped, announced;
  int vr; /* -1 undecided, 0 stays inside the desktop, 1 floats as its own VR panel */
  struct Win *next;
} Win;

static GDBusConnection *bus;
static GMainLoop *loop;
static void *pool;
static Slot slots[BRIDGE_SLOTS];
static Win *wins;
static GHashTable *vr_apps; /* desktop ids launched from the VR shell: their windows become VR panels */
static gint64 last_launch;

static struct pw_thread_loop *pwl;
static struct pw_core *core;

static struct wl_display *dpy;
static struct wl_registry *reg;
static struct org_kde_plasma_window_management *wm;
static struct zkde_screencast_unstable_v1 *sc;
static struct org_kde_kwin_fake_input *fake;
static struct wl_output *output;
static int kde_ready;
static char *wl_name;

static void out(const char *fmt, ...) G_GNUC_PRINTF(1, 2);
static void out(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vprintf(fmt, ap);
  va_end(ap);
  putchar('\n');
  fflush(stdout);
}

static GPtrArray *icon_themes(void) {
  static GPtrArray *list;
  if (list) return list;
  list = g_ptr_array_new();
  const char *const *sys = g_get_system_data_dirs();
  int ns = 0;
  while (sys[ns]) ns++;
  char **bases = g_new0(char *, ns + 4);
  int nb = 0;
  bases[nb++] = g_build_filename(g_get_user_data_dir(), "icons", NULL);
  for (int i = 0; i < ns; i++) bases[nb++] = g_build_filename(sys[i], "icons", NULL);
  bases[nb++] = g_strdup("/usr/share/icons");
  static const char *first[] = {"breeze", "hicolor", "Adwaita", NULL};
  for (int b = 0; bases[b]; b++) {
    for (int f = 0; first[f]; f++) {
      char *p = g_build_filename(bases[b], first[f], NULL);
      if (g_file_test(p, G_FILE_TEST_IS_DIR)) g_ptr_array_add(list, p);
      else g_free(p);
    }
    GDir *d = g_dir_open(bases[b], 0, NULL);
    const char *n;
    while (d && (n = g_dir_read_name(d))) {
      int skip = 0;
      for (int f = 0; first[f]; f++) skip |= !strcmp(n, first[f]);
      char *p = g_build_filename(bases[b], n, NULL);
      if (!skip && g_file_test(p, G_FILE_TEST_IS_DIR)) g_ptr_array_add(list, p);
      else g_free(p);
    }
    if (d) g_dir_close(d);
  }
  for (int b = 0; bases[b]; b++) g_free(bases[b]);
  g_free(bases);
  return list;
}

static char *find_icon_file(const char *name) {
  static const char *sizes[] = {"scalable", "512", "256", "128", "96", "64", "48", "32", "24", NULL};
  static const char *exts[] = {"svg", "png", NULL};
  static const char *ctx[] = {"apps", "preferences", "categories", "devices", "status", "places", "actions", "mimetypes", "emblems", "applets", NULL};
  GPtrArray *themes = icon_themes();
  for (guint t = 0; t < themes->len; t++)
    for (int c0 = 0; ctx[c0]; c0++)
      for (int x = 0; exts[x]; x++)
        for (int s = 0; sizes[s]; s++) {
          const char *th = g_ptr_array_index(themes, t);
          char *cand[2] = {NULL, NULL};
          if (!strcmp(sizes[s], "scalable")) {
            cand[0] = g_strdup_printf("%s/scalable/%s/%s.%s", th, ctx[c0], name, exts[x]);
            cand[1] = g_strdup_printf("%s/%s/scalable/%s.%s", th, ctx[c0], name, exts[x]);
          } else {
            cand[0] = g_strdup_printf("%s/%sx%s/%s/%s.%s", th, sizes[s], sizes[s], ctx[c0], name, exts[x]);
            cand[1] = g_strdup_printf("%s/%s/%s/%s.%s", th, ctx[c0], sizes[s], name, exts[x]);
          }
          for (int c = 0; c < 2; c++) {
            if (g_file_test(cand[c], G_FILE_TEST_EXISTS)) {
              char *r = cand[c];
              g_free(cand[1 - c]);
              return r;
            }
          }
          g_free(cand[0]);
          g_free(cand[1]);
        }
  static const char *pix[] = {"png", "svg", "xpm", NULL};
  for (int x = 0; pix[x]; x++) {
    char *p = g_strdup_printf("/usr/share/pixmaps/%s.%s", name, pix[x]);
    if (g_file_test(p, G_FILE_TEST_EXISTS)) return p;
    g_free(p);
  }
  return NULL;
}

static char *find_icon(GIcon *icon) {
  if (!icon) return NULL;
  if (G_IS_FILE_ICON(icon)) return g_file_get_path(g_file_icon_get_file(G_FILE_ICON(icon)));
  if (!G_IS_THEMED_ICON(icon)) return NULL;
  const char *const *names = g_themed_icon_get_names(G_THEMED_ICON(icon));
  for (int n = 0; names && names[n]; n++) {
    char *p = find_icon_file(names[n]);
    if (p) return p;
  }
  return NULL;
}

static char *render_icon(const char *id, GIcon *icon) {
  char *src = find_icon(icon);
  if (!src) return NULL;
  GdkPixbuf *pb = gdk_pixbuf_new_from_file_at_scale(src, 96, 96, TRUE, NULL);
  g_free(src);
  if (!pb) return NULL;
  GdkPixbuf *rgba = gdk_pixbuf_add_alpha(pb, FALSE, 0, 0, 0);
  g_object_unref(pb);
  char *dir = g_build_filename(g_get_user_runtime_dir(), "oreonvr-icons", NULL);
  g_mkdir_with_parents(dir, 0755);
  char *path = g_strdup_printf("%s/%s.rgba", dir, id);
  g_free(dir);
  FILE *f = fopen(path, "wb");
  if (f) {
    uint32_t wh[2] = {(uint32_t)gdk_pixbuf_get_width(rgba), (uint32_t)gdk_pixbuf_get_height(rgba)};
    fwrite(wh, 4, 2, f);
    const guchar *px = gdk_pixbuf_read_pixels(rgba);
    int rs = gdk_pixbuf_get_rowstride(rgba);
    for (uint32_t y = 0; y < wh[1]; y++) fwrite(px + (size_t)y * rs, 4, wh[0], f);
    fclose(f);
  }
  g_object_unref(rgba);
  return path;
}

static int app_listed(GAppInfo *a) {
  const char *id = g_app_info_get_id(a);
  static const char *const hidden[] = {"org.kde.plasma", "org.kde.plasmashell", "org.kde.kdeconnect", "org.kde.klipper",
                                       "org.kde.kwalletmanager", "org.kde.kinfocenter", "org.kde.drkonqi", "org.kde.kuserfeedback",
                                       "org.freedesktop.", "liveinst", "plasma-", "kcm_", "nm-", "bluetooth-sendto",
                                       "org.kde.ksystemstats", "org.kde.kscreen", "org.kde.kded", "org.kde.polkit", NULL};
  for (int i = 0; hidden[i]; i++)
    if (g_str_has_prefix(id, hidden[i])) return 0;
  if (G_IS_DESKTOP_APP_INFO(a) && g_desktop_app_info_get_boolean(G_DESKTOP_APP_INFO(a), "Terminal")) return 0;
  return 1;
}

static void list_apps(void) {
  GList *all = g_app_info_get_all();
  for (GList *l = all; l; l = l->next) {
    GAppInfo *a = l->data;
    if (!g_app_info_should_show(a)) continue;
    const char *id = g_app_info_get_id(a);
    if (!id) continue;
    if (!app_listed(a)) continue;
    const char *file = G_IS_DESKTOP_APP_INFO(a) ? g_desktop_app_info_get_filename(G_DESKTOP_APP_INFO(a)) : NULL;
    if (!file) continue;
    char *icon = render_icon(id, g_app_info_get_icon(a));
    char *name = g_strdelimit(g_strdup(g_app_info_get_name(a)), "\t\n", ' ');
    out("app\t%s\t%s\t%s\t%s", id, name, icon ? icon : "", file);
    g_free(name);
    g_free(icon);
  }
  g_list_free_full(all, g_object_unref);
  out("apps-done");
}

typedef struct {
  char *id, *name, *desc, *icon, *cat, *kind;
  int weight;
} Kcm;

typedef struct {
  char *name, *parent;
  int weight;
} KCat;

static GHashTable *kcm_cats;

static const unsigned char *cb_head(const unsigned char *p, const unsigned char *e, int *mt, guint64 *v, int *indef) {
  if (p >= e) return NULL;
  int ib = *p++;
  *mt = ib >> 5;
  int ai = ib & 31;
  *indef = 0;
  if (ai < 24) *v = (guint64)ai;
  else if (ai >= 24 && ai <= 27) {
    int n = 1 << (ai - 24);
    if (e - p < n) return NULL;
    *v = 0;
    for (int i = 0; i < n; i++) *v = (*v << 8) | p[i];
    p += n;
  } else if (ai == 31) *indef = 1, *v = 0;
  else return NULL;
  return p;
}

static const unsigned char *cb_skip(const unsigned char *p, const unsigned char *e, int depth) {
  int mt, indef;
  guint64 v;
  if (depth > 32 || !(p = cb_head(p, e, &mt, &v, &indef))) return NULL;
  switch (mt) {
  case 0:
  case 1:
    return p;
  case 2:
  case 3:
    if (indef) {
      while (p && p < e && *p != 0xff) p = cb_skip(p, e, depth + 1);
      return p && p < e ? p + 1 : NULL;
    }
    return (guint64)(e - p) >= v ? p + v : NULL;
  case 4:
  case 5: {
    guint64 n = mt == 5 ? v * 2 : v;
    if (indef) {
      while (p && p < e && *p != 0xff) p = cb_skip(p, e, depth + 1);
      return p && p < e ? p + 1 : NULL;
    }
    for (guint64 i = 0; i < n && p; i++) p = cb_skip(p, e, depth + 1);
    return p;
  }
  case 6:
    return cb_skip(p, e, depth + 1);
  default:
    if (v == 25) return e - p >= 2 ? p + 2 : NULL;
    if (v == 26) return e - p >= 4 ? p + 4 : NULL;
    if (v == 27) return e - p >= 8 ? p + 8 : NULL;
    return p;
  }
}

static char *cb_text(const unsigned char *p, const unsigned char *e) {
  int mt, indef;
  guint64 v;
  if (!(p = cb_head(p, e, &mt, &v, &indef)) || mt != 3 || indef || (guint64)(e - p) < v) return NULL;
  return g_strndup((const char *)p, (gsize)v);
}

static int cb_int(const unsigned char *p, const unsigned char *e, int *out) {
  int mt, indef;
  guint64 v;
  if (!(p = cb_head(p, e, &mt, &v, &indef))) return 0;
  if (mt == 0) return *out = (int)v, 1;
  if (mt == 1) return *out = -1 - (int)v, 1;
  if (mt == 3 && !indef && (guint64)(e - p) >= v) {
    char *t = g_strndup((const char *)p, (gsize)v);
    *out = atoi(t);
    g_free(t);
    return 1;
  }
  return 0;
}

typedef void (*CbEntry)(const char *key, const unsigned char *val, const unsigned char *e, void *ud);

static int cb_map(const unsigned char *p, const unsigned char *e, CbEntry fn, void *ud) {
  int mt, indef;
  guint64 n;
  if (!(p = cb_head(p, e, &mt, &n, &indef)) || mt != 5) return 0;
  for (guint64 i = 0; p && p < e && (indef ? *p != 0xff : i < n); i++) {
    int kmt, kind;
    guint64 kv;
    const unsigned char *kp = cb_head(p, e, &kmt, &kv, &kind);
    if (!kp) return 0;
    char *key = kmt == 3 ? cb_text(p, e) : g_strdup_printf("#%" G_GUINT64_FORMAT, kv);
    const unsigned char *val = cb_skip(p, e, 0);
    if (!val) {
      g_free(key);
      return 0;
    }
    fn(key, val, e, ud);
    g_free(key);
    p = cb_skip(val, e, 0);
  }
  return 1;
}

static const char *const *locales(void) {
  static const char *const *l;
  if (!l) l = g_get_language_names();
  return l;
}

static int loc_rank(const char *key, const char *base) {
  size_t n = strlen(base);
  if (strncmp(key, base, n)) return -1;
  if (!key[n]) return 1000;
  if (key[n] != '[') return -1;
  const char *const *l = locales();
  for (int i = 0; l[i]; i++) {
    size_t m = strlen(l[i]);
    if (!strcmp(l[i], "C")) break;
    if (!strncmp(key + n + 1, l[i], m) && key[n + 1 + m] == ']' && !key[n + 2 + m]) return i;
  }
  return -1;
}

typedef struct {
  Kcm *k;
  int rn, rd;
} KcmParse;

static void kp_set(char **dst, int *rank, int r, const unsigned char *val, const unsigned char *e) {
  if (r < 0 || r >= *rank) return;
  char *t = cb_text(val, e);
  if (!t) return;
  g_free(*dst);
  *dst = t;
  *rank = r;
}

static void kplugin_entry(const char *key, const unsigned char *val, const unsigned char *e, void *ud) {
  KcmParse *kp = ud;
  int r;
  if ((r = loc_rank(key, "Name")) >= 0) kp_set(&kp->k->name, &kp->rn, r, val, e);
  else if ((r = loc_rank(key, "Description")) >= 0) kp_set(&kp->k->desc, &kp->rd, r, val, e);
  else if (!strcmp(key, "Icon")) {
    g_free(kp->k->icon);
    kp->k->icon = cb_text(val, e);
  }
}

static void meta_entry(const char *key, const unsigned char *val, const unsigned char *e, void *ud) {
  KcmParse *kp = ud;
  if (!strcmp(key, "KPlugin")) cb_map(val, e, kplugin_entry, kp);
  else if (!strcmp(key, "X-KDE-System-Settings-Parent-Category") || !strcmp(key, "X-KDE-KInfoCenter-Category")) {
    char *t = cb_text(val, e);
    if (t && *t && !kp->k->cat) kp->k->cat = t;
    else g_free(t);
  } else if (!strcmp(key, "X-KDE-Weight")) cb_int(val, e, &kp->k->weight);
}

static void top_entry(const char *key, const unsigned char *val, const unsigned char *e, void *ud) {
  if (!strcmp(key, "#4")) cb_map(val, e, meta_entry, ud);
}

static int read_kcm_plugin(const char *path, Kcm *k) {
  gsize n;
  char *data;
  if (!g_file_get_contents(path, &data, &n, NULL)) return 0;
  int ok = 0;
  const char *magic = "qt-project!";
  for (gsize i = 0; i + 16 < n && !ok; i++) {
    if (data[i] != 'q' || memcmp(data + i, magic, 12)) continue;
    const unsigned char *p = (const unsigned char *)data + i + 12, *e = (const unsigned char *)data + n;
    for (int s = 0; s < 8 && p < e && !ok; s++, p++)
      if ((*p & 0xe0) == 0xa0) {
        KcmParse kp = {k, 1 << 20, 1 << 20};
        ok = cb_map(p, e, top_entry, &kp) && k->name;
      }
  }
  g_free(data);
  return ok;
}

static char *kf_locale(GKeyFile *kf, const char *key) {
  char *v = g_key_file_get_locale_string(kf, G_KEY_FILE_DESKTOP_GROUP, key, NULL, NULL);
  if (v && !*v) {
    g_free(v);
    v = NULL;
  }
  return v;
}

static void load_kcm_cats(void) {
  if (kcm_cats) return;
  kcm_cats = g_hash_table_new(g_str_hash, g_str_equal);
  const char *const *dirs = g_get_system_data_dirs();
  for (int d = -1; d < 0 || dirs[d]; d++) {
    char *dir = g_build_filename(d < 0 ? g_get_user_data_dir() : dirs[d], "systemsettings", "categories", NULL);
    GDir *gd = g_dir_open(dir, 0, NULL);
    const char *f;
    while (gd && (f = g_dir_read_name(gd))) {
      if (!g_str_has_suffix(f, ".desktop")) continue;
      char *p = g_build_filename(dir, f, NULL);
      GKeyFile *kf = g_key_file_new();
      if (g_key_file_load_from_file(kf, p, G_KEY_FILE_NONE, NULL)) {
        char *id = g_key_file_get_string(kf, G_KEY_FILE_DESKTOP_GROUP, "X-KDE-System-Settings-Category", NULL);
        if (id && *id && !g_hash_table_contains(kcm_cats, id)) {
          KCat *c = g_new0(KCat, 1);
          c->name = kf_locale(kf, "Name");
          c->parent = g_key_file_get_string(kf, G_KEY_FILE_DESKTOP_GROUP, "X-KDE-System-Settings-Parent-Category", NULL);
          c->weight = g_key_file_get_integer(kf, G_KEY_FILE_DESKTOP_GROUP, "X-KDE-Weight", NULL);
          g_hash_table_insert(kcm_cats, id, c);
          id = NULL;
        }
        g_free(id);
      }
      g_key_file_unref(kf);
      g_free(p);
    }
    if (gd) g_dir_close(gd);
    g_free(dir);
  }
}

static KCat *top_cat(const char *id, char **top_id) {
  KCat *c = NULL;
  *top_id = NULL;
  for (int i = 0; id && *id && i < 8; i++) {
    KCat *n = g_hash_table_lookup(kcm_cats, id);
    if (!n) break;
    c = n;
    *top_id = (char *)id;
    id = n->parent;
  }
  return c;
}

static GPtrArray *plugin_dirs(void) {
  GPtrArray *a = g_ptr_array_new_with_free_func(g_free);
  const char *env = g_getenv("QT_PLUGIN_PATH");
  if (env) {
    char **v = g_strsplit(env, ":", -1);
    for (int i = 0; v[i]; i++)
      if (*v[i]) g_ptr_array_add(a, g_strdup(v[i]));
    g_strfreev(v);
  }
  static const char *const base[] = {"/usr/lib64/qt6/plugins", "/usr/lib/qt6/plugins", "/usr/lib/x86_64-linux-gnu/qt6/plugins",
                                     "/usr/lib/aarch64-linux-gnu/qt6/plugins", "/usr/local/lib64/qt6/plugins", "/usr/local/lib/qt6/plugins", NULL};
  for (int i = 0; base[i]; i++) g_ptr_array_add(a, g_strdup(base[i]));
  return a;
}

static void kcm_free(gpointer p) {
  Kcm *k = p;
  g_free(k->id), g_free(k->name), g_free(k->desc), g_free(k->icon), g_free(k->cat), g_free(k->kind);
  g_free(k);
}

static int kcm_cmp(gconstpointer a, gconstpointer b) {
  const Kcm *x = *(Kcm *const *)a, *y = *(Kcm *const *)b;
  return g_utf8_collate(x->name, y->name);
}

static GPtrArray *collect_kcms(void) {
  load_kcm_cats();
  GHashTable *seen = g_hash_table_new(g_str_hash, g_str_equal);
  GPtrArray *list = g_ptr_array_new_with_free_func(kcm_free);
  static const char *const sub[][2] = {{"plasma/kcms/systemsettings", "settings"}, {"plasma/kcms/systemsettings_qwidgets", "settings"},
                                       {"plasma/kcms/desktop", "settings"},         {"plasma/kcms/kinfocenter", "info"},
                                       {"plasma/kcms", "info"}};
  GPtrArray *dirs = plugin_dirs();
  for (guint d = 0; d < dirs->len; d++)
    for (unsigned s = 0; s < G_N_ELEMENTS(sub); s++) {
      char *dir = g_build_filename(g_ptr_array_index(dirs, d), sub[s][0], NULL);
      GDir *gd = g_dir_open(dir, 0, NULL);
      const char *f;
      while (gd && (f = g_dir_read_name(gd))) {
        if (!g_str_has_suffix(f, ".so")) continue;
        char *id = g_strndup(f, strlen(f) - 3);
        if (g_hash_table_contains(seen, id)) {
          g_free(id);
          continue;
        }
        char *p = g_build_filename(dir, f, NULL);
        Kcm *k = g_new0(Kcm, 1);
        k->weight = 100;
        if (read_kcm_plugin(p, k)) {
          k->id = id;
          k->kind = g_strdup(sub[s][1]);
          g_hash_table_add(seen, k->id);
          g_ptr_array_add(list, k);
        } else {
          kcm_free(k);
          g_free(id);
        }
        g_free(p);
      }
      if (gd) g_dir_close(gd);
      g_free(dir);
    }
  g_ptr_array_unref(dirs);
  GList *all = g_app_info_get_all();
  for (GList *l = all; l; l = l->next) {
    const char *did = g_app_info_get_id(l->data);
    if (!did || !g_str_has_prefix(did, "kcm_") || !g_str_has_suffix(did, ".desktop") || !G_IS_DESKTOP_APP_INFO(l->data)) continue;
    char *id = g_strndup(did, strlen(did) - 8);
    if (g_hash_table_contains(seen, id)) {
      g_free(id);
      continue;
    }
    GDesktopAppInfo *a = l->data;
    Kcm *k = g_new0(Kcm, 1);
    k->id = id;
    k->name = g_strdup(g_app_info_get_name(l->data));
    k->desc = g_strdup(g_app_info_get_description(l->data));
    k->icon = g_desktop_app_info_get_string(a, "Icon");
    k->cat = g_desktop_app_info_get_string(a, "X-KDE-System-Settings-Parent-Category");
    k->kind = g_strdup("desktop");
    k->weight = 100;
    g_hash_table_add(seen, k->id);
    g_ptr_array_add(list, k);
  }
  g_list_free_full(all, g_object_unref);
  g_hash_table_unref(seen);
  g_ptr_array_sort(list, kcm_cmp);
  return list;
}

static char *render_named_icon(const char *id, const char *name) {
  if (!name || !*name) return NULL;
  GIcon *ic = name[0] == '/' ? g_file_icon_new(g_file_new_for_path(name)) : g_themed_icon_new_with_default_fallbacks(name);
  char *r = render_icon(id, ic);
  g_object_unref(ic);
  return r;
}

static void clean(char *s) {
  for (; s && *s; s++)
    if (*s == '\t' || *s == '\n' || *s == '\r') *s = ' ';
}

static void list_settings(int with_icons) {
  GPtrArray *list = collect_kcms();
  for (guint i = 0; i < list->len; i++) {
    Kcm *k = g_ptr_array_index(list, i);
    char *top = NULL;
    KCat *tc = top_cat(k->cat, &top);
    int root = top && !strcmp(top, "rootcategory");
    const char *group = !strcmp(k->kind, "info") ? "About this System" : root ? "General" : tc && tc->name ? tc->name : "More settings";
    int gw = !strcmp(k->kind, "info") ? 900 : root ? 0 : tc ? tc->weight : 800;
    char *icon = with_icons ? render_named_icon(k->id, k->icon) : NULL;
    if (with_icons && !icon) icon = render_named_icon(k->id, "preferences-system");
    clean(k->name), clean(k->desc);
    out("setting\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%s\t%s", k->id, k->name, icon ? icon : "", k->desc ? k->desc : "", group, gw, k->weight,
        k->kind, k->icon ? k->icon : "");
    g_free(icon);
  }
  out("settings-done\t%u", list->len);
  g_ptr_array_unref(list);
}

static GHashTable *kcm_pids;

static void kcm_exited(GPid pid, gint status, gpointer id) {
  if (GPOINTER_TO_INT(g_hash_table_lookup(kcm_pids, id)) == pid) g_hash_table_remove(kcm_pids, id);
  g_spawn_close_pid(pid);
}

static void open_kcm(const char *id) {
  static const char *const ids[] = {"systemsettings.desktop", "org.kde.systemsettings.desktop", "kdesystemsettings.desktop",
                                    "org.kde.kinfocenter.desktop", "kinfocenter.desktop", "kcmshell6.desktop", "org.kde.kcmshell6.desktop", NULL};
  for (int i = 0; ids[i]; i++) g_hash_table_add(vr_apps, g_strdup(ids[i]));
  g_hash_table_add(vr_apps, g_strdup_printf("%s.desktop", id));
  last_launch = g_get_monotonic_time();
  if (!kcm_pids) kcm_pids = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
  if (g_hash_table_contains(kcm_pids, id)) return;
  char *shell = g_find_program_in_path("kcmshell6");
  char *arg = NULL;
  int info = 0;
  GPtrArray *dirs = plugin_dirs();
  static const char *const std_ns[] = {"plasma/kcms/systemsettings", "plasma/kcms/systemsettings_qwidgets", "plasma/kcms/kinfocenter", "plasma/kcms", NULL};
  for (guint d = 0; d < dirs->len && !arg; d++) {
    const char *base = g_ptr_array_index(dirs, d);
    for (int n = 0; std_ns[n] && !arg; n++) {
      char *p = g_strdup_printf("%s/%s/%s.so", base, std_ns[n], id);
      if (g_file_test(p, G_FILE_TEST_EXISTS)) arg = g_strdup(id), info = n >= 2;
      g_free(p);
    }
    char *kcms = g_build_filename(base, "plasma", "kcms", NULL);
    const char *roots[] = {kcms, base};
    for (int r = 0; r < 2 && !arg; r++) {
      GDir *dir = g_dir_open(roots[r], 0, NULL);
      const char *sub;
      while (dir && !arg && (sub = g_dir_read_name(dir))) {
        char *p = g_strdup_printf("%s/%s/%s.so", roots[r], sub, id);
        if (g_file_test(p, G_FILE_TEST_EXISTS)) arg = r ? g_strdup_printf("%s/%s", sub, id) : g_strdup_printf("plasma/kcms/%s/%s", sub, id);
        g_free(p);
      }
      if (dir) g_dir_close(dir);
    }
    g_free(kcms);
  }
  g_ptr_array_unref(dirs);
  char *argv[] = {shell ? shell : info ? "kinfocenter" : "systemsettings", shell && arg ? arg : (char *)id, NULL};
  char **env = g_get_environ();
  env = g_environ_setenv(env, "WAYLAND_DISPLAY", wl_name, TRUE);
  env = g_environ_setenv(env, "XDG_SESSION_TYPE", "wayland", TRUE);
  env = g_environ_setenv(env, "XDG_CURRENT_DESKTOP", "KDE", TRUE);
  env = g_environ_unsetenv(env, "DISPLAY");
  GError *e = NULL;
  GPid pid;
  if (!g_spawn_async(NULL, argv, env, G_SPAWN_SEARCH_PATH | G_SPAWN_STDOUT_TO_DEV_NULL | (shell ? G_SPAWN_DO_NOT_REAP_CHILD : 0), NULL, NULL, &pid, &e)) {
    fprintf(stderr, "bridge: open %s: %s\n", id, e->message);
    g_error_free(e);
  } else if (shell) {
    char *key = g_strdup(id);
    g_hash_table_insert(kcm_pids, key, GINT_TO_POINTER(pid));
    g_child_watch_add(pid, kcm_exited, key);
  }
  g_strfreev(env);
  g_free(shell);
  g_free(arg);
}

static void on_param_changed(void *data, uint32_t id, const struct spa_pod *param) {
  Slot *s = data;
  if (!param || id != SPA_PARAM_Format) return;
  if (spa_format_video_raw_parse(param, &s->fmt) < 0) return;
  uint8_t buf[1024];
  struct spa_pod_builder b = SPA_POD_BUILDER_INIT(buf, sizeof buf);

  const struct spa_pod *p =
      spa_pod_builder_add_object(&b, SPA_TYPE_OBJECT_ParamBuffers, SPA_PARAM_Buffers, SPA_PARAM_BUFFERS_dataType,
                                 SPA_POD_Int((1 << SPA_DATA_MemFd) | (1 << SPA_DATA_MemPtr)));
  pw_stream_update_params(s->stream, &p, 1);
}

static void on_process(void *data) {
  Slot *s = data;
  struct pw_buffer *b = pw_stream_dequeue_buffer(s->stream);
  if (!b) return;
  struct spa_data *d = &b->buffer->datas[0];
  uint32_t w = s->fmt.size.width, h = s->fmt.size.height;
  if (s->copy && d->data && d->chunk && d->chunk->size && w && h && !(d->chunk->flags & SPA_CHUNK_FLAG_CORRUPTED)) {
    if (w > BRIDGE_MAX_W) w = BRIDGE_MAX_W;
    if (h > BRIDGE_MAX_H) h = BRIDGE_MAX_H;
    int stride = d->chunk->stride ? d->chunk->stride : (int)s->fmt.size.width * 4;
    const uint8_t *src = (const uint8_t *)d->data + d->chunk->offset;
    uint32_t *dst = (uint32_t *)(s->hdr + 1);
    int swap = s->fmt.format == SPA_VIDEO_FORMAT_RGBx || s->fmt.format == SPA_VIDEO_FORMAT_RGBA;
    for (uint32_t y = 0; y < h; y++) {
      const uint32_t *row = (const uint32_t *)(src + (size_t)y * stride);
      uint32_t *o = dst + (size_t)y * w;
      if (!swap) memcpy(o, row, (size_t)w * 4);
      else
        for (uint32_t x = 0; x < w; x++) {
          uint32_t v = row[x];
          o[x] = (v & 0xff00ff00u) | ((v & 0xff) << 16) | ((v >> 16) & 0xff);
        }
    }
    s->hdr->w = w, s->hdr->h = h;

    s->hdr->pad[0] = s != &slots[0] && (s->fmt.format == SPA_VIDEO_FORMAT_BGRA || s->fmt.format == SPA_VIDEO_FORMAT_RGBA);
    atomic_fetch_add_explicit((_Atomic uint32_t *)&s->hdr->seq, 1, memory_order_release);
  }
  pw_stream_queue_buffer(s->stream, b);
}

static const struct pw_stream_events stream_events = {
    PW_VERSION_STREAM_EVENTS, .param_changed = on_param_changed, .process = on_process};

static void connect_stream(Slot *s, guint node) {
  pw_thread_loop_lock(pwl);
  if (!core) core = pw_context_connect(pw_context_new(pw_thread_loop_get_loop(pwl), NULL, 0), NULL, 0);
  if (!core) {
    pw_thread_loop_unlock(pwl);
    fprintf(stderr, "bridge: cannot reach pipewire\n");
    return;
  }
  s->stream = pw_stream_new(core, "oreonvr",
                            pw_properties_new(PW_KEY_MEDIA_TYPE, "Video", PW_KEY_MEDIA_CATEGORY, "Capture",
                                              PW_KEY_MEDIA_ROLE, "Screen", NULL));
  pw_stream_add_listener(s->stream, &s->listener, &stream_events, s);
  uint8_t buf[1024];
  struct spa_pod_builder b = SPA_POD_BUILDER_INIT(buf, sizeof buf);
  struct spa_rectangle def = SPA_RECTANGLE(1280, 800), min = SPA_RECTANGLE(1, 1),
                       max = SPA_RECTANGLE(BRIDGE_MAX_W, BRIDGE_MAX_H);
  struct spa_fraction fr0 = SPA_FRACTION(0, 1), fr = SPA_FRACTION(30, 1), frmax = SPA_FRACTION(60, 1);
  const struct spa_pod *params[1] = {spa_pod_builder_add_object(
      &b, SPA_TYPE_OBJECT_Format, SPA_PARAM_EnumFormat, SPA_FORMAT_mediaType, SPA_POD_Id(SPA_MEDIA_TYPE_video),
      SPA_FORMAT_mediaSubtype, SPA_POD_Id(SPA_MEDIA_SUBTYPE_raw), SPA_FORMAT_VIDEO_format,
      SPA_POD_CHOICE_ENUM_Id(5, s == &slots[0] ? SPA_VIDEO_FORMAT_BGRx : SPA_VIDEO_FORMAT_BGRA, SPA_VIDEO_FORMAT_BGRA,
                             SPA_VIDEO_FORMAT_BGRx, SPA_VIDEO_FORMAT_RGBA, SPA_VIDEO_FORMAT_RGBx),
      SPA_FORMAT_VIDEO_size, SPA_POD_CHOICE_RANGE_Rectangle(&def, &min, &max), SPA_FORMAT_VIDEO_framerate,
      SPA_POD_CHOICE_RANGE_Fraction(&fr, &fr0, &frmax))};
  pw_stream_connect(s->stream, PW_DIRECTION_INPUT, node, PW_STREAM_FLAG_AUTOCONNECT | PW_STREAM_FLAG_MAP_BUFFERS,
                    params, 1);
  pw_thread_loop_unlock(pwl);
}

static void cast_created(void *data, struct zkde_screencast_stream_unstable_v1 *c, uint32_t node) {
  Slot *s = data;
  if (s->used && !s->stream) connect_stream(s, node);
}

static void cast_failed(void *data, struct zkde_screencast_stream_unstable_v1 *c, const char *err) {
  fprintf(stderr, "bridge: screencast failed: %s\n", err);
}

static void cast_closed(void *data, struct zkde_screencast_stream_unstable_v1 *c) {}

static struct zkde_screencast_stream_unstable_v1_listener cast_ln = {
    .closed = cast_closed, .created = cast_created, .failed = cast_failed};

static void drop_stream(Slot *s) {
  if (s->stream) {
    pw_thread_loop_lock(pwl);
    pw_stream_destroy(s->stream);
    pw_thread_loop_unlock(pwl);
    s->stream = NULL;
  }
  if (s->cast) {
    zkde_screencast_stream_unstable_v1_close(s->cast);
    s->cast = NULL;
  }
}

static const char *desktop_id(const char *app) {
  static char buf[256];
  buf[0] = 0;
  if (!app || !*app) return buf;
  snprintf(buf, sizeof buf, "%s.desktop", app);
  GDesktopAppInfo *d = g_desktop_app_info_new(buf);
  if (d) {
    g_object_unref(d);
    return buf;
  }
  buf[0] = 0;
  GList *all = g_app_info_get_all();
  for (GList *l = all; l && !buf[0]; l = l->next) {
    const char *id = g_app_info_get_id(l->data);
    const char *wmc = G_IS_DESKTOP_APP_INFO(l->data) ? g_desktop_app_info_get_startup_wm_class(l->data) : NULL;
    if (id && ((wmc && !g_ascii_strcasecmp(wmc, app)) ||
               (g_str_has_suffix(id, ".desktop") && !g_ascii_strncasecmp(id, app, strlen(id) - 8) && strlen(app) == strlen(id) - 8)))
      snprintf(buf, sizeof buf, "%s", id);
  }
  g_list_free_full(all, g_object_unref);
  return buf;
}

static void noop(void) {}

static void fill_noop(void *listener, size_t size) {
  void **f = listener;
  for (size_t i = 0; i < size / sizeof *f; i++)
    if (!f[i]) f[i] = (void *)noop;
}

static void start_desktop(void) {
  Slot *s = &slots[0];
  if (s->used || !sc || !output) return;
  s->used = 1;
  s->cast = zkde_screencast_unstable_v1_stream_output(sc, output, ZKDE_SCREENCAST_UNSTABLE_V1_POINTER_EMBEDDED);
  zkde_screencast_stream_unstable_v1_add_listener(s->cast, &cast_ln, s);
  wl_display_flush(dpy);
}

static Win *win_by_id(guint64 id);

/* Only apps opened from the VR shell float out as panels (with their dialogs); anything opened inside the
   Plasma desktop, including its own menus and popups, stays in the desktop. */
static int is_vr(Win *w) {
  if (w->vr >= 0) return w->vr;
  if (w->parent) {
    Win *p = win_by_id(w->parent);
    w->vr = p && p->vr == 1;
  } else {
    const char *id = desktop_id(w->app_id);
    w->vr = id[0] ? g_hash_table_contains(vr_apps, id) : g_get_monotonic_time() - last_launch < 30 * G_USEC_PER_SEC;
    if (w->vr)
      org_kde_plasma_window_set_state(w->pw, ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_MAXIMIZED,
                                      ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_MAXIMIZED);
  }
  return w->vr;
}

static void announce(Win *w) {
  if (!w->mapped || w->w <= 0 || w->h <= 0 || !w->uuid[0] || !is_vr(w)) return;
  int at = -1;
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (slots[i].used && slots[i].win == w->id) at = i;
  if (at < 0) {
    for (int i = 1; i < BRIDGE_SLOTS && at < 0; i++)
      if (!slots[i].used) at = i;
    if (at < 0) return;
    Slot *s = &slots[at];
    s->used = 1, s->win = w->id, s->copy = 1;
    s->hdr->seq = 0, s->hdr->w = s->hdr->h = 0;
    s->cast = zkde_screencast_unstable_v1_stream_window(sc, w->uuid, ZKDE_SCREENCAST_UNSTABLE_V1_POINTER_HIDDEN);
    zkde_screencast_stream_unstable_v1_add_listener(s->cast, &cast_ln, s);
    wl_display_flush(dpy);
  }
  char *t = g_strdelimit(g_strdup(w->title ? w->title : ""), "\t\n", ' ');
  out("win\t%d\t%" G_GUINT64_FORMAT "\t%" G_GUINT64_FORMAT "\t%s\t%d\t%d\t%d\t%d\t%s\t%s", at, w->id, w->parent,
      w->parent ? "child" : "normal", w->x, w->y, w->w, w->h, t, desktop_id(w->app_id));
  g_free(t);
}

static void w_title(void *d, struct org_kde_plasma_window *p, const char *t) {
  Win *w = d;
  g_free(w->title);
  w->title = g_strdup(t);
  announce(w);
}

static void w_app_id(void *d, struct org_kde_plasma_window *p, const char *a) {
  Win *w = d;
  g_free(w->app_id);
  w->app_id = g_strdup(a);
  announce(w);
}

static void w_parent(void *d, struct org_kde_plasma_window *p, struct org_kde_plasma_window *parent) {
  Win *w = d, *pw = parent ? wl_proxy_get_user_data((struct wl_proxy *)parent) : NULL;
  w->parent = pw ? pw->id : 0;
  announce(w);
}

static void w_geometry(void *d, struct org_kde_plasma_window *p, int32_t x, int32_t y, uint32_t ww, uint32_t hh) {
  Win *w = d;
  w->x = x, w->y = y, w->w = (int)ww, w->h = (int)hh;
  announce(w);
}

static void w_initial(void *d, struct org_kde_plasma_window *p) {
  Win *w = d;
  w->mapped = 1;
  announce(w);
}

static void w_unmapped(void *d, struct org_kde_plasma_window *p) {
  Win *w = d;
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (slots[i].used && slots[i].win == w->id) {
      drop_stream(&slots[i]);
      slots[i].used = 0;
      slots[i].hdr->seq = 0;
      out("gone\t%d", i);
    }
  for (Win **pp = &wins; *pp; pp = &(*pp)->next)
    if (*pp == w) {
      *pp = w->next;
      break;
    }
  org_kde_plasma_window_destroy(w->pw);
  g_free(w->title);
  g_free(w->app_id);
  g_free(w);
}

static struct org_kde_plasma_window_listener win_ln = {.title_changed = w_title,
                                                             .app_id_changed = w_app_id,
                                                             .parent_window = w_parent,
                                                             .geometry = w_geometry,
                                                             .initial_state = w_initial,
                                                             .unmapped = w_unmapped};

static void wm_window(void *d, struct org_kde_plasma_window_management *m, uint32_t id, const char *uuid) {
  Win *w = g_new0(Win, 1);
  w->id = id, w->vr = -1;
  g_strlcpy(w->uuid, uuid, sizeof w->uuid);
  w->next = wins, wins = w;
  w->pw = org_kde_plasma_window_management_get_window_by_uuid(m, uuid);
  org_kde_plasma_window_add_listener(w->pw, &win_ln, w);
}

static struct org_kde_plasma_window_management_listener wm_ln = {.window_with_uuid = wm_window};

static void reg_global(void *d, struct wl_registry *r, uint32_t name, const char *iface, uint32_t ver) {
  if (!strcmp(iface, org_kde_plasma_window_management_interface.name) && ver >= 13) {
    wm = wl_registry_bind(r, name, &org_kde_plasma_window_management_interface, ver < 17 ? ver : 17);
    org_kde_plasma_window_management_add_listener(wm, &wm_ln, NULL);
  } else if (!strcmp(iface, zkde_screencast_unstable_v1_interface.name))
    sc = wl_registry_bind(r, name, &zkde_screencast_unstable_v1_interface, ver < 5 ? ver : 5);
  else if (!strcmp(iface, org_kde_kwin_fake_input_interface.name))
    fake = wl_registry_bind(r, name, &org_kde_kwin_fake_input_interface, ver < 6 ? ver : 6);
  else if (!strcmp(iface, wl_output_interface.name) && !output)
    output = wl_registry_bind(r, name, &wl_output_interface, 1);
}

static void reg_remove(void *d, struct wl_registry *r, uint32_t name) {}

static const struct wl_registry_listener reg_ln = {reg_global, reg_remove};

static gboolean on_wayland(gint fd, GIOCondition cond, gpointer data) {
  if ((cond & (G_IO_ERR | G_IO_HUP)) || wl_display_dispatch(dpy) < 0) {
    fprintf(stderr, "bridge: lost KWin\n");
    g_main_loop_quit(loop);
    return FALSE;
  }
  wl_display_flush(dpy);
  return TRUE;
}

static char *socket_path(void) {
  const char *rt = g_get_user_runtime_dir();
  return g_build_filename(rt, wl_name, NULL);
}

static int ensure_kde(void) {
  if (kde_ready) return 1;
  if (!getenv("OREONVR_NO_UNIT")) {
    GError *e = NULL;
    GVariant *job = g_dbus_connection_call_sync(bus, "org.freedesktop.systemd1", "/org/freedesktop/systemd1",
                                                "org.freedesktop.systemd1.Manager", "StartUnit",
                                                g_variant_new("(ss)", KDE_UNIT, "replace"), G_VARIANT_TYPE("(o)"),
                                                G_DBUS_CALL_FLAGS_NONE, 60000, NULL, &e);
    if (job) g_variant_unref(job);
    else {
      fprintf(stderr, "bridge: starting KWin: %s\n", e->message);
      g_clear_error(&e);
    }
  }
  for (int i = 0; i < 240 && !dpy; i++) {
    dpy = wl_display_connect(wl_name);
    if (!dpy) g_usleep(500000);
  }
  if (!dpy) {
    fprintf(stderr, "bridge: KWin did not come up\n");
    return 0;
  }
  reg = wl_display_get_registry(dpy);
  wl_registry_add_listener(reg, &reg_ln, NULL);
  wl_display_roundtrip(dpy);
  wl_display_roundtrip(dpy);
  if (!wm || !sc || !fake || !output) {
    fprintf(stderr, "bridge: KWin lacks window management, screencast or fake input (is KWIN_WAYLAND_NO_PERMISSION_CHECKS=1 set?)\n");
    return 0;
  }
  org_kde_kwin_fake_input_authenticate(fake, "oreonvr", "Oreon VR shows the Plasma desktop");
  wl_display_flush(dpy);
  g_unix_fd_add(wl_display_get_fd(dpy), G_IO_IN | G_IO_ERR | G_IO_HUP, on_wayland, NULL);
  kde_ready = 1;
  out("ready");
  return 1;
}

static void launch(const char *id) {
  GDesktopAppInfo *a = g_desktop_app_info_new(id);
  if (!a) return;
  g_hash_table_add(vr_apps, g_strdup(id));
  last_launch = g_get_monotonic_time();
  GAppLaunchContext *ctx = g_app_launch_context_new();
  g_app_launch_context_setenv(ctx, "WAYLAND_DISPLAY", wl_name);
  g_app_launch_context_setenv(ctx, "XDG_SESSION_TYPE", "wayland");
  g_app_launch_context_setenv(ctx, "XDG_CURRENT_DESKTOP", "KDE");
  g_app_launch_context_unsetenv(ctx, "DISPLAY");
  GError *e = NULL;
  int nul = open("/dev/null", O_WRONLY | O_CLOEXEC);
  gboolean ok = g_desktop_app_info_launch_uris_as_manager_with_fds(a, NULL, ctx, G_SPAWN_SEARCH_PATH, NULL, NULL, NULL, NULL, -1, nul, -1, &e);
  if (nul >= 0) close(nul);
  if (!ok) {
    fprintf(stderr, "bridge: launch %s: %s\n", id, e->message);
    g_error_free(e);
  }
  g_object_unref(ctx);
  g_object_unref(a);
}

static Win *win_by_id(guint64 id) {
  for (Win *w = wins; w; w = w->next)
    if (w->id == id) return w;
  return NULL;
}

static gboolean on_stdin(GIOChannel *ch, GIOCondition cond, gpointer data) {
  char *line = NULL;
  gsize len;
  if ((cond & (G_IO_HUP | G_IO_ERR)) && !(cond & G_IO_IN)) {
    g_main_loop_quit(loop);
    return FALSE;
  }
  if (g_io_channel_read_line(ch, &line, &len, NULL, NULL) == G_IO_STATUS_EOF) {
    g_main_loop_quit(loop);
    return FALSE;
  }
  if (!line) return TRUE;
  g_strchomp(line);
  double x, y;
  int a, b;
  guint64 id;
  char arg[512];
  if (sscanf(line, "m %lf %lf", &x, &y) == 2) {
    if (kde_ready) org_kde_kwin_fake_input_pointer_motion_absolute(fake, wl_fixed_from_double(x), wl_fixed_from_double(y));
  } else if (sscanf(line, "b %d %d", &a, &b) == 2) {
    if (kde_ready) org_kde_kwin_fake_input_button(fake, (uint32_t)a, b ? 1 : 0);
  } else if (sscanf(line, "a %d", &a) == 1) {
    if (kde_ready) org_kde_kwin_fake_input_axis(fake, 0, wl_fixed_from_double(15.0 * a));
  } else if (sscanf(line, "k %d %d", &a, &b) == 2) {
    if (kde_ready) org_kde_kwin_fake_input_keyboard_key(fake, (uint32_t)a, b ? 1 : 0);
  } else if (sscanf(line, "launch %511s", arg) == 1) {
    if (ensure_kde()) launch(arg);
  } else if (sscanf(line, "kcm %511s", arg) == 1) {
    if (ensure_kde()) open_kcm(arg);
  } else if (sscanf(line, "raise %" G_GUINT64_FORMAT, &id) == 1) {
    Win *w = win_by_id(id);
    if (w) org_kde_plasma_window_set_state(w->pw, ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_ACTIVE, ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_ACTIVE);
  } else if (sscanf(line, "close %" G_GUINT64_FORMAT, &id) == 1) {
    Win *w = win_by_id(id);
    if (w) org_kde_plasma_window_close(w->pw);
  } else if (!strcmp(line, "attach")) {
    char *p = socket_path();
    if (!access(p, F_OK)) ensure_kde();
    g_free(p);
  } else if (sscanf(line, "desktop %d", &a) == 1) {
    slots[0].copy = a;
    if (a && ensure_kde()) start_desktop();
  }
  if (dpy) wl_display_flush(dpy);
  g_free(line);
  return TRUE;
}

int main(int argc, char **argv) {
  if (argc > 1 && !strcmp(argv[1], "--list-settings")) {
    setenv("XDG_CURRENT_DESKTOP", "KDE", 1);
    list_settings(argc > 2 && !strcmp(argv[2], "--icons"));
    return 0;
  }
  struct stat sb;
  if (fstat(3, &sb) || (size_t)sb.st_size < BRIDGE_SHM_SIZE) {
    fprintf(stderr, "bridge: expects the slot pool on fd 3\n");
    return 2;
  }
  pool = mmap(NULL, BRIDGE_SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, 3, 0);
  if (pool == MAP_FAILED) return 2;
  for (int i = 0; i < BRIDGE_SLOTS; i++) slots[i].hdr = bridge_slot(pool, i);

  setenv("XDG_CURRENT_DESKTOP", "KDE", 1);
  {
    const char *old = g_getenv("XDG_DATA_DIRS");
    char *dirs = g_strdup_printf("%s:/var/lib/flatpak/exports/share:%s/flatpak/exports/share",
                                 old && *old ? old : "/usr/local/share:/usr/share", g_get_user_data_dir());
    g_setenv("XDG_DATA_DIRS", dirs, TRUE);
    g_free(dirs);
  }
  vr_apps = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
  fill_noop(&cast_ln, sizeof cast_ln), fill_noop(&win_ln, sizeof win_ln), fill_noop(&wm_ln, sizeof wm_ln);
  wl_name = g_strdup(g_getenv("OREONVR_WAYLAND") ? g_getenv("OREONVR_WAYLAND") : KDE_SOCKET);
  pw_init(NULL, NULL);
  pwl = pw_thread_loop_new("bridge", NULL);
  pw_thread_loop_start(pwl);
  GError *e = NULL;
  bus = g_bus_get_sync(G_BUS_TYPE_SESSION, NULL, &e);
  if (!bus) {
    fprintf(stderr, "bridge: session bus: %s\n", e->message);
    return 1;
  }
  list_apps();
  list_settings(1);
  GIOChannel *in = g_io_channel_unix_new(0);
  g_io_add_watch(in, G_IO_IN | G_IO_HUP | G_IO_ERR, on_stdin, NULL);
  loop = g_main_loop_new(NULL, FALSE);
  g_main_loop_run(loop);

  for (int i = 0; i < BRIDGE_SLOTS; i++)
    if (slots[i].used) drop_stream(&slots[i]);
  if (dpy) {
    wl_display_flush(dpy);
    wl_display_disconnect(dpy);
  }
  pw_thread_loop_stop(pwl);
  return 0;
}
