#!/bin/sh

set -eu
cd "$(dirname "$0")/.."
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
mark="$out/answer"
export OREONVR_BRIDGE="$PWD/tests/fake-bridge.py" FAKE_LOG="$out/bridge.log" OREONVR_WELCOME=1 OREONVR_WIDGETS_FILE="$out/widgets" OREONVR_LAUNCHER_FILE="$out/launcher"

./oreonvr-shell --headless 1280x800 --script "
  waitms 1500;
  tap dock 44 29; wait 20; assert open apps 1; assert gnome 2;
  tap apps 274 140; wait 20; assert open files 1; assert open apps 0;
  tap files 109 26; wait 5;
  tap files 836 20; wait 5; assert open files 0;
  lock; waitms 1200; assert locked 1; look 20 0; wait 3; assert locked 0;
  lock; wait 3; assert locked 1; key 57; wait 3; assert locked 0;
  vr 1; wait 5; shot $out/vr.ppm; vr 0;
  point welcome 200 20; wheel 4; wait 5; assert far welcome 1100;
  grab welcome 200 20 -150 0; wait 10;
  tap welcome 100 170; wait 30; assert open terminal 1; assert focus terminal;
  type echo \$((6*7)) > $mark|n; wait 40;
  tap terminal 736 20; wait 5; assert open terminal 0;
  shot $out/flat.ppm;
  quit"
./oreonvr-shell --headless 1280x800 --script "
  waitms 1500;
  tap dock 44 29; wait 20;
  tap apps 580 67; wait 5;
  tap apps 74 420; wait 5; assert open apps 1;
  tap apps 174 67; wait 5;
  quit"
grep -q '^pin lx:' "$out/launcher" && grep -q '^linux 0' "$out/launcher" ||
  { echo "smoke: launcher did not save the pin and the hidden Linux section" >&2; cat "$out/launcher" >&2; exit 1; }

test "$(cat "$mark" 2>/dev/null)" = 42 || { echo "smoke: terminal did not run the command" >&2; exit 1; }
for f in vr flat; do test -s "$out/$f.ppm" || { echo "smoke: no $f frame" >&2; exit 1; }; done

./oreonvr-shell --headless 1280x800 --script "
  waitms 1500;
  tap dock 44 29; wait 20;
  tap apps 74 420; waitms 800; wait 30; assert open gnome-window 1; assert open apps 0;
  tap gnome-window 320 200; waitms 400; wait 20; assert focus gnome-window;
  type hi; waitms 300;
  tap dock 244 29; waitms 400; wait 20; assert open keyboard 1; assert focus gnome-window;
  tap keyboard 35 82; waitms 400; wait 10; look 0 20; wait 60;
  rtap gnome-window 320 200; waitms 800; wait 20; assert open gnome-child 1;
  tap gnome-child 50 55; waitms 400; wait 20;
  shot $out/gnome.ppm;
  tap gnome-window 616 20; waitms 800; wait 20; assert open gnome-window 0; assert open gnome-child 0;
  quit"
log="$out/bridge.log"
for want in 'launch org.test.Calc.desktop' 'raise 101' 'k 16 1' 'k 16 0' 'b 272 1' 'b 272 0' 'k 35 1' 'k 23 0' 'b 273 1' \
  'close 101'; do
  grep -qx "$want" "$log" || { echo "smoke: bridge never got '$want'" >&2; cat "$log" >&2; exit 1; }
done

grep -Eqx 'm 39[6-9] 3(0[6-9]|1[0-4])|m 40[0-4] 3(0[6-9]|1[0-4])' "$log" || { echo "smoke: menu click landed elsewhere" >&2; exit 1; }
OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 500;
  tap dock 346 29; wait 20; assert open power 1;
  tap power 300 140; wait 20; assert open power 0;
  tap dock 346 29; wait 20; tap power 205 140; wait 10; assert open power 0; assert locked 1; key 57; wait 3; assert locked 0;
  quit"
OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 500; assert width dock 381;
  open settings; wait 20; tap settings 60 116; wait 20;
  tap settings 572 244; wait 20; assert width dock 333;
  tap settings 572 288; wait 20; assert width dock 288;
  quit"
OREONVR_TASKS_FILE="$out/tasks" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 500;
  open tasks; wait 20; assert open tasks 1; assert focus tasks;
  type Buy milk|n; type Call mum|n; wait 10;
  tap tasks 50 152; wait 10;
  tap tasks 280 84; wait 20; assert open keyboard 1; assert focus tasks;
  tap keyboard 35 82; wait 5; tap keyboard 65 208; wait 5; tap keyboard 101 124; wait 5; tap keyboard 450 166; wait 10;
  look 0 20; wait 60; tap tasks 536 20; wait 5; assert open tasks 0;
  quit"
test "$(sed -n 1p "$out/tasks")" = "done=1" || { echo "smoke: completed task was not counted" >&2; exit 1; }
grep -qP '\tBuy milk$' "$out/tasks" || { echo "smoke: task was not saved" >&2; exit 1; }
grep -qP '\tq@$' "$out/tasks" || { echo "smoke: on-screen keyboard did not type" >&2; exit 1; }
test "$(wc -l < "$out/tasks")" -eq 3 || { echo "smoke: wrong number of saved tasks" >&2; exit 1; }
mkdir -p "$out/run"
chmod 700 "$out/run"
(sleep 1; XDG_RUNTIME_DIR="$out/run" WAYLAND_DISPLAY=wayland-0 timeout 30 ./tests/wlclient "$out/wltext") &
XDG_RUNTIME_DIR="$out/run" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 2500; wait 60; assert open keyboard 1;
  tap keyboard 260 124; tap keyboard 117 82; tap keyboard 383 124; tap keyboard 383 124; tap keyboard 363 82; waitms 400; wait 10;
  shot $out/textedit.ppm;
  open terminal; waitms 800; wait 20; assert open keyboard 0;
  quit"
wait
test "$(cat "$out/wltext" 2>/dev/null)" = hello || { echo "smoke: keyboard did not type into the native app" >&2; exit 1; }
OREONVR_DOCS_DIR="$out/notes" HOME="$out/home" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open office; waitms 400; wait 20; assert open office 1; assert focus office;
  tap office 250 348; waitms 300; wait 10; look 0 20; wait 40; tap office 33 71; wait 10; assert open keyboard 1;
  keydown 29; key 49; keyup 29; waitms 200; wait 5; look 0 20; wait 40;
  type Plan|n; type - Ship |n; keydown 29; key 48; keyup 29; type Notes; keydown 29; key 48; keyup 29; type |n;
  keydown 29; key 44; keyup 29; keydown 29; key 21; keyup 29;
  tap office 866 68; wait 5; tap office 900 224; waitms 1200; wait 5;
  quit"
md="$out/home/Documents/Untitled document.md"
grep -qx -- '- \*\*Notes\*\*' "$md" || { echo "smoke: notes export missing formatted list item" >&2; cat "$md" >&2; exit 1; }
test "$(ls "$out/notes" | wc -l)" -eq 2 || { echo "smoke: notes did not save documents" >&2; exit 1; }
grep -qP "\tAction items$" "$out"/notes/*.odoc || { echo "smoke: meeting notes template was not created" >&2; exit 1; }
OREONVR_SHEETS_DIR="$out/sheets" OREONVR_DOCS_DIR="$out/docs2" HOME="$out/home" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open office; waitms 400; wait 20;
  tap office 540 72; wait 10; tap office 185 348; waitms 300; wait 10; look 0 20; wait 40;
  tap office 100 254; wait 3; type 2|n; type 3|n; type =sum(a1:a2)*10|n; type =if(a3>40,\"big\",\"small\")|n;
  tap office 830 68; wait 5; tap office 900 224; waitms 1200; wait 5;
  quit"
csv="$out/home/Documents/Untitled spreadsheet.csv"
test "$(sed -n 3p "$csv")" = 50 || { echo "smoke: sheets formula result wrong" >&2; cat "$csv" >&2; exit 1; }
test "$(sed -n 4p "$csv")" = big || { echo "smoke: sheets IF result wrong" >&2; cat "$csv" >&2; exit 1; }
OREONVR_SLIDES_DIR="$out/slides" OREONVR_DOCS_DIR="$out/docs3" HOME="$out/home" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open office; waitms 400; wait 20; look 0 20; wait 40;
  tap office 652 72; wait 10; tap office 150 348; waitms 300; wait 10;
  tap office 630 389; wait 5; type Quarterly Review; key 1; keydown 29; key 50; keyup 29; wait 5;
  tap office 630 240; wait 5; type Highlights; tap office 500 420; wait 5; type Revenue up|nNew office; key 1; wait 3;
  tap office 705 68; wait 5; tap office 800 224; waitms 1200; wait 5;
  quit"
txt="$out/home/Documents/Untitled presentation.txt"
grep -qx '  Quarterly Review' "$txt" || { echo "smoke: slides title missing" >&2; cat "$txt" >&2; exit 1; }
grep -qx '  - New office' "$txt" || { echo "smoke: slides bullet missing" >&2; cat "$txt" >&2; exit 1; }
test "$(grep -c '^Slide ' "$txt")" -eq 2 || { echo "smoke: slides count wrong" >&2; exit 1; }
test "$(ls "$out/slides" | wc -l)" -eq 1 || { echo "smoke: slides did not save" >&2; exit 1; }
OREONVR_SHEETS_DIR="$out/esheets" OREONVR_DOCS_DIR="$out/edocs" OREONVR_SLIDES_DIR="$out/eslides" HOME="$out/ehome" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open office; waitms 400; wait 20; look 0 20; wait 40;
  tap office 540 72; wait 10; tap office 185 348; waitms 300; wait 10;
  tap office 100 254; wait 3; type 7|n5|n=a1*a2|n; key 1; tap office 30 68; waitms 300; wait 10;
  tap office 428 72; wait 10; keydown 29; key 49; keyup 29; waitms 300; wait 10; type Report|n;
  tap office 955 68; wait 5; tap office 832 336; waitms 300; wait 5; tap office 500 270; waitms 300; wait 5;
  type After; tap office 866 68; wait 5; tap office 900 224; waitms 1200; wait 5;
  quit"
emd="$out/ehome/Documents/Untitled document.md"
grep -qx '> Spreadsheet: Untitled spreadsheet' "$emd" || { echo "smoke: embedded sheet missing from doc" >&2; cat "$emd" >&2; exit 1; }
grep -qx 'After' "$emd" || { echo "smoke: text after embed missing" >&2; cat "$emd" >&2; exit 1; }
grep -qP '\t2\t\t1:sheet[0-9]+:0$' "$out"/edocs/*.odoc || { echo "smoke: embed not saved in doc" >&2; exit 1; }
IO="$out/io"
OREONVR_DOCS_DIR="$IO/docs" OREONVR_SHEETS_DIR="$IO/sheets" OREONVR_SLIDES_DIR="$IO/slides" HOME="$IO/home" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open office; waitms 400; wait 20; look 0 20; wait 40;
  keydown 29; key 49; keyup 29; waitms 300; wait 10; type Hello world|n; tap office 866 68; wait 5; tap office 900 292; waitms 600; wait 5;
  tap office 30 68; waitms 300; wait 10; tap office 840 160; waitms 300; wait 5; tap office 500 270; waitms 500; wait 10;
  tap office 866 68; wait 5; tap office 900 224; waitms 1200; wait 5; tap office 866 68; wait 5; tap office 900 326; waitms 600; wait 5;
  tap office 30 68; waitms 300; wait 10; tap office 840 160; waitms 300; wait 5; tap office 500 270; waitms 500; wait 10;
  tap office 866 68; wait 5; tap office 900 258; waitms 600; wait 5; tap office 30 68; waitms 300; wait 10;
  tap office 540 72; wait 10; tap office 185 348; waitms 300; wait 10; tap office 100 254; wait 3; type 2|n3|n=a1+a2|n; key 1;
  tap office 830 68; wait 5; tap office 900 258; waitms 600; wait 5; tap office 30 68; waitms 300; wait 10;
  tap office 840 160; waitms 300; wait 5; tap office 500 270; waitms 500; wait 10; tap office 830 68; wait 5; tap office 900 224; waitms 600; wait 5;
  tap office 30 68; waitms 300; wait 10; tap office 652 72; wait 10; tap office 150 348; waitms 300; wait 10;
  tap office 630 389; wait 5; type Launch; key 1; wait 3; tap office 705 68; wait 5; tap office 800 258; waitms 600; wait 5; tap office 30 68; waitms 300; wait 10;
  tap office 840 160; waitms 300; wait 5; tap office 500 270; waitms 500; wait 10; tap office 705 68; wait 5; tap office 800 224; waitms 600; wait 5;
  quit"
iod="$IO/home/Documents"
for f in "Untitled document.docx" "Untitled document.rtf" "Untitled spreadsheet.xlsx" "Untitled presentation.pptx"; do
  test -s "$iod/$f" || { echo "smoke: export missing $f" >&2; ls "$iod" >&2; exit 1; }
done
grep -qx 'Hello world' "$iod/Untitled document.md" || { echo "smoke: docx import lost text" >&2; exit 1; }
grep -qx 'Hello world' "$iod/Untitled document.txt" || { echo "smoke: rtf import lost text" >&2; exit 1; }
test "$(sed -n 3p "$iod/Untitled spreadsheet.csv")" = 5 || { echo "smoke: xlsx import lost formula" >&2; cat "$iod/Untitled spreadsheet.csv" >&2; exit 1; }
grep -qx '  Launch' "$iod/Untitled presentation.txt" || { echo "smoke: pptx import lost text" >&2; exit 1; }
test "$(ls "$IO/docs" | wc -l)" -eq 3 || { echo "smoke: imports did not create documents" >&2; exit 1; }
ST="$out/store"
mkdir -p "$ST/fp"
FAKE_FP_DIR="$ST/fp" OREONVR_FLATPAK="$PWD/tests/fake-flatpak.sh" OREONVR_STORE_CURL="$PWD/tests/fake-curl.sh" OREONVR_STORE_CACHE="$ST/cache" HOME="$ST/home" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open store; waitms 400; wait 10; look 0 20; wait 20; waitms 2500; wait 10;
  tap store 454 505; waitms 3800; wait 10; tap store 454 505; waitms 800; wait 10;
  tap store 300 474; waitms 1500; wait 10; tap store 676 448; wait 5; key 1; wait 3;
  tap store 102 172; waitms 1500; wait 10; tap store 986 242; waitms 1500; wait 10;
  assert open store 1; quit"
grep -q '^org.test.Alpha' "$ST/fp/installed" && { echo "smoke: store did not uninstall" >&2; exit 1; }
test -f "$ST/fp/ran_org.test.Alpha" || { echo "smoke: store did not launch the installed app" >&2; ls "$ST/fp" >&2; exit 1; }
IN="$out/inst"
mkdir -p "$IN"
OREONVR_ROOT="$out/none" OREONVR_INSTALL_FORCE=1 OREONVR_LSBLK="$PWD/tests/fake-lsblk.sh" OREONVR_INSTALLER="$PWD/tests/fake-install.sh" FAKE_INSTALL_OUT="$IN/out" ./oreonvr-shell --headless 1600x1000 --script "
  waitms 400; tap welcome 446 20; wait 5; open install; waitms 800; wait 10;
  tap install 762 555; waitms 1500; wait 10; tap install 500 226; wait 5;
  tap install 762 555; wait 10; tap install 762 555; waitms 3500; wait 10;
  assert open install 1; quit"
test "$(cat "$IN/out" 2>/dev/null)" = "--disk /dev/vda" || { echo "smoke: installer did not start the Centrio backend" >&2; exit 1; }
SF="$out/surf"
mkdir -p "$SF"
OREONVR_CHROMIUM=/nonexistent/chrome OREONVR_SURF_DIR="$SF/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 400; tap welcome 446 20; wait 5; open surf; waitms 600; wait 10; assert open surf 1;
  tap surf 1214 22; wait 5; assert open surf 0; quit"
./oreonvr-shell --headless 1280x800 --script "
  waitms 1200; wait 10; open settings; wait 10; tap settings 60 248; wait 10;
  tap settings 300 166; wait 10; tap settings 600 76; wait 10; quit"
grep -q 'kcm kcm_kscreen' "$out/bridge.log" || { echo "smoke: desktop setting did not open" >&2; cat "$out/bridge.log" >&2; exit 1; }
grep -q 'launch systemsettings.desktop' "$out/bridge.log" || { echo "smoke: system settings did not open" >&2; exit 1; }
mkdir -p "$out/whome"
printf '2\tWater the plants\n2\tShip widgets\n' > "$out/wtasks"
OREONVR_WELCOME=0 OREONVR_WIDGETS_FILE="$out/w2" OREONVR_TASKS_FILE="$out/wtasks" HOME="$out/whome" OREONVR_ROOT="$out/none" ./oreonvr-shell --headless 1280x800 --script "
  waitms 800; wait 10; assert open welcome 0; assert open w-clock 1; assert wpage 0;
  tap w-tasks 100 90; wait 5;
  tap w-pager 390 32; wait 10; assert wedit 1;
  tap w-clock 18 18; wait 10; assert open w-clock 0;
  tap w-pager 250 32; wait 10; tap w-gallery 150 200; wait 10; assert open w-clock 1;
  point w-tasks 250 120; wait 2; down 1; wait 3; point w-surf 250 120; wait 3; point w-surf 280 130; wait 10; up 1; waitms 400; wait 10;
  key 1; wait 10; assert wedit 0; quit"
grep -q 'done=1' "$out/wtasks" || { echo "smoke: widget did not complete the task" >&2; exit 1; }
grep -q 'tasks 0 2 1' "$out/w2" || { echo "smoke: widget drag and drop not saved" >&2; cat "$out/w2" >&2; exit 1; }
chrome=${OREONVR_CHROMIUM:-}
if [ -z "$chrome" ]; then
  for c in chromium chromium-browser google-chrome-stable google-chrome; do command -v "$c" >/dev/null 2>&1 && chrome=$(command -v "$c") && break; done
fi
[ -z "$chrome" ] && chrome=$(ls /opt/pw-browsers/chromium-*/chrome-linux/chrome 2>/dev/null | tail -n 1 || true)
if [ -n "$chrome" ] && [ -x "$chrome" ]; then
  printf '<title>Surf smoke</title><a href="#next">next</a>' > "$SF/page.html"
  OREONVR_CHROMIUM="$chrome" OREONVR_SURF_DIR="$SF/data" ./oreonvr-shell --headless 1280x800 --script "
    waitms 400; tap welcome 446 20; wait 5; open surf; waitms 5000; wait 10;
    tap surf 600 66; wait 3; type file://$SF/page.html|n; waitms 3000; wait 10;
    keydown 29; key 32; keyup 29; wait 5; assert open surf 1; quit"
  grep -q 'Surf smoke' "$SF/data/bookmarks.tsv" 2>/dev/null || { echo "smoke: surf did not load the page" >&2; tail -n 5 "$SF/data/chromium.log" >&2 || true; exit 1; }
fi
echo "smoke: ok"
