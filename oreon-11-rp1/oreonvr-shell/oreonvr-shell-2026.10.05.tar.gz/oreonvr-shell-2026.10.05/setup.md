```
# you need: docker or podman on an arm64 machine (Apple Silicon is fine), ~25gb free disk, internet

git clone <repo> && cd oreonvr
sh os/build-iso.sh
# -> os/out/oreonvr-11-aarch64.iso  (takes ~30 min)

# or on the mac: sh ~/Documents/build-oreonvr-arm.sh

# test it in qemu
sh os/run-iso-window-aarch64.sh os/out/oreonvr-11-aarch64.iso
```
the shell is packaged by packaging/oreonvr-shell.spec. that spec is what goes to Oreon's spec repository; Oreon's
build service turns it into rpms (versions are dates, YYYY.MM.DD; Source0 is the GitHub tarball of tag v<Version>, so tag a release before submitting).
locally, os/build-service.sh stands in for that service: it builds every spec in packaging/ in a clean, minimal
Oreon 11 build root (cached), packing the working tree as Source0 (FROM_GIT=1 downloads the real tarball instead).
the rpms land in os/out/rpms/ and the iso installs the shell from them with dnf.
RPM_ONLY=1 sh ~/Documents/build-oreonvr-arm.sh builds just the packages (under a minute once the build root is cached).
on any Oreon 11 system: `sudo dnf install ./oreonvr-shell-*.or11.aarch64.rpm`, then
`sudo systemctl enable oreonvr-shell && sudo systemctl set-default multi-user.target` boots into it.
the iso-only bits (branding, the oreonvr live user, sudoers, polkit rule) stay in os/overlay.

the base is the official Oreon 11 (KDE Plasma) aarch64 iso. everything is built and installed inside its own root with its
own dnf5, so only the repos the iso ships are used (oreon, plus mozilla). apps come from flathub (Chromium by default;
FLATPAK_APPS="org.chromium.Chromium org.qbittorrent.qBittorrent" to add more, DNF_APPS for native ones).

the desktop is a headless KWin that the shell captures and drives (os/overlay/usr/libexec/oreonvr-kwin). window capture
needs OpenGL, so the vm needs a gpu device (virtio-gpu); without a render node KWin falls back to software compositing and
the desktop panels stay empty.

login is oreonvr / oreonvr. use a usb mouse in qemu/utm, not the tablet kind.
