#include <errno.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

#include "oreonvr.h"

static uint32_t *back;
static int bw, bh;

static uint32_t *alloc_back(int w, int h, int *stride) {
  if (!back || bw != w || bh != h) {
    free(back);
    back = calloc((size_t)w * h, 4);
    bw = w, bh = h;
  }
  *stride = w;
  return back;
}

#ifdef HAVE_DRM
#include <xf86drm.h>
#include <xf86drmMode.h>

static struct {
  int fd;
  uint32_t crtc, conn, fb[2], handle[2], pitch;
  uint8_t *map[2];
  size_t size;
  int cur, flip_pending, can_flip;
  drmModeModeInfo mode;
  drmModeCrtc *saved;
} D = {.fd = -1};

static void flip_done(int fd, unsigned seq, unsigned s, unsigned us, void *data) {
  (void)fd, (void)seq, (void)s, (void)us, (void)data;
  D.flip_pending = 0;
}

static uint32_t *drm_begin(int *stride) { return alloc_back(D.mode.hdisplay, D.mode.vdisplay, stride); }

static void drm_end(void) {
  if (D.flip_pending) {
    drmEventContext ev = {.version = 2, .page_flip_handler = flip_done};
    struct timeval tv = {0, 50000};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(D.fd, &fds);
    if (select(D.fd + 1, &fds, NULL, NULL, &tv) > 0) drmHandleEvent(D.fd, &ev);
    D.flip_pending = 0;
  }
  int nxt = D.can_flip ? D.cur ^ 1 : D.cur;
  for (int y = 0; y < bh; y++) memcpy(D.map[nxt] + (size_t)y * D.pitch, back + (size_t)y * bw, (size_t)bw * 4);
  if (D.can_flip) {
    if (drmModePageFlip(D.fd, D.crtc, D.fb[nxt], DRM_MODE_PAGE_FLIP_EVENT, NULL) == 0) {
      D.flip_pending = 1;
      D.cur = nxt;
    } else {
      D.can_flip = 0;
      drmModeSetCrtc(D.fd, D.crtc, D.fb[nxt], 0, 0, &D.conn, 1, &D.mode);
      D.cur = nxt;
    }
  }
}

static int drm_pump(void) { return 1; }

static void drm_shutdown(void) {
  if (D.fd < 0) return;
  if (D.saved) {
    drmModeSetCrtc(D.fd, D.saved->crtc_id, D.saved->buffer_id, D.saved->x, D.saved->y, &D.conn, 1, &D.saved->mode);
    drmModeFreeCrtc(D.saved);
  }
  close(D.fd);
  D.fd = -1;
}

static int make_fb(int i) {
  struct drm_mode_create_dumb c = {.width = D.mode.hdisplay, .height = D.mode.vdisplay, .bpp = 32};
  if (drmIoctl(D.fd, DRM_IOCTL_MODE_CREATE_DUMB, &c)) return 0;
  D.handle[i] = c.handle, D.pitch = c.pitch, D.size = c.size;
  if (drmModeAddFB(D.fd, c.width, c.height, 24, 32, c.pitch, c.handle, &D.fb[i])) return 0;
  struct drm_mode_map_dumb m = {.handle = c.handle};
  if (drmIoctl(D.fd, DRM_IOCTL_MODE_MAP_DUMB, &m)) return 0;
  D.map[i] = mmap(NULL, c.size, PROT_READ | PROT_WRITE, MAP_SHARED, D.fd, (off_t)m.offset);
  if (D.map[i] == MAP_FAILED) return 0;
  memset(D.map[i], 0, c.size);
  return 1;
}

int out_drm(Output *o) {
  char path[32];
  for (int n = 0; n < 4; n++) {
    snprintf(path, sizeof path, "/dev/dri/card%d", n);
    int fd = open(path, O_RDWR | O_CLOEXEC);
    if (fd < 0) continue;
    drmModeRes *res = drmModeGetResources(fd);
    if (!res) {
      close(fd);
      continue;
    }
    drmModeConnector *conn = NULL;
    for (int i = 0; i < res->count_connectors && !conn; i++) {
      drmModeConnector *c = drmModeGetConnector(fd, res->connectors[i]);
      if (c && c->connection == DRM_MODE_CONNECTED && c->count_modes > 0) conn = c;
      else if (c) drmModeFreeConnector(c);
    }
    if (!conn) {
      drmModeFreeResources(res);
      close(fd);
      continue;
    }
    D.fd = fd;
    D.conn = conn->connector_id;
    D.mode = conn->modes[0];
    for (int i = 0; i < conn->count_modes; i++)
      if (conn->modes[i].type & DRM_MODE_TYPE_PREFERRED) {
        D.mode = conn->modes[i];
        break;
      }
    const char *want = getenv("OREONVR_MODE");
    if (want) {
      int ww, hh;
      if (sscanf(want, "%dx%d", &ww, &hh) == 2)
        for (int i = 0; i < conn->count_modes; i++)
          if (conn->modes[i].hdisplay == ww && conn->modes[i].vdisplay == hh) {
            D.mode = conn->modes[i];
            break;
          }
    }
    drmModeEncoder *enc = conn->encoder_id ? drmModeGetEncoder(fd, conn->encoder_id) : NULL;
    D.crtc = enc && enc->crtc_id ? enc->crtc_id : 0;
    if (!D.crtc)
      for (int e = 0; e < conn->count_encoders && !D.crtc; e++) {
        drmModeEncoder *en = drmModeGetEncoder(fd, conn->encoders[e]);
        for (int c = 0; en && c < res->count_crtcs; c++)
          if (en->possible_crtcs & (1u << c)) {
            D.crtc = res->crtcs[c];
            break;
          }
        if (en) drmModeFreeEncoder(en);
      }
    if (enc) drmModeFreeEncoder(enc);
    drmModeFreeConnector(conn);
    drmModeFreeResources(res);
    D.saved = drmModeGetCrtc(fd, D.crtc);
    if (!make_fb(0) || !make_fb(1) || drmModeSetCrtc(fd, D.crtc, D.fb[0], 0, 0, &D.conn, 1, &D.mode)) {
      fprintf(stderr, "oreonvr: %s: modeset failed: %s\n", path, strerror(errno));
      close(fd);
      D.fd = -1;
      continue;
    }
    D.can_flip = 1;
    o->name = "drm";
    o->w = D.mode.hdisplay, o->h = D.mode.vdisplay;
    o->begin = drm_begin, o->end = drm_end, o->pump = drm_pump, o->shutdown = drm_shutdown;
    fprintf(stderr, "oreonvr: %s %dx%d@%d\n", path, o->w, o->h, D.mode.vrefresh);
    return 1;
  }
  return 0;
}
#else
int out_drm(Output *o) {
  (void)o;
  return 0;
}
#endif

static struct {
  int fd, line, bpp, w, h;
  uint8_t *mem;
  size_t len;
} F = {.fd = -1};

static uint32_t *fb_begin(int *stride) { return alloc_back(F.w, F.h, stride); }

static void fb_end(void) {
  for (int y = 0; y < F.h; y++) {
    uint8_t *dst = F.mem + (size_t)y * F.line;
    const uint32_t *src = back + (size_t)y * bw;
    if (F.bpp == 32) memcpy(dst, src, (size_t)F.w * 4);
    else if (F.bpp == 16)
      for (int x = 0; x < F.w; x++) {
        uint32_t p = src[x];
        ((uint16_t *)dst)[x] = (uint16_t)(((p >> 8) & 0xf800) | ((p >> 5) & 0x07e0) | ((p >> 3) & 0x001f));
      }
  }
}

static int fb_pump(void) { return 1; }

static void fb_shutdown(void) {
  if (F.mem) munmap(F.mem, F.len);
  if (F.fd >= 0) close(F.fd);
}

int out_fbdev(Output *o) {
  F.fd = open("/dev/fb0", O_RDWR | O_CLOEXEC);
  if (F.fd < 0) return 0;
  struct fb_var_screeninfo v;
  struct fb_fix_screeninfo f;
  if (ioctl(F.fd, FBIOGET_VSCREENINFO, &v) || ioctl(F.fd, FBIOGET_FSCREENINFO, &f) ||
      (v.bits_per_pixel != 32 && v.bits_per_pixel != 16)) {
    close(F.fd);
    F.fd = -1;
    return 0;
  }
  F.w = (int)v.xres, F.h = (int)v.yres, F.line = (int)f.line_length, F.bpp = (int)v.bits_per_pixel;
  F.len = f.smem_len ? f.smem_len : (size_t)F.line * F.h;
  F.mem = mmap(NULL, F.len, PROT_READ | PROT_WRITE, MAP_SHARED, F.fd, 0);
  if (F.mem == MAP_FAILED) {
    close(F.fd);
    F.fd = -1, F.mem = NULL;
    return 0;
  }
  o->name = "fbdev";
  o->w = F.w, o->h = F.h;
  o->begin = fb_begin, o->end = fb_end, o->pump = fb_pump, o->shutdown = fb_shutdown;
  fprintf(stderr, "oreonvr: fb0 %dx%d %dbpp\n", F.w, F.h, F.bpp);
  return 1;
}

#ifdef HAVE_SDL
#include <SDL2/SDL.h>

static SDL_Window *win;
static SDL_Renderer *ren;
static SDL_Texture *tex;
static int sw, sh;

static uint32_t *sdl_begin(int *stride) { return alloc_back(sw, sh, stride); }

static void sdl_end(void) {
  SDL_UpdateTexture(tex, NULL, back, sw * 4);
  SDL_RenderClear(ren);
  SDL_RenderCopy(ren, tex, NULL, NULL);
  SDL_RenderPresent(ren);
}

static int sdl_key(SDL_Scancode s) {
  static const unsigned char letters[26] = {30, 48, 46, 32, 18, 33, 34, 35, 23, 36, 37, 38, 50,
                                            49, 24, 25, 16, 19, 31, 20, 22, 47, 17, 45, 21, 44};
  if (s >= SDL_SCANCODE_A && s <= SDL_SCANCODE_Z) return letters[s - SDL_SCANCODE_A];
  if (s >= SDL_SCANCODE_1 && s <= SDL_SCANCODE_0) return 2 + (s - SDL_SCANCODE_1);
  if (s >= SDL_SCANCODE_F1 && s <= SDL_SCANCODE_F10) return 59 + (s - SDL_SCANCODE_F1);
  switch (s) {
  case SDL_SCANCODE_RETURN: return 28;
  case SDL_SCANCODE_ESCAPE: return 1;
  case SDL_SCANCODE_BACKSPACE: return 14;
  case SDL_SCANCODE_TAB: return 15;
  case SDL_SCANCODE_SPACE: return 57;
  case SDL_SCANCODE_MINUS: return 12;
  case SDL_SCANCODE_EQUALS: return 13;
  case SDL_SCANCODE_LEFTBRACKET: return 26;
  case SDL_SCANCODE_RIGHTBRACKET: return 27;
  case SDL_SCANCODE_BACKSLASH: return 43;
  case SDL_SCANCODE_SEMICOLON: return 39;
  case SDL_SCANCODE_APOSTROPHE: return 40;
  case SDL_SCANCODE_GRAVE: return 41;
  case SDL_SCANCODE_COMMA: return 51;
  case SDL_SCANCODE_PERIOD: return 52;
  case SDL_SCANCODE_SLASH: return 53;
  case SDL_SCANCODE_CAPSLOCK: return 58;
  case SDL_SCANCODE_INSERT: return 110;
  case SDL_SCANCODE_HOME: return 102;
  case SDL_SCANCODE_PAGEUP: return 104;
  case SDL_SCANCODE_DELETE: return 111;
  case SDL_SCANCODE_END: return 107;
  case SDL_SCANCODE_PAGEDOWN: return 109;
  case SDL_SCANCODE_RIGHT: return 106;
  case SDL_SCANCODE_LEFT: return 105;
  case SDL_SCANCODE_DOWN: return 108;
  case SDL_SCANCODE_UP: return 103;
  case SDL_SCANCODE_KP_ENTER: return 96;
  case SDL_SCANCODE_LCTRL: return 29;
  case SDL_SCANCODE_LSHIFT: return 42;
  case SDL_SCANCODE_LALT: return 56;
  case SDL_SCANCODE_RCTRL: return 97;
  case SDL_SCANCODE_RSHIFT: return 54;
  case SDL_SCANCODE_RALT: return 100;
  default: return 0;
  }
}

static int sdl_pump(void) {
  SDL_Event e;
  int ww, wh;
  SDL_GetWindowSize(win, &ww, &wh);
  while (SDL_PollEvent(&e)) {
    switch (e.type) {
    case SDL_QUIT: return 0;
    case SDL_MOUSEMOTION: input_pointer_move(e.motion.x * sw / ww, e.motion.y * sh / wh); break;
    case SDL_MOUSEBUTTONDOWN:
    case SDL_MOUSEBUTTONUP: {
      int b = e.button.button == SDL_BUTTON_LEFT ? 1 : e.button.button == SDL_BUTTON_RIGHT ? 3 : 2;
      input_pointer_move(e.button.x * sw / ww, e.button.y * sh / wh);
      input_button(b, e.type == SDL_MOUSEBUTTONDOWN);
      break;
    }
    case SDL_MOUSEWHEEL: input_wheel(e.wheel.y); break;
    case SDL_KEYDOWN:
    case SDL_KEYUP: {
      int k = sdl_key(e.key.keysym.scancode);
      if (k) input_key(k, e.type == SDL_KEYDOWN, e.key.repeat);
      break;
    }
    }
  }
  return 1;
}

static void sdl_shutdown(void) {
  SDL_DestroyTexture(tex);
  SDL_DestroyRenderer(ren);
  SDL_DestroyWindow(win);
  SDL_Quit();
}

int out_sdl(Output *o, int w, int h) {
  if (SDL_Init(SDL_INIT_VIDEO)) return 0;
  sw = w, sh = h;
  win = SDL_CreateWindow("Oreon VR", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, SDL_WINDOW_RESIZABLE);
  if (!win) return 0;
  ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_PRESENTVSYNC);
  if (!ren) ren = SDL_CreateRenderer(win, -1, 0);
  tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, w, h);
  if (!ren || !tex) return 0;
  SDL_ShowCursor(SDL_DISABLE);
  o->name = "sdl";
  o->w = w, o->h = h;
  o->begin = sdl_begin, o->end = sdl_end, o->pump = sdl_pump, o->shutdown = sdl_shutdown;
  return 1;
}
#else
int out_sdl(Output *o, int w, int h) {
  (void)o, (void)w, (void)h;
  return 0;
}
#endif

static int hw, hh;
static uint32_t *hl_begin(int *stride) { return alloc_back(hw, hh, stride); }
static void hl_end(void) {}
static int hl_pump(void) { return 1; }
static void hl_shutdown(void) {}

int out_headless(Output *o, int w, int h) {
  hw = w, hh = h;
  o->name = "headless";
  o->w = w, o->h = h;
  o->begin = hl_begin, o->end = hl_end, o->pump = hl_pump, o->shutdown = hl_shutdown;
  return 1;
}

void out_headless_shot(const char *path) {
  FILE *f = fopen(path, "wb");
  if (!f || !back) {
    if (f) fclose(f);
    return;
  }
  fprintf(f, "P6\n%d %d\n255\n", bw, bh);
  unsigned char *row = malloc((size_t)bw * 3);
  for (int y = 0; y < bh; y++) {
    for (int x = 0; x < bw; x++) {
      uint32_t p = back[(size_t)y * bw + x];
      row[x * 3] = (unsigned char)(p >> 16), row[x * 3 + 1] = (unsigned char)(p >> 8), row[x * 3 + 2] = (unsigned char)p;
    }
    fwrite(row, 3, (size_t)bw, f);
  }
  free(row);
  fclose(f);
}
