#ifndef OREONVR_STORE_H
#define OREONVR_STORE_H

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

#include "office.h"

typedef struct J J;

enum { J_NULL, J_BOOL, J_NUM, J_STR, J_ARR, J_OBJ };

J *json_parse(const char *s, size_t n);
void json_free(J *j);
int jtype(const J *j);
J *jget(const J *j, const char *key);
J *jat(const J *j, int i);
int jlen(const J *j);
const char *jkey(const J *j, int i);
const char *jstr(const J *j, const char *key, const char *def);
const char *jval(const J *j, const char *def);
double jnum(const J *j, const char *key, double def);
double jnumv(const J *j, double def);
int jbool(const J *j, const char *key, int def);

enum { NET_IDLE, NET_QUEUED, NET_RUN, NET_OK, NET_FAIL };

typedef struct NetReq {
  int used, state, rc, fd, pty, disk, ttl;
  pid_t pid;
  uint32_t t0, t1, touched;
  char key[700], url[560], post[360], path[800];
  Buf out;
} NetReq;

NetReq *net_http(const char *url, const char *post, int ttl_sec);
NetReq *net_proc(const char *key, char *const argv[], int pty);
void net_drop(NetReq *r);
int net_poll(void);
int net_busy(void);
const char *net_cache_dir(void);

typedef struct Img {
  int used, state, w, h, round, maxw;
  uint32_t *px, accent, touched;
  char url[512];
} Img;

enum { IMG_NONE, IMG_LOADING, IMG_READY, IMG_FAILED };

void img_frame(void);
Img *img_get(const char *url, int maxw, int round);
int img_pending(void);
uint32_t *img_decode_file(const char *path, int *w, int *h);
uint32_t *img_shrink(uint32_t *src, int w, int h, int nw, int nh);
unsigned char *office_inflate(const unsigned char *in, size_t n, size_t *outn);

int wl_spawn(char *const argv[]);
uint32_t *jpeg_decode(const unsigned char *data, size_t n, int *w, int *h);

#endif
