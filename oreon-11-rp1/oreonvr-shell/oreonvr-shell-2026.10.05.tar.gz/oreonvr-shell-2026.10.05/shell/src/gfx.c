#include <math.h>

#include "oreonicon.h"
#include <stdlib.h>
#include <string.h>

#include "oreonvr.h"
#include "font_data.h"

const Font *F_UI = &FONT_UI_DATA;
const Font *F_UI_MED = &FONT_UI_MED_DATA;
const Font *F_BODY = &FONT_BODY_DATA;
const Font *F_SMALL = &FONT_SMALL_DATA;
const Font *F_H1 = &FONT_H1_DATA;
const Font *F_CLOCK = &FONT_CLOCK_DATA;
const Font *F_MONO = &FONT_MONO_DATA;

static inline uint32_t div255(uint32_t x) { return (x + 1 + (x >> 8)) >> 8; }

int surf_init(Surface *s, int lw, int lh, int scale) {
  memset(s, 0, sizeof *s);
  s->scale = scale;
  s->w = lw * scale;
  s->h = lh * scale;
  s->stride = s->w;
  s->px = calloc((size_t)s->w * (size_t)s->h, 4);
  s->owned = 1;
  gfx_noclip(s);
  return s->px != NULL;
}

void surf_wrap(Surface *s, uint32_t *px, int w, int h, int stride) {
  memset(s, 0, sizeof *s);
  s->px = px;
  s->w = w;
  s->h = h;
  s->stride = stride;
  s->scale = 1;
  gfx_noclip(s);
}

void surf_free(Surface *s) {
  if (s->owned) free(s->px);
  memset(s, 0, sizeof *s);
}

void surf_clear(Surface *s, uint32_t argb) {
  uint32_t a = argb >> 24;
  uint32_t r = div255(((argb >> 16) & 255) * a), g = div255(((argb >> 8) & 255) * a), b = div255((argb & 255) * a);
  uint32_t v = (a << 24) | (r << 16) | (g << 8) | b;
  for (int y = 0; y < s->h; y++) {
    uint32_t *row = s->px + (size_t)y * s->stride;
    for (int x = 0; x < s->w; x++) row[x] = v;
  }
}

void gfx_clip(Surface *s, float x, float y, float w, float h) {
  float k = (float)s->scale;
  s->cx0 = (int)floorf(x * k);
  s->cy0 = (int)floorf(y * k);
  s->cx1 = (int)ceilf((x + w) * k);
  s->cy1 = (int)ceilf((y + h) * k);
  if (s->cx0 < 0) s->cx0 = 0;
  if (s->cy0 < 0) s->cy0 = 0;
  if (s->cx1 > s->w) s->cx1 = s->w;
  if (s->cy1 > s->h) s->cy1 = s->h;
}

void gfx_noclip(Surface *s) {
  s->cx0 = s->cy0 = 0;
  s->cx1 = s->w;
  s->cy1 = s->h;
}

static inline void plot(Surface *s, int x, int y, uint32_t c, uint32_t cov) {
  if (x < s->cx0 || y < s->cy0 || x >= s->cx1 || y >= s->cy1) return;
  uint32_t a = div255((c >> 24) * cov);
  if (!a) return;
  uint32_t *p = s->px + (size_t)y * s->stride + x;
  uint32_t sr = div255(((c >> 16) & 255) * a), sg = div255(((c >> 8) & 255) * a), sb = div255((c & 255) * a);
  if (a == 255) {
    *p = 0xff000000u | (sr << 16) | (sg << 8) | sb;
    return;
  }
  uint32_t d = *p, ia = 255 - a;
  uint32_t da = d >> 24, dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
  *p = ((a + div255(da * ia)) << 24) | ((sr + div255(dr * ia)) << 16) | ((sg + div255(dg * ia)) << 8) |
       (sb + div255(db * ia));
}

static inline uint32_t cov_of(float d) {
  float a = 0.5f - d;
  if (a <= 0.f) return 0;
  if (a >= 1.f) return 255;
  return (uint32_t)(a * 255.f + 0.5f);
}

static inline float sd_rr(float px, float py, float cx, float cy, float hw, float hh, float r) {
  float dx = fabsf(px - cx) - (hw - r);
  float dy = fabsf(py - cy) - (hh - r);
  float ox = dx > 0.f ? dx : 0.f, oy = dy > 0.f ? dy : 0.f;
  float in = dx > dy ? dx : dy;
  if (in > 0.f) in = 0.f;
  return sqrtf(ox * ox + oy * oy) + in - r;
}

void gfx_rect(Surface *s, float x, float y, float w, float h, uint32_t c) {
  gfx_rrect(s, x, y, w, h, 0.f, c);
}

void gfx_rrect_band(Surface *s, float x, float y, float w, float h, float r, float y0, float y1, uint32_t c) {
  float k = (float)s->scale;
  float X = x * k, Y = y * k, Wd = w * k, H = h * k, R = r * k;
  if (Wd <= 0 || H <= 0) return;
  if (R > Wd * 0.5f) R = Wd * 0.5f;
  if (R > H * 0.5f) R = H * 0.5f;
  float cx = X + Wd * 0.5f, cy = Y + H * 0.5f, hw = Wd * 0.5f, hh = H * 0.5f;
  int xa = (int)floorf(X) - 1, xb = (int)ceilf(X + Wd) + 1;
  int ya = (int)floorf(Y) - 1, yb = (int)ceilf(Y + H) + 1;
  int ba = (int)floorf(y0 * k), bb = (int)ceilf(y1 * k);
  if (ya < ba) ya = ba;
  if (yb > bb) yb = bb;
  if (xa < s->cx0) xa = s->cx0;
  if (xb > s->cx1) xb = s->cx1;
  if (ya < s->cy0) ya = s->cy0;
  if (yb > s->cy1) yb = s->cy1;
  for (int py = ya; py < yb; py++) {
    float fy = (float)py + 0.5f;
    int straight = fabsf(fy - cy) < hh - R - 1.f;
    for (int px = xa; px < xb; px++) {
      float fx = (float)px + 0.5f;
      uint32_t cv;
      if (straight && fabsf(fx - cx) < hw - 1.f) cv = 255;
      else if (fabsf(fx - cx) < hw - R - 1.f && fabsf(fy - cy) < hh - 1.f) cv = 255;
      else cv = cov_of(sd_rr(fx, fy, cx, cy, hw, hh, R));
      if (cv) plot(s, px, py, c, cv);
    }
  }
}

void gfx_rrect(Surface *s, float x, float y, float w, float h, float r, uint32_t c) {
  gfx_rrect_band(s, x, y, w, h, r, y - 2.f, y + h + 2.f, c);
}

void gfx_shadow(Surface *s, float x, float y, float w, float h, float r, float blur, uint32_t c) {
  float k = (float)s->scale;
  float X = x * k, Y = y * k, Wd = w * k, H = h * k, R = r * k, B = blur * k;
  float cx = X + Wd * 0.5f, cy = Y + H * 0.5f, hw = Wd * 0.5f, hh = H * 0.5f;
  int xa = (int)floorf(X - B), xb = (int)ceilf(X + Wd + B);
  int ya = (int)floorf(Y - B), yb = (int)ceilf(Y + H + B);
  if (xa < s->cx0) xa = s->cx0;
  if (xb > s->cx1) xb = s->cx1;
  if (ya < s->cy0) ya = s->cy0;
  if (yb > s->cy1) yb = s->cy1;
  for (int py = ya; py < yb; py++)
    for (int px = xa; px < xb; px++) {
      float d = sd_rr((float)px + 0.5f, (float)py + 0.5f, cx, cy, hw, hh, R);

      float t = (d + B * 0.35f) / (B * 1.35f);
      if (t >= 1.f) continue;
      if (t < 0.f) t = 0.f;
      float f = 1.f - t;
      f = f * f * (3.f - 2.f * f);
      plot(s, px, py, c, (uint32_t)(f * 255.f));
    }
}

void gfx_disc(Surface *s, float cx, float cy, float r, uint32_t c) {
  float k = (float)s->scale;
  float X = cx * k, Y = cy * k, R = r * k;
  int xa = (int)floorf(X - R - 1), xb = (int)ceilf(X + R + 1);
  int ya = (int)floorf(Y - R - 1), yb = (int)ceilf(Y + R + 1);
  for (int py = ya; py <= yb; py++)
    for (int px = xa; px <= xb; px++) {
      float d = hypotf((float)px + 0.5f - X, (float)py + 0.5f - Y) - R;
      uint32_t cv = cov_of(d);
      if (cv) plot(s, px, py, c, cv);
    }
}

void gfx_ring(Surface *s, float cx, float cy, float r, float th, uint32_t c) {
  float k = (float)s->scale;
  float X = cx * k, Y = cy * k, R = r * k, T = th * k * 0.5f;
  int xa = (int)floorf(X - R - T - 1), xb = (int)ceilf(X + R + T + 1);
  int ya = (int)floorf(Y - R - T - 1), yb = (int)ceilf(Y + R + T + 1);
  for (int py = ya; py <= yb; py++)
    for (int px = xa; px <= xb; px++) {
      float d = fabsf(hypotf((float)px + 0.5f - X, (float)py + 0.5f - Y) - R) - T;
      uint32_t cv = cov_of(d);
      if (cv) plot(s, px, py, c, cv);
    }
}

void gfx_line(Surface *s, float x0, float y0, float x1, float y1, float th, uint32_t c) {
  float k = (float)s->scale;
  x0 *= k, y0 *= k, x1 *= k, y1 *= k;
  float hr = th * k * 0.5f;
  float dx = x1 - x0, dy = y1 - y0, len = hypotf(dx, dy);
  float nx = len > 1e-4f ? dx / len : 0.f, ny = len > 1e-4f ? dy / len : 0.f;
  int xa = (int)floorf(fminf(x0, x1) - hr - 1), xb = (int)ceilf(fmaxf(x0, x1) + hr + 1);
  int ya = (int)floorf(fminf(y0, y1) - hr - 1), yb = (int)ceilf(fmaxf(y0, y1) + hr + 1);
  for (int py = ya; py <= yb; py++)
    for (int px = xa; px <= xb; px++) {
      float fx = (float)px + 0.5f, fy = (float)py + 0.5f;
      float t = (fx - x0) * nx + (fy - y0) * ny;
      if (t < 0.f) t = 0.f;
      if (t > len) t = len;
      float d = hypotf(fx - (x0 + nx * t), fy - (y0 + ny * t)) - hr;
      uint32_t cv = cov_of(d);
      if (cv) plot(s, px, py, c, cv);
    }
}

void gfx_tri(Surface *s, float x0, float y0, float x1, float y1, float x2, float y2, uint32_t c) {
  float k = (float)s->scale;
  x0 *= k, y0 *= k, x1 *= k, y1 *= k, x2 *= k, y2 *= k;
  float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
  if (fabsf(area) < 1e-4f) return;
  if (area < 0) {
    float tx = x1, ty = y1;
    x1 = x2, y1 = y2, x2 = tx, y2 = ty;
  }
  float ex[3] = {x1 - x0, x2 - x1, x0 - x2}, ey[3] = {y1 - y0, y2 - y1, y0 - y2};
  float ox[3] = {x0, x1, x2}, oy[3] = {y0, y1, y2};
  float el[3];
  for (int i = 0; i < 3; i++) el[i] = hypotf(ex[i], ey[i]);
  int xa = (int)floorf(fminf(x0, fminf(x1, x2)) - 1), xb = (int)ceilf(fmaxf(x0, fmaxf(x1, x2)) + 1);
  int ya = (int)floorf(fminf(y0, fminf(y1, y2)) - 1), yb = (int)ceilf(fmaxf(y0, fmaxf(y1, y2)) + 1);
  for (int py = ya; py <= yb; py++)
    for (int px = xa; px <= xb; px++) {
      float fx = (float)px + 0.5f, fy = (float)py + 0.5f, dmax = -1e9f;
      for (int i = 0; i < 3; i++) {

        float d = -(ex[i] * (fy - oy[i]) - ey[i] * (fx - ox[i])) / el[i];
        if (d > dmax) dmax = d;
      }
      uint32_t cv = cov_of(dmax);
      if (cv) plot(s, px, py, c, cv);
    }
}

float gfx_text_w(const Font *f, const char *t) {
  int a = 0;
  for (; *t; t++) {
    unsigned ch = (unsigned char)*t;
    if (ch < 32 || ch > 126) ch = '?';
    a += f->glyphs[ch - 32].adv16;
  }
  return (float)a / 16.f / SCALE;
}

float gfx_text(Surface *s, const Font *f, float x, float y, const char *t, uint32_t c) {
  float k = (float)s->scale;

  int pen16 = (int)(x * k * 16.f);
  int base = (int)(y * k + 0.5f) + f->ascent;
  for (; *t; t++) {
    unsigned ch = (unsigned char)*t;
    if (ch < 32 || ch > 126) ch = '?';
    const Glyph *g = &f->glyphs[ch - 32];
    int gx = (pen16 + 8) / 16 + g->ox, gy = base + g->oy;
    const unsigned char *b = f->bits + g->off;
    for (int j = 0; j < g->h; j++) {
      int py = gy + j;
      if (py < s->cy0 || py >= s->cy1) continue;
      for (int i = 0; i < g->w; i++) {
        uint32_t cv = b[j * g->w + i];
        if (cv) plot(s, gx + i, py, c, cv);
      }
    }
    pen16 += g->adv16;
  }
  return (float)pen16 / 16.f / k - x;
}

float gfx_text_scaled(Surface *s, const Font *f, float x, float y, const char *t, int n, uint32_t c, float q) {
  float k = (float)s->scale, pen = x * k, base = y * k + f->ascent * q;
  for (int i = 0; t[i] && (n < 0 || i < n); i++) {
    unsigned ch = (unsigned char)t[i];
    if (ch < 32 || ch > 126) ch = '?';
    const Glyph *g = &f->glyphs[ch - 32];
    if (g->w && g->h && ch != ' ') {
      float gx = pen + g->ox * q, gy = base + g->oy * q, gw = g->w * q, gh = g->h * q;
      int x0 = (int)floorf(gx), y0 = (int)floorf(gy), x1 = (int)ceilf(gx + gw), y1 = (int)ceilf(gy + gh);
      if (y1 > s->cy0 && y0 < s->cy1 && x1 > s->cx0 && x0 < s->cx1) {
        const unsigned char *b = f->bits + g->off;
        for (int py = y0; py < y1; py++) {
          if (py < s->cy0 || py >= s->cy1) continue;
          float sy = (py + 0.5f - gy) / q - 0.5f;
          int iy = (int)floorf(sy);
          float fy = sy - iy;
          for (int px = x0; px < x1; px++) {
            if (px < s->cx0 || px >= s->cx1) continue;
            float sx = (px + 0.5f - gx) / q - 0.5f;
            int ix = (int)floorf(sx);
            float fx = sx - ix, v = 0;
            for (int j = 0; j < 4; j++) {
              int xx = ix + (j & 1), yy = iy + (j >> 1);
              if (xx < 0 || yy < 0 || xx >= g->w || yy >= g->h) continue;
              v += b[yy * g->w + xx] * ((j & 1) ? fx : 1 - fx) * ((j >> 1) ? fy : 1 - fy);
            }
            if (q < 0.7f) {
              float acc = 0;
              int cnt = 0;
              for (float oy = -0.5f; oy <= 0.5f; oy += 0.5f)
                for (float ox = -0.5f; ox <= 0.5f; ox += 0.5f) {
                  int xx = (int)floorf(sx + 0.5f + ox / q), yy = (int)floorf(sy + 0.5f + oy / q);
                  if (xx >= 0 && yy >= 0 && xx < g->w && yy < g->h) acc += b[yy * g->w + xx];
                  cnt++;
                }
              v = acc / cnt;
            }
            uint32_t cv = (uint32_t)(v + 0.5f);
            if (cv) plot(s, px, py, c, cv > 255 ? 255 : cv);
          }
        }
      }
    }
    pen += g->adv16 / 16.f * q;
  }
  return pen / k - x;
}

void gfx_text_c(Surface *s, const Font *f, float cx, float y, const char *t, uint32_t c) {
  gfx_text(s, f, cx - gfx_text_w(f, t) * 0.5f, y, t, c);
}

void gfx_text_fit(Surface *s, const Font *f, float x, float y, float maxw, const char *t, uint32_t c) {
  if (gfx_text_w(f, t) <= maxw) {
    gfx_text(s, f, x, y, t, c);
    return;
  }
  char buf[256];
  int n = (int)strlen(t);
  if (n > 250) n = 250;
  float dots = gfx_text_w(f, "...");
  while (n > 0) {
    memcpy(buf, t, (size_t)n);
    buf[n] = 0;
    if (gfx_text_w(f, buf) + dots <= maxw) break;
    n--;
  }
  memcpy(buf + n, "...", 4);
  gfx_text(s, f, x, y, buf, c);
}

void gfx_blit_bilinear(Surface *s, const uint32_t *src, int sw, int sh, float x, float y, float w, float h,
                       float r_bottom) {
  float k = (float)s->scale;
  int X0 = (int)(x * k), Y0 = (int)(y * k), X1 = (int)((x + w) * k), Y1 = (int)((y + h) * k);
  float R = r_bottom * k;
  if (X1 <= X0 || Y1 <= Y0 || sw < 2 || sh < 2) return;
  int ya = Y0 > s->cy0 ? Y0 : s->cy0, yb = Y1 < s->cy1 ? Y1 : s->cy1;
  int xa = X0 > s->cx0 ? X0 : s->cx0, xb = X1 < s->cx1 ? X1 : s->cx1;
  int64_t fx = ((int64_t)(sw - 1) << 16) / (X1 - X0), fy = ((int64_t)(sh - 1) << 16) / (Y1 - Y0);
  for (int py = ya; py < yb; py++) {
    int64_t sy = (py - Y0) * fy;
    int y0 = (int)(sy >> 16);
    uint32_t wy = (uint32_t)((sy >> 8) & 255);
    if (y0 >= sh - 1) y0 = sh - 2, wy = 255;
    const uint32_t *r0 = src + (size_t)y0 * sw, *r1 = r0 + sw;
    uint32_t *row = s->px + (size_t)py * s->stride;
    int corner_row = py + 0.5f > Y1 - R;
    for (int px = xa; px < xb; px++) {
      int64_t sx = (px - X0) * fx;
      int x0 = (int)(sx >> 16);
      uint32_t wx = (uint32_t)((sx >> 8) & 255);
      if (x0 >= sw - 1) x0 = sw - 2, wx = 255;
      uint32_t a = r0[x0], b = r0[x0 + 1], c = r1[x0], d = r1[x0 + 1];
      uint32_t rb0 = ((a & 0xff00ff) * (256 - wx) + (b & 0xff00ff) * wx) >> 8 & 0xff00ff;
      uint32_t g0 = ((a & 0xff00) * (256 - wx) + (b & 0xff00) * wx) >> 8 & 0xff00;
      uint32_t rb1 = ((c & 0xff00ff) * (256 - wx) + (d & 0xff00ff) * wx) >> 8 & 0xff00ff;
      uint32_t g1 = ((c & 0xff00) * (256 - wx) + (d & 0xff00) * wx) >> 8 & 0xff00;
      uint32_t rb = (rb0 * (256 - wy) + rb1 * wy) >> 8 & 0xff00ff, g = (g0 * (256 - wy) + g1 * wy) >> 8 & 0xff00;
      uint32_t v = 0xff000000u | rb | g;
      if (corner_row && R > 0) {
        float cx = px + 0.5f < X0 + R ? X0 + R : (px + 0.5f > X1 - R ? X1 - R : px + 0.5f);
        float d2 = hypotf(px + 0.5f - cx, py + 0.5f - (Y1 - R)) - R;
        uint32_t cv = cov_of(d2);
        if (cv < 255) {
          if (cv) plot(s, px, py, v, cv);
          continue;
        }
      }
      row[px] = v;
    }
  }
}

void gfx_blit_premul(Surface *s, const uint32_t *src, int sw, int sh, float x, float y, float w, float h) {
  float k = (float)s->scale;
  int X0 = (int)floorf(x * k), Y0 = (int)floorf(y * k), X1 = (int)ceilf((x + w) * k), Y1 = (int)ceilf((y + h) * k);
  if (X1 <= X0 || Y1 <= Y0 || sw < 1 || sh < 1) return;
  int ya = Y0 > s->cy0 ? Y0 : s->cy0, yb = Y1 < s->cy1 ? Y1 : s->cy1;
  int xa = X0 > s->cx0 ? X0 : s->cx0, xb = X1 < s->cx1 ? X1 : s->cx1;
  float fx = (float)sw / (X1 - X0), fy = (float)sh / (Y1 - Y0);
  for (int py = ya; py < yb; py++) {
    float sy = (py - Y0 + 0.5f) * fy - 0.5f;
    if (sy < 0) sy = 0;
    int y0 = (int)sy, y1 = y0 + 1 < sh ? y0 + 1 : y0;
    uint32_t wy = (uint32_t)((sy - y0) * 256.f);
    const uint32_t *r0 = src + (size_t)y0 * sw, *r1 = src + (size_t)y1 * sw;
    uint32_t *row = s->px + (size_t)py * s->stride;
    for (int px = xa; px < xb; px++) {
      float sx = (px - X0 + 0.5f) * fx - 0.5f;
      if (sx < 0) sx = 0;
      int x0 = (int)sx, x1 = x0 + 1 < sw ? x0 + 1 : x0;
      uint32_t wx = (uint32_t)((sx - x0) * 256.f);
      uint32_t a = r0[x0], b = r0[x1], c = r1[x0], d = r1[x1];
      uint32_t w00 = (256 - wx) * (256 - wy) >> 8, w10 = wx * (256 - wy) >> 8, w01 = (256 - wx) * wy >> 8,
               w11 = wx * wy >> 8;
      uint32_t ag = ((((a >> 8) & 0xff00ff) * w00 + ((b >> 8) & 0xff00ff) * w10 + ((c >> 8) & 0xff00ff) * w01 +
                      ((d >> 8) & 0xff00ff) * w11) >> 8) & 0xff00ff;
      uint32_t rb =
          (((a & 0xff00ff) * w00 + (b & 0xff00ff) * w10 + (c & 0xff00ff) * w01 + (d & 0xff00ff) * w11) >> 8) & 0xff00ff;
      uint32_t sa = ag >> 16;
      if (!sa) continue;
      uint32_t v = (ag << 8) | rb;
      if (sa >= 255) {
        row[px] = v | 0xff000000u;
        continue;
      }
      uint32_t o = row[px], ia = 255 - sa;
      uint32_t r = div255(((o >> 16) & 255) * ia) + (rb >> 16), gg = div255(((o >> 8) & 255) * ia) + (ag & 255),
               bb = div255((o & 255) * ia) + (rb & 255), aa = div255((o >> 24) * ia) + sa;
      if (r > 255) r = 255;
      if (gg > 255) gg = 255;
      if (bb > 255) bb = 255;
      if (aa > 255) aa = 255;
      row[px] = (aa << 24) | (r << 16) | (gg << 8) | bb;
    }
  }
}

void gfx_icon(Surface *s, int icon, float x, float y, float size) {
  float u = size / 28.f;
#define X(v) (x + (v) * u)
#define Y(v) (y + (v) * u)
#define L(v) ((v) * u)
  switch (icon) {
  case IC_APPS:
    for (int r = 0; r < 3; r++)
      for (int c = 0; c < 3; c++) gfx_disc(s, X(5.5f + c * 8.5f), Y(5.5f + r * 8.5f), L(2.2f), THEME(RGB(58, 63, 70), RGB(210, 215, 222)));
    break;
  case IC_TERM:
    gfx_rrect(s, X(1.75f), Y(1.75f), L(24.5f), L(24.5f), L(6.5f), RGB(31, 41, 51));
    gfx_line(s, X(8), Y(10.2f), X(12.2f), Y(14), L(2), C_TERM_GREEN);
    gfx_line(s, X(12.2f), Y(14), X(8), Y(17.8f), L(2), C_TERM_GREEN);
    gfx_line(s, X(14.2f), Y(17.8f), X(20), Y(17.8f), L(2), C_TERM_FG);
    break;
  case IC_FILES:
  case IC_FOLDER:
    gfx_rrect(s, X(4.2f), Y(5.8f), L(9.5f), L(6), L(2), RGB(255, 212, 90));
    gfx_rrect(s, X(4.2f), Y(8.4f), L(19.6f), L(15.2f), L(3.2f), RGB(255, 212, 90));
    gfx_rrect(s, X(4.2f), Y(12.6f), L(19.6f), L(11), L(3.2f), RGB(245, 185, 66));
    break;
  case IC_NOTES:
    gfx_rrect(s, X(1.75f), Y(1.75f), L(24.5f), L(24.5f), L(6.5f), RGB(18, 181, 160));
    gfx_line(s, X(8), Y(10), X(20), Y(10), L(2), RGB(255, 255, 255));
    gfx_line(s, X(8), Y(14.2f), X(20), Y(14.2f), L(2), RGB(255, 255, 255));
    gfx_line(s, X(8), Y(18.4f), X(16), Y(18.4f), L(2), RGB(255, 255, 255));
    break;
  case IC_SETTINGS: {
    float cx = X(14), cy = Y(14);
    for (int i = 0; i < 8; i++) {
      float a = (float)i * PI_F / 4.f;
      gfx_disc(s, cx + cosf(a) * L(8.4f), cy + sinf(a) * L(8.4f), L(2.6f), RGB(107, 114, 128));
    }
    gfx_disc(s, cx, cy, L(8.6f), RGB(107, 114, 128));
    gfx_disc(s, cx, cy, L(3.4f), RGB(255, 255, 255));
    break;
  }
  case IC_DESKTOP:
    gfx_rrect(s, X(1.5f), Y(3.5f), L(25), L(17.5f), L(3.5f), RGB(40, 44, 52));
    gfx_rrect(s, X(3.2f), Y(5.2f), L(21.6f), L(14), L(2), RGB(78, 30, 110));
    gfx_clip(s, X(3.2f), Y(5.2f), L(21.6f), L(14));
    gfx_ring(s, X(21), Y(21), L(11), L(2.2f), RGB(214, 84, 120));
    gfx_ring(s, X(23), Y(22), L(7.5f), L(1.8f), RGB(120, 120, 240));
    gfx_noclip(s);
    gfx_rect(s, X(12.5f), Y(21), L(3), L(3), RGB(40, 44, 52));
    gfx_rrect(s, X(8), Y(23.6f), L(12), L(2.4f), L(1.2f), RGB(40, 44, 52));
    break;
  case IC_TASKS:
    gfx_rrect(s, X(1.75f), Y(1.75f), L(24.5f), L(24.5f), L(6.5f), RGB(66, 120, 245));
    for (int i = 0; i < 3; i++) {
      gfx_disc(s, X(8.2f), Y(8.4f + i * 5.6f), L(1.7f), RGB(255, 255, 255));
      gfx_line(s, X(12.2f), Y(8.4f + i * 5.6f), X(20.4f), Y(8.4f + i * 5.6f), L(1.9f), RGB(255, 255, 255));
    }
    break;
  case IC_OFFICE:
    gfx_rrect(s, X(1.75f), Y(1.75f), L(24.5f), L(24.5f), L(6.5f), RGB(76, 68, 226));
    gfx_rrect(s, X(5.6f), Y(5.4f), L(11), L(13), L(2.2f), RGB(255, 150, 82));
    gfx_rrect(s, X(8.6f), Y(7.9f), L(11), L(13), L(2.2f), RGB(52, 44, 180));
    gfx_rrect(s, X(9), Y(8.3f), L(11), L(13), L(2.2f), RGB(70, 200, 140));
    gfx_rrect(s, X(11.6f), Y(10.4f), L(11), L(13), L(2.2f), RGB(52, 44, 180));
    gfx_rrect(s, X(12), Y(10.8f), L(11), L(13), L(2.2f), RGB(255, 255, 255));
    gfx_rect(s, X(14.2f), Y(14), L(6.6f), L(1.4f), RGB(84, 76, 230));
    gfx_rect(s, X(14.2f), Y(16.9f), L(6.6f), L(1.4f), RGB(188, 184, 246));
    gfx_rect(s, X(14.2f), Y(19.8f), L(4.4f), L(1.4f), RGB(188, 184, 246));
    break;
  case IC_STORE:
    gfx_rrect(s, X(1.75f), Y(1.75f), L(24.5f), L(24.5f), L(6.5f), RGB(22, 126, 232));
    gfx_rrect(s, X(6.6f), Y(10.4f), L(14.8f), L(11.6f), L(3), RGB(255, 255, 255));
    gfx_ring(s, X(14), Y(10.4f), L(3.9f), L(1.7f), RGB(255, 255, 255));
    gfx_line(s, X(14), Y(13.2f), X(14), Y(18.2f), L(1.9f), RGB(22, 126, 232));
    gfx_line(s, X(14), Y(18.4f), X(11.6f), Y(15.9f), L(1.9f), RGB(22, 126, 232));
    gfx_line(s, X(14), Y(18.4f), X(16.4f), Y(15.9f), L(1.9f), RGB(22, 126, 232));
    break;
  case IC_SURF: {
    float cx = X(14), cy = Y(14), r = L(12.6f);
    for (int i = 0; i < 12; i++) {
      float t = i / 11.f;
      gfx_disc(s, cx - r * 0.1f * t, cy - r * 0.1f * t, r * (1 - t * 0.5f), RGB((int)(46 - 46 * t), (int)(134 + 80 * t), (int)(255 - 41 * t)));
    }
    gfx_disc(s, cx + r * 0.38f, cy - r * 0.42f, r * 0.17f, RGBA(255, 255, 255, 235));
    for (int k = 0; k < 3; k++) {
      float yb = cy + r * (k == 0 ? 0.12f : k == 1 ? 0.34f : 0.62f), amp = r * (k == 2 ? 0.17f : 0.2f), ph = k == 0 ? 0.6f : k == 1 ? 3.2f : 1.4f;
      uint32_t c = k == 0 ? RGBA(255, 255, 255, 110) : k == 1 ? RGB(255, 255, 255) : RGB(18, 96, 214);
      for (float dx = -r + 0.5f; dx < r - 0.4f; dx += 0.5f) {
        float hh = sqrtf(r * r - dx * dx) - 0.5f, wy = yb - amp * sinf(dx / r * 2.6f + ph);
        float top = wy < cy - hh ? cy - hh : wy, bot = cy + hh;
        if (top < bot) gfx_rect(s, cx + dx, top, 0.8f, bot - top, c);
      }
    }
    break;
  }
  case IC_INSTALL:
    gfx_blit_premul(s, (const uint32_t *)OREON_ICON, OREON_ICON_W, OREON_ICON_H, X(1.5f), Y(2.2f), L(25), L(25) * OREON_ICON_H / OREON_ICON_W);
    break;
  case IC_KEYBOARD:
    gfx_rrect(s, X(1.5f), Y(6.5f), L(25), L(15.5f), L(3.5f), RGB(70, 78, 92));
    for (int r = 0; r < 3; r++)
      for (int c = 0; c < (r == 2 ? 1 : 5); c++) {
        if (r == 2) gfx_rrect(s, X(8.5f), Y(15.8f), L(11), L(2.4f), L(1.2f), RGB(226, 232, 242));
        else gfx_rrect(s, X(4.2f + c * 4.3f + r * 1.6f), Y(9.2f + r * 3.3f), L(2.8f), L(2.2f), L(0.8f), RGB(226, 232, 242));
      }
    break;
  case IC_DOC:
    gfx_rrect(s, X(6), Y(3), L(16), L(22), L(3), RGB(214, 220, 228));
    gfx_line(s, X(10), Y(10), X(18), Y(10), L(1.6f), RGB(150, 158, 170));
    gfx_line(s, X(10), Y(14), X(18), Y(14), L(1.6f), RGB(150, 158, 170));
    gfx_line(s, X(10), Y(18), X(15), Y(18), L(1.6f), RGB(150, 158, 170));
    break;
  }
#undef X
#undef Y
#undef L
}
