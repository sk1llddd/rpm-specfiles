#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "store.h"

struct J {
  int t, nk, cap;
  double n;
  char *s;
  J **k;
  char **key;
};

typedef struct {
  const char *p, *end;
  int err;
} JP;

static J *mk(int t) {
  J *j = calloc(1, sizeof *j);
  j->t = t;
  return j;
}

static void ws(JP *p) {
  while (p->p < p->end && (*p->p == ' ' || *p->p == '\n' || *p->p == '\t' || *p->p == '\r')) p->p++;
}

static void put_utf8(Buf *b, unsigned cp) {
  char u[4];
  int l;
  if (cp < 0x80) u[0] = (char)cp, l = 1;
  else if (cp < 0x800) u[0] = (char)(0xC0 | cp >> 6), u[1] = (char)(0x80 | (cp & 63)), l = 2;
  else if (cp < 0x10000) u[0] = (char)(0xE0 | cp >> 12), u[1] = (char)(0x80 | ((cp >> 6) & 63)), u[2] = (char)(0x80 | (cp & 63)), l = 3;
  else u[0] = (char)(0xF0 | cp >> 18), u[1] = (char)(0x80 | ((cp >> 12) & 63)), u[2] = (char)(0x80 | ((cp >> 6) & 63)), u[3] = (char)(0x80 | (cp & 63)), l = 4;
  buf_put(b, u, (size_t)l);
}

static unsigned hex4(const char *s) {
  unsigned v = 0;
  for (int i = 0; i < 4; i++) {
    char c = s[i];
    v = v << 4 | (unsigned)(c >= 'a' ? c - 'a' + 10 : c >= 'A' ? c - 'A' + 10 : c - '0');
  }
  return v;
}

static char *pstr(JP *p) {
  if (p->p >= p->end || *p->p != '"') return p->err = 1, NULL;
  p->p++;
  Buf b = {0};
  buf_put(&b, "", 0);
  while (p->p < p->end && *p->p != '"') {
    char c = *p->p++;
    if (c != '\\') {
      if (c == '\n' || c == '\r' || c == '\t') c = ' ';
      buf_put(&b, &c, 1);
      continue;
    }
    if (p->p >= p->end) break;
    c = *p->p++;
    switch (c) {
    case 'n': case 'r': case 't': case 'f': case 'b': buf_put(&b, " ", 1); break;
    case 'u':
      if (p->p + 4 <= p->end) {
        unsigned cp = hex4(p->p);
        p->p += 4;
        if (cp >= 0xD800 && cp < 0xDC00 && p->p + 6 <= p->end && p->p[0] == '\\' && p->p[1] == 'u') {
          unsigned lo = hex4(p->p + 2);
          if (lo >= 0xDC00 && lo < 0xE000) cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00), p->p += 6;
        }
        put_utf8(&b, cp);
      }
      break;
    default: buf_put(&b, &c, 1);
    }
  }
  if (p->p < p->end) p->p++;
  else p->err = 1;
  char *out = malloc(b.n * 3 + 8);
  office_ascii(b.s ? b.s : "", (int)b.n, out, (int)(b.n * 3 + 8));
  free(b.s);
  return out;
}

static void add(J *o, char *key, J *v) {
  if (o->nk == o->cap) {
    o->cap = o->cap ? o->cap * 2 : 4;
    o->k = realloc(o->k, sizeof(J *) * (size_t)o->cap);
    o->key = realloc(o->key, sizeof(char *) * (size_t)o->cap);
  }
  o->k[o->nk] = v;
  o->key[o->nk++] = key;
}

static J *pval(JP *p, int depth) {
  ws(p);
  if (p->p >= p->end || depth > 40) return p->err = 1, NULL;
  char c = *p->p;
  if (c == '{' || c == '[') {
    J *j = mk(c == '{' ? J_OBJ : J_ARR);
    char close = c == '{' ? '}' : ']';
    p->p++;
    ws(p);
    if (p->p < p->end && *p->p == close) return p->p++, j;
    for (;;) {
      ws(p);
      char *key = NULL;
      if (c == '{') {
        key = pstr(p);
        if (!key) break;
        ws(p);
        if (p->p >= p->end || *p->p != ':') {
          free(key);
          p->err = 1;
          break;
        }
        p->p++;
      }
      J *v = pval(p, depth + 1);
      if (!v) {
        free(key);
        break;
      }
      add(j, key, v);
      ws(p);
      if (p->p < p->end && *p->p == ',') {
        p->p++;
        continue;
      }
      if (p->p < p->end && *p->p == close) {
        p->p++;
        return j;
      }
      p->err = 1;
      break;
    }
    json_free(j);
    return NULL;
  }
  if (c == '"') {
    J *j = mk(J_STR);
    j->s = pstr(p);
    if (!j->s) return free(j), NULL;
    return j;
  }
  if (!strncmp(p->p, "true", 4)) {
    p->p += 4;
    J *j = mk(J_BOOL);
    j->n = 1;
    return j;
  }
  if (!strncmp(p->p, "false", 5)) {
    p->p += 5;
    return mk(J_BOOL);
  }
  if (!strncmp(p->p, "null", 4)) {
    p->p += 4;
    return mk(J_NULL);
  }
  char *e;
  double d = strtod(p->p, &e);
  if (e == p->p) return p->err = 1, NULL;
  p->p = e;
  J *j = mk(J_NUM);
  j->n = d;
  return j;
}

J *json_parse(const char *s, size_t n) {
  JP p = {s, s + n, 0};
  J *j = pval(&p, 0);
  return p.err ? (json_free(j), NULL) : j;
}

void json_free(J *j) {
  if (!j) return;
  for (int i = 0; i < j->nk; i++) {
    json_free(j->k[i]);
    free(j->key ? j->key[i] : NULL);
  }
  free(j->k);
  free(j->key);
  free(j->s);
  free(j);
}

int jtype(const J *j) { return j ? j->t : J_NULL; }

J *jget(const J *j, const char *key) {
  if (!j || j->t != J_OBJ) return NULL;
  for (int i = 0; i < j->nk; i++)
    if (!strcmp(j->key[i], key)) return j->k[i];
  return NULL;
}

J *jat(const J *j, int i) { return j && (j->t == J_ARR || j->t == J_OBJ) && i >= 0 && i < j->nk ? j->k[i] : NULL; }

int jlen(const J *j) { return j && (j->t == J_ARR || j->t == J_OBJ) ? j->nk : 0; }

const char *jkey(const J *j, int i) { return j && j->t == J_OBJ && i >= 0 && i < j->nk ? j->key[i] : ""; }

const char *jval(const J *j, const char *def) { return j && j->t == J_STR && j->s ? j->s : def; }

const char *jstr(const J *j, const char *key, const char *def) { return jval(jget(j, key), def); }

double jnumv(const J *j, double def) {
  if (!j) return def;
  if (j->t == J_NUM || j->t == J_BOOL) return j->n;
  if (j->t == J_STR && j->s) return atof(j->s);
  return def;
}

double jnum(const J *j, const char *key, double def) { return jnumv(jget(j, key), def); }

int jbool(const J *j, const char *key, int def) {
  J *v = jget(j, key);
  if (!v) return def;
  if (v->t == J_STR) return v->s && (!strcmp(v->s, "true") || !strcmp(v->s, "1"));
  return v->n != 0;
}
