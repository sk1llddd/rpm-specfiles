#include <ctype.h>
#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "oreonvr.h"

#define MAXT 600
#define PAD 20
#define WIN_W 560
#define NEW_Y 16
#define NEW_H 56
#define LIST_Y 84
#define ROW_H 56
#define ROWS 3
#define WIN_H (BAR_H + LIST_Y + ROWS * ROW_H + 16)

enum { Z_ADD = 1, Z_UP, Z_DOWN, Z_ROW = 10 };

typedef struct {
  char title[96];
} Task;

extern const char *user_home(void);

static Task tasks[MAXT];
static int ntasks, ndone, loaded, top;
static char entry[64];
static int elen;

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static const char *store_path(void) {
  static char path[512];
  const char *e = getenv("OREONVR_TASKS_FILE");
  if (e && *e) return e;
  snprintf(path, sizeof path, "%s/.oreonvr-tasks", user_home());
  return path;
}

static void save_tasks(void) {
  FILE *f = fopen(store_path(), "w");
  if (!f) return;
  fprintf(f, "done=%d\n", ndone);
  for (int i = 0; i < ntasks; i++) fprintf(f, "2\t%s\n", tasks[i].title);
  fclose(f);
}

static void load_tasks(void) {
  if (loaded) return;
  loaded = 1;
  FILE *f = fopen(store_path(), "r");
  if (!f) return;
  char line[256];
  while (fgets(line, sizeof line, f)) {
    line[strcspn(line, "\r\n")] = 0;
    int n;
    if (sscanf(line, "done=%d", &n) == 1) {
      ndone = n < 0 ? 0 : n;
      continue;
    }
    char *title = strchr(line, '\t');
    if (!title || ntasks >= MAXT) continue;
    title++;
    float a, b, c;
    int used = 0;
    if (sscanf(title, "%f\t%f\t%f\t%n", &a, &b, &c, &used) == 3 && used > 0) title += used;
    if (!*title) continue;
    snprintf(tasks[ntasks++].title, sizeof tasks[0].title, "%s", title);
  }
  fclose(f);
}

static int matches(const Task *t) {
  if (!elen) return 1;
  for (const char *h = t->title; *h; h++) {
    int k = 0;
    while (entry[k] && h[k] && tolower((unsigned char)h[k]) == tolower((unsigned char)entry[k])) k++;
    if (!entry[k]) return 1;
  }
  return 0;
}

static int visible_count(void) {
  int n = 0;
  for (int i = 0; i < ntasks; i++) n += matches(&tasks[i]);
  return n;
}

static int visible_nth(int k) {
  for (int i = ntasks - 1; i >= 0; i--)
    if (matches(&tasks[i]) && k-- == 0) return i;
  return -1;
}

static void clamp_top(void) {
  int max = visible_count() - ROWS;
  if (top > max) top = max;
  if (top < 0) top = 0;
}

static void add_task(void) {
  if (!elen || ntasks >= MAXT) return;
  snprintf(tasks[ntasks++].title, sizeof tasks[0].title, "%s", entry);
  keyboard_clear_echo();
  memset(entry, 0, sizeof entry);
  elen = 0;
  top = 0;
  save_tasks();
}

static void complete_task(int i) {
  if (i < 0 || i >= ntasks) return;
  memmove(&tasks[i], &tasks[i + 1], (size_t)(ntasks - i - 1) * sizeof tasks[0]);
  ntasks--;
  ndone++;
  clamp_top();
  save_tasks();
}

int tasks_total(void) {
  load_tasks();
  return ntasks;
}

int tasks_done_count(void) {
  load_tasks();
  return ndone;
}

const char *tasks_title_at(int k) {
  load_tasks();
  return k >= 0 && k < ntasks ? tasks[ntasks - 1 - k].title : "";
}

void tasks_complete_at(int k) {
  load_tasks();
  if (k < 0 || k >= ntasks) return;
  complete_task(ntasks - 1 - k);
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app && !strcmp(P[i].app->id, "tasks")) P[i].dirty = 1;
}

static void type_char(char c) {
  if (elen >= (int)sizeof entry - 1) return;
  entry[elen++] = c;
  entry[elen] = 0;
  top = 0;
}

static void backspace(void) {
  if (elen) entry[--elen] = 0;
  top = 0;
}

static int tasks_zone(Panel *p, float x, float y) {
  (void)p;
  if (x >= PAD && x < WIN_W - PAD && y >= NEW_Y && y < NEW_Y + NEW_H) return Z_ADD;
  float lx = WIN_W - PAD - 56;
  if (x >= lx && x < lx + 56 && y >= LIST_Y && y < LIST_Y + 56) return Z_UP;
  if (x >= lx && x < lx + 56 && y >= LIST_Y + ROWS * ROW_H - 56 && y < LIST_Y + ROWS * ROW_H) return Z_DOWN;
  if (x >= PAD && x < PAD + 72 && y >= LIST_Y && y < LIST_Y + ROWS * ROW_H) {
    int r = (int)((y - LIST_Y) / ROW_H);
    if (visible_nth(top + r) >= 0) return Z_ROW + r;
  }
  return 0;
}

static void tasks_click(Panel *p, float x, float y) {
  int z = tasks_zone(p, x, y);
  if (z == Z_ADD) {
    if (elen) add_task();
    else panel_open_app("keyboard");
  } else if (z == Z_UP) top -= ROWS - 1, clamp_top();
  else if (z == Z_DOWN) top += ROWS - 1, clamp_top();
  else if (z >= Z_ROW && z < Z_ROW + ROWS) complete_task(visible_nth(top + z - Z_ROW));
}

static void tasks_scroll(Panel *p, float x, float y, int steps) {
  (void)p, (void)x, (void)y;
  top -= steps;
  clamp_top();
}

static void tasks_key(Panel *p, int code, int mods) {
  (void)p;
  char buf[8];
  int n = key_to_bytes(code, mods, buf);
  if (n != 1) return;
  unsigned char c = (unsigned char)buf[0];
  if (c == '\r') add_task();
  else if (c == 127) backspace();
  else if (c == 27) {
    memset(entry, 0, sizeof entry);
    elen = 0;
    top = 0;
  } else if (c >= 32 && c < 127) type_char((char)c);
}

static void tasks_open(Panel *p) {
  (void)p;
  load_tasks();
  memset(entry, 0, sizeof entry);
  elen = 0;
  top = 0;
}

static void tasks_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  float w = WIN_W - 2 * PAD;
  gfx_rrect(s, ox + PAD, oy + NEW_Y, w, NEW_H, 14, hot == Z_ADD ? RGB(36, 92, 230) : C_ACCENT);
  char label[96];
  if (elen) snprintf(label, sizeof label, "Add  \"%s\"", entry);
  else snprintf(label, sizeof label, "+  New task");
  gfx_text_fit(s, F_UI_MED, ox + PAD + 20, oy + NEW_Y + (NEW_H - line_h(F_UI_MED)) * 0.5f, w - 40, label, RGB(255, 255, 255));

  int total = visible_count();
  for (int r = 0; r < ROWS; r++) {
    int i = visible_nth(top + r);
    float y = oy + LIST_Y + r * ROW_H;
    if (i < 0) break;
    gfx_rrect(s, ox + PAD, y + 2, w - 64, ROW_H - 6, 12, THEME(RGB(240, 243, 248), RGB(40, 45, 53)));
    int h = hot == Z_ROW + r;
    float cy = y + ROW_H * 0.5f - 1;
    gfx_ring(s, ox + PAD + 30, cy, 16, 3.f, h ? RGB(60, 180, 120) : THEME(RGB(150, 160, 176), RGB(130, 140, 156)));
    if (h) {
      gfx_line(s, ox + PAD + 22, cy, ox + PAD + 28, cy + 6, 3.f, RGB(60, 180, 120));
      gfx_line(s, ox + PAD + 28, cy + 6, ox + PAD + 39, cy - 7, 3.f, RGB(60, 180, 120));
    }
    gfx_text_fit(s, F_BODY, ox + PAD + 62, y + (ROW_H - 6 - line_h(F_BODY)) * 0.5f + 2, w - 64 - 80, tasks[i].title, C_TEXT);
  }
  if (!total)
    gfx_text(s, F_BODY, ox + PAD + 8, oy + LIST_Y + 18, ntasks ? "No matches. Tap Add to create it." : "Nothing to do. Tap New task.", C_MUTED);
  float lx = ox + WIN_W - PAD - 56;
  uint32_t bg0 = hot == Z_UP ? THEME(RGB(214, 220, 230), RGB(78, 85, 98)) : THEME(RGB(232, 236, 242), RGB(52, 57, 66));
  uint32_t bg1 = hot == Z_DOWN ? THEME(RGB(214, 220, 230), RGB(78, 85, 98)) : THEME(RGB(232, 236, 242), RGB(52, 57, 66));
  gfx_rrect(s, lx, oy + LIST_Y, 56, 56, 12, bg0);
  gfx_rrect(s, lx, oy + LIST_Y + ROWS * ROW_H - 56, 56, 56, 12, bg1);
  float ax = lx + 28, ay = oy + LIST_Y + 28, by = oy + LIST_Y + ROWS * ROW_H - 28;
  uint32_t ac = top > 0 ? C_TEXT : C_MUTED, bc = top + ROWS < total ? C_TEXT : C_MUTED;
  gfx_tri(s, ax - 10, ay + 5, ax + 10, ay + 5, ax, ay - 7, ac);
  gfx_tri(s, ax - 10, by - 5, ax + 10, by - 5, ax, by + 7, bc);
  char cnt[32];
  snprintf(cnt, sizeof cnt, "%d", total);
  gfx_text_c(s, F_SMALL, lx + 28, oy + LIST_Y + ROWS * ROW_H * 0.5f - 8, cnt, C_MUTED);
}

App tasks_app = {"tasks", "Tasks", IC_TASKS, WIN_W, WIN_H, tasks_open, tasks_draw, tasks_click, tasks_scroll, tasks_key,
                 tasks_zone, NULL, NULL};
