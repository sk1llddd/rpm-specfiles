#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "oreonicon.h"
#include "store.h"

#define NW 900
#define NH 620
#define SIDE 230
#define MAXD 12
#define MX (SIDE + 48)
#define MW (NW - SIDE - 96)
#define BY (NH - BAR_H - 88)

#define I_ACC THEME(RGB(14, 116, 224), RGB(88, 166, 255))
#define I_TINT THEME(RGB(224, 238, 253), RGB(28, 52, 86))
#define I_OK THEME(RGB(24, 140, 84), RGB(92, 205, 140))
#define I_BAD THEME(RGB(206, 52, 40), RGB(255, 120, 108))
#define I_BAD_BG THEME(RGB(253, 236, 234), RGB(74, 36, 34))
#define I_WARN THEME(RGB(214, 120, 12), RGB(255, 178, 84))
#define I_CARD THEME(RGB(255, 255, 255), RGB(38, 42, 49))
#define I_BG THEME(RGB(246, 247, 249), RGB(30, 33, 39))

enum { ST_WELCOME, ST_DISK, ST_REVIEW, ST_INSTALL, ST_COUNT };
enum { Z_NEXT = 10, Z_BACK, Z_REBOOT, Z_RETRY, Z_RESCAN, Z_DISK = 100 };

typedef struct {
  char name[40], model[60], tran[12];
  double size;
  int busy;
} Disk;

static struct {
  int step, nd, sel, panel, press, live, started, finished, failed, scan_done;
  Disk d[MAXD];
  char status[120], failmsg[240];
  float pct, shown;
  uint32_t t0;
  NetReq *scan, *job;
} S;

static Surface *SF;
static float OX, OY;
static int HOT;
static struct {
  float x, y, w, h;
  int z;
} HR[64];
static int nhr;

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }
static void hit(int z, float x, float y, float w, float h) {
  if (nhr < 64) HR[nhr].x = x, HR[nhr].y = y, HR[nhr].w = w, HR[nhr].h = h, HR[nhr++].z = z;
}
static void rc(float x, float y, float w, float h, uint32_t c) { gfx_rect(SF, OX + x, OY + y, w, h, c); }
static void rr(float x, float y, float w, float h, float r, uint32_t c) { gfx_rrect(SF, OX + x, OY + y, w, h, r, c); }
static void dsc(float x, float y, float r, uint32_t c) { gfx_disc(SF, OX + x, OY + y, r, c); }
static void ln(float x0, float y0, float x1, float y1, float th, uint32_t c) { gfx_line(SF, OX + x0, OY + y0, OX + x1, OY + y1, th, c); }
static void tx(const Font *f, float x, float y, const char *t, uint32_t c) { gfx_text(SF, f, OX + x, OY + y, t, c); }
static void tf(const Font *f, float x, float y, float w, const char *t, uint32_t c) { gfx_text_fit(SF, f, OX + x, OY + y, w, t, c); }
static void tcn(const Font *f, float cx, float y, const char *t, uint32_t c) { gfx_text_c(SF, f, OX + cx, OY + y, t, c); }

static uint32_t mixc(uint32_t a, uint32_t b, float t) {
  int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
  return RGB((int)(ar + (br - ar) * t), (int)(ag + (bg - ag) * t), (int)(ab + (bb - ab) * t));
}

static int is_live(void) { return getenv("OREONVR_INSTALL_FORCE") || access("/run/initramfs/live", F_OK) == 0; }

static void scan_start(void) {
  if (S.scan) return;
  char *av[] = {"lsblk", "-J", "-p", "-b", "-o", "NAME,SIZE,MODEL,TYPE,RM,TRAN,MOUNTPOINTS", NULL};
  const char *fake = getenv("OREONVR_LSBLK");
  if (fake && *fake) av[0] = (char *)fake;
  S.scan = net_proc("inst:lsblk", av, 0);
  S.scan_done = 0;
}

static int mounts_live(const J *n) {
  J *m = jget(n, "mountpoints");
  for (int i = 0; i < jlen(m); i++) {
    const char *p = jval(jat(m, i), "");
    if (!strcmp(p, "/") || !strncmp(p, "/run/initramfs", 14) || !strncmp(p, "/run/live", 9)) return 1;
  }
  for (int i = 0; i < jlen(jget(n, "children")); i++)
    if (mounts_live(jat(jget(n, "children"), i))) return 1;
  return 0;
}

static void scan_parse(const char *s, size_t n) {
  J *j = json_parse(s, n);
  S.nd = 0;
  J *bd = jget(j, "blockdevices");
  for (int i = 0; i < jlen(bd) && S.nd < MAXD; i++) {
    J *b = jat(bd, i);
    if (strcmp(jstr(b, "type", ""), "disk")) continue;
    const char *nm = jstr(b, "name", "");
    if (!strncmp(nm, "/dev/loop", 9) || !strncmp(nm, "/dev/zram", 9) || !strncmp(nm, "/dev/sr", 7) || !strncmp(nm, "/dev/ram", 8)) continue;
    if (jnum(b, "size", 0) < 8e9) continue;
    Disk *d = &S.d[S.nd++];
    memset(d, 0, sizeof *d);
    snprintf(d->name, sizeof d->name, "%s", nm);
    snprintf(d->model, sizeof d->model, "%s", jstr(b, "model", ""));
    snprintf(d->tran, sizeof d->tran, "%s", jstr(b, "tran", ""));
    d->size = jnum(b, "size", 0);
    d->busy = mounts_live(b);
  }
  json_free(j);
  if (S.sel >= S.nd) S.sel = -1;
  S.scan_done = 1;
}

static void fmt_size(double b, char *o, int n) {
  if (b >= 1e12) snprintf(o, (size_t)n, "%.1f TB", b / 1e12);
  else snprintf(o, (size_t)n, "%.0f GB", b / 1e9);
}

static void start_install(void) {
  const char *inst = getenv("OREONVR_INSTALLER");
  char cmd[900];
  if (inst && *inst) snprintf(cmd, sizeof cmd, "exec %s --disk '%s'", inst, S.d[S.sel].name);
  else snprintf(cmd, sizeof cmd, "exec python3 /usr/libexec/oreonvr-centrio-run --disk '%s'", S.d[S.sel].name);
  static char script[900];
  snprintf(script, sizeof script, "%s", cmd);
  char *av[] = {"sh", "-c", script, NULL};
  S.job = net_proc("inst:run", av, 0);
  S.started = 1, S.failed = 0, S.finished = 0, S.pct = 0, S.shown = 0;
  S.t0 = now_ms();
  snprintf(S.status, sizeof S.status, "Starting Centrio");
  if (!S.job) S.failed = 1, snprintf(S.failmsg, sizeof S.failmsg, "Could not start the installer");
}

static int job_poll(void) {
  if (!S.job) return 0;
  int ch = 0;
  const char *s = S.job->out.s ? S.job->out.s : "";
  const char *p = s;
  while (*p) {
    const char *e = strchr(p, '\n');
    if (!e) break;
    char line[400];
    snprintf(line, sizeof line, "%.*s", (int)(e - p > 399 ? 399 : e - p), p);
    if (!strncmp(line, "PROGRESS ", 9)) {
      int pc = atoi(line + 9);
      const char *t = strchr(line + 9, ' ');
      if (pc >= 0 && pc <= 100) S.pct = pc / 100.f;
      if (t) snprintf(S.status, sizeof S.status, "%.119s", t + 1);
    } else if (!strncmp(line, "ERROR ", 6)) {
      S.failed = 1;
      snprintf(S.failmsg, sizeof S.failmsg, "%.239s", line + 6);
    } else if (!strcmp(line, "DONE")) S.finished = 1, S.pct = 1;
    p = e + 1;
  }
  if (S.job->state >= NET_OK) {
    if (!S.finished && !S.failed) {
      S.failed = 1;
      if (!S.failmsg[0]) snprintf(S.failmsg, sizeof S.failmsg, "The installer stopped unexpectedly");
    }
    net_drop(S.job);
    S.job = NULL;
    ch = 1;
  }
  return ch || S.started;
}

static void button(float x, float y, float w, float h, const char *label, int z, int primary, int enabled) {
  int hv = HOT == z && enabled;
  uint32_t bg = primary ? (enabled ? (hv ? mixc(I_ACC, RGB(0, 0, 0), 0.12f) : I_ACC) : THEME(RGB(214, 219, 226), RGB(58, 64, 74))) : 0;
  if (!primary && hv) bg = THEME(RGB(232, 236, 242), RGB(50, 55, 64));
  if (bg) rr(x, y, w, h, h / 2, bg);
  tcn(F_UI_MED, x + w / 2, y + h / 2 - line_h(F_UI_MED) / 2, label, primary ? (g_dark && enabled ? RGB(16, 22, 32) : RGB(255, 255, 255)) : C_MUTED);
  if (enabled) hit(z, x, y, w, h);
}

static void mark(float x, float y, float w) {
  float h = w * OREON_ICON_H / OREON_ICON_W;
  gfx_blit_premul(SF, (const uint32_t *)OREON_ICON, OREON_ICON_W, OREON_ICON_H, OX + x, OY + y, w, h);
}

static void check(float cx, float cy, float r, uint32_t bg) {
  dsc(cx, cy, r, bg);
  ln(cx - r * 0.45f, cy + r * 0.05f, cx - r * 0.1f, cy + r * 0.42f, r * 0.22f, RGB(255, 255, 255));
  ln(cx - r * 0.1f, cy + r * 0.42f, cx + r * 0.5f, cy - r * 0.38f, r * 0.22f, RGB(255, 255, 255));
}

static void draw_sidebar(void) {
  rc(0, 0, SIDE, NH - BAR_H, I_CARD);
  rc(SIDE - 1, 0, 1, NH - BAR_H, C_BAR_LINE);
  mark(26, 28, 46);
  tx(F_UI_MED, 84, 32, "Install", C_TEXT);
  tx(F_SMALL, 84, 54, "Oreon VR 11", C_MUTED);
  const char *lab[ST_COUNT] = {"Welcome", "Disk", "Review", "Install"};
  for (int i = 0; i < ST_COUNT; i++) {
    float y = 120 + i * 50;
    int cur = i == S.step, done = i < S.step || (i == ST_INSTALL && S.finished);
    if (cur && !(i == ST_INSTALL && S.finished)) rr(14, y, SIDE - 28, 40, 12, I_TINT);
    if (done) check(40, y + 20, 11, I_OK);
    else {
      dsc(40, y + 20, 11, cur ? I_ACC : THEME(RGB(222, 226, 232), RGB(60, 66, 76)));
      char n[4];
      snprintf(n, sizeof n, "%d", i + 1);
      tcn(F_SMALL, 40, y + 20 - line_h(F_SMALL) / 2, n, cur ? RGB(255, 255, 255) : C_MUTED);
    }
    tx(F_UI, 62, y + 20 - line_h(F_UI) / 2, lab[i], cur && !done ? I_ACC : done ? C_TEXT : C_MUTED);
  }
  tx(F_SMALL, 26, NH - BAR_H - 34, "Powered by Centrio", C_MUTED);
}

static void head(const char *t, const char *sub) {
  tx(F_H1, MX, 40, t, C_TEXT);
  if (sub) tx(F_UI, MX, 40 + line_h(F_H1) + 8, sub, C_MUTED);
}

static void nav(int back, int next, const char *label, int ok) {
  rc(SIDE, BY - 18, NW - SIDE, 1, C_BAR_LINE);
  if (back) button(MX, BY, 110, 46, "Back", Z_BACK, 0, 1);
  if (next) button(MX + MW - 180, BY, 180, 46, label, Z_NEXT, 1, ok);
}

static void draw_welcome(void) {
  head("Install Oreon VR", "Set up this computer in a few steps.");
  const char *t[3] = {"Choose a disk", "Review", "Install"};
  const char *d[3] = {"Pick where Oreon VR goes. The disk is erased.", "Check what is about to happen.", "Centrio copies the system and sets up the boot loader."};
  for (int i = 0; i < 3; i++) {
    float y = 160 + i * 96;
    rr(MX, y, MW, 80, 16, I_CARD);
    dsc(MX + 40, y + 40, 18, I_TINT);
    char n[4];
    snprintf(n, sizeof n, "%d", i + 1);
    tcn(F_UI_MED, MX + 40, y + 40 - line_h(F_UI_MED) / 2, n, I_ACC);
    tx(F_UI_MED, MX + 80, y + 18, t[i], C_TEXT);
    tx(F_SMALL, MX + 80, y + 44, d[i], C_MUTED);
  }
  if (!S.live) tx(F_SMALL, MX, 460, "The installer only runs from the live system.", I_WARN);
  nav(0, 1, "Get started", S.live);
}

static void draw_disk(void) {
  head("Choose a disk", "Everything on the disk you pick will be erased.");
  float y = 150;
  if (!S.scan_done && S.scan) tx(F_UI, MX, y + 6, "Looking for disks...", C_MUTED);
  else if (!S.nd) {
    rr(MX, y, MW, 84, 16, I_CARD);
    tx(F_UI_MED, MX + 26, y + 20, "No disks found", C_TEXT);
    tx(F_SMALL, MX + 26, y + 48, "Attach a disk of at least 8 GB, then press Rescan.", C_MUTED);
  }
  for (int i = 0; i < S.nd; i++) {
    Disk *d = &S.d[i];
    float yy = y + i * 84;
    int sel = i == S.sel, hv = HOT == Z_DISK + i;
    rr(MX, yy, MW, 72, 16, sel ? I_TINT : hv ? mixc(I_CARD, RGB(128, 140, 160), 0.1f) : I_CARD);
    dsc(MX + 36, yy + 36, 11, sel ? I_ACC : THEME(RGB(214, 219, 227), RGB(66, 72, 84)));
    if (sel) dsc(MX + 36, yy + 36, 5, RGB(255, 255, 255));
    char sz[24], sub[100];
    fmt_size(d->size, sz, sizeof sz);
    snprintf(sub, sizeof sub, "%s   %s%s%s", d->name, sz, d->tran[0] ? "   " : "", d->tran);
    tf(F_UI_MED, MX + 64, yy + 13, MW - 220, d->model[0] ? d->model : "Disk", C_TEXT);
    tx(F_SMALL, MX + 64, yy + 40, sub, C_MUTED);
    if (d->busy) {
      rr(MX + MW - 164, yy + 22, 144, 28, 14, THEME(RGB(253, 240, 224), RGB(70, 50, 28)));
      tcn(F_SMALL, MX + MW - 92, yy + 36 - line_h(F_SMALL) / 2, "Live system disk", I_WARN);
    }
    hit(Z_DISK + i, MX, yy, MW, 72);
  }
  float ry = y + (S.nd ? S.nd : 1) * 84 + 4;
  if (ry > BY - 60) ry = BY - 60;
  button(MX, ry, 100, 38, "Rescan", Z_RESCAN, 0, 1);
  nav(1, 1, "Continue", S.sel >= 0);
}

static void kv(float y, const char *k, const char *v, uint32_t c) {
  tx(F_UI, MX + 28, y, k, C_MUTED);
  tf(F_UI_MED, MX + 190, y, MW - 220, v, c);
}

static void draw_review(void) {
  head("Ready to install", "Check the details, then start.");
  float y = 150;
  rr(MX, y, MW, 172, 18, I_CARD);
  char sz[24], disk[240];
  fmt_size(S.d[S.sel].size, sz, sizeof sz);
  snprintf(disk, sizeof disk, "%s  (%s %s)", S.d[S.sel].name, S.d[S.sel].model, sz);
  kv(y + 24, "Disk", disk, I_BAD);
  kv(y + 62, "Filesystem", "ext4 on LVM", C_TEXT);
  kv(y + 100, "Boot mode", access("/sys/firmware/efi", F_OK) == 0 ? "UEFI" : "BIOS", C_TEXT);
  kv(y + 138, "Installer", "Centrio", C_TEXT);
  rr(MX, y + 190, MW, 52, 14, I_BAD_BG);
  tx(F_UI, MX + 24, y + 216 - line_h(F_UI) / 2, "Everything on this disk will be permanently erased.", I_BAD);
  if (S.d[S.sel].busy) {
    rr(MX, y + 254, MW, 52, 14, THEME(RGB(253, 240, 224), RGB(70, 50, 28)));
    tf(F_SMALL, MX + 24, y + 280 - line_h(F_SMALL) / 2, MW - 48, "This is the disk you booted from. The system is copied into memory first and installed from there.", I_WARN);
  }
  nav(1, 1, "Install", 1);
}

static void draw_install(void) {
  if (S.finished) {
    head("All done", "Oreon VR is installed.");
    float cx = MX + MW / 2.f;
    check(cx, 230, 50, I_OK);
    tcn(F_UI, cx, 310, "Remove the install media, then restart.", C_TEXT);
    button(cx - 100, 360, 200, 50, "Restart now", Z_REBOOT, 1, 1);
    return;
  }
  if (S.failed) {
    head("Installation failed", "Nothing more was changed.");
    rr(MX, 150, MW, 130, 18, I_BAD_BG);
    tf(F_UI_MED, MX + 26, 176, MW - 52, S.failmsg, I_BAD);
    tx(F_SMALL, MX + 26, 232, "Details: journalctl -u oreonvr-shell", C_MUTED);
    button(MX, 310, 150, 46, "Try again", Z_RETRY, 1, 1);
    return;
  }
  head("Installing", "Keep this window open. This takes a few minutes.");
  rr(MX, 160, MW, 170, 18, I_CARD);
  tf(F_UI_MED, MX + 30, 188, MW - 60, S.status, C_TEXT);
  rr(MX + 30, 250, MW - 60, 10, 5, THEME(RGB(226, 230, 236), RGB(52, 58, 68)));
  float fw = (MW - 60) * S.shown;
  if (fw > 10) rr(MX + 30, 250, fw, 10, 5, I_ACC);
  char p[16];
  snprintf(p, sizeof p, "%d%%", (int)(S.shown * 100 + 0.5f));
  tx(F_UI, MX + 30, 282, p, C_MUTED);
}

static void install_draw(Panel *p, Surface *s, float ox, float oy) {
  SF = s, OX = ox, OY = oy, S.panel = (int)(p - P);
  HOT = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  nhr = 0;
  rc(0, 0, NW, NH - BAR_H, I_BG);
  draw_sidebar();
  switch (S.step) {
  case ST_WELCOME: draw_welcome(); break;
  case ST_DISK: draw_disk(); break;
  case ST_REVIEW: draw_review(); break;
  default: draw_install(); break;
  }
}

static int install_zone(Panel *p, float x, float y) {
  (void)p;
  for (int i = nhr - 1; i >= 0; i--)
    if (x >= HR[i].x && x < HR[i].x + HR[i].w && y >= HR[i].y && y < HR[i].y + HR[i].h) return HR[i].z;
  return 0;
}

static void go(int step) {
  S.step = step;
  if (step == ST_DISK) scan_start();
}

static void action(int z) {
  if (z == Z_NEXT) {
    if (S.step == ST_REVIEW) {
      go(ST_INSTALL);
      start_install();
    } else if (S.step < ST_REVIEW) go(S.step + 1);
  } else if (z == Z_BACK) {
    if (S.step > 0) go(S.step - 1);
  } else if (z == Z_REBOOT) shell_power("reboot");
  else if (z == Z_RETRY) go(ST_DISK), S.started = S.failed = S.finished = 0, S.failmsg[0] = 0;
  else if (z == Z_RESCAN) scan_start();
  else if (z >= Z_DISK && z < Z_DISK + MAXD) S.sel = z - Z_DISK;
}

static void install_press(Panel *p, float x, float y, int button, int down) {
  S.panel = (int)(p - P);
  int z = install_zone(p, x, y);
  p->dirty = 1;
  if (button != 1) return;
  if (down) {
    S.press = z;
    return;
  }
  int pz = S.press;
  S.press = 0;
  if (z && z == pz) action(z);
}

static void install_key(Panel *p, int code, int mods) {
  (void)mods;
  p->dirty = 1;
  if (code == 28 && S.step < ST_REVIEW && (S.step != ST_DISK || S.sel >= 0) && S.live) action(Z_NEXT);
}

static int install_tick(Panel *p, uint32_t now) {
  (void)p, (void)now;
  int ch = 0;
  if (net_poll()) ch = 1;
  if (S.scan && S.scan->state >= NET_OK) {
    if (S.scan->state == NET_OK) scan_parse(S.scan->out.s ? S.scan->out.s : "", S.scan->out.n);
    else S.nd = 0, S.scan_done = 1;
    net_drop(S.scan);
    S.scan = NULL;
    ch = 1;
  }
  if (job_poll()) ch = 1;
  if (S.shown < S.pct) S.shown += (S.pct - S.shown) * 0.12f + 0.0005f, ch = 1;
  if (S.shown > S.pct) S.shown = S.pct;
  return ch;
}

static void install_open(Panel *p) {
  memset(&S, 0, sizeof S);
  S.panel = (int)(p - P);
  S.sel = -1;
  S.live = is_live();
  snprintf(p->title, sizeof p->title, "Install Oreon VR");
}

static void install_close(Panel *p) {
  (void)p;
  if (S.scan) net_drop(S.scan), S.scan = NULL;
}

static int install_close_request(Panel *p) {
  (void)p;
  return S.job != NULL;
}

App install_app = {"install", "Install", IC_INSTALL, NW, NH, install_open, install_draw, NULL, NULL, install_key, install_zone, install_tick, install_close, install_press, NULL, install_close_request};
