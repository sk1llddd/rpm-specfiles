#include "oreonvr.h"

#ifndef HAVE_WL

void wl_init(void) {}
void wl_poll(uint32_t now) { (void)now; }
int wl_launch(const char *desktop_file) { (void)desktop_file; return 0; }
int wl_spawn(char *const argv[]) {
  pid_t pid = fork();
  if (pid < 0) return 0;
  if (pid > 0) {
    waitpid(pid, NULL, 0);
    return 1;
  }
  if (fork() != 0) _exit(0);
  setsid();
  execvp(argv[0], argv);
  _exit(127);
}
int wl_surface_count(void) { return 0; }

#else

#include <fcntl.h>
#include <grp.h>
#include <math.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <wayland-server.h>

#include "proto/keymap_us.h"
#include "proto/xdg-decoration-unstable-v1-server-protocol.h"
#include "proto/text-input-unstable-v3-server-protocol.h"
#include "proto/xdg-shell-server-protocol.h"

#define OUT_SCALE 2
#define OUT_W 1280
#define OUT_H 800
#define MAXRES 128
#define BTN_LEFT_ 272

typedef struct WlSurf WlSurf;
extern App wlwin_app, wlpopup_app;
typedef struct {
  WlSurf *s;
} PanelRef;

typedef struct {
  int w, h, ax, ay, aw, ah, anchor, gravity, ox, oy;
} Positioner;

struct WlSurf {
  struct wl_resource *res, *xdg, *top, *popup, *sub, *deco;
  struct wl_resource *pending_buf;
  struct wl_listener buf_destroy;
  int has_pending, pending_scale;
  uint32_t *px;
  int bw, bh, cap, scale;
  struct wl_resource *pend_cb[16];
  int npend;
  int role;
  int configured, entered;
  int csd;
  int gx, gy, gw, gh, geom_set;
  char title[96], app_id[96];
  int panel;
  PanelRef *ref;
  WlSurf *parent;
  int sx, sy;
  int grab;
  WlSurf *subs[8];
  int nsubs;
  WlSurf *next, *prev;
};

static struct wl_display *dpy;
static struct wl_event_loop *loop;
static struct wl_resource *ptrs[MAXRES], *kbds[MAXRES], *outs[MAXRES], *ready_cb[256];
static int nready;
static WlSurf *surfs;
static uint32_t serial_no;
static char sock_name[64] = "";
static char runtime_dir[256] = "";
static uid_t run_uid;
static gid_t run_gid;
static int have_user;

static uint32_t next_serial(void) { return ++serial_no; }

static void res_add(struct wl_resource **a, struct wl_resource *r) {
  for (int i = 0; i < MAXRES; i++)
    if (!a[i]) {
      a[i] = r;
      return;
    }
}

static void res_del(struct wl_resource **a, struct wl_resource *r) {
  for (int i = 0; i < MAXRES; i++)
    if (a[i] == r) a[i] = NULL;
}

#define EACH(arr, client, var) \
  for (int _i = 0; _i < MAXRES; _i++) \
    for (struct wl_resource *var = arr[_i]; var && wl_resource_get_client(var) == (client); var = NULL)

static PanelRef *panel_ref(Panel *p) { return p->state; }

static WlSurf *surf_of_panel(Panel *p) { return p && p->state ? panel_ref(p)->s : NULL; }

static void noop_destroy(struct wl_client *c, struct wl_resource *r) { wl_resource_destroy(r); }

static void surf_close_panel(WlSurf *s) {
  if (s->panel >= 0 && P[s->panel].used) panel_close(s->panel);
  s->panel = -1;
  s->ref = NULL;
}

static int lw_of(WlSurf *s) { return s->geom_set ? s->gw : s->bw / (s->scale ? s->scale : 1); }
static int lh_of(WlSurf *s) { return s->geom_set ? s->gh : s->bh / (s->scale ? s->scale : 1); }

static void send_configure(WlSurf *s) {
  uint32_t ser = next_serial();
  if (s->role == 1 && s->top) {
    struct wl_array st;
    wl_array_init(&st);
    uint32_t *a = wl_array_add(&st, sizeof(uint32_t));
    *a = XDG_TOPLEVEL_STATE_ACTIVATED;
    xdg_toplevel_send_configure(s->top, 0, 0, &st);
    wl_array_release(&st);
  }
  if (s->xdg) xdg_surface_send_configure(s->xdg, ser);
  s->configured = 1;
}

static void place_popup(WlSurf *s) {
  if (!s->parent || s->parent->panel < 0 || s->panel < 0) return;
  Panel *pp = &P[s->parent->panel], *c = &P[s->panel];
  if (!pp->used || !c->used) return;
  float ca = cosf(pp->yaw), sa = sinf(pp->yaw), ct = cosf(pp->tilt), st = sinf(pp->tilt);
  float pr[3] = {ca, 0, sa}, pu[3] = {-sa * st, ct, ca * st};
  float n[3] = {pr[1] * pu[2] - pr[2] * pu[1], pr[2] * pu[0] - pr[0] * pu[2], pr[0] * pu[1] - pr[1] * pu[0]};
  float sw = pp->lw + 2.f * MARGIN, sh = pp->lh + 2.f * MARGIN;
  float bx = MARGIN + (float)s->sx + c->lw * 0.5f;
  float by = MARGIN + (pp->kind == PK_WINDOW ? BARH(pp) : 0) + (float)s->sy + c->lh * 0.5f;
  float ox = bx - sw * 0.5f, oy = by - sh * 0.5f;
  c->x = pp->x + pr[0] * ox - pu[0] * oy + n[0] * 4.f;
  c->y = pp->y + pr[1] * ox - pu[1] * oy + n[1] * 4.f;
  c->z = pp->z + pr[2] * ox - pu[2] * oy + n[2] * 4.f;
  c->yaw = pp->yaw, c->tilt = pp->tilt;
  c->visible = pp->visible;
  c->parent = s->parent->panel;
}

static WlSurf *root_of(WlSurf *s) {
  while (s && s->role == 3 && s->parent) s = s->parent;
  return s;
}

static struct wl_resource *output_of(struct wl_client *c) {
  for (int i = 0; i < MAXRES; i++)
    if (outs[i] && wl_resource_get_client(outs[i]) == c) return outs[i];
  return NULL;
}

static void surf_updated(WlSurf *s) {
  WlSurf *r = root_of(s);
  if (!r) return;
  if (!r->entered && r->px) {
    struct wl_resource *o = output_of(wl_resource_get_client(r->res));
    if (o) wl_surface_send_enter(r->res, o), r->entered = 1;
  }
  if (r->role != 1 && r->role != 2) return;
  if (!r->px) {
    if (r->panel >= 0) surf_close_panel(r);
    return;
  }
  int lw = lw_of(r), lh = lh_of(r);
  if (lw < 8) lw = 8;
  if (lh < 8) lh = 8;
  int body = r->role == 1 && !r->csd ? BAR_H : 0;
  if (r->panel >= 0 && P[r->panel].used) {
    Panel *p = &P[r->panel];
    if (p->nobar != (r->role == 1 && r->csd)) {
      p->nobar = r->role == 1 && r->csd;
      p->chrome_key = -1;
    }
    if (p->lw != lw || p->lh != lh + body) panel_resize(r->panel, lw, lh + body);
    if (r->role == 1 && strcmp(p->title, r->title)) {
      snprintf(p->title, sizeof p->title, "%.63s", r->title);
      p->chrome_key = -1;
    }
    p->dirty = 1;
    return;
  }
  if (r->role == 2 && (!r->parent || r->parent->panel < 0)) return;
  int i = panel_create(r->role == 1 ? PK_WINDOW : PK_CHILD, lw, lh + body,
                       r->title[0] ? r->title : (r->app_id[0] ? r->app_id : "Window"),
                       r->role == 1 ? &wlwin_app : &wlpopup_app);
  if (i < 0) return;
  PanelRef *ref = calloc(1, sizeof *ref);
  ref->s = r;
  P[i].state = ref;
  P[i].nobar = r->role == 1 && r->csd;
  r->panel = i;
  r->ref = ref;
  if (r->role == 2) {
    P[i].appear = 1.f;
    place_popup(r);
  } else {
    panel_place_new(i);
    W.focus = i;
  }
}

static void surf_unlink(WlSurf *s) {
  if (s->next) s->next->prev = s->prev;
  if (s->prev) s->prev->next = s->next;
  else surfs = s->next;
}

static void surf_destroyed(struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s->xdg) wl_resource_set_user_data(s->xdg, NULL);
  if (s->top) wl_resource_set_user_data(s->top, NULL);
  if (s->popup) wl_resource_set_user_data(s->popup, NULL);
  if (s->sub) wl_resource_set_user_data(s->sub, NULL);
  if (s->deco) wl_resource_set_user_data(s->deco, NULL);
  if (s->pending_buf) wl_list_remove(&s->buf_destroy.link);
  for (WlSurf *o = surfs; o; o = o->next) {
    if (o->parent == s) o->parent = NULL;
    for (int i = 0; i < o->nsubs; i++)
      if (o->subs[i] == s) o->subs[i] = o->subs[--o->nsubs];
  }
  WlSurf *root = root_of(s);
  surf_close_panel(s);
  if (root && root != s && root->panel >= 0) P[root->panel].dirty = 1;
  for (int i = 0; i < s->npend; i++) wl_resource_destroy(s->pend_cb[i]);
  surf_unlink(s);
  free(s->px);
  free(s);
}

static void buf_gone(struct wl_listener *l, void *data) {
  WlSurf *s = wl_container_of(l, s, buf_destroy);
  s->pending_buf = NULL;
  s->has_pending = 0;
}

static void s_attach(struct wl_client *c, struct wl_resource *r, struct wl_resource *buf, int32_t x, int32_t y) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s->pending_buf) wl_list_remove(&s->buf_destroy.link);
  s->pending_buf = buf;
  s->has_pending = 1;
  if (buf) {
    s->buf_destroy.notify = buf_gone;
    wl_resource_add_destroy_listener(buf, &s->buf_destroy);
  }
}

static void s_damage(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y, int32_t w, int32_t h) {}

static void cb_gone(struct wl_resource *r) {
  res_del(ready_cb, r);
  WlSurf *s;
  for (s = surfs; s; s = s->next)
    for (int i = 0; i < s->npend; i++)
      if (s->pend_cb[i] == r) s->pend_cb[i] = s->pend_cb[--s->npend];
}

static void s_frame(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  WlSurf *s = wl_resource_get_user_data(r);
  struct wl_resource *cb = wl_resource_create(c, &wl_callback_interface, 1, id);
  if (!cb) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(cb, NULL, NULL, cb_gone);
  if (s->npend < 16) s->pend_cb[s->npend++] = cb;
  else wl_callback_send_done(cb, now_ms()), wl_resource_destroy(cb);
}

static void s_region(struct wl_client *c, struct wl_resource *r, struct wl_resource *region) {}

static void upload(WlSurf *s, struct wl_resource *buf) {
  struct wl_shm_buffer *shm = wl_shm_buffer_get(buf);
  if (!shm) return;
  int w = wl_shm_buffer_get_width(shm), h = wl_shm_buffer_get_height(shm), stride = wl_shm_buffer_get_stride(shm);
  uint32_t fmt = wl_shm_buffer_get_format(shm);
  if (w <= 0 || h <= 0 || w > 8192 || h > 8192) return;
  if ((size_t)w * h > (size_t)s->cap) {
    free(s->px);
    s->px = malloc((size_t)w * h * 4);
    s->cap = s->px ? w * h : 0;
    if (!s->px) return;
  }
  wl_shm_buffer_begin_access(shm);
  const uint8_t *src = wl_shm_buffer_get_data(shm);
  uint32_t force = fmt == WL_SHM_FORMAT_XRGB8888 ? 0xff000000u : 0;
  for (int y = 0; y < h; y++) {
    const uint32_t *row = (const uint32_t *)(src + (size_t)y * stride);
    uint32_t *dst = s->px + (size_t)y * w;
    for (int x = 0; x < w; x++) dst[x] = row[x] | force;
  }
  wl_shm_buffer_end_access(shm);
  s->bw = w, s->bh = h;
}

static void s_commit(struct wl_client *c, struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s->pending_scale) s->scale = s->pending_scale;
  if (!s->scale) s->scale = 1;
  if (s->has_pending) {
    struct wl_resource *buf = s->pending_buf;
    s->has_pending = 0;
    if (buf) {
      wl_list_remove(&s->buf_destroy.link);
      s->pending_buf = NULL;
      upload(s, buf);
      wl_buffer_send_release(buf);
    } else {
      free(s->px);
      s->px = NULL, s->cap = 0, s->bw = s->bh = 0;
    }
  }
  for (int i = 0; i < s->npend; i++) {
    if (nready < 256) ready_cb[nready++] = s->pend_cb[i];
    else wl_callback_send_done(s->pend_cb[i], now_ms()), wl_resource_destroy(s->pend_cb[i]);
  }
  s->npend = 0;
  if (!s->configured && (s->role == 1 || s->role == 2)) send_configure(s);
  surf_updated(s);
}

static void s_transform(struct wl_client *c, struct wl_resource *r, int32_t t) {}

static void s_scale(struct wl_client *c, struct wl_resource *r, int32_t scale) {
  WlSurf *s = wl_resource_get_user_data(r);
  s->pending_scale = scale > 0 ? scale : 1;
}

static void s_offset(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y) {}

static const struct wl_surface_interface surface_impl = {
    .destroy = noop_destroy,
    .attach = s_attach,
    .damage = s_damage,
    .frame = s_frame,
    .set_opaque_region = s_region,
    .set_input_region = s_region,
    .commit = s_commit,
    .set_buffer_transform = s_transform,
    .set_buffer_scale = s_scale,
    .damage_buffer = s_damage,
    .offset = s_offset,
};

static void region_add(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y, int32_t w, int32_t h) {}
static const struct wl_region_interface region_impl = {.destroy = noop_destroy, .add = region_add, .subtract = region_add};

static void comp_create_surface(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  WlSurf *s = calloc(1, sizeof *s);
  s->res = wl_resource_create(c, &wl_surface_interface, wl_resource_get_version(r), id);
  if (!s->res) {
    free(s);
    return wl_client_post_no_memory(c);
  }
  s->panel = -1;
  s->scale = 1;
  s->next = surfs;
  if (surfs) surfs->prev = s;
  surfs = s;
  wl_resource_set_implementation(s->res, &surface_impl, s, surf_destroyed);
}

static void comp_create_region(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  struct wl_resource *reg = wl_resource_create(c, &wl_region_interface, wl_resource_get_version(r), id);
  if (!reg) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(reg, &region_impl, NULL, NULL);
}

static const struct wl_compositor_interface compositor_impl = {comp_create_surface, comp_create_region};

static void bind_compositor(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  struct wl_resource *r = wl_resource_create(c, &wl_compositor_interface, version > 4 ? 4 : (int)version, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &compositor_impl, NULL, NULL);
}

static void sub_pos(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s) return;
  s->sx = x, s->sy = y;
}
static void sub_sibling(struct wl_client *c, struct wl_resource *r, struct wl_resource *sib) {}
static void sub_mode(struct wl_client *c, struct wl_resource *r) {}
static const struct wl_subsurface_interface subsurface_impl = {noop_destroy, sub_pos, sub_sibling, sub_sibling, sub_mode, sub_mode};

static void sub_gone(struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s) return;
  s->sub = NULL;
  if (s->parent) {
    for (int i = 0; i < s->parent->nsubs; i++)
      if (s->parent->subs[i] == s) s->parent->subs[i] = s->parent->subs[--s->parent->nsubs];
    if (s->parent->panel >= 0) P[s->parent->panel].dirty = 1;
  }
  s->role = 0;
}

static void subc_get(struct wl_client *c, struct wl_resource *r, uint32_t id, struct wl_resource *surf,
                     struct wl_resource *parent) {
  WlSurf *s = wl_resource_get_user_data(surf), *p = wl_resource_get_user_data(parent);
  struct wl_resource *sr = wl_resource_create(c, &wl_subsurface_interface, wl_resource_get_version(r), id);
  if (!sr) return wl_client_post_no_memory(c);
  s->role = 3, s->parent = p, s->sub = sr;
  if (p->nsubs < 8) p->subs[p->nsubs++] = s;
  wl_resource_set_implementation(sr, &subsurface_impl, s, sub_gone);
}

static const struct wl_subcompositor_interface subcompositor_impl = {noop_destroy, subc_get};

static void bind_subcompositor(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  struct wl_resource *r = wl_resource_create(c, &wl_subcompositor_interface, 1, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &subcompositor_impl, NULL, NULL);
}

static void pos_set_size(struct wl_client *c, struct wl_resource *r, int32_t w, int32_t h) {
  Positioner *p = wl_resource_get_user_data(r);
  p->w = w, p->h = h;
}
static void pos_anchor_rect(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y, int32_t w, int32_t h) {
  Positioner *p = wl_resource_get_user_data(r);
  p->ax = x, p->ay = y, p->aw = w, p->ah = h;
}
static void pos_anchor(struct wl_client *c, struct wl_resource *r, uint32_t a) {
  ((Positioner *)wl_resource_get_user_data(r))->anchor = (int)a;
}
static void pos_gravity(struct wl_client *c, struct wl_resource *r, uint32_t g) {
  ((Positioner *)wl_resource_get_user_data(r))->gravity = (int)g;
}
static void pos_constraint(struct wl_client *c, struct wl_resource *r, uint32_t v) {}
static void pos_offset(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y) {
  Positioner *p = wl_resource_get_user_data(r);
  p->ox = x, p->oy = y;
}
static void pos_reactive(struct wl_client *c, struct wl_resource *r) {}
static void pos_parent_size(struct wl_client *c, struct wl_resource *r, int32_t w, int32_t h) {}
static void pos_parent_conf(struct wl_client *c, struct wl_resource *r, uint32_t s) {}

static const struct xdg_positioner_interface positioner_impl = {
    noop_destroy, pos_set_size, pos_anchor_rect, pos_anchor, pos_gravity, pos_constraint, pos_offset,
    pos_reactive, pos_parent_size, pos_parent_conf,
};

static void pos_gone(struct wl_resource *r) { free(wl_resource_get_user_data(r)); }

static void popup_geometry(const Positioner *p, int *x, int *y) {
  int a = p->anchor, g = p->gravity;
  int ax = (a == 3 || a == 5 || a == 6) ? p->ax : (a == 4 || a == 7 || a == 8) ? p->ax + p->aw : p->ax + p->aw / 2;
  int ay = (a == 1 || a == 5 || a == 7) ? p->ay : (a == 2 || a == 6 || a == 8) ? p->ay + p->ah : p->ay + p->ah / 2;
  *x = ax + p->ox - ((g == 3 || g == 5 || g == 6) ? p->w : (g == 4 || g == 7 || g == 8) ? 0 : p->w / 2);
  *y = ay + p->oy - ((g == 1 || g == 5 || g == 7) ? p->h : (g == 2 || g == 6 || g == 8) ? 0 : p->h / 2);
}

static void wmb_create_pos(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  struct wl_resource *pr = wl_resource_create(c, &xdg_positioner_interface, wl_resource_get_version(r), id);
  if (!pr) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(pr, &positioner_impl, calloc(1, sizeof(Positioner)), pos_gone);
}

static void top_parent(struct wl_client *c, struct wl_resource *r, struct wl_resource *p) {}

static void ascii_dashes(char *t) {
  char *o = t;
  for (const char *i = t; *i;) {
    if ((unsigned char)i[0] == 0xe2 && (unsigned char)i[1] == 0x80 && ((unsigned char)i[2] >= 0x90 && (unsigned char)i[2] <= 0x95)) {
      *o++ = '-';
      i += 3;
    } else {
      *o++ = *i++;
    }
  }
  *o = 0;
}

static void top_title(struct wl_client *c, struct wl_resource *r, const char *t) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s) return;
  snprintf(s->title, sizeof s->title, "%s", t);
  ascii_dashes(s->title);
  if (s->panel >= 0 && P[s->panel].used) {
    snprintf(P[s->panel].title, sizeof P[s->panel].title, "%.63s", s->title);
    P[s->panel].chrome_key = -1;
  }
}
static void top_app_id(struct wl_client *c, struct wl_resource *r, const char *t) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s) snprintf(s->app_id, sizeof s->app_id, "%s", t);
}
static void top_menu(struct wl_client *c, struct wl_resource *r, struct wl_resource *seat, uint32_t ser, int32_t x, int32_t y) {}
static void point_at(WlSurf *t, float sx, float sy, uint32_t now);

static void top_move(struct wl_client *c, struct wl_resource *r, struct wl_resource *seat, uint32_t ser) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s || s->panel < 0) return;
  point_at(NULL, 0, 0, now_ms());
  input_begin_drag(s->panel);
}
static void top_resize(struct wl_client *c, struct wl_resource *r, struct wl_resource *seat, uint32_t ser, uint32_t e) {}
static void top_size(struct wl_client *c, struct wl_resource *r, int32_t w, int32_t h) {}
static void top_nop(struct wl_client *c, struct wl_resource *r) {}
static void top_fs(struct wl_client *c, struct wl_resource *r, struct wl_resource *o) {}

static const struct xdg_toplevel_interface toplevel_impl = {
    .destroy = noop_destroy, .set_parent = top_parent, .set_title = top_title, .set_app_id = top_app_id,
    .show_window_menu = top_menu, .move = top_move, .resize = top_resize, .set_max_size = top_size,
    .set_min_size = top_size, .set_maximized = top_nop, .unset_maximized = top_nop, .set_fullscreen = top_fs,
    .unset_fullscreen = top_nop, .set_minimized = top_nop,
};

static void top_gone(struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s) return;
  s->top = NULL;
  surf_close_panel(s);
  s->role = 0;
}

static void popup_grab(struct wl_client *c, struct wl_resource *r, struct wl_resource *seat, uint32_t ser) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s) s->grab = 1;
}
static void popup_reposition(struct wl_client *c, struct wl_resource *r, struct wl_resource *pos, uint32_t token) {
  WlSurf *s = wl_resource_get_user_data(r);
  Positioner *p = wl_resource_get_user_data(pos);
  if (!s || !p) return;
  int x, y;
  popup_geometry(p, &x, &y);
  s->sx = x, s->sy = y;
  xdg_popup_send_repositioned(r, token);
  xdg_popup_send_configure(r, x, y, p->w, p->h);
  if (s->xdg) xdg_surface_send_configure(s->xdg, next_serial());
}
static const struct xdg_popup_interface popup_impl = {noop_destroy, popup_grab, popup_reposition};

static void popup_gone(struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s) return;
  s->popup = NULL;
  surf_close_panel(s);
  s->role = 0;
}

static void xs_toplevel(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  WlSurf *s = wl_resource_get_user_data(r);
  struct wl_resource *t = wl_resource_create(c, &xdg_toplevel_interface, wl_resource_get_version(r), id);
  if (!t) return wl_client_post_no_memory(c);
  s->role = 1, s->top = t;
  s->csd = 1;
  wl_resource_set_implementation(t, &toplevel_impl, s, top_gone);
}

static void xs_popup(struct wl_client *c, struct wl_resource *r, uint32_t id, struct wl_resource *parent,
                     struct wl_resource *pos) {
  WlSurf *s = wl_resource_get_user_data(r);
  struct wl_resource *pr = wl_resource_create(c, &xdg_popup_interface, wl_resource_get_version(r), id);
  if (!pr) return wl_client_post_no_memory(c);
  s->role = 2, s->popup = pr;
  s->parent = parent ? wl_resource_get_user_data(parent) : NULL;
  Positioner *p = wl_resource_get_user_data(pos);
  int x, y;
  popup_geometry(p, &x, &y);
  s->sx = x, s->sy = y;
  s->gw = p->w, s->gh = p->h, s->geom_set = 0;
  wl_resource_set_implementation(pr, &popup_impl, s, popup_gone);
  uint32_t ser = next_serial();
  xdg_popup_send_configure(pr, x, y, p->w, p->h);
  xdg_surface_send_configure(r, ser);
  s->configured = 1;
}

static void xs_geometry(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y, int32_t w, int32_t h) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (!s || w <= 0 || h <= 0) return;
  s->gx = x, s->gy = y, s->gw = w, s->gh = h, s->geom_set = 1;
}
static void xs_ack(struct wl_client *c, struct wl_resource *r, uint32_t ser) {}

static const struct xdg_surface_interface xdg_surface_impl = {noop_destroy, xs_toplevel, xs_popup, xs_geometry, xs_ack};

static void xs_gone(struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s) s->xdg = NULL;
}

static void wmb_get_xdg_surface(struct wl_client *c, struct wl_resource *r, uint32_t id, struct wl_resource *surf) {
  WlSurf *s = wl_resource_get_user_data(surf);
  struct wl_resource *x = wl_resource_create(c, &xdg_surface_interface, wl_resource_get_version(r), id);
  if (!x) return wl_client_post_no_memory(c);
  s->xdg = x;
  wl_resource_set_implementation(x, &xdg_surface_impl, s, xs_gone);
}

static void wmb_pong(struct wl_client *c, struct wl_resource *r, uint32_t s) {}

static const struct xdg_wm_base_interface wm_base_impl = {noop_destroy, wmb_create_pos, wmb_get_xdg_surface, wmb_pong};

static void bind_wm_base(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  struct wl_resource *r = wl_resource_create(c, &xdg_wm_base_interface, version > 4 ? 4 : (int)version, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &wm_base_impl, NULL, NULL);
}

static void deco_apply(struct wl_resource *r, uint32_t want) {
  WlSurf *s = wl_resource_get_user_data(r);
  uint32_t mode = want == ZXDG_TOPLEVEL_DECORATION_V1_MODE_CLIENT_SIDE ? want : ZXDG_TOPLEVEL_DECORATION_V1_MODE_SERVER_SIDE;
  zxdg_toplevel_decoration_v1_send_configure(r, mode);
  if (!s) return;
  s->csd = mode == ZXDG_TOPLEVEL_DECORATION_V1_MODE_CLIENT_SIDE;
  if (s->xdg && s->configured) xdg_surface_send_configure(s->xdg, next_serial());
  if (s->px) surf_updated(s);
}

static void deco_set_mode(struct wl_client *c, struct wl_resource *r, uint32_t mode) { deco_apply(r, mode); }
static void deco_unset_mode(struct wl_client *c, struct wl_resource *r) { deco_apply(r, ZXDG_TOPLEVEL_DECORATION_V1_MODE_SERVER_SIDE); }
static const struct zxdg_toplevel_decoration_v1_interface deco_impl = {noop_destroy, deco_set_mode, deco_unset_mode};

static void deco_gone(struct wl_resource *r) {
  WlSurf *s = wl_resource_get_user_data(r);
  if (s) s->deco = NULL;
}

static void decom_get(struct wl_client *c, struct wl_resource *r, uint32_t id, struct wl_resource *toplevel) {
  WlSurf *s = wl_resource_get_user_data(toplevel);
  struct wl_resource *d = wl_resource_create(c, &zxdg_toplevel_decoration_v1_interface, wl_resource_get_version(r), id);
  if (!d) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(d, &deco_impl, s, deco_gone);
  if (s) s->deco = d, s->csd = 0;
  zxdg_toplevel_decoration_v1_send_configure(d, ZXDG_TOPLEVEL_DECORATION_V1_MODE_SERVER_SIDE);
}

static const struct zxdg_decoration_manager_v1_interface decom_impl = {noop_destroy, decom_get};

static void bind_decom(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  struct wl_resource *r = wl_resource_create(c, &zxdg_decoration_manager_v1_interface, 1, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &decom_impl, NULL, NULL);
}

static const struct wl_output_interface output_impl = {noop_destroy};
static void out_gone(struct wl_resource *r) { res_del(outs, r); }

static void bind_output(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  int v = version > 3 ? 3 : (int)version;
  struct wl_resource *r = wl_resource_create(c, &wl_output_interface, v, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &output_impl, NULL, out_gone);
  res_add(outs, r);
  wl_output_send_geometry(r, 0, 0, 600, 375, WL_OUTPUT_SUBPIXEL_UNKNOWN, "Oreon", "VR", WL_OUTPUT_TRANSFORM_NORMAL);
  wl_output_send_mode(r, WL_OUTPUT_MODE_CURRENT | WL_OUTPUT_MODE_PREFERRED, OUT_W * OUT_SCALE, OUT_H * OUT_SCALE, 60000);
  if (v >= 2) {
    wl_output_send_scale(r, OUT_SCALE);
    wl_output_send_done(r);
  }
}

static void ptr_set_cursor(struct wl_client *c, struct wl_resource *r, uint32_t ser, struct wl_resource *s, int32_t x, int32_t y) {}
static const struct wl_pointer_interface pointer_impl = {ptr_set_cursor, noop_destroy};
static const struct wl_keyboard_interface keyboard_impl = {noop_destroy};
static void ptr_gone(struct wl_resource *r) { res_del(ptrs, r); }
static void kbd_gone(struct wl_resource *r) { res_del(kbds, r); }

static void seat_get_pointer(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  struct wl_resource *p = wl_resource_create(c, &wl_pointer_interface, wl_resource_get_version(r), id);
  if (!p) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(p, &pointer_impl, NULL, ptr_gone);
  res_add(ptrs, p);
}

static void seat_get_keyboard(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  struct wl_resource *k = wl_resource_create(c, &wl_keyboard_interface, wl_resource_get_version(r), id);
  if (!k) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(k, &keyboard_impl, NULL, kbd_gone);
  res_add(kbds, k);
  int fd = memfd_create("keymap", MFD_CLOEXEC);
  if (fd >= 0) {
    size_t n = sizeof wl_keymap_us;
    if (write(fd, wl_keymap_us, n) == (ssize_t)n) wl_keyboard_send_keymap(k, WL_KEYBOARD_KEYMAP_FORMAT_XKB_V1, fd, (uint32_t)n);
    close(fd);
  }
  if (wl_resource_get_version(k) >= 4) wl_keyboard_send_repeat_info(k, 30, 400);
}

static void seat_get_touch(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  wl_resource_post_error(r, WL_SEAT_ERROR_MISSING_CAPABILITY, "no touch");
}

static const struct wl_seat_interface seat_impl = {seat_get_pointer, seat_get_keyboard, seat_get_touch, noop_destroy};

static void bind_seat(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  int v = version > 5 ? 5 : (int)version;
  struct wl_resource *r = wl_resource_create(c, &wl_seat_interface, v, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &seat_impl, NULL, NULL);
  wl_seat_send_capabilities(r, WL_SEAT_CAPABILITY_POINTER | WL_SEAT_CAPABILITY_KEYBOARD);
  if (v >= 2) wl_seat_send_name(r, "seat0");
}

static void ds_offer(struct wl_client *c, struct wl_resource *r, const char *m) {}
static void ds_actions(struct wl_client *c, struct wl_resource *r, uint32_t a) {}
static const struct wl_data_source_interface data_source_impl = {ds_offer, noop_destroy, ds_actions};
static void dd_drag(struct wl_client *c, struct wl_resource *r, struct wl_resource *src, struct wl_resource *o,
                    struct wl_resource *icon, uint32_t ser) {}
static void dd_sel(struct wl_client *c, struct wl_resource *r, struct wl_resource *src, uint32_t ser) {}
static const struct wl_data_device_interface data_device_impl = {dd_drag, dd_sel, noop_destroy};

static void ddm_source(struct wl_client *c, struct wl_resource *r, uint32_t id) {
  struct wl_resource *s = wl_resource_create(c, &wl_data_source_interface, wl_resource_get_version(r), id);
  if (!s) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(s, &data_source_impl, NULL, NULL);
}

static void ddm_device(struct wl_client *c, struct wl_resource *r, uint32_t id, struct wl_resource *seat) {
  struct wl_resource *d = wl_resource_create(c, &wl_data_device_interface, wl_resource_get_version(r), id);
  if (!d) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(d, &data_device_impl, NULL, NULL);
}

static const struct wl_data_device_manager_interface ddm_impl = {ddm_source, ddm_device};

static void bind_ddm(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  struct wl_resource *r = wl_resource_create(c, &wl_data_device_manager_interface, version > 3 ? 3 : (int)version, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &ddm_impl, NULL, NULL);
}

static uint32_t *scratch;
static size_t scratch_cap;

static uint32_t *scratch_get(size_t n) {
  if (n > scratch_cap) {
    free(scratch);
    scratch = malloc(n * 4);
    scratch_cap = scratch ? n : 0;
  }
  return scratch;
}

static uint32_t over(uint32_t d, uint32_t s) {
  uint32_t sa = s >> 24;
  if (sa == 255) return s;
  if (!sa) return d;
  uint32_t ia = 255 - sa, r = 0;
  for (int sh = 0; sh < 32; sh += 8) {
    uint32_t v = ((s >> sh) & 255) + ((((d >> sh) & 255) * ia + 127) / 255);
    r |= (v > 255 ? 255 : v) << sh;
  }
  return r;
}

static const uint32_t *surf_image(WlSurf *w, int *iw, int *ih) {
  const uint32_t *src = w->px;
  int sw = w->bw, sh = w->bh;
  if (w->nsubs) {
    uint32_t *tmp = scratch_get((size_t)sw * sh);
    if (!tmp) return NULL;
    memcpy(tmp, src, (size_t)sw * sh * 4);
    for (int i = 0; i < w->nsubs; i++) {
      WlSurf *c = w->subs[i];
      if (!c->px) continue;
      int ox = c->sx * w->scale, oy = c->sy * w->scale;
      for (int y = 0; y < c->bh; y++) {
        int dy = oy + y;
        if (dy < 0 || dy >= sh) continue;
        for (int x = 0; x < c->bw; x++) {
          int dx = ox + x;
          if (dx < 0 || dx >= sw) continue;
          tmp[(size_t)dy * sw + dx] = over(tmp[(size_t)dy * sw + dx], c->px[(size_t)y * c->bw + x]);
        }
      }
    }
    src = tmp;
  }
  if (w->geom_set) {
    int sc = w->scale ? w->scale : 1;
    int x0 = w->gx * sc, y0 = w->gy * sc, cw = w->gw * sc, ch = w->gh * sc;
    if (x0 < 0) cw += x0, x0 = 0;
    if (y0 < 0) ch += y0, y0 = 0;
    if (x0 + cw > sw) cw = sw - x0;
    if (y0 + ch > sh) ch = sh - y0;
    if (cw > 0 && ch > 0 && (cw != sw || ch != sh)) {
      static uint32_t *crop;
      static size_t crop_cap;
      if ((size_t)cw * ch > crop_cap) {
        free(crop);
        crop = malloc((size_t)cw * ch * 4);
        crop_cap = crop ? (size_t)cw * ch : 0;
      }
      if (crop) {
        for (int y = 0; y < ch; y++) memcpy(crop + (size_t)y * cw, src + (size_t)(y0 + y) * sw + x0, (size_t)cw * 4);
        *iw = cw, *ih = ch;
        return crop;
      }
    }
  }
  *iw = sw, *ih = sh;
  return src;
}

static void wl_draw(Panel *p, Surface *s, float ox, float oy) {
  WlSurf *w = surf_of_panel(p);
  if (!w || !w->px) return;
  int iw, ih;
  const uint32_t *img = surf_image(w, &iw, &ih);
  if (img) gfx_blit_premul(s, img, iw, ih, ox, oy, (float)p->lw, (float)(p->kind == PK_WINDOW ? p->lh - BARH(p) : p->lh));
}

typedef struct {
  struct wl_resource *r;
  int pending, active;
} TextInput;

static TextInput tis[32];
static WlSurf *hover_surf, *kbd_surf;

static void ti_gone(struct wl_resource *r) {
  for (int i = 0; i < 32; i++)
    if (tis[i].r == r) tis[i].r = NULL, tis[i].active = tis[i].pending = 0;
}

static TextInput *ti_of(struct wl_resource *r) {
  for (int i = 0; i < 32; i++)
    if (tis[i].r == r) return &tis[i];
  return NULL;
}

static void ti_destroy(struct wl_client *c, struct wl_resource *r) { wl_resource_destroy(r); }
static void ti_enable(struct wl_client *c, struct wl_resource *r) {
  TextInput *t = ti_of(r);
  if (t) t->pending = 1;
}
static void ti_disable(struct wl_client *c, struct wl_resource *r) {
  TextInput *t = ti_of(r);
  if (t) t->pending = 0;
}
static void ti_surrounding(struct wl_client *c, struct wl_resource *r, const char *text, int32_t cur, int32_t anc) {}
static void ti_cause(struct wl_client *c, struct wl_resource *r, uint32_t cause) {}
static void ti_content(struct wl_client *c, struct wl_resource *r, uint32_t hint, uint32_t purpose) {}
static void ti_rect(struct wl_client *c, struct wl_resource *r, int32_t x, int32_t y, int32_t w, int32_t h) {}
static void ti_commit(struct wl_client *c, struct wl_resource *r) {
  TextInput *t = ti_of(r);
  if (t) t->active = t->pending;
}

static const struct zwp_text_input_v3_interface ti_impl = {ti_destroy, ti_enable, ti_disable, ti_surrounding, ti_cause, ti_content, ti_rect, ti_commit};

static void tim_get(struct wl_client *c, struct wl_resource *r, uint32_t id, struct wl_resource *seat) {
  struct wl_resource *t = wl_resource_create(c, &zwp_text_input_v3_interface, wl_resource_get_version(r), id);
  if (!t) return wl_client_post_no_memory(c);
  for (int i = 0; i < 32; i++)
    if (!tis[i].r) {
      tis[i] = (TextInput){t, 0, 0};
      break;
    }
  wl_resource_set_implementation(t, &ti_impl, NULL, ti_gone);
  if (kbd_surf && wl_resource_get_client(kbd_surf->res) == c) zwp_text_input_v3_send_enter(t, kbd_surf->res);
}

static const struct zwp_text_input_manager_v3_interface tim_impl = {noop_destroy, tim_get};

static void bind_tim(struct wl_client *c, void *data, uint32_t version, uint32_t id) {
  struct wl_resource *r = wl_resource_create(c, &zwp_text_input_manager_v3_interface, 1, id);
  if (!r) return wl_client_post_no_memory(c);
  wl_resource_set_implementation(r, &tim_impl, NULL, NULL);
}

static void ti_focus(WlSurf *s, int enter) {
  struct wl_client *c = wl_resource_get_client(s->res);
  for (int i = 0; i < 32; i++) {
    if (!tis[i].r || wl_resource_get_client(tis[i].r) != c) continue;
    if (enter) zwp_text_input_v3_send_enter(tis[i].r, s->res);
    else {
      zwp_text_input_v3_send_leave(tis[i].r, s->res);
      tis[i].active = tis[i].pending = 0;
    }
  }
}

static int ti_wanted(void) {
  if (!kbd_surf) return 0;
  struct wl_client *c = wl_resource_get_client(kbd_surf->res);
  for (int i = 0; i < 32; i++)
    if (tis[i].r && tis[i].active && wl_resource_get_client(tis[i].r) == c) return 1;
  return 0;
}

static int last_sx = -99999, last_sy = -99999;
static uint32_t mods_dep, mods_locked;

static void ptr_frame(struct wl_resource *p) {
  if (wl_resource_get_version(p) >= 5) wl_pointer_send_frame(p);
}

static void send_modifiers(WlSurf *s) {
  if (!s) return;
  EACH(kbds, wl_resource_get_client(s->res), k) wl_keyboard_send_modifiers(k, next_serial(), mods_dep, 0, mods_locked, 0);
}

static void focus_keyboard(WlSurf *s) {
  if (s == kbd_surf) return;
  if (kbd_surf) {
    struct wl_client *c = wl_resource_get_client(kbd_surf->res);
    EACH(kbds, c, k) wl_keyboard_send_leave(k, next_serial(), kbd_surf->res);
    ti_focus(kbd_surf, 0);
  }
  kbd_surf = s;
  if (s) {
    struct wl_client *c = wl_resource_get_client(s->res);
    struct wl_array keys;
    wl_array_init(&keys);
    EACH(kbds, c, k) wl_keyboard_send_enter(k, next_serial(), s->res, &keys);
    wl_array_release(&keys);
    send_modifiers(s);
    ti_focus(s, 1);
  }
}

static void dismiss_popups(void) {
  for (WlSurf *s = surfs; s; s = s->next)
    if (s->role == 2 && s->popup) xdg_popup_send_popup_done(s->popup);
}

static void point_at(WlSurf *t, float sx, float sy, uint32_t now) {
  if (t != hover_surf) {
    if (hover_surf) {
      struct wl_client *c = wl_resource_get_client(hover_surf->res);
      EACH(ptrs, c, ptr) {
        wl_pointer_send_leave(ptr, next_serial(), hover_surf->res);
        ptr_frame(ptr);
      }
    }
    hover_surf = t;
    last_sx = last_sy = -99999;
    if (t) {
      struct wl_client *c = wl_resource_get_client(t->res);
      EACH(ptrs, c, ptr) {
        wl_pointer_send_enter(ptr, next_serial(), t->res, wl_fixed_from_double(sx), wl_fixed_from_double(sy));
        ptr_frame(ptr);
      }
      last_sx = (int)sx, last_sy = (int)sy;
    }
  } else if (t && ((int)sx != last_sx || (int)sy != last_sy)) {
    struct wl_client *c = wl_resource_get_client(t->res);
    EACH(ptrs, c, ptr) {
      wl_pointer_send_motion(ptr, now, wl_fixed_from_double(sx), wl_fixed_from_double(sy));
      ptr_frame(ptr);
    }
    last_sx = (int)sx, last_sy = (int)sy;
  }
}

static void wlwin_press(Panel *p, float x, float y, int button, int down) {
  WlSurf *s = surf_of_panel(p);
  if (!s) return;
  if (down && p->kind == PK_WINDOW) {
    int open = 0;
    for (WlSurf *o = surfs; o; o = o->next) open |= o->role == 2 && o->popup && o->grab;
    if (open) {
      dismiss_popups();
      return;
    }
  }
  uint32_t t = now_ms();
  if (down) point_at(s, x + (s->geom_set ? s->gx : 0), y + (s->geom_set ? s->gy : 0), t);
  struct wl_client *c = wl_resource_get_client(s->res);
  int code = button == 1 ? BTN_LEFT_ : button == 3 ? BTN_LEFT_ + 1 : BTN_LEFT_ + 2;
  EACH(ptrs, c, ptr) {
    wl_pointer_send_button(ptr, next_serial(), t, (uint32_t)code, down ? WL_POINTER_BUTTON_STATE_PRESSED : WL_POINTER_BUTTON_STATE_RELEASED);
    ptr_frame(ptr);
  }
}

static void wlwin_scroll(Panel *p, float x, float y, int steps) {
  WlSurf *s = surf_of_panel(p);
  if (!s) return;
  struct wl_client *c = wl_resource_get_client(s->res);
  uint32_t t = now_ms();
  EACH(ptrs, c, ptr) {
    if (wl_resource_get_version(ptr) >= 5) wl_pointer_send_axis_discrete(ptr, WL_POINTER_AXIS_VERTICAL_SCROLL, -steps);
    wl_pointer_send_axis(ptr, t, WL_POINTER_AXIS_VERTICAL_SCROLL, wl_fixed_from_int(-steps * 10));
    ptr_frame(ptr);
  }
}

static void wlwin_rawkey(Panel *p, int code, int down) {
  WlSurf *s = surf_of_panel(p);
  if (!s) return;
  focus_keyboard(s);
  uint32_t bit = 0;
  switch (code) {
  case 42: case 54: bit = 1; break;
  case 29: case 97: bit = 4; break;
  case 56: case 100: bit = 8; break;
  case 125: case 126: bit = 64; break;
  }
  struct wl_client *c = wl_resource_get_client(s->res);
  uint32_t t = now_ms();
  EACH(kbds, c, k) wl_keyboard_send_key(k, next_serial(), t, (uint32_t)code, down ? WL_KEYBOARD_KEY_STATE_PRESSED : WL_KEYBOARD_KEY_STATE_RELEASED);
  if (bit) {
    if (down) mods_dep |= bit;
    else mods_dep &= ~bit;
    send_modifiers(s);
  } else if (code == 58 && down) {
    mods_locked ^= 2;
    send_modifiers(s);
  }
}

static int wlwin_close_request(Panel *p) {
  WlSurf *s = surf_of_panel(p);
  if (!s || !s->top) return 0;
  xdg_toplevel_send_close(s->top);
  return 1;
}

static void wl_gone(Panel *p) {
  WlSurf *s = surf_of_panel(p);
  if (s) {
    if (hover_surf == s) hover_surf = NULL;
    if (kbd_surf == s) kbd_surf = NULL;
    s->panel = -1, s->ref = NULL;
  }
}

App wlwin_app = {"wl-window", "Linux app", IC_DESKTOP, 0, 0, NULL, wl_draw, NULL, wlwin_scroll, NULL, NULL,
                 NULL, wl_gone, wlwin_press, wlwin_rawkey, wlwin_close_request};
App wlpopup_app = {"wl-popup", "", IC_DESKTOP, 0, 0, NULL, wl_draw, NULL, wlwin_scroll, NULL, NULL,
                   NULL, wl_gone, wlwin_press, NULL, NULL};

int wl_surface_count(void) {
  int n = 0;
  for (WlSurf *s = surfs; s; s = s->next) n += s->role == 1 && s->panel >= 0;
  return n;
}

static void setup_runtime_dir(void) {
  const char *user = getenv("OREONVR_USER");
  struct passwd *pw = NULL;
  if (getuid() == 0 && user && *user) pw = getpwnam(user);
  if (pw) {
    have_user = 1;
    run_uid = pw->pw_uid, run_gid = pw->pw_gid;
    snprintf(runtime_dir, sizeof runtime_dir, "/run/user/%u", (unsigned)pw->pw_uid);
  } else {
    run_uid = getuid(), run_gid = getgid();
    const char *x = getenv("XDG_RUNTIME_DIR");
    if (x && *x) snprintf(runtime_dir, sizeof runtime_dir, "%s", x);
    else snprintf(runtime_dir, sizeof runtime_dir, "/tmp/oreonvr-run-%u", (unsigned)run_uid);
  }
  if (mkdir(runtime_dir, 0700) == 0 && getuid() == 0) {
    if (chown(runtime_dir, run_uid, run_gid)) {  }
  }
}

static void child_prepare(void) {
  if (getuid() == 0 && have_user) {
    struct passwd *pw = getpwuid(run_uid);
    if (pw && (initgroups(pw->pw_name, run_gid) || setgid(run_gid) || setuid(run_uid))) _exit(126);
    if (pw) {
      setenv("HOME", pw->pw_dir, 1);
      setenv("USER", pw->pw_name, 1);
      setenv("LOGNAME", pw->pw_name, 1);
      if (chdir(pw->pw_dir)) {  }
    }
  }
  setenv("XDG_RUNTIME_DIR", runtime_dir, 1);
  setenv("WAYLAND_DISPLAY", sock_name, 1);
  setenv("XDG_SESSION_TYPE", "wayland", 1);
  setenv("GDK_BACKEND", "wayland", 1);
  setenv("QT_QPA_PLATFORM", "wayland", 1);
  setenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1", 1);
  setenv("SDL_VIDEODRIVER", "wayland", 1);
  setenv("GTK_IM_MODULE", "wayland", 1);
  setenv("QT_IM_MODULE", "wayland", 1);
  setenv("MOZ_ENABLE_WAYLAND", "1", 1);
  setenv("ELECTRON_OZONE_PLATFORM_HINT", "wayland", 1);
  setenv("GSK_RENDERER", "cairo", 1);
  setenv("QT_QUICK_BACKEND", "software", 1);
  setenv("LIBGL_ALWAYS_SOFTWARE", "1", 1);
  setenv("NO_AT_BRIDGE", "1", 1);
  unsetenv("DISPLAY");
  unsetenv("DBUS_SESSION_BUS_ADDRESS");
  int nul = open("/dev/null", O_RDWR);
  if (nul >= 0 && !getenv("OREONVR_WL_DEBUG")) dup2(nul, 0), dup2(nul, 1), dup2(nul, 2);
}

int wl_launch(const char *desktop_file) {
  if (!dpy || !desktop_file || !*desktop_file) return 0;
  pid_t pid = fork();
  if (pid < 0) return 0;
  if (pid > 0) {
    int st;
    waitpid(pid, &st, 0);
    return 1;
  }
  if (fork() != 0) _exit(0);
  setsid();
  child_prepare();
  execlp("dbus-run-session", "dbus-run-session", "--", "gio", "launch", desktop_file, (char *)NULL);
  execlp("gio", "gio", "launch", desktop_file, (char *)NULL);
  _exit(127);
}

int wl_spawn(char *const argv[]) {
  if (!dpy) return 0;
  pid_t pid = fork();
  if (pid < 0) return 0;
  if (pid > 0) {
    waitpid(pid, NULL, 0);
    return 1;
  }
  if (fork() != 0) _exit(0);
  setsid();
  child_prepare();
  execvp(argv[0], argv);
  _exit(127);
}

void wl_init(void) {
  setup_runtime_dir();
  setenv("XDG_RUNTIME_DIR", runtime_dir, 1);
  dpy = wl_display_create();
  if (!dpy) return;
  loop = wl_display_get_event_loop(dpy);
  mode_t old = umask(0);
  const char *name = wl_display_add_socket_auto(dpy);
  umask(old);
  if (!name) {
    fprintf(stderr, "oreonvr: wayland: could not create a socket in %s\n", runtime_dir);
    wl_display_destroy(dpy);
    dpy = NULL;
    return;
  }
  snprintf(sock_name, sizeof sock_name, "%s", name);
  wl_display_init_shm(dpy);
  wl_global_create(dpy, &wl_compositor_interface, 4, NULL, bind_compositor);
  wl_global_create(dpy, &wl_subcompositor_interface, 1, NULL, bind_subcompositor);
  wl_global_create(dpy, &xdg_wm_base_interface, 4, NULL, bind_wm_base);
  wl_global_create(dpy, &zxdg_decoration_manager_v1_interface, 1, NULL, bind_decom);
  wl_global_create(dpy, &wl_seat_interface, 5, NULL, bind_seat);
  wl_global_create(dpy, &wl_output_interface, 3, NULL, bind_output);
  wl_global_create(dpy, &wl_data_device_manager_interface, 3, NULL, bind_ddm);
  wl_global_create(dpy, &zwp_text_input_manager_v3_interface, 1, NULL, bind_tim);
  fprintf(stderr, "oreonvr: wayland socket %s/%s\n", runtime_dir, sock_name);
}

void wl_poll(uint32_t now) {
  if (!dpy) return;
  wl_event_loop_dispatch(loop, 0);

  for (int i = 0; i < nready; i++) {
    struct wl_resource *cb = ready_cb[i];
    ready_cb[i] = NULL;
    if (cb) {
      wl_callback_send_done(cb, now);
      wl_resource_destroy(cb);
    }
  }
  nready = 0;

  for (WlSurf *s = surfs; s; s = s->next) {
    if (s->role == 2 && s->panel >= 0) place_popup(s);
    if (s->role == 3 && s->parent) {
      WlSurf *r = root_of(s);
      if (r && r->panel >= 0 && P[r->panel].used) P[r->panel].dirty = 1;
    }
  }

  WlSurf *t = NULL;
  float sx = 0, sy = 0;
  int hv = W.hover;
  if (hv >= 0 && P[hv].used && (P[hv].app == &wlwin_app || P[hv].app == &wlpopup_app)) {
    t = surf_of_panel(&P[hv]);
    float by = P[hv].kind == PK_WINDOW ? W.ht - BARH(&P[hv]) : W.ht;
    if (t && (by < 0 || input_dragging())) t = NULL;
    if (t) sx = W.hs + (t->geom_set ? t->gx : 0), sy = by + (t->geom_set ? t->gy : 0);
  }
  point_at(t, sx, sy, now);

  WlSurf *fk = NULL;
  if (W.focus >= 0 && P[W.focus].used && P[W.focus].app == &wlwin_app) fk = surf_of_panel(&P[W.focus]);
  focus_keyboard(fk);

  static int was_wanted, auto_open;
  int want = ti_wanted();
  if (want && !was_wanted) {
    int open = 0;
    for (int i = 0; i < MAXP; i++) open |= P[i].used && P[i].app == &keyboard_app;
    if (!open) {
      panel_open_app("keyboard");
      auto_open = 1;
    }
  } else if (!want && was_wanted && auto_open) {
    for (int i = 0; i < MAXP; i++)
      if (P[i].used && P[i].app == &keyboard_app) panel_close(i);
    auto_open = 0;
  }
  was_wanted = want;

  wl_display_flush_clients(dpy);
}

#endif
