#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "store.h"

#define MAXREQ 220
#define MAXRUN 6

static NetReq R[MAXREQ];
static char cache_dir[600];

const char *net_cache_dir(void) {
  if (!cache_dir[0]) {
    const char *e = getenv("OREONVR_STORE_CACHE");
    if (e && *e) snprintf(cache_dir, sizeof cache_dir, "%s", e);
    else snprintf(cache_dir, sizeof cache_dir, "%s/.cache/oreonvr/store", user_home());
    office_mkdirs(cache_dir);
  }
  return cache_dir;
}

static uint64_t fnv(const char *s) {
  uint64_t h = 1469598103934665603ull;
  for (; *s; s++) h = (h ^ (unsigned char)*s) * 1099511628211ull;
  return h;
}

static void kill_req(NetReq *r) {
  if (r->fd >= 0) close(r->fd);
  r->fd = -1;
  if (r->pid > 0) {
    kill(r->pid, SIGKILL);
    waitpid(r->pid, NULL, 0);
  }
  r->pid = 0;
}

void net_drop(NetReq *r) {
  if (!r || !r->used) return;
  kill_req(r);
  free(r->out.s);
  memset(r, 0, sizeof *r);
  r->fd = -1;
}

static NetReq *slot(void) {
  for (int i = 0; i < MAXREQ; i++)
    if (!R[i].used) return &R[i];
  NetReq *best = NULL;
  for (int i = 0; i < MAXREQ; i++)
    if ((R[i].state == NET_OK || R[i].state == NET_FAIL) && !R[i].pty && (!best || R[i].touched < best->touched)) best = &R[i];
  if (!best) return NULL;
  net_drop(best);
  return best;
}

static int running(void) {
  int n = 0;
  for (int i = 0; i < MAXREQ; i++)
    if (R[i].used && R[i].state == NET_RUN && !R[i].pty) n++;
  return n;
}

static int spawn_curl(NetReq *r) {
  int fds[2];
  if (pipe(fds)) return 0;
  pid_t pid = fork();
  if (pid < 0) {
    close(fds[0]), close(fds[1]);
    return 0;
  }
  if (pid == 0) {
    dup2(fds[1], 1);
    int nul = open("/dev/null", O_RDWR);
    if (nul >= 0) dup2(nul, 2), dup2(nul, 0);
    close(fds[0]);
    const char *cmd = getenv("OREONVR_STORE_CURL");
    char *av[24];
    int n = 0;
    av[n++] = (char *)(cmd && *cmd ? cmd : "curl");
    av[n++] = "-sS", av[n++] = "-f", av[n++] = "-L", av[n++] = "-m", av[n++] = "40";
    av[n++] = "--connect-timeout", av[n++] = "12", av[n++] = "-A", av[n++] = "OreonVR-Store/1";
    if (r->post[0]) av[n++] = "-H", av[n++] = "Content-Type: application/json", av[n++] = "-X", av[n++] = "POST", av[n++] = "--data-raw", av[n++] = r->post;
    av[n++] = r->url;
    av[n] = NULL;
    execvp(av[0], av);
    _exit(127);
  }
  close(fds[1]);
  fcntl(fds[0], F_SETFL, fcntl(fds[0], F_GETFL) | O_NONBLOCK);
  fcntl(fds[0], F_SETFD, FD_CLOEXEC);
  r->fd = fds[0], r->pid = pid;
  return 1;
}

static int load_disk(NetReq *r) {
  struct stat st;
  if (r->ttl <= 0 || stat(r->path, &st) || time(NULL) - st.st_mtime > r->ttl) return 0;
  FILE *f = fopen(r->path, "rb");
  if (!f) return 0;
  char tmp[8192];
  size_t n;
  r->out.n = 0;
  buf_put(&r->out, "", 0);
  while ((n = fread(tmp, 1, sizeof tmp, f)) > 0) buf_put(&r->out, tmp, n);
  fclose(f);
  return r->out.n > 0;
}

static void start(NetReq *r) {
  r->out.n = 0;
  buf_put(&r->out, "", 0);
  r->t0 = now_ms();
  if (load_disk(r)) {
    r->state = NET_OK, r->t1 = r->t0, r->rc = 0;
    return;
  }
  if (running() >= MAXRUN) {
    r->state = NET_QUEUED;
    return;
  }
  r->state = spawn_curl(r) ? NET_RUN : NET_FAIL;
  if (r->state == NET_FAIL) r->t1 = now_ms();
}

NetReq *net_http(const char *url, const char *post, int ttl) {
  char key[700];
  snprintf(key, sizeof key, "%s\n%s", url, post ? post : "");
  uint32_t now = now_ms();
  for (int i = 0; i < MAXREQ; i++)
    if (R[i].used && !R[i].pty && !strcmp(R[i].key, key)) {
      NetReq *r = &R[i];
      r->touched = now;
      if ((r->state == NET_OK || r->state == NET_FAIL) && now - r->t1 > (uint32_t)(r->state == NET_FAIL ? 20 : ttl) * 1000u) {
        r->ttl = ttl;
        start(r);
      }
      return r;
    }
  NetReq *r = slot();
  if (!r) return NULL;
  memset(r, 0, sizeof *r);
  r->used = 1, r->fd = -1, r->ttl = ttl, r->touched = now, r->disk = ttl > 0;
  snprintf(r->key, sizeof r->key, "%s", key);
  snprintf(r->url, sizeof r->url, "%s", url);
  snprintf(r->post, sizeof r->post, "%s", post ? post : "");
  snprintf(r->path, sizeof r->path, "%s/%016llx", net_cache_dir(), (unsigned long long)fnv(key));
  start(r);
  return r;
}

NetReq *net_proc(const char *key, char *const argv[], int pty) {
  NetReq *r = slot();
  if (!r) return NULL;
  memset(r, 0, sizeof *r);
  r->used = 1, r->fd = -1, r->pty = 1, r->touched = now_ms(), r->t0 = r->touched;
  snprintf(r->key, sizeof r->key, "%s", key);
  buf_put(&r->out, "", 0);
  int master = -1, pfd[2] = {-1, -1};
  if (pty) {
    master = posix_openpt(O_RDWR | O_NOCTTY);
    if (master < 0 || grantpt(master) || unlockpt(master)) {
      if (master >= 0) close(master);
      r->state = NET_FAIL, r->t1 = r->t0;
      return r;
    }
  } else if (pipe(pfd)) {
    r->state = NET_FAIL, r->t1 = r->t0;
    return r;
  }
  pid_t pid = fork();
  if (pid < 0) {
    r->state = NET_FAIL, r->t1 = r->t0;
    return r;
  }
  if (pid == 0) {
    setsid();
    if (pty) {
      char *sn = ptsname(master);
      int sl = sn ? open(sn, O_RDWR) : -1;
      if (sl < 0) _exit(126);
      struct winsize ws = {30, 110, 0, 0};
      ioctl(sl, TIOCSWINSZ, &ws);
      dup2(sl, 0), dup2(sl, 1), dup2(sl, 2);
      if (sl > 2) close(sl);
      close(master);
      setenv("TERM", "xterm", 1);
    } else {
      dup2(pfd[1], 1), dup2(pfd[1], 2);
      int nul = open("/dev/null", O_RDONLY);
      if (nul >= 0) dup2(nul, 0);
      close(pfd[0]);
    }
    setenv("LC_ALL", "C", 1);
    execvp(argv[0], argv);
    _exit(127);
  }
  if (pty) r->fd = master;
  else r->fd = pfd[0], close(pfd[1]);
  fcntl(r->fd, F_SETFL, fcntl(r->fd, F_GETFL) | O_NONBLOCK);
  fcntl(r->fd, F_SETFD, FD_CLOEXEC);
  r->pid = pid;
  r->state = NET_RUN;
  return r;
}

static void finish(NetReq *r) {
  int st = 0;
  if (r->fd >= 0) close(r->fd);
  r->fd = -1;
  if (r->pid > 0) waitpid(r->pid, &st, 0);
  r->pid = 0;
  r->rc = WIFEXITED(st) ? WEXITSTATUS(st) : 255;
  r->t1 = now_ms();
  if (r->rc == 0 && (r->out.n > 0 || r->pty)) {
    r->state = NET_OK;
    if (r->disk) {
      FILE *f = fopen(r->path, "wb");
      if (f) {
        fwrite(r->out.s, 1, r->out.n, f);
        fclose(f);
      }
    }
  } else r->state = NET_FAIL;
}

int net_poll(void) {
  int changed = 0;
  uint32_t now = now_ms();
  for (int i = 0; i < MAXREQ; i++) {
    NetReq *r = &R[i];
    if (!r->used || r->state != NET_RUN) continue;
    char tmp[8192];
    for (;;) {
      ssize_t n = read(r->fd, tmp, sizeof tmp);
      if (n > 0) {
        if (r->pty && r->out.n > 60000) r->out.n = 0;
        buf_put(&r->out, tmp, (size_t)n);
        changed = 1;
        continue;
      }
      if (n < 0 && errno == EAGAIN) {
        if (!r->pty && now - r->t0 > 60000) kill_req(r), r->state = NET_FAIL, r->t1 = now, changed = 1;
        break;
      }
      finish(r);
      changed = 1;
      break;
    }
  }
  for (int i = 0; i < MAXREQ; i++)
    if (R[i].used && R[i].state == NET_QUEUED && running() < MAXRUN) {
      R[i].state = spawn_curl(&R[i]) ? NET_RUN : NET_FAIL;
      R[i].t0 = now;
      changed = 1;
    }
  return changed;
}

int net_busy(void) {
  for (int i = 0; i < MAXREQ; i++)
    if (R[i].used && (R[i].state == NET_RUN || R[i].state == NET_QUEUED)) return 1;
  return 0;
}
