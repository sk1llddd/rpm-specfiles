#include <dirent.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>

#include "office.h"

#define PK_MAX 128
#define PK_W 660
#define PK_H 500
#define PK_ROW 56
#define PK_TH_W 138
#define PK_TH_GAP 14

typedef struct {
  char id[40], title[96];
  long mtime;
  int nslides;
} PickItem;

static int depth;

static struct {
  int on, tab, deck;
  char host_id[40];
  int host_kind;
  float scroll;
  PickItem it[3][PK_MAX];
  int n[3];
  int files, nf;
  char fpath[PK_MAX][768], fname[PK_MAX][96];
  const char *fdir[PK_MAX];
  long fmt[PK_MAX];
  long fsz[PK_MAX];
  int floc[PK_MAX], loc, nvis, vis[PK_MAX], cnt[5];
  char chosen[768];
} PK;

static const char *const KIND_SUB[3] = {"Docs", "Sheets", "Slides"};
static const char *const KIND_ENV[3] = {"OREONVR_DOCS_DIR", "OREONVR_SHEETS_DIR", "OREONVR_SLIDES_DIR"};
static const char *const KIND_EXT[3] = {".odoc", ".osheet", ".oslides"};
static const char *const KIND_NAME[3] = {"Document", "Spreadsheet", "Slide"};

static float lh(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

uint32_t office_acc(int kind) { return kind == 2 ? P_ACC : kind == 1 ? S_ACC : N_ACC; }

void office_clip_push(Surface *s, float x, float y, float w, float h, int *save) {
  save[0] = s->cx0, save[1] = s->cy0, save[2] = s->cx1, save[3] = s->cy1;
  int k = s->scale;
  int x0 = (int)floorf(x * k), y0 = (int)floorf(y * k), x1 = (int)ceilf((x + w) * k), y1 = (int)ceilf((y + h) * k);
  if (x0 < s->cx0) x0 = s->cx0;
  if (y0 < s->cy0) y0 = s->cy0;
  if (x1 > s->cx1) x1 = s->cx1;
  if (y1 > s->cy1) y1 = s->cy1;
  if (x1 < x0) x1 = x0;
  if (y1 < y0) y1 = y0;
  s->cx0 = x0, s->cy0 = y0, s->cx1 = x1, s->cy1 = y1;
}

void office_clip_pop(Surface *s, const int *save) { s->cx0 = save[0], s->cy0 = save[1], s->cx1 = save[2], s->cy1 = save[3]; }

int office_embed_parse(const char *ref, int *kind, char *id, int idn, int *sub) {
  int k = 0, sb = 0;
  char buf[48];
  if (!ref || sscanf(ref, "%d:%47[A-Za-z0-9_-]:%d", &k, buf, &sb) != 3 || k < 0 || k > 2) return 0;
  *kind = k, *sub = sb < 0 ? 0 : sb;
  snprintf(id, (size_t)idn, "%s", buf);
  return 1;
}

void office_embed_ref(char *out, int n, int kind, const char *id, int sub) { snprintf(out, (size_t)n, "%d:%s:%d", kind, id, sub); }

static int render_body(Surface *s, int kind, const char *id, int sub, float x, float y, float w, float h, char *title, int tn) {
  if (depth >= 2) return 0;
  depth++;
  int ok = kind == 0 ? docs_embed(s, id, x, y, w, h, title, tn)
         : kind == 1 ? sheets_embed(s, id, x, y, w, h, title, tn)
                     : slides_embed(s, id, sub, x, y, w, h, title, tn);
  depth--;
  return ok;
}

int office_embed_title(int kind, const char *id, int sub, char *t, int tn) { return render_body(NULL, kind, id, sub, 0, 0, 0, 0, t, tn); }

static void missing(Surface *s, int kind, float x, float y, float w, float h) {
  gfx_rect(s, x, y, w, h, THEME(RGB(246, 246, 248), RGB(40, 42, 48)));
  if (w < 120 || h < 60) return;
  float cx = x + w / 2, cy = y + h / 2;
  office_mark(s, cx - 9, cy - 30, kind == 2 ? 3 : kind);
  gfx_text_c(s, F_SMALL, cx, cy, "This file is no longer available", C_MUTED);
}

void office_embed_draw(Surface *s, int kind, const char *id, int sub, float x, float y, float w, float h, int flags) {
  int sv[4];
  char title[96] = "";
  uint32_t acc = office_acc(kind);
  if (!(flags & EMB_CHROME)) {
    office_clip_push(s, x, y, w, h, sv);
    if (!render_body(s, kind, id, sub, x, y, w, h, title, sizeof title)) missing(s, kind, x, y, w, h);
    office_clip_pop(s, sv);
    return;
  }
  float hh = 36;
  uint32_t page = THEME(RGB(255, 255, 255), RGB(34, 36, 42));
  if (flags & EMB_SEL) gfx_rrect(s, x - 3, y - 3, w + 6, h + 6, 13, acc);
  else gfx_shadow(s, x, y + 3, w, h, 10, 12, RGBA(30, 28, 60, 28));
  gfx_rrect(s, x - 1, y - 1, w + 2, h + 2, 11, THEME(RGB(222, 222, 228), RGB(58, 60, 68)));
  gfx_rrect(s, x, y, w, h, 10, page);
  gfx_rrect(s, x, y, w, hh + 10, 10, THEME(RGB(249, 248, 246), RGB(40, 42, 48)));
  float by = y + hh + 1, bh = h - hh - 2;
  office_clip_push(s, x + 1, by, w - 2, bh, sv);
  int ok = render_body(s, kind, id, sub, x + 1, by, w - 2, bh, title, sizeof title);
  if (!ok) missing(s, kind, x + 1, by, w - 2, bh);
  office_clip_pop(s, sv);
  gfx_rect(s, x, y + hh, w, 1, THEME(RGB(232, 230, 226), RGB(52, 54, 62)));
  office_mark(s, x + 12, y + 9, kind == 2 ? 3 : kind);
  char lab[48];
  if (kind == 2) snprintf(lab, sizeof lab, "Slide %d", sub + 1);
  else snprintf(lab, sizeof lab, "%s", KIND_NAME[kind]);
  float lw = gfx_text_w(F_SMALL, lab);
  gfx_text(s, F_SMALL, x + w - 14 - lw, y + hh / 2 - lh(F_SMALL) / 2, lab, (flags & EMB_SEL) ? acc : C_MUTED);
  gfx_text_fit(s, F_UI_MED, x + 38, y + hh / 2 - lh(F_UI_MED) / 2, w - 70 - lw, ok ? title : "Missing file", C_TEXT);
}

static void pk_scan(int kind) {
  PK.n[kind] = 0;
  char dir[512];
  office_dirs(dir, sizeof dir, KIND_SUB[kind], KIND_ENV[kind]);
  DIR *d = opendir(dir);
  if (!d) return;
  struct dirent *e;
  size_t el = strlen(KIND_EXT[kind]);
  while ((e = readdir(d)) && PK.n[kind] < PK_MAX) {
    size_t l = strlen(e->d_name);
    if (l <= el || strcmp(e->d_name + l - el, KIND_EXT[kind])) continue;
    PickItem *it = &PK.it[kind][PK.n[kind]];
    memset(it, 0, sizeof *it);
    snprintf(it->id, sizeof it->id, "%.*s", (int)(l - el), e->d_name);
    if (kind == PK.host_kind && kind != 2 && !strcmp(it->id, PK.host_id)) continue;
    char path[800];
    snprintf(path, sizeof path, "%s/%s", dir, e->d_name);
    struct stat st;
    it->mtime = stat(path, &st) ? 0 : (long)st.st_mtime;
    snprintf(it->title, sizeof it->title, "Untitled");
    char *body = office_read_file(path);
    if (body) {
      char *q = body;
      while (*q) {
        char *nl = strchr(q, '\n');
        int len = nl ? (int)(nl - q) : (int)strlen(q);
        if (!strncmp(q, "title\t", 6) && len > 6) snprintf(it->title, sizeof it->title, "%.*s", len - 6 > 95 ? 95 : len - 6, q + 6);
        else if (q[0] == 's' && q[1] == '\t') it->nslides++;
        q += len + (nl ? 1 : 0);
      }
      free(body);
    }
    PK.n[kind]++;
  }
  closedir(d);
  for (int i = 1; i < PK.n[kind]; i++)
    for (int j = i; j > 0 && PK.it[kind][j].mtime > PK.it[kind][j - 1].mtime; j--) {
      PickItem t = PK.it[kind][j];
      PK.it[kind][j] = PK.it[kind][j - 1];
      PK.it[kind][j - 1] = t;
    }
}

void office_picker_open(int tab, int host_kind, const char *host_id) {
  memset(&PK, 0, sizeof PK);
  PK.on = 1;
  PK.tab = tab;
  PK.deck = -1;
  PK.host_kind = host_kind;
  snprintf(PK.host_id, sizeof PK.host_id, "%s", host_id ? host_id : "");
  for (int k = 0; k < 3; k++) pk_scan(k);
}

int office_picker_on(void) { return PK.on; }

void office_picker_close(void) { PK.on = 0; }

static void pk_rect(float w, float h, float *x, float *y) {
  *x = (w - PK_W) / 2;
  *y = (h - PK_H) / 2;
  if (*y < 16) *y = 16;
}

static float pk_list_y(void) { return 112; }

static float pk_list_h(void) { return PK_H - pk_list_y() - 20; }

static int pk_cols(void) { return (PK_W - 40 + PK_TH_GAP) / (PK_TH_W + PK_TH_GAP); }

static const char *const IMP_EXT[3][3] = {{".docx", ".rtf", NULL}, {".xlsx", ".csv", NULL}, {".pptx", NULL, NULL}};

static const char *const LOC_NAMES[5] = {"All", "Documents", "Downloads", "Desktop", "Home"};

static float chip_w(int k) {
  char nb[12];
  snprintf(nb, sizeof nb, "%d", PK.cnt[k]);
  return gfx_text_w(F_SMALL, LOC_NAMES[k]) + gfx_text_w(F_SMALL, nb) + 40;
}

static void imp_filter(void) {
  memset(PK.cnt, 0, sizeof PK.cnt);
  PK.nvis = 0;
  for (int i = 0; i < PK.nf; i++) {
    PK.cnt[0]++, PK.cnt[1 + PK.floc[i]]++;
    if (PK.loc == 0 || PK.floc[i] == PK.loc - 1) PK.vis[PK.nvis++] = i;
  }
}

static void imp_scan(void) {
  static const char *const sub[4] = {"Documents", "Downloads", "Desktop", ""};
  static const char *const lab[4] = {"Documents", "Downloads", "Desktop", "Home"};
  PK.nf = 0;
  for (int d = 0; d < 4; d++) {
    char dir[512];
    if (sub[d][0]) snprintf(dir, sizeof dir, "%s/%s", user_home(), sub[d]);
    else snprintf(dir, sizeof dir, "%s", user_home());
    DIR *dp = opendir(dir);
    if (!dp) continue;
    struct dirent *e;
    while ((e = readdir(dp)) && PK.nf < PK_MAX) {
      if (e->d_name[0] == '.' || e->d_name[0] == '~') continue;
      size_t l = strlen(e->d_name);
      int ok = 0;
      for (int k = 0; k < 3 && IMP_EXT[PK.tab][k]; k++) {
        size_t el = strlen(IMP_EXT[PK.tab][k]);
        if (l > el && !strcasecmp(e->d_name + l - el, IMP_EXT[PK.tab][k])) ok = 1;
      }
      if (!ok) continue;
      int i = PK.nf;
      snprintf(PK.fpath[i], sizeof PK.fpath[i], "%s/%s", dir, e->d_name);
      struct stat st;
      if (stat(PK.fpath[i], &st) || !S_ISREG(st.st_mode)) continue;
      office_ascii(e->d_name, (int)l, PK.fname[i], sizeof PK.fname[i]);
      PK.fdir[i] = lab[d];
      PK.floc[i] = d;
      PK.fsz[i] = (long)st.st_size;
      PK.fmt[i] = (long)st.st_mtime;
      PK.nf++;
    }
    closedir(dp);
  }
  for (int i = 1; i < PK.nf; i++)
    for (int j = i; j > 0 && PK.fmt[j] > PK.fmt[j - 1]; j--) {
      char tp[768], tn[96];
      memcpy(tp, PK.fpath[j], sizeof tp), memcpy(tn, PK.fname[j], sizeof tn);
      memcpy(PK.fpath[j], PK.fpath[j - 1], sizeof tp), memcpy(PK.fname[j], PK.fname[j - 1], sizeof tn);
      memcpy(PK.fpath[j - 1], tp, sizeof tp), memcpy(PK.fname[j - 1], tn, sizeof tn);
      const char *td = PK.fdir[j];
      PK.fdir[j] = PK.fdir[j - 1], PK.fdir[j - 1] = td;
      long tm = PK.fmt[j];
      PK.fmt[j] = PK.fmt[j - 1], PK.fmt[j - 1] = tm;
      tm = PK.fsz[j];
      PK.fsz[j] = PK.fsz[j - 1], PK.fsz[j - 1] = tm;
      int tl = PK.floc[j];
      PK.floc[j] = PK.floc[j - 1], PK.floc[j - 1] = tl;
    }
  imp_filter();
}

void office_import_open(int kind) {
  memset(&PK, 0, sizeof PK);
  PK.on = 1;
  PK.files = 1;
  PK.tab = kind;
  PK.deck = -1;
  imp_scan();
}

const char *office_import_path(void) { return PK.chosen; }

static float pk_content_h(void) {
  if (PK.files) return PK.nvis * PK_ROW;
  if (PK.deck >= 0) {
    int n = PK.it[2][PK.deck].nslides;
    if (n < 1) n = 1;
    return ((n + pk_cols() - 1) / pk_cols()) * (PK_TH_W * 9 / 16 + 40) + 8;
  }
  return PK.n[PK.tab] * PK_ROW;
}

void office_picker_scroll(int steps) {
  if (!PK.on) return;
  PK.scroll -= steps * 60;
  float m = pk_content_h() - pk_list_h();
  if (PK.scroll > m) PK.scroll = m;
  if (PK.scroll < 0) PK.scroll = 0;
}

int office_picker_zone(float x, float y, float w, float h) {
  float px, py;
  pk_rect(w, h, &px, &py);
  if (x < px || x >= px + PK_W || y < py || y >= py + PK_H) return PZ_DIM;
  float rx = x - px, ry = y - py;
  if (ry < 60) {
    if (rx >= PK_W - 56 && ry >= 12 && ry < 48) return PZ_CLOSE;
    if (PK.deck >= 0 && rx < 60 && ry >= 12 && ry < 48) return PZ_BACK;
    return PZ_BLOCK;
  }
  if (PK.files && ry >= 64 && ry < 100) {
    float cx = 24;
    for (int i = 0; i < 5; i++) {
      float cwid = chip_w(i);
      if (rx >= cx && rx < cx + cwid) return PZ_LOC + i;
      cx += cwid + 8;
    }
    return PZ_BLOCK;
  }
  if (PK.deck < 0 && !PK.files && ry >= 64 && ry < 100) {
    float sx = (PK_W - 330) / 2;
    if (rx >= sx && rx < sx + 330) return PZ_TAB + (int)((rx - sx) / 110);
    return PZ_BLOCK;
  }
  float ly = pk_list_y();
  if (ry < ly || ry >= ly + pk_list_h()) return PZ_BLOCK;
  float cy = ry - ly + PK.scroll;
  if (PK.deck >= 0) {
    float th = PK_TH_W * 9 / 16 + 40;
    int col = (int)((rx - 20) / (PK_TH_W + PK_TH_GAP)), row = (int)(cy / th);
    if (rx < 20 || col >= pk_cols() || rx - 20 - col * (PK_TH_W + PK_TH_GAP) >= PK_TH_W) return PZ_BLOCK;
    int i = row * pk_cols() + col;
    int n = PK.it[2][PK.deck].nslides;
    return i < (n < 1 ? 1 : n) ? PZ_SLIDE + i : PZ_BLOCK;
  }
  int i = (int)(cy / PK_ROW);
  if (rx < 16 || rx >= PK_W - 16 || i < 0 || i >= (PK.files ? PK.nvis : PK.n[PK.tab])) return PZ_BLOCK;
  return PZ_ROW + i;
}

int office_picker_press(int z, int *kind, char *id, int idn, int *sub) {
  if (z == PZ_DIM || z == PZ_CLOSE) {
    PK.on = 0;
    return 0;
  }
  if (z == PZ_BACK) {
    PK.deck = -1;
    PK.scroll = 0;
    return 0;
  }
  if (z >= PZ_TAB && z < PZ_TAB + 3) {
    PK.tab = z - PZ_TAB;
    PK.scroll = 0;
    return 0;
  }
  if (PK.files && z >= PZ_LOC && z < PZ_LOC + 5) {
    PK.loc = z - PZ_LOC;
    PK.scroll = 0;
    imp_filter();
    return 0;
  }
  if (PK.files && z >= PZ_ROW && z < PZ_ROW + PK_MAX) {
    int i = z - PZ_ROW;
    if (i >= PK.nvis) return 0;
    snprintf(PK.chosen, sizeof PK.chosen, "%s", PK.fpath[PK.vis[i]]);
    PK.on = 0;
    return 2;
  }
  if (z >= PZ_ROW && z < PZ_ROW + PK_MAX) {
    int i = z - PZ_ROW;
    if (i >= PK.n[PK.tab]) return 0;
    if (PK.tab == 2 && PK.it[2][i].nslides > 1) {
      PK.deck = i;
      PK.scroll = 0;
      return 0;
    }
    *kind = PK.tab, *sub = 0;
    snprintf(id, (size_t)idn, "%s", PK.it[PK.tab][i].id);
    PK.on = 0;
    return 1;
  }
  if (z >= PZ_SLIDE && PK.deck >= 0) {
    *kind = 2, *sub = z - PZ_SLIDE;
    snprintf(id, (size_t)idn, "%s", PK.it[2][PK.deck].id);
    PK.on = 0;
    return 1;
  }
  return 0;
}

static void close_x(Surface *s, float cx, float cy, int hot) {
  if (hot) gfx_disc(s, cx, cy, 16, THEME(RGB(238, 238, 242), RGB(56, 58, 66)));
  gfx_line(s, cx - 5.5f, cy - 5.5f, cx + 5.5f, cy + 5.5f, 1.8f, C_TEXT);
  gfx_line(s, cx + 5.5f, cy - 5.5f, cx - 5.5f, cy + 5.5f, 1.8f, C_TEXT);
}

void office_picker_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  if (!PK.on) return;
  gfx_rect(s, ox, oy, w, h, RGBA(16, 16, 24, 110));
  float px, py;
  pk_rect(w, h, &px, &py);
  px += ox, py += oy;
  gfx_shadow(s, px, py + 10, PK_W, PK_H, 18, 36, RGBA(10, 10, 30, 90));
  gfx_rrect(s, px, py, PK_W, PK_H, 18, THEME(RGB(255, 255, 255), RGB(36, 38, 45)));
  int deck = PK.deck;
  float tx = px + 24;
  if (deck >= 0) {
    float bx = px + 32, by = py + 30;
    if (hot == PZ_BACK) gfx_disc(s, bx, by, 16, THEME(RGB(238, 238, 242), RGB(56, 58, 66)));
    gfx_line(s, bx + 3, by - 6, bx - 3, by, 2.f, C_TEXT);
    gfx_line(s, bx - 3, by, bx + 3, by + 6, 2.f, C_TEXT);
    tx = px + 58;
  }
  gfx_text(s, F_H1, tx, py + 30 - lh(F_H1) / 2, PK.files ? "Import a file" : deck >= 0 ? "Choose a slide" : "Insert from Office", C_TEXT);
  close_x(s, px + PK_W - 34, py + 30, hot == PZ_CLOSE);
  if (PK.files) {
    float cx = px + 24, cy = py + 64;
    for (int k = 0; k < 5; k++) {
      float cwid = chip_w(k);
      int on = PK.loc == k;
      uint32_t acc = office_acc(PK.tab);
      gfx_rrect(s, cx, cy + 2, cwid, 30, 15, on ? acc : hot == PZ_LOC + k ? THEME(RGB(232, 230, 236), RGB(60, 62, 72)) : THEME(RGB(242, 241, 238), RGB(48, 50, 58)));
      char lb[48];
      snprintf(lb, sizeof lb, "%s", LOC_NAMES[k]);
      gfx_text(s, F_SMALL, cx + 12, cy + 17 - lh(F_SMALL) / 2, lb, on ? RGB(255, 255, 255) : C_TEXT);
      char nb[12];
      snprintf(nb, sizeof nb, "%d", PK.cnt[k]);
      float nw = gfx_text_w(F_SMALL, nb);
      gfx_text(s, F_SMALL, cx + cwid - 12 - nw, cy + 17 - lh(F_SMALL) / 2, nb, on ? RGBA(255, 255, 255, 190) : C_MUTED);
      cx += cwid + 8;
    }
  } else if (deck < 0) {
    float sx = px + (PK_W - 330) / 2, sy = py + 64;
    gfx_rrect(s, sx, sy, 330, 36, 18, THEME(RGB(240, 239, 236), RGB(46, 48, 56)));
    gfx_rrect(s, sx + 3 + PK.tab * 110 - (PK.tab == 2 ? 3 : 0), sy + 3, 107, 30, 15, THEME(RGB(255, 255, 255), RGB(70, 72, 82)));
    for (int i = 0; i < 3; i++) {
      float cx = sx + 55 + i * 110, tw = gfx_text_w(F_UI_MED, KIND_SUB[i]);
      office_mark(s, cx - tw / 2 - 13, sy + 9, i == 2 ? 3 : i);
      gfx_text(s, F_UI_MED, cx - tw / 2 + 9, sy + 18 - lh(F_UI_MED) / 2, KIND_SUB[i],
               PK.tab == i ? office_acc(i) : hot == PZ_TAB + i ? C_TEXT : C_MUTED);
    }
  } else {
    gfx_text_fit(s, F_SMALL, tx, py + 30 + lh(F_H1) / 2 + 4, PK_W - 140, PK.it[2][deck].title, C_MUTED);
  }
  float ly = py + pk_list_y(), lhh = pk_list_h();
  gfx_rect(s, px + 16, ly - 6, PK_W - 32, 1, THEME(RGB(236, 234, 232), RGB(52, 54, 62)));
  int sv[4];
  office_clip_push(s, px, ly, PK_W, lhh, sv);
  if (deck >= 0) {
    int n = PK.it[2][deck].nslides;
    if (n < 1) n = 1;
    float thh = PK_TH_W * 9.f / 16.f;
    for (int i = 0; i < n; i++) {
      float x = px + 20 + (i % pk_cols()) * (PK_TH_W + PK_TH_GAP), y = ly + 4 + (i / pk_cols()) * (thh + 40) - PK.scroll;
      if (y > ly + lhh || y + thh + 40 < ly) continue;
      int hv = hot == PZ_SLIDE + i;
      if (hv) gfx_rrect(s, x - 3, y - 3, PK_TH_W + 6, thh + 6, 9, P_ACC);
      gfx_rrect(s, x - 1, y - 1, PK_TH_W + 2, thh + 2, 7, THEME(RGB(222, 222, 228), RGB(64, 66, 74)));
      office_embed_draw(s, 2, PK.it[2][deck].id, i, x, y, PK_TH_W, thh, 0);
      char b[24];
      snprintf(b, sizeof b, "Slide %d", i + 1);
      gfx_text_c(s, F_SMALL, x + PK_TH_W / 2, y + thh + 10, b, hv ? P_ACC : C_MUTED);
    }
  } else if (PK.files) {
    if (!PK.nvis) gfx_text_c(s, F_UI, px + PK_W / 2, ly + 80, "No compatible files here", C_MUTED);
    for (int vi = 0; vi < PK.nvis; vi++) {
      int i = PK.vis[vi];
      float y = ly + vi * PK_ROW - PK.scroll;
      if (y > ly + lhh || y + PK_ROW < ly) continue;
      int hv = hot == PZ_ROW + vi;
      if (hv) gfx_rrect(s, px + 12, y + 2, PK_W - 24, PK_ROW - 4, 12, THEME(RGB(245, 244, 250), RGB(48, 50, 60)));
      float ix = px + 28, iy = y + PK_ROW / 2;
      gfx_rrect(s, ix, iy - 17, 34, 34, 9, THEME(RGB(244, 243, 240), RGB(50, 52, 60)));
      office_mark(s, ix + 8, iy - 9, PK.tab == 2 ? 3 : PK.tab);
      gfx_text_fit(s, F_UI_MED, ix + 48, iy - lh(F_UI_MED) - 1, PK_W - 260, PK.fname[i], hv ? office_acc(PK.tab) : C_TEXT);
      char d[48], m[96];
      office_fmt_date(PK.fmt[i], d, sizeof d);
      long kb = (PK.fsz[i] + 1023) / 1024;
      char sz[24];
      if (kb >= 1024) snprintf(sz, sizeof sz, "%.1f MB", kb / 1024.0);
      else snprintf(sz, sizeof sz, "%ld KB", kb < 1 ? 1 : kb);
      snprintf(m, sizeof m, "%s  -  %s  -  %s", PK.fdir[i], d, sz);
      gfx_text(s, F_SMALL, ix + 48, iy + 3, m, C_MUTED);
      if (hv) {
        float aw = gfx_text_w(F_SMALL, "Import") + 28;
        gfx_rrect(s, px + PK_W - 28 - aw, iy - 15, aw, 30, 15, office_acc(PK.tab));
        gfx_text(s, F_SMALL, px + PK_W - 14 - aw, iy - lh(F_SMALL) / 2, "Import", RGB(255, 255, 255));
      }
    }
  } else if (!PK.n[PK.tab]) {
    char m[96];
    snprintf(m, sizeof m, "No %s yet", PK.tab == 0 ? "documents" : PK.tab == 1 ? "spreadsheets" : "presentations");
    gfx_text_c(s, F_UI, px + PK_W / 2, ly + 80, m, C_MUTED);
  } else {
    for (int i = 0; i < PK.n[PK.tab]; i++) {
      PickItem *it = &PK.it[PK.tab][i];
      float y = ly + i * PK_ROW - PK.scroll;
      if (y > ly + lhh || y + PK_ROW < ly) continue;
      int hv = hot == PZ_ROW + i;
      if (hv) gfx_rrect(s, px + 12, y + 2, PK_W - 24, PK_ROW - 4, 12, THEME(RGB(245, 244, 250), RGB(48, 50, 60)));
      float ix = px + 28, iy = y + PK_ROW / 2;
      gfx_rrect(s, ix, iy - 17, 34, 34, 9, THEME(RGB(244, 243, 240), RGB(50, 52, 60)));
      office_mark(s, ix + 8, iy - 9, PK.tab == 2 ? 3 : PK.tab);
      gfx_text_fit(s, F_UI_MED, ix + 48, iy - lh(F_UI_MED) - 1, PK_W - 260, it->title, hv ? office_acc(PK.tab) : C_TEXT);
      char d[48], m[96];
      office_fmt_date(it->mtime, d, sizeof d);
      if (PK.tab == 2) snprintf(m, sizeof m, "%s  -  %d slide%s", d, it->nslides, it->nslides == 1 ? "" : "s");
      else snprintf(m, sizeof m, "%s", d);
      gfx_text(s, F_SMALL, ix + 48, iy + 3, m, C_MUTED);
      const char *act = PK.tab == 2 && it->nslides > 1 ? "Choose slide" : "Insert";
      float aw = gfx_text_w(F_SMALL, act) + 28;
      if (hv) {
        gfx_rrect(s, px + PK_W - 28 - aw, iy - 15, aw, 30, 15, office_acc(PK.tab));
        gfx_text(s, F_SMALL, px + PK_W - 14 - aw, iy - lh(F_SMALL) / 2, act, RGB(255, 255, 255));
      }
    }
  }
  office_clip_pop(s, sv);
  float ch = pk_content_h();
  if (ch > lhh) {
    float th = lhh * lhh / ch, ty = ly + (lhh - th) * (PK.scroll / (ch - lhh));
    gfx_rrect(s, px + PK_W - 10, ty, 4, th, 2, THEME(RGBA(0, 0, 0, 60), RGBA(255, 255, 255, 60)));
  }
}
