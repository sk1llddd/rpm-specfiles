#include <dirent.h>
#include <linux/input.h>
#include <pwd.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/reboot.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "oreonvr.h"

#include "office.h"
#include "store.h"

int g_dark;
static int seq_counter;
static int dock_idx = -1;

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static int hot_of(Panel *p) { return (W.hover == (int)(p - P) && p->zone >= 100) ? p->zone - 100 : 0; }

static int in_rect(float x, float y, float rx, float ry, float rw, float rh) {
  return x >= rx && y >= ry && x < rx + rw && y < ry + rh;
}

static void button(Surface *s, float x, float y, float w, float h, const char *label, int hot, int primary) {
  uint32_t bg = primary ? (hot ? RGB(36, 92, 230) : C_ACCENT) : (hot ? THEME(RGB(226, 230, 236), RGB(70, 76, 88)) : THEME(RGB(236, 238, 242), RGB(54, 59, 68)));
  gfx_rrect(s, x, y, w, h, h * 0.5f, bg);
  gfx_text_c(s, F_UI_MED, x + w * 0.5f, y + (h - line_h(F_UI_MED)) * 0.5f, label, primary ? RGB(255, 255, 255) : C_TEXT);
}

static int alloc_panel(void) {
  for (int i = 0; i < MAXP; i++)
    if (!P[i].used) return i;
  return -1;
}

static int surfaces(Panel *p) {
  return surf_init(&p->surf, p->lw + 2 * MARGIN, p->lh + 2 * MARGIN, SCALE) &&
         (p->kind == PK_CHILD || surf_init(&p->base, p->lw + 2 * MARGIN, p->lh + 2 * MARGIN, SCALE));
}

int panel_create(PanelKind kind, int lw, int lh, const char *title, App *app) {
  int i = alloc_panel();
  if (i < 0) return -1;
  Panel *p = &P[i];
  memset(p, 0, sizeof *p);
  p->used = p->visible = 1;
  p->kind = kind;
  p->lw = lw, p->lh = lh;
  p->app = app;
  p->chrome_key = -1;
  p->dirty = 1;
  p->seq = ++seq_counter;
  p->parent = -1;
  snprintf(p->title, sizeof p->title, "%s", title);
  if (!surfaces(p)) {
    surf_free(&p->surf);
    surf_free(&p->base);
    p->used = 0;
    return -1;
  }
  return i;
}

void panel_resize(int i, int lw, int lh) {
  Panel *p = &P[i];
  surf_free(&p->surf);
  surf_free(&p->base);
  p->lw = lw, p->lh = lh;
  p->chrome_key = -1;
  p->dirty = 1;
  if (!surfaces(p)) p->visible = 0;
}

void panel_raise(int i) {
  if (i >= 0) P[i].seq = ++seq_counter;
}

void panel_close(int i) {
  Panel *p = &P[i];
  if (!p->used || p->kind == PK_DOCK) return;
  int was_kb = p->app == &keyboard_app;
  if (p->app && p->app->close) p->app->close(p);
  free(p->state);
  surf_free(&p->surf);
  surf_free(&p->base);
  memset(p, 0, sizeof *p);
  if (W.focus == i) W.focus = -1;
  if (W.hover == i) W.hover = -1;
  if (dock_idx >= 0) P[dock_idx].dirty = 1;
  if (was_kb && W.focus >= 0 && P[W.focus].used) P[W.focus].dirty = 1;
}

static int find_app_panel(App *a) {
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app == a && P[i].kind == PK_WINDOW) return i;
  return -1;
}


static float open_dist(int self, int lw, int lh) {

  float d = fmaxf(640.f, fmaxf(lw * 1.22f, (lh + 2.f * MARGIN) * 1.25f)), nearest = 1e9f;
  for (int i = 0; i < MAXP; i++) {
    Panel *p = &P[i];
    if (i == self || !p->used || !p->visible || p->kind != PK_WINDOW || widget_panel(p)) continue;
    float dx = p->x - W.gx, dy = p->y - W.gy, dz = p->z - W.gz;
    nearest = fminf(nearest, sqrtf(dx * dx + dy * dy + dz * dz));
  }
  if (d > nearest - 90.f) d = fmaxf(fminf(d, lw > 900 ? d : 520.f), nearest - 90.f);
  return d;
}

void panel_place_new(int i) {
  Panel *p = &P[i];
  int n = 0;
  for (int k = 0; k < MAXP; k++)
    if (P[k].used && P[k].kind == PK_WINDOW) n++;
  p->appear = 0.f;
  scene_place_in_view(p, open_dist(i, p->lw, p->lh), (float)((n % 3) - 1) * 40.f);
  if (p->lh > 450) {
    p->y += (p->lh - 450) * 0.4f;
    scene_face_head(p);
  }
  panel_raise(i);
}

int panel_open_app(const char *id) {
  App *a = app_by_id(id);
  if (!a) return -1;
  int i = find_app_panel(a);
  if (i >= 0) {

    scene_place_in_view(&P[i], open_dist(i, P[i].lw, P[i].lh), 0.f);
    panel_raise(i);
    if (a == &keyboard_app) keyboard_place(i);
  } else {
    i = panel_create(PK_WINDOW, a->w, a->h, a->name, a);
    if (i < 0) return -1;
    if (a->open) a->open(&P[i]);
    panel_place_new(i);
    if (a == &keyboard_app) keyboard_place(i);
  }
  if (a->key || a->rawkey) W.focus = i;
  if (dock_idx >= 0) P[dock_idx].dirty = 1;
  return i;
}

static int chrome_zone(Panel *p, float x, float y) {
  if (p->kind != PK_WINDOW || p->nobar) return 0;
  if (y < BAR_H && x >= p->lw - 44) return 1;
  return 0;
}

static int keyboard_up(void) {
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app == &keyboard_app) return 1;
  return 0;
}

static void draw_chrome(Panel *p, Surface *s, int close_hot, int target) {
  surf_clear(s, 0);
  const float M = MARGIN, w = (float)p->lw, h = (float)p->lh;
  if (!widget_panel(p)) gfx_shadow(s, M, M + 8, w, h, 10, 24, RGBA(28, 36, 48, 64));
  if (p->nobar) return;
  if (target) gfx_rrect(s, M - 3, M - 3, w + 6, h + 6, 13, C_ACCENT);
  gfx_rrect(s, M - 1, M - 1, w + 2, h + 2, 11, target ? C_ACCENT : C_WIN_EDGE);
  gfx_rrect(s, M, M, w, h, 10, C_WIN);
  gfx_rrect_band(s, M, M, w, h, 10, M, M + BAR_H, C_BAR);
  gfx_rect(s, M, M + BAR_H - 1, w, 1, C_BAR_LINE);
  gfx_text_fit(s, F_UI_MED, M + 14, M + (BAR_H - line_h(F_UI_MED)) * 0.5f, w - 80, p->title, C_TITLE);
  float cx = M + w - 24, cy = M + BAR_H * 0.5f;
  uint32_t xc = C_CLOSE;
  if (close_hot) {
    gfx_rrect(s, M + w - 42, M + 5, 36, BAR_H - 10, 7, C_CLOSE_HOT);
    xc = RGB(255, 255, 255);
  }
  gfx_line(s, cx - 5, cy - 5, cx + 5, cy + 5, 1.8f, xc);
  gfx_line(s, cx + 5, cy - 5, cx - 5, cy + 5, 1.8f, xc);
}

static void draw_dock(Panel *p, Surface *s);

void panel_redraw(Panel *p) {
  if (p->kind == PK_CHILD) {
    surf_clear(&p->surf, 0);
    gfx_shadow(&p->surf, MARGIN, MARGIN + 4, (float)p->lw, (float)p->lh, 8, 16, RGBA(16, 20, 28, 50));
    if (p->app && p->app->draw) p->app->draw(p, &p->surf, MARGIN, MARGIN);
    p->dirty = 0;
    return;
  }
  if (p->kind == PK_DOCK) {
    draw_dock(p, &p->surf);
    p->dirty = 0;
    return;
  }
  int idx = (int)(p - P);
  int target = W.focus == idx && keyboard_up();
  int key = ((W.hover == idx && p->zone == 1) ? 1 : 0) | (target ? 2 : 0);
  if (key != p->chrome_key) {
    draw_chrome(p, &p->base, key & 1, target);
    p->chrome_key = key;
  }
  memcpy(p->surf.px, p->base.px, (size_t)p->surf.w * p->surf.h * 4);
  if (p->app && p->app->draw) {
    gfx_clip(&p->surf, MARGIN, MARGIN + BARH(p), (float)p->lw, (float)(p->lh - BARH(p)));
    p->app->draw(p, &p->surf, MARGIN, MARGIN + BARH(p));
    gfx_noclip(&p->surf);
  }
  p->dirty = 0;
}

static void launcher_changed(void);

#define D_PAD 28
#define D_ICON 32
#define D_GAP 18
#define D_H 58
#define D_MAX 16
#define S_GAP 8
#define S_PAD_L 18
#define S_PAD_R 24
#define S_WIFI_W 22
#define S_BAT_W 58
#define S_CLOCK_W 40
#define S_POWER_W 22

typedef struct {
  App *app;
  GApp *g;
} DockItem;

static DockItem ditems[D_MAX];
static int ndock;

typedef struct {
  int has_wifi, wifi_up, wifi_bars;
  int has_bat, bat_pct, bat_charging;
} Status;

typedef struct {
  float sep, wifi, bat, clock, power, end;
} StatusX;

static Status status;

static const char *sys_root(void) {
  const char *r = getenv("OREONVR_ROOT");
  return r ? r : "";
}

static int read_text(const char *rel, char *buf, int n) {
  char path[512];
  snprintf(path, sizeof path, "%s%s", sys_root(), rel);
  FILE *f = fopen(path, "r");
  if (!f) return 0;
  int r = (int)fread(buf, 1, (size_t)n - 1, f);
  fclose(f);
  buf[r < 0 ? 0 : r] = 0;
  return r > 0;
}

static int tray_wifi = 1, tray_bat = 1, tray_clock = 1, tray_power = 1;

static void status_poll(void) {
  Status st = {0};
  char path[512], buf[128];
  snprintf(path, sizeof path, "%s/sys/class/power_supply", sys_root());
  DIR *d = opendir(path);
  struct dirent *e;
  while (d && (e = readdir(d))) {
    if (e->d_name[0] == '.') continue;
    snprintf(path, sizeof path, "/sys/class/power_supply/%s/type", e->d_name);
    if (!read_text(path, buf, sizeof buf) || strncmp(buf, "Battery", 7)) continue;
    snprintf(path, sizeof path, "/sys/class/power_supply/%s/scope", e->d_name);
    if (read_text(path, buf, sizeof buf) && !strncmp(buf, "Device", 6)) continue;
    snprintf(path, sizeof path, "/sys/class/power_supply/%s/capacity", e->d_name);
    if (!read_text(path, buf, sizeof buf)) continue;
    st.has_bat = 1;
    st.bat_pct = atoi(buf);
    if (st.bat_pct < 0) st.bat_pct = 0;
    if (st.bat_pct > 100) st.bat_pct = 100;
    snprintf(path, sizeof path, "/sys/class/power_supply/%s/status", e->d_name);
    st.bat_charging = read_text(path, buf, sizeof buf) && !strncmp(buf, "Charging", 8);
    break;
  }
  if (d) closedir(d);
  snprintf(path, sizeof path, "%s/sys/class/net", sys_root());
  d = opendir(path);
  char iface[64] = "";
  while (d && (e = readdir(d))) {
    if (e->d_name[0] == '.') continue;
    struct stat sb;
    snprintf(path, sizeof path, "%s/sys/class/net/%s/wireless", sys_root(), e->d_name);
    if (stat(path, &sb) || !S_ISDIR(sb.st_mode)) continue;
    st.has_wifi = 1;
    snprintf(iface, sizeof iface, "%.63s", e->d_name);
    snprintf(path, sizeof path, "/sys/class/net/%s/operstate", e->d_name);
    st.wifi_up = read_text(path, buf, sizeof buf) && !strncmp(buf, "up", 2);
    break;
  }
  if (d) closedir(d);
  if (st.has_wifi && st.wifi_up) {
    st.wifi_bars = 1;
    char line[256];
    snprintf(path, sizeof path, "%s/proc/net/wireless", sys_root());
    FILE *f = fopen(path, "r");
    while (f && fgets(line, sizeof line, f)) {
      char name[64];
      float q, lvl;
      if (sscanf(line, " %63[^:]: %*x %f %f", name, &q, &lvl) != 3 || strcmp(name, iface)) continue;
      if (q > 0) st.wifi_bars = (int)(q / 70.f * 4.f + 0.999f);
      else if (lvl < 0) st.wifi_bars = lvl >= -55 ? 4 : lvl >= -65 ? 3 : lvl >= -75 ? 2 : 1;
      if (st.wifi_bars > 4) st.wifi_bars = 4;
      if (st.wifi_bars < 1) st.wifi_bars = 1;
    }
    if (f) fclose(f);
  }
  status = st;
}

static void status_layout(StatusX *o) {
  float x = D_PAD + ndock * (D_ICON + D_GAP) - D_GAP * 0.5f;
  o->sep = x;
  o->wifi = o->bat = o->clock = o->power = -1;
  int n = (status.has_wifi && tray_wifi) + (status.has_bat && tray_bat) + tray_clock + tray_power;
  if (!n) {
    o->end = D_PAD * 2 + ndock * D_ICON + (ndock - 1) * D_GAP;
    return;
  }
  x += S_PAD_L;
  if (status.has_wifi && tray_wifi) o->wifi = x, x += S_WIFI_W + S_GAP;
  if (status.has_bat && tray_bat) o->bat = x, x += S_BAT_W + S_GAP;
  if (tray_clock) o->clock = x, x += S_CLOCK_W + S_GAP;
  if (tray_power) o->power = x, x += S_POWER_W + S_GAP;
  o->end = x - S_GAP + S_PAD_R;
}

static int dock_width(void) {
  StatusX o;
  status_layout(&o);
  return (int)o.end;
}

static void dock_rebuild(void) {
  App *builtin[] = {app_by_id("apps"), &desktop_app, app_by_id("terminal"), app_by_id("files"), &keyboard_app};
  ndock = 0;
  for (unsigned i = 0; i < sizeof builtin / sizeof *builtin; i++)
    if (builtin[i]) ditems[ndock++] = (DockItem){builtin[i], NULL};
  if (dock_idx >= 0) {
    if (P[dock_idx].lw != dock_width()) panel_resize(dock_idx, dock_width(), D_H);
    P[dock_idx].dirty = 1;
  }
}

static int dock_slot(float x, float y) {
  (void)y;
  float in = x - D_PAD + D_GAP * 0.5f;
  if (in < 0) return -1;
  int i = (int)(in / (D_ICON + D_GAP));
  return i < ndock ? i : -1;
}

static int power_hit(float x) {
  StatusX o;
  status_layout(&o);
  return o.power >= 0 && x >= o.power - 7 && x < o.power + S_POWER_W + 7;
}

static int dock_zone(Panel *p, float x, float y) {
  (void)p;
  if (power_hit(x)) return ndock + 1;
  return dock_slot(x, y) + 1;
}

static void gapp_icon(Surface *s, GApp *g, float x, float y, float size) {
  if (g->icon) {
    gfx_blit_premul(s, g->icon, g->iw, g->ih, x, y, size, size);
    return;
  }
  gfx_rrect(s, x + size * 0.06f, y + size * 0.06f, size * 0.88f, size * 0.88f, size * 0.24f, RGB(98, 110, 130));
  char c[2] = {g->name[0] ? g->name[0] : '?', 0};
  const Font *f = size > 40 ? F_H1 : F_UI_MED;
  gfx_text_c(s, f, x + size * 0.5f, y + (size - line_h(f)) * 0.5f, c, RGB(255, 255, 255));
}

static void draw_wifi(Surface *s, float x, float cy, int bars, int up) {
  uint32_t ink = THEME(RGB(58, 63, 70), RGB(210, 215, 222));
  uint32_t faint = THEME(RGBA(58, 63, 70, 70), RGBA(210, 215, 222, 80));
  for (int i = 0; i < 4; i++) {
    float h = 5.f + i * 3.f;
    gfx_rrect(s, x + i * 5.5f, cy + 7 - h, 3.6f, h, 1.2f, up && i < bars ? ink : faint);
  }
  if (!up) gfx_line(s, x - 1, cy + 8, x + 21, cy - 8, 1.8f, RGB(229, 72, 77));
}

static void draw_battery(Surface *s, float x, float cy, int pct, int charging) {
  uint32_t ink = THEME(RGB(58, 63, 70), RGB(210, 215, 222));
  uint32_t bg = THEME(RGB(255, 255, 255), RGB(34, 38, 45));
  uint32_t fill = pct <= 20 ? RGB(229, 72, 77) : RGB(48, 164, 108);
  gfx_rrect(s, x, cy - 6.5f, 24, 13, 3.4f, ink);
  gfx_rrect(s, x + 1.6f, cy - 4.9f, 20.8f, 9.8f, 2.2f, bg);
  gfx_rrect(s, x + 24.6f, cy - 2.6f, 2.4f, 5.2f, 1.2f, ink);
  float fw = 17.6f * (float)pct / 100.f;
  if (fw > 0.5f) gfx_rrect(s, x + 3.2f, cy - 3.3f, fw < 2.6f ? 2.6f : fw, 6.6f, 1.4f, fill);
  if (charging) {
    gfx_line(s, x + 13, cy - 4.4f, x + 9.5f, cy + 0.6f, 1.6f, RGB(255, 255, 255));
    gfx_line(s, x + 9.5f, cy + 0.6f, x + 14.5f, cy + 0.2f, 1.6f, RGB(255, 255, 255));
    gfx_line(s, x + 14.5f, cy + 0.2f, x + 11, cy + 4.8f, 1.6f, RGB(255, 255, 255));
  }
  char t[8];
  snprintf(t, sizeof t, "%d%%", pct);
  gfx_text(s, F_SMALL, x + 32, cy - line_h(F_SMALL) * 0.5f, t, C_TITLE);
}

static void draw_power(Surface *s, float cx, float cy, int hot) {
  uint32_t ink = THEME(RGB(58, 63, 70), RGB(210, 215, 222));
  uint32_t bg = THEME(RGB(255, 255, 255), RGB(34, 38, 45));
  if (hot) gfx_disc(s, cx, cy, 15, C_HOVER);
  gfx_ring(s, cx, cy + 0.5f, 7.6f, 2.2f, ink);
  gfx_rect(s, cx - 3.2f, cy - 10, 6.4f, 8.4f, hot ? C_HOVER : bg);
  gfx_line(s, cx, cy - 8.6f, cx, cy - 0.4f, 2.4f, ink);
}

static void draw_dock(Panel *p, Surface *s) {
  surf_clear(s, 0);
  const float M = MARGIN, w = (float)p->lw, h = (float)p->lh;
  gfx_shadow(s, M, M + 6, w, h, h * 0.5f, 22, RGBA(16, 24, 40, 50));
  gfx_rrect(s, M, M, w, h, h * 0.5f, THEME(RGBA(255, 255, 255, 236), RGBA(34, 38, 45, 236)));
  int hot = hot_of(p) - 1;
  for (int i = 0; i < ndock; i++) {
    float ix = M + D_PAD + i * (D_ICON + D_GAP), iy = M + (h - D_ICON) * 0.5f;
    if (hot == i) gfx_disc(s, ix + D_ICON * 0.5f, iy + D_ICON * 0.5f, 22, C_HOVER);
    DockItem *d = &ditems[i];
    int open;
    if (d->app) {
      gfx_icon(s, d->app->icon, ix + 2, iy + 2, 28);
      open = find_app_panel(d->app) >= 0;
    } else {
      gapp_icon(s, d->g, ix + 2, iy + 2, 28);
      open = gnome_app_running(d->g->id);
    }
    if (open) gfx_disc(s, ix + D_ICON * 0.5f, iy + D_ICON + 6, 2.2f, RGB(120, 128, 140));
  }
  StatusX o;
  status_layout(&o);
  float cy = M + h * 0.5f;
  if (o.wifi >= 0 || o.bat >= 0 || o.clock >= 0 || o.power >= 0)
    gfx_rect(s, M + o.sep, M + 16, 1, h - 32, THEME(RGB(224, 228, 234), RGB(70, 76, 86)));
  if (o.wifi >= 0) draw_wifi(s, M + o.wifi, cy, status.wifi_bars, status.wifi_up);
  if (o.bat >= 0) draw_battery(s, M + o.bat, cy, status.bat_pct, status.bat_charging);
  if (o.clock >= 0) {
    char buf[16];
    time_t t = time(NULL);
    strftime(buf, sizeof buf, "%H:%M", localtime(&t));
    gfx_text_c(s, F_UI_MED, M + o.clock + S_CLOCK_W * 0.5f, M + (h - line_h(F_UI_MED)) * 0.5f, buf, C_TITLE);
  }
  if (o.power >= 0) draw_power(s, M + o.power + S_POWER_W * 0.5f, cy, hot == ndock);
}

static void dock_click(Panel *p, float x, float y) {
  (void)p;
  if (power_hit(x)) {
    panel_open_app("power");
    return;
  }
  int i = dock_slot(x, y);
  if (i < 0) return;
  if (ditems[i].app) panel_open_app(ditems[i].app->id);
  else gnome_launch(ditems[i].g->id);
}

static int dock_tick(Panel *p, uint32_t now) {
  (void)p;
  if (gnome_apps_changed) {
    gnome_apps_changed = 0;
    dock_rebuild();
    launcher_changed();
  }
  static uint32_t last, last_status;
  int changed = 0;
  if (!last_status || now - last_status >= 5000) {
    Status before = status;
    last_status = now ? now : 1;
    status_poll();
    if (memcmp(&before, &status, sizeof status)) {
      dock_rebuild();
      changed = 1;
    }
  }
  if (now - last < 1000) return changed;
  last = now;
  static int lastmin = -1;
  time_t t = time(NULL);
  int m = localtime(&t)->tm_min;
  if (m == lastmin) return changed;
  lastmin = m;
  return 1;
}

static App dock_app = {"dock", "Dock", IC_APPS, 0, 0, NULL, NULL, dock_click, NULL, NULL, dock_zone, dock_tick, NULL};

static float dock_yaw, dock_pitch;

void dock_init(void) {
  status_poll();
  dock_rebuild();
  dock_idx = panel_create(PK_DOCK, dock_width(), D_H, "Dock", &dock_app);
  P[dock_idx].appear = 1.f;
  dock_follow(0.f, 1);
}

void dock_follow(float dt, int snap) {
  if (dock_idx < 0) return;
  float ty = W.gyaw, tp = W.gpitch - 0.34f;
  float dy = ty - dock_yaw;
  while (dy > PI_F) dy -= 2 * PI_F;
  while (dy < -PI_F) dy += 2 * PI_F;
  static int chasing;
  if (fabsf(dy) > 0.42f) chasing = 1;
  if (fabsf(dy) < 0.02f) chasing = 0;
  if (snap) {
    dock_yaw = ty, dock_pitch = tp;
  } else {
    float k = 1.f - expf(-dt * 5.f);
    if (chasing) dock_yaw += dy * k;
    dock_pitch += (tp - dock_pitch) * k;
  }
  float f[3], r[3], u[3];
  scene_basis(dock_yaw, dock_pitch, f, r, u);
  Panel *p = &P[dock_idx];
  const float dist = 780.f;
  p->x = W.cx + f[0] * dist, p->y = W.cy + f[1] * dist, p->z = W.cz + f[2] * dist;
  p->yaw = dock_yaw, p->tilt = dock_pitch;
}

#define L_COLS 6
#define L_ROWS 4
#define L_TW 100
#define L_TH 106
#define L_HDR 34
#define L_NATIVE 10

static int lrow;

static GApp *qt_nth(int k) { return gnome_app(k); }

static int qt_total(void) { return gnome_app_count(); }

static int native_rows(void) { return (L_NATIVE + L_COLS - 1) / L_COLS; }

static int launch_rows(void) {
  int q = qt_total();
  return native_rows() + (q ? 1 + (q + L_COLS - 1) / L_COLS : 0);
}

static void row_info(int r, int *kind, int *first) {
  int nr = native_rows();
  if (r < nr) *kind = 0, *first = r * L_COLS;
  else if (r == nr) *kind = 1, *first = 0;
  else *kind = 2, *first = (r - nr - 1) * L_COLS;
}

static float row_h(int kind) { return kind == 1 ? (float)L_HDR : (float)L_TH; }

static void launch_item(int i, App **a, GApp **g) {
  static const char *builtin[] = {"desktop", "terminal", "files", "surf", "office", "store", "install", "tasks", "keyboard", "settings"};
  *a = NULL, *g = NULL;
  if (i < L_NATIVE) *a = app_by_id(builtin[i]);
  else *g = qt_nth(i - L_NATIVE);
}

static int launch_slot(float x, float y) {
  float gx = x - 24, gy = y - 12, top = 0;
  if (gx < 0 || gy < 0) return -1;
  int c = (int)(gx / L_TW), rows = launch_rows();
  if (c >= L_COLS) return -1;
  for (int r = lrow; r < rows && top < L_ROWS * L_TH; r++) {
    int kind, first;
    row_info(r, &kind, &first);
    float h = row_h(kind);
    if (gy < top + h) {
      if (kind == 1) return -1;
      int k = first + c;
      if (kind == 0) return k < L_NATIVE ? k : -1;
      return k < qt_total() ? L_NATIVE + k : -1;
    }
    top += h;
  }
  return -1;
}

static const char *const home_builtin[] = {"surf", "files", "office", "terminal", "store", "tasks"};

int home_app_count(void) {
  int n = qt_total() + 6;
  return n > 6 ? 6 : n;
}

static void home_app(int i, App **a, GApp **g) {
  int q = qt_total();
  *a = NULL, *g = NULL;
  if (i < q) *g = qt_nth(i);
  else {
    int k = i - q, n = 0;
    for (int j = 0; j < 6; j++) {
      App *x = app_by_id(home_builtin[j]);
      if (x && n++ == k) {
        *a = x;
        return;
      }
    }
  }
}

const char *home_app_name(int i) {
  App *a;
  GApp *g;
  home_app(i, &a, &g);
  return a ? a->name : g ? g->name : "";
}

void home_app_icon(int i, Surface *s, float x, float y, float size) {
  App *a;
  GApp *g;
  home_app(i, &a, &g);
  if (a) gfx_icon(s, a->icon, x, y, size);
  else if (g) gapp_icon(s, g, x, y, size);
}

void home_app_launch(int i) {
  App *a;
  GApp *g;
  home_app(i, &a, &g);
  if (a) panel_open_app(a->id);
  else if (g && !(g->path[0] && wl_launch(g->path))) gnome_launch(g->id);
}

static void launcher_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = hot_of(p) - 1;
  int rows = launch_rows();
  float top = 0;
  for (int r = lrow; r < rows && top < L_ROWS * L_TH; r++) {
    int kind, first;
    row_info(r, &kind, &first);
    float y = oy + 12 + top;
    if (kind == 1) {
      gfx_text(s, F_UI_MED, ox + 28, y + 6, "Linux Apps", C_MUTED);
      gfx_rect(s, ox + 24 + gfx_text_w(F_UI_MED, "Linux Apps") + 16, y + 6 + line_h(F_UI_MED) * 0.5f, L_COLS * L_TW - gfx_text_w(F_UI_MED, "Linux Apps") - 20, 1, C_BAR_LINE);
    } else {
      for (int c = 0; c < L_COLS; c++) {
        int i = kind == 0 ? first + c : L_NATIVE + first + c;
        if (kind == 0 ? first + c >= L_NATIVE : first + c >= qt_total()) break;
        App *a;
        GApp *g;
        launch_item(i, &a, &g);
        float x = ox + 24 + c * L_TW;
        if (hot == i) gfx_rrect(s, x + 2, y, L_TW - 4, L_TH - 4, 14, C_HOVER);
        const char *name = a ? a->name : g->name;
        if (a) gfx_icon(s, a->icon, x + 26, y + 12, 48);
        else gapp_icon(s, g, x + 26, y + 12, 48);
        if (gfx_text_w(F_SMALL, name) <= L_TW - 10) gfx_text_c(s, F_SMALL, x + L_TW * 0.5f, y + 70, name, C_TEXT);
        else gfx_text_fit(s, F_SMALL, x + 5, y + 70, L_TW - 10, name, C_TEXT);
      }
    }
    top += row_h(kind);
  }
  if (rows > L_ROWS) {
    float th = L_ROWS * L_TH - 8.f, bh = th * L_ROWS / rows, by = th * lrow / rows;
    gfx_rrect(s, ox + p->lw - 10, oy + 14 + by, 3, bh, 1.5f, RGB(200, 205, 212));
  }
}

static void launcher_click(Panel *p, float x, float y) {
  int i = launch_slot(x, y);
  if (i < 0) return;
  App *a;
  GApp *g;
  launch_item(i, &a, &g);
  panel_close((int)(p - P));
  if (a) panel_open_app(a->id);
  else if (g && !(g->path[0] && wl_launch(g->path))) gnome_launch(g->id);
}

static void launcher_scroll(Panel *p, float x, float y, int steps) {
  (void)x, (void)y;
  int rows = launch_rows();
  lrow -= steps;
  if (lrow > rows - L_ROWS) lrow = rows - L_ROWS;
  if (lrow < 0) lrow = 0;
  p->dirty = 1;
}

static int launcher_zone(Panel *p, float x, float y) {
  (void)p;
  return launch_slot(x, y) + 1;
}

static void launcher_open(Panel *p) {
  (void)p;
  lrow = 0;
}

static App launcher = {"apps", "Apps", IC_APPS, 24 * 2 + L_COLS * L_TW, 12 + L_ROWS * L_TH + 8 + BAR_H, launcher_open,
                       launcher_draw, launcher_click, launcher_scroll, NULL, launcher_zone, NULL, NULL};

static void launcher_changed(void) {
  int i = find_app_panel(&launcher);
  if (i >= 0) P[i].dirty = 1;
}

typedef struct {
  Term *t;
  int cols, rows;
  float cw, ch;
  int blink;
  uint32_t last_blink;
} TermState;

static void term_open(Panel *p) {
  TermState *st = calloc(1, sizeof *st);
  p->state = st;
  st->cw = (float)F_MONO->glyphs['M' - 32].adv16 / 16.f / SCALE;
  st->ch = line_h(F_MONO) + 1.f;
  st->cols = (int)((p->lw - 24) / st->cw);
  st->rows = (int)((p->lh - BAR_H - 16) / st->ch);
  st->t = term_new(st->cols, st->rows);
}

static void term_close(Panel *p) {
  TermState *st = p->state;
  if (st && st->t) term_free(st->t);
}

static void term_app_draw(Panel *p, Surface *s, float ox, float oy) {
  TermState *st = p->state;
  gfx_rrect_band(s, ox, oy - BAR_H, (float)p->lw, (float)p->lh, 10, oy, oy + p->lh, C_TERM_BG);
  if (!st->t) {
    gfx_text(s, F_UI, ox + 14, oy + 14, "Could not start a shell.", C_TERM_FG);
    return;
  }
  int focused = W.focus == (int)(p - P);
  term_draw(st->t, s, ox + 12, oy + 8, st->cw, st->ch, focused && !st->blink);
}

static int term_app_tick(Panel *p, uint32_t now) {
  TermState *st = p->state;
  if (!st->t) return 0;
  int ch = term_poll(st->t);
  if (!term_alive(st->t)) {

    panel_close((int)(p - P));
    return 0;
  }
  if (ch) {
    st->blink = 0;
    st->last_blink = now;
  }
  if (W.focus == (int)(p - P) && now - st->last_blink > 530) {
    st->blink ^= 1;
    st->last_blink = now;
    ch = 1;
  }
  return ch;
}

static void term_app_key(Panel *p, int code, int mods) {
  TermState *st = p->state;
  char b[16];
  int n = key_to_bytes(code, mods, b);
  if (n > 0 && st->t) {
    term_scroll(st->t, -100000);
    term_write(st->t, b, n);
  }
}

static void term_app_scroll(Panel *p, float x, float y, int steps) {
  (void)x, (void)y;
  TermState *st = p->state;
  if (st->t) term_scroll(st->t, steps * 3);
  p->dirty = 1;
}

static App terminal = {"terminal", "Terminal", IC_TERM, 760, 470, term_open, term_app_draw, NULL, term_app_scroll,
                       term_app_key, NULL, term_app_tick, term_close};

typedef struct {
  char name[128];
  int dir;
  long long size;
  time_t mtime;
} Entry;

#define FHIST 24
#define F_SIDE 184
#define F_TB 56
#define F_HDR 30
#define F_ST 28
#define F_ROW 36
#define F_CELL_W 124
#define F_CELL_H 112
#define F_ACC THEME(RGB(14, 116, 224), RGB(88, 166, 255))
#define F_TINT THEME(RGB(222, 236, 252), RGB(40, 62, 98))

enum { FZ_BACK = 1, FZ_FWD, FZ_UP, FZ_VIEW, FZ_HIDDEN, FZ_SEARCH, FZ_CLEAR, FZ_PLACE = 10, FZ_SORT = 24, FZ_CRUMB = 30, FZ_ITEM = 100 };

typedef struct {
  char cwd[1024];
  char back[FHIST][1024], fwd[FHIST][1024];
  int nback, nfwd;
  Entry *e;
  int n, *vis, nvis;
  float top;
  int sel, grid, hidden, sort, asc, focus;
  char q[64];
  uint32_t click_at;
  int click_idx;
  char place_path[8][512];
  const char *place_name[8];
  int place_icon[8], nplace;
  char crumb_path[8][1024];
  float crumb_x[8], crumb_w[8];
  int ncrumb;
  int pick; /* opened from Settings to choose a wallpaper */
} FilesState;

static int f_sort;
static int f_asc;

static int entry_cmp(const void *a, const void *b) {
  const Entry *x = a, *y = b;
  if (x->dir != y->dir) return y->dir - x->dir;
  int r;
  if (f_sort == 1) r = x->size < y->size ? -1 : x->size > y->size;
  else if (f_sort == 2) r = x->mtime < y->mtime ? -1 : x->mtime > y->mtime;
  else r = strcasecmp(x->name, y->name);
  if (!r) r = strcasecmp(x->name, y->name);
  return f_asc ? r : -r;
}

static void files_filter(FilesState *st) {
  free(st->vis);
  st->vis = malloc(sizeof(int) * (size_t)(st->n + 1));
  st->nvis = 0;
  for (int i = 0; i < st->n; i++) {
    if (st->q[0] && !strcasestr(st->e[i].name, st->q)) continue;
    st->vis[st->nvis++] = i;
  }
  st->sel = -1;
  st->top = 0;
}

static void files_sort(FilesState *st) {
  f_sort = st->sort, f_asc = st->asc;
  char keep[128] = "";
  if (st->sel >= 0 && st->sel < st->nvis) snprintf(keep, sizeof keep, "%s", st->e[st->vis[st->sel]].name);
  qsort(st->e, (size_t)st->n, sizeof(Entry), entry_cmp);
  files_filter(st);
  if (keep[0])
    for (int i = 0; i < st->nvis; i++)
      if (!strcmp(st->e[st->vis[i]].name, keep)) st->sel = i;
}

static void files_load(FilesState *st) {
  free(st->e);
  st->e = NULL, st->n = 0;
  DIR *d = opendir(st->cwd);
  if (d) {
    int cap = 64;
    st->e = malloc(sizeof(Entry) * (size_t)cap);
    struct dirent *de;
    while ((de = readdir(d))) {
      if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
      if (de->d_name[0] == '.' && !st->hidden) continue;
      if (st->n == cap) {
        cap *= 2;
        st->e = realloc(st->e, sizeof(Entry) * (size_t)cap);
      }
      Entry *e = &st->e[st->n++];
      snprintf(e->name, sizeof e->name, "%.127s", de->d_name);
      char path[1280];
      snprintf(path, sizeof path, "%s/%s", strcmp(st->cwd, "/") ? st->cwd : "", de->d_name);
      struct stat sb;
      int ok = stat(path, &sb) == 0;
      e->dir = ok && S_ISDIR(sb.st_mode);
      e->size = ok && !e->dir ? (long long)sb.st_size : 0;
      e->mtime = ok ? sb.st_mtime : 0;
    }
    closedir(d);
  }
  files_sort(st);
}

const char *user_home(void) {
  const char *u = getenv("OREONVR_USER");
  struct passwd *pw = u && *u ? getpwnam(u) : NULL;
  if (pw && pw->pw_dir && *pw->pw_dir) return pw->pw_dir;
  const char *home = getenv("HOME");
  return home && *home ? home : "/";
}

static void files_go(FilesState *st, const char *path, int record) {
  if (!strcmp(path, st->cwd)) return;
  if (record) {
    if (st->nback == FHIST) {
      memmove(st->back[0], st->back[1], sizeof st->back[0] * (FHIST - 1));
      st->nback--;
    }
    snprintf(st->back[st->nback++], sizeof st->back[0], "%s", st->cwd);
    st->nfwd = 0;
  }
  snprintf(st->cwd, sizeof st->cwd, "%s", path);
  st->q[0] = 0;
  files_load(st);
}

static void files_up(FilesState *st) {
  char up[1024];
  snprintf(up, sizeof up, "%s", st->cwd);
  char *sl = strrchr(up, '/');
  if (sl && sl != up) *sl = 0;
  else snprintf(up, sizeof up, "/");
  files_go(st, up, 1);
}

static void files_back(FilesState *st) {
  if (!st->nback) return;
  if (st->nfwd < FHIST) snprintf(st->fwd[st->nfwd++], sizeof st->fwd[0], "%s", st->cwd);
  char path[1024];
  snprintf(path, sizeof path, "%s", st->back[--st->nback]);
  files_go(st, path, 0);
}

static void files_forward(FilesState *st) {
  if (!st->nfwd) return;
  if (st->nback < FHIST) snprintf(st->back[st->nback++], sizeof st->back[0], "%s", st->cwd);
  char path[1024];
  snprintf(path, sizeof path, "%s", st->fwd[--st->nfwd]);
  files_go(st, path, 0);
}

static int bg_is_image(const char *name);
static void bg_import(const char *path);

static void files_open_entry(FilesState *st, int vi) {
  if (vi < 0 || vi >= st->nvis) return;
  Entry *e = &st->e[st->vis[vi]];
  char path[1280];
  snprintf(path, sizeof path, "%s%s%s", st->cwd, strcmp(st->cwd, "/") ? "/" : "", e->name);
  if (e->dir) files_go(st, path, 1);
  else if (st->pick) {
    if (!bg_is_image(e->name)) return;
    bg_import(path);
    for (int i = 0; i < MAXP; i++)
      if (P[i].used && P[i].state == st) {
        panel_close(i);
        break;
      }
  } else {
    char *av[] = {"xdg-open", path, NULL};
    wl_spawn(av);
  }
}

static void files_add_place(FilesState *st, const char *name, int icon, const char *path) {
  if (st->nplace >= 8) return;
  struct stat sb;
  if (stat(path, &sb) || !S_ISDIR(sb.st_mode)) return;
  snprintf(st->place_path[st->nplace], sizeof st->place_path[0], "%s", path);
  st->place_name[st->nplace] = name;
  st->place_icon[st->nplace++] = icon;
}

static void files_open(Panel *p) {
  FilesState *st = calloc(1, sizeof *st);
  p->state = st;
  st->asc = 1;
  st->sel = -1;
  st->click_idx = -1;
  const char *h = user_home();
  char b[600];
  files_add_place(st, "Home", IC_FOLDER, h);
  static const char *const sub[] = {"Desktop", "Documents", "Downloads", "Pictures", "Music", "Videos"};
  for (int i = 0; i < 6; i++) {
    snprintf(b, sizeof b, "%s/%s", h, sub[i]);
    files_add_place(st, sub[i], IC_FOLDER, b);
  }
  if (st->nplace < 8) files_add_place(st, "Computer", IC_DESKTOP, "/");
  snprintf(st->cwd, sizeof st->cwd, "%s", h);
  files_load(st);
}

void files_open_path(const char *path) {
  int i = panel_open_app("files");
  if (i < 0 || !P[i].state) return;
  files_go(P[i].state, path, 1);
  P[i].dirty = 1;
}

static void files_pick_wallpaper(void) {
  int i = panel_open_app("files");
  if (i < 0 || !P[i].state) return;
  FilesState *st = P[i].state;
  char pics[600];
  snprintf(pics, sizeof pics, "%s/Pictures", user_home());
  struct stat sb;
  st->pick = 1;
  files_go(st, !stat(pics, &sb) && S_ISDIR(sb.st_mode) ? pics : user_home(), 1);
  P[i].dirty = 1;
}

static void files_close(Panel *p) {
  FilesState *st = p->state;
  free(st->e);
  free(st->vis);
}

static void human(long long n, char *b, int sz) {
  const char *u[] = {"B", "KB", "MB", "GB", "TB"};
  double v = (double)n;
  int i = 0;
  while (v >= 1024 && i < 4) v /= 1024, i++;
  snprintf(b, (size_t)sz, i ? "%.1f %s" : "%.0f %s", v, u[i]);
}

static void when(time_t t, char *b, int sz) {
  struct tm tm;
  time_t now = time(NULL);
  localtime_r(&t, &tm);
  strftime(b, (size_t)sz, now - t < 180 * 86400 && t <= now ? "%b %e, %H:%M" : "%b %e, %Y", &tm);
}

static void files_geom(Panel *p, FilesState *st, float *lx, float *ly, float *lw, float *lh) {
  *lx = F_SIDE;
  *ly = F_TB + (st->grid ? 0 : F_HDR);
  *lw = (float)p->lw - F_SIDE;
  *lh = (float)(p->lh - BAR_H) - F_ST - *ly;
}

static int files_cols(float lw) {
  int c = (int)((lw - 16) / F_CELL_W);
  return c < 1 ? 1 : c;
}

static float files_content_h(Panel *p, FilesState *st) {
  float lx, ly, lw, lh;
  files_geom(p, st, &lx, &ly, &lw, &lh);
  if (st->grid) return 12 + (float)((st->nvis + files_cols(lw) - 1) / files_cols(lw)) * F_CELL_H;
  return 6 + (float)st->nvis * F_ROW;
}

static void files_clamp(Panel *p, FilesState *st) {
  float lx, ly, lw, lh;
  files_geom(p, st, &lx, &ly, &lw, &lh);
  float mx = files_content_h(p, st) - lh;
  if (st->top > mx) st->top = mx;
  if (st->top < 0) st->top = 0;
}

static void files_reveal(Panel *p, FilesState *st) {
  if (st->sel < 0) return;
  float lx, ly, lw, lh;
  files_geom(p, st, &lx, &ly, &lw, &lh);
  float y0, y1;
  if (st->grid) {
    int c = files_cols(lw);
    y0 = 6 + (float)(st->sel / c) * F_CELL_H;
    y1 = y0 + F_CELL_H;
  } else {
    y0 = 3 + (float)st->sel * F_ROW;
    y1 = y0 + F_ROW;
  }
  if (y0 < st->top) st->top = y0 - 4;
  if (y1 > st->top + lh) st->top = y1 - lh + 4;
  files_clamp(p, st);
}

static void f_arrow(Surface *s, float cx, float cy, int dir, uint32_t c) {
  float d = dir == 0 ? -1 : 1;
  if (dir == 2) {
    gfx_line(s, cx, cy + 6, cx, cy - 6, 2, c);
    gfx_line(s, cx - 6, cy, cx, cy - 6, 2, c);
    gfx_line(s, cx + 6, cy, cx, cy - 6, 2, c);
    return;
  }
  gfx_line(s, cx - 6 * d, cy, cx + 6 * d, cy, 2, c);
  gfx_line(s, cx + 6 * d, cy, cx + 1 * d, cy - 5, 2, c);
  gfx_line(s, cx + 6 * d, cy, cx + 1 * d, cy + 5, 2, c);
}

static void files_draw(Panel *p, Surface *s, float ox, float oy) {
  FilesState *st = p->state;
  int hot = hot_of(p);
  float w = (float)p->lw, ch = (float)(p->lh - BAR_H);
  uint32_t line = C_BAR_LINE;
  uint32_t side = THEME(RGB(240, 242, 246), RGB(34, 38, 44));
  uint32_t mute = C_MUTED;
  uint32_t field = THEME(RGB(238, 240, 244), RGB(50, 55, 63));

  gfx_rect(s, ox, oy, F_SIDE, ch, side);
  gfx_rect(s, ox + F_SIDE - 1, oy, 1, ch, line);
  gfx_text(s, F_UI_MED, ox + 18, oy + 14, "Places", mute);
  for (int i = 0; i < st->nplace; i++) {
    float y = oy + 42 + (float)i * 38;
    int on = !strcmp(st->cwd, st->place_path[i]);
    if (on) gfx_rrect(s, ox + 8, y, F_SIDE - 16, 34, 9, F_TINT);
    else if (hot == FZ_PLACE + i) gfx_rrect(s, ox + 8, y, F_SIDE - 16, 34, 9, C_HOVER);
    gfx_icon(s, st->place_icon[i], ox + 18, y + 5, 24);
    gfx_text_fit(s, F_UI_MED, ox + 52, y + (34 - line_h(F_UI_MED)) * 0.5f, F_SIDE - 64, st->place_name[i], on ? F_ACC : C_TEXT);
  }

  float cx = ox + F_SIDE;
  float cw = w - F_SIDE;
  gfx_rect(s, cx, oy + F_TB - 1, cw, 1, line);
  struct { float x; int z, dir, ok; } nav[3] = {{cx + 12, FZ_BACK, 0, st->nback > 0}, {cx + 52, FZ_FWD, 1, st->nfwd > 0}, {cx + 92, FZ_UP, 2, strcmp(st->cwd, "/") != 0}};
  for (int i = 0; i < 3; i++) {
    if (hot == nav[i].z && nav[i].ok) gfx_disc(s, nav[i].x + 16, oy + 28, 17, C_HOVER);
    f_arrow(s, nav[i].x + 16, oy + 28, nav[i].dir, nav[i].ok ? C_TEXT : THEME(RGB(190, 195, 203), RGB(84, 90, 100)));
  }

  float tx = cx + cw - 12;
  float bw = 34;
  tx -= bw;
  float hid_x = tx;
  tx -= bw + 4;
  float view_x = tx;
  float sw = 176;
  tx -= sw + 10;
  float sx = tx;
  float px = cx + 136, pw = sx - 10 - px;
  gfx_rrect(s, px, oy + 11, pw, 34, 17, field);
  st->ncrumb = 0;
  {
    char parts[8][128];
    char paths[8][1024];
    int np = 0;
    const char *home = user_home();
    size_t hl = strlen(home);
    int in_home = hl > 1 && !strncmp(st->cwd, home, hl) && (st->cwd[hl] == 0 || st->cwd[hl] == '/');
    snprintf(parts[np], sizeof parts[0], "%s", "/");
    snprintf(paths[np++], sizeof paths[0], "/");
    if (in_home) {
      np = 0;
      snprintf(parts[np], sizeof parts[0], "Home");
      snprintf(paths[np++], sizeof paths[0], "%s", home);
    }
    const char *r = st->cwd + (in_home ? hl : 0);
    char acc[1024];
    snprintf(acc, sizeof acc, "%s", in_home ? home : "");
    while (*r) {
      while (*r == '/') r++;
      if (!*r) break;
      const char *e = strchr(r, '/');
      size_t n = e ? (size_t)(e - r) : strlen(r);
      if (np >= 8) {
        memmove(parts[0], parts[1], sizeof parts[0] * 7);
        memmove(paths[0], paths[1], sizeof paths[0] * 7);
        np--;
      }
      snprintf(parts[np], sizeof parts[0], "%.*s", (int)n, r);
      size_t al = strlen(acc);
      snprintf(acc + al, sizeof acc - al, "/%.*s", (int)n, r);
      snprintf(paths[np++], sizeof paths[0], "%s", acc);
      r += n;
    }
    float tw = 0;
    float sep = 18;
    for (int i = 0; i < np; i++) tw += gfx_text_w(F_UI_MED, parts[i]) + 16 + (i ? sep : 0);
    int first = 0;
    while (first < np - 1 && tw > pw - 8) {
      tw -= gfx_text_w(F_UI_MED, parts[first]) + 16 + (first ? sep : 0);
      first++;
    }
    float x = px + 8;
    gfx_clip(s, px, oy + 11, pw, 34);
    for (int i = first; i < np; i++) {
      if (i > first) {
        gfx_line(s, x + 6, oy + 22, x + 11, oy + 28, 1.5f, mute);
        gfx_line(s, x + 11, oy + 28, x + 6, oy + 34, 1.5f, mute);
        x += sep;
      }
      float lw = gfx_text_w(F_UI_MED, parts[i]) + 16;
      int last = i == np - 1;
      if (hot == FZ_CRUMB + st->ncrumb && !last) gfx_rrect(s, x, oy + 15, lw, 26, 13, C_HOVER);
      gfx_text(s, F_UI_MED, x + 8, oy + 11 + (34 - line_h(F_UI_MED)) * 0.5f, parts[i], last ? C_TEXT : mute);
      st->crumb_x[st->ncrumb] = x;
      st->crumb_w[st->ncrumb] = lw;
      snprintf(st->crumb_path[st->ncrumb], sizeof st->crumb_path[0], "%s", paths[i]);
      st->ncrumb++;
      x += lw;
    }
    gfx_noclip(s);
  }

  gfx_rrect(s, sx, oy + 11, sw, 34, 17, st->focus ? THEME(RGB(255, 255, 255), RGB(26, 29, 34)) : field);
  gfx_ring(s, sx + 19, oy + 26, 6, 1.8f, mute);
  gfx_line(s, sx + 23.5f, oy + 30.5f, sx + 28, oy + 35, 1.8f, mute);
  if (st->q[0]) {
    gfx_text_fit(s, F_UI, sx + 36, oy + 11 + (34 - line_h(F_UI)) * 0.5f, sw - 70, st->q, C_TEXT);
    if (hot == FZ_CLEAR) gfx_disc(s, sx + sw - 18, oy + 28, 9, C_HOVER);
    gfx_line(s, sx + sw - 22, oy + 24, sx + sw - 14, oy + 32, 1.6f, mute);
    gfx_line(s, sx + sw - 14, oy + 24, sx + sw - 22, oy + 32, 1.6f, mute);
  } else {
    gfx_text(s, F_UI, sx + 36, oy + 11 + (34 - line_h(F_UI)) * 0.5f, "Search", mute);
  }
  if (st->focus) gfx_rect(s, sx + 36 + (st->q[0] ? gfx_text_w(F_UI, st->q) : 0) + 1, oy + 19, 1.5f, 18, F_ACC);

  if (hot == FZ_VIEW) gfx_rrect(s, view_x, oy + 11, bw, 34, 9, C_HOVER);
  if (hot == FZ_HIDDEN) gfx_rrect(s, hid_x, oy + 11, bw, 34, 9, C_HOVER);
  {
    float vx = view_x + bw * 0.5f, vy = oy + 28;
    uint32_t c = C_TEXT;
    if (st->grid) {
      for (int i = 0; i < 3; i++) {
        gfx_rect(s, vx - 8, vy - 8 + (float)i * 7, 3, 3, c);
        gfx_rect(s, vx - 2, vy - 8 + (float)i * 7, 10, 3, c);
      }
    } else {
      for (int a = 0; a < 2; a++)
        for (int b = 0; b < 2; b++) gfx_rrect(s, vx - 8 + (float)a * 9, vy - 8 + (float)b * 9, 7, 7, 1.5f, c);
    }
    float ex = hid_x + bw * 0.5f;
    uint32_t hc = st->hidden ? F_ACC : mute;
    gfx_ring(s, ex, vy, 8, 1.8f, hc);
    gfx_disc(s, ex, vy, 2.6f, hc);
    if (!st->hidden) gfx_line(s, ex - 9, vy + 8, ex + 9, vy - 8, 2, hc);
  }

  float lx, ly, lw, lh;
  files_geom(p, st, &lx, &ly, &lw, &lh);
  if (!st->grid) {
    static const char *const hn[3] = {"Name", "Size", "Modified"};
    float hx[3] = {cx + 52, cx + cw - 250, cx + cw - 150};
    for (int i = 0; i < 3; i++) {
      float x = hx[i];
      int on = st->sort == i;
      if (hot == FZ_SORT + i) gfx_rrect(s, x - 8, oy + F_TB + 3, gfx_text_w(F_UI_MED, hn[i]) + 36, F_HDR - 6, 8, C_HOVER);
      gfx_text(s, F_UI_MED, x, oy + F_TB + (F_HDR - line_h(F_UI_MED)) * 0.5f, hn[i], on ? C_TEXT : mute);
      if (on) {
        float ax = x + gfx_text_w(F_UI_MED, hn[i]) + 12, ay = oy + F_TB + F_HDR * 0.5f;
        if (st->asc) gfx_tri(s, ax - 4, ay + 2, ax + 4, ay + 2, ax, ay - 3, mute);
        else gfx_tri(s, ax - 4, ay - 2, ax + 4, ay - 2, ax, ay + 3, mute);
      }
    }
    gfx_rect(s, cx, oy + F_TB + F_HDR - 1, cw, 1, line);
  }

  gfx_clip(s, ox + lx, oy + ly, lw, lh);
  if (!st->nvis) {
    gfx_icon(s, IC_FOLDER, ox + lx + lw * 0.5f - 24, oy + ly + lh * 0.5f - 52, 48);
    gfx_text_c(s, F_UI_MED, ox + lx + lw * 0.5f, oy + ly + lh * 0.5f + 4, st->q[0] ? "No matches" : "This folder is empty", mute);
  }
  files_clamp(p, st);
  if (st->grid) {
    int cols = files_cols(lw);
    float gx = lx + (lw - (float)cols * F_CELL_W) * 0.5f;
    for (int i = 0; i < st->nvis; i++) {
      float y = ly + 6 + (float)(i / cols) * F_CELL_H - st->top;
      if (y + F_CELL_H < ly || y > ly + lh) continue;
      float x = gx + (float)(i % cols) * F_CELL_W;
      Entry *e = &st->e[st->vis[i]];
      if (i == st->sel) gfx_rrect(s, ox + x + 4, oy + y, F_CELL_W - 8, F_CELL_H - 6, 12, F_TINT);
      else if (hot == FZ_ITEM + i - 0) gfx_rrect(s, ox + x + 4, oy + y, F_CELL_W - 8, F_CELL_H - 6, 12, C_HOVER);
      gfx_icon(s, e->dir ? IC_FOLDER : IC_DOC, ox + x + (F_CELL_W - 52) * 0.5f, oy + y + 12, 52);
      if (gfx_text_w(F_UI, e->name) <= F_CELL_W - 20) gfx_text_c(s, F_UI, ox + x + F_CELL_W * 0.5f, oy + y + 72, e->name, i == st->sel ? F_ACC : C_TEXT);
      else gfx_text_fit(s, F_UI, ox + x + 10, oy + y + 72, F_CELL_W - 20, e->name, i == st->sel ? F_ACC : C_TEXT);
      if (!e->dir) {
        char b[32];
        human(e->size, b, sizeof b);
        gfx_text_c(s, F_SMALL, ox + x + F_CELL_W * 0.5f, oy + y + 90, b, mute);
      }
    }
  } else {
    for (int i = 0; i < st->nvis; i++) {
      float y = ly + 3 + (float)i * F_ROW - st->top;
      if (y + F_ROW < ly || y > ly + lh) continue;
      Entry *e = &st->e[st->vis[i]];
      if (i == st->sel) gfx_rrect(s, cx + 8, oy + y, cw - 16, F_ROW - 2, 8, F_TINT);
      else if (hot == FZ_ITEM + i) gfx_rrect(s, cx + 8, oy + y, cw - 16, F_ROW - 2, 8, C_HOVER);
      else if (i & 1) gfx_rrect(s, cx + 8, oy + y, cw - 16, F_ROW - 2, 8, THEME(RGB(250, 251, 252), RGB(33, 36, 42)));
      float ty = oy + y + (F_ROW - 2 - line_h(F_UI)) * 0.5f;
      gfx_icon(s, e->dir ? IC_FOLDER : IC_DOC, cx + 16, oy + y + 4, 26);
      gfx_text_fit(s, F_UI, cx + 52, ty, cw - 320, e->name, i == st->sel ? F_ACC : C_TEXT);
      if (!e->dir) {
        char b[32];
        human(e->size, b, sizeof b);
        gfx_text(s, F_UI, cx + cw - 250, ty, b, mute);
      } else {
        gfx_text(s, F_UI, cx + cw - 250, ty, "Folder", mute);
      }
      char b[40];
      when(e->mtime, b, sizeof b);
      gfx_text(s, F_UI, cx + cw - 150, ty, b, mute);
    }
  }
  gfx_noclip(s);

  float mh = files_content_h(p, st);
  if (mh > lh) {
    float bh = lh * lh / mh, by = lh * st->top / mh;
    gfx_rrect(s, ox + w - 7, oy + ly + by + 2, 4, bh - 4, 2, THEME(RGB(196, 201, 209), RGB(84, 90, 100)));
  }

  gfx_rect(s, cx, oy + ch - F_ST, cw, F_ST, THEME(RGB(250, 251, 252), RGB(34, 38, 44)));
  gfx_rect(s, cx, oy + ch - F_ST, cw, 1, line);
  char b[200];
  if (st->sel >= 0 && st->sel < st->nvis) {
    Entry *e = &st->e[st->vis[st->sel]];
    char sz[32] = "";
    if (!e->dir) human(e->size, sz, sizeof sz);
    snprintf(b, sizeof b, "\"%s\" selected%s%s", e->name, sz[0] ? "  -  " : "", sz);
  } else if (st->pick) {
    snprintf(b, sizeof b, "Double-click a JPG or PNG to use it as your wallpaper");
  } else {
    int dirs = 0;
    for (int i = 0; i < st->nvis; i++) dirs += st->e[st->vis[i]].dir;
    snprintf(b, sizeof b, "%d item%s%s%s", st->nvis, st->nvis == 1 ? "" : "s", dirs ? ", " : "", "");
    if (dirs) snprintf(b + strlen(b), sizeof b - strlen(b), "%d folder%s", dirs, dirs == 1 ? "" : "s");
  }
  gfx_text_fit(s, F_SMALL, cx + 16, oy + ch - F_ST + (F_ST - line_h(F_SMALL)) * 0.5f, cw - 32, b, mute);
}

static int files_zone(Panel *p, float x, float y) {
  FilesState *st = p->state;
  float w = (float)p->lw;
  if (x < F_SIDE) {
    for (int i = 0; i < st->nplace; i++)
      if (in_rect(x, y, 8, 42 + (float)i * 38, F_SIDE - 16, 34)) return FZ_PLACE + i;
    return 0;
  }
  float cx = F_SIDE, cw = w - F_SIDE;
  if (y < F_TB) {
    for (int i = 0; i < 3; i++)
      if (in_rect(x, y, cx + 12 + 40 * (float)i, 11, 32, 34)) return FZ_BACK + i;
    float tx = cx + cw - 12 - 34;
    if (in_rect(x, y, tx, 11, 34, 34)) return FZ_HIDDEN;
    tx -= 38;
    if (in_rect(x, y, tx, 11, 34, 34)) return FZ_VIEW;
    float sw = 176;
    tx -= sw + 10;
    if (in_rect(x, y, tx, 11, sw, 34)) return st->q[0] && x > tx + sw - 32 ? FZ_CLEAR : FZ_SEARCH;
    for (int i = 0; i < st->ncrumb - 1; i++)
      if (in_rect(x, y, st->crumb_x[i], 15, st->crumb_w[i], 26)) return FZ_CRUMB + i;
    return 0;
  }
  float lx, ly, lw, lh;
  files_geom(p, st, &lx, &ly, &lw, &lh);
  if (!st->grid && y < ly) {
    float hx[3] = {cx + 52, cx + cw - 250, cx + cw - 150};
    for (int i = 2; i >= 0; i--)
      if (x >= hx[i] - 8) return FZ_SORT + i;
    return 0;
  }
  if (y < ly || y >= ly + lh) return 0;
  int i;
  if (st->grid) {
    int cols = files_cols(lw);
    float gx = lx + (lw - (float)cols * F_CELL_W) * 0.5f;
    int c = (int)((x - gx) / F_CELL_W);
    if (x < gx || c >= cols) return 0;
    i = (int)((y - ly - 6 + st->top) / F_CELL_H) * cols + c;
  } else {
    i = (int)((y - ly - 3 + st->top) / F_ROW);
  }
  return i >= 0 && i < st->nvis ? FZ_ITEM + i : 0;
}

static void files_click(Panel *p, float x, float y) {
  FilesState *st = p->state;
  int z = files_zone(p, x, y);
  st->focus = z == FZ_SEARCH;
  if (z == FZ_BACK) files_back(st);
  else if (z == FZ_FWD) files_forward(st);
  else if (z == FZ_UP) files_up(st);
  else if (z == FZ_VIEW) {
    st->grid ^= 1;
    st->top = 0;
    files_reveal(p, st);
  } else if (z == FZ_HIDDEN) {
    st->hidden ^= 1;
    files_load(st);
  } else if (z == FZ_CLEAR) {
    st->q[0] = 0;
    files_filter(st);
  } else if (z >= FZ_PLACE && z < FZ_PLACE + 8) files_go(st, st->place_path[z - FZ_PLACE], 1);
  else if (z >= FZ_SORT && z < FZ_SORT + 3) {
    int c = z - FZ_SORT;
    if (st->sort == c) st->asc ^= 1;
    else st->sort = c, st->asc = c == 0;
    files_sort(st);
  } else if (z >= FZ_CRUMB && z < FZ_CRUMB + 8) {
    char path[1024];
    snprintf(path, sizeof path, "%s", st->crumb_path[z - FZ_CRUMB]);
    files_go(st, path, 1);
  } else if (z >= FZ_ITEM) {
    int i = z - FZ_ITEM;
    uint32_t t = now_ms();
    if (i == st->click_idx && t - st->click_at < 600) {
      st->click_idx = -1;
      files_open_entry(st, i);
    } else {
      st->sel = i;
      st->click_idx = i;
      st->click_at = t;
    }
  } else {
    st->sel = -1;
  }
  p->dirty = 1;
}

static void files_scroll(Panel *p, float x, float y, int steps) {
  FilesState *st = p->state;
  st->top -= (float)steps * 48;
  files_clamp(p, st);
  p->dirty = 1;
}

static void files_key(Panel *p, int code, int mods) {
  FilesState *st = p->state;
  int ctrl = mods & MOD_CTRL, alt = mods & MOD_ALT;
  p->dirty = 1;
  if (ctrl && code == KEY_F) {
    st->focus = 1;
    return;
  }
  if (ctrl && code == KEY_H) {
    st->hidden ^= 1;
    files_load(st);
    return;
  }
  if (st->focus) {
    int l = (int)strlen(st->q);
    if (code == KEY_ESC || code == KEY_ENTER || code == KEY_KPENTER) {
      if (code == KEY_ESC) st->q[0] = 0, files_filter(st);
      st->focus = 0;
    } else if (code == KEY_BACKSPACE) {
      if (l) st->q[l - 1] = 0, files_filter(st);
    } else if (!ctrl && !alt) {
      char b[8];
      int n = key_to_bytes(code, mods, b);
      if (n == 1 && b[0] >= 32 && b[0] < 127 && l < 60) st->q[l] = b[0], st->q[l + 1] = 0, files_filter(st);
    }
    return;
  }
  float lx, ly, lw, lh;
  files_geom(p, st, &lx, &ly, &lw, &lh);
  int cols = st->grid ? files_cols(lw) : 1;
  if (alt && code == KEY_LEFT) files_back(st);
  else if (alt && code == KEY_RIGHT) files_forward(st);
  else if (alt && code == KEY_UP) files_up(st);
  else if (code == KEY_BACKSPACE) files_up(st);
  else if (code == KEY_ENTER || code == KEY_KPENTER) files_open_entry(st, st->sel);
  else if (code == KEY_ESC) st->sel = -1;
  else if (code == KEY_DOWN || code == KEY_RIGHT || code == KEY_UP || code == KEY_LEFT) {
    int d = code == KEY_DOWN ? cols : code == KEY_UP ? -cols : code == KEY_RIGHT ? 1 : -1;
    if (!st->grid && (code == KEY_LEFT || code == KEY_RIGHT)) return;
    int n = st->sel < 0 ? (d > 0 ? 0 : st->nvis - 1) : st->sel + d;
    if (n >= 0 && n < st->nvis) st->sel = n;
    files_reveal(p, st);
  } else if (code == KEY_HOME) {
    st->sel = st->nvis ? 0 : -1;
    files_reveal(p, st);
  } else if (code == KEY_END) {
    st->sel = st->nvis - 1;
    files_reveal(p, st);
  } else if (code == KEY_SLASH || code == KEY_F3) {
    st->focus = 1;
  }
}

static App files = {"files", "Files", IC_FILES, 860, 560 + BAR_H, files_open, files_draw, files_click, files_scroll, files_key,
                    files_zone, NULL, files_close};

#define NOTE_BTN_X 22
#define NOTE_BTN_Y 112
#define NOTE_BTN_W 168
#define NOTE_BTN_H 36

static void notes_draw(Panel *p, Surface *s, float ox, float oy) {
  gfx_text(s, F_H1, ox + 22, oy + 22, "Welcome to OreonVR", C_TEXT);
  gfx_text(s, F_BODY, ox + 23, oy + 66, "OreonVR is a VR operating system powered by Linux.", THEME(RGB(70, 76, 86), RGB(190, 196, 206)));
  button(s, ox + NOTE_BTN_X, oy + NOTE_BTN_Y, NOTE_BTN_W, NOTE_BTN_H, "Go to Terminal", hot_of(p) == 1, 1);
}

static int notes_zone(Panel *p, float x, float y) {
  (void)p;
  return in_rect(x, y, NOTE_BTN_X, NOTE_BTN_Y, NOTE_BTN_W, NOTE_BTN_H);
}

static void notes_click(Panel *p, float x, float y) {
  if (notes_zone(p, x, y)) panel_open_app("terminal");
}

static App welcome = {"welcome", "Welcome", IC_DOC, 470, 210, NULL, notes_draw, notes_click, NULL, NULL, notes_zone, NULL, NULL};

#define S_SIDE 170
#define S_TAB_H 36
#define S_TAB_Y 14
#define S_CARD_W 160
#define S_CARD_H 100
#define S_CARD_Y 104
#define S_PWR_Y 84

static int set_tab;
static const char *const set_tabs[] = {"Theme", "System tray", "Background", "Power"};
#define NTABS 4
#define T_THEME 0
#define T_TRAY 1
#define T_BG 2
#define S_ROW_Y 96
#define S_ROW_H 44
static const char *const tray_names[] = {"Wi-Fi", "Battery", "Time", "Power button"};

static int *tray_flag(int i) {
  int *f[] = {&tray_wifi, &tray_bat, &tray_clock, &tray_power};
  return f[i];
}

static int tray_present(int i) { return i == 0 ? status.has_wifi : i == 1 ? status.has_bat : 1; }

static void toggle(Surface *s, float x, float y, int on) {
  gfx_rrect(s, x, y, 44, 24, 12, on ? C_ACCENT : THEME(RGB(200, 205, 212), RGB(70, 76, 86)));
  gfx_disc(s, x + (on ? 32.f : 12.f), y + 12, 9, RGB(255, 255, 255));
}

static void set_theme(int dark) {
  if (g_dark == dark) return;
  g_dark = dark;
  for (int i = 0; i < MAXP; i++)
    if (P[i].used) P[i].dirty = 1, P[i].chrome_key = -1;
}

/* Backgrounds: wallpapers (the sky plus images in a backgrounds folder), colours (presets and a custom picker) and
   the user's own images, which are copied into ~/.local/share/oreonvr/wallpapers. */
#define BG_MAX 64
#define BG_TW 96
#define BG_TH 56
#define BG_PANE_W 390
enum { BGV_WALL, BGV_COLOR, BGV_MINE };
enum { BGK_FILE, BGK_SOLID, BGK_GRAD };
typedef struct {
  char name[40], path[600];
  int kind, view;
  uint32_t c1, c2, *thumb;
} Bg;
static Bg bgs[BG_MAX];
static int nbg, bg_view, bg_page, bg_edit;
static char bg_cur[640];
static int cc_grad, cc_slot;
static uint32_t cc_col[2] = {RGB(64, 96, 168), RGB(18, 22, 46)};
static float cc_h, cc_s, cc_v;

static const struct {
  const char *name;
  int kind;
  uint32_t c1, c2;
} presets[] = {
    {"Dark", BGK_SOLID, RGB(28, 31, 37), 0},       {"Light", BGK_SOLID, RGB(226, 230, 236), 0},
    {"Slate", BGK_SOLID, RGB(66, 80, 96), 0},      {"Sage", BGK_SOLID, RGB(96, 128, 108), 0},
    {"Sand", BGK_SOLID, RGB(214, 200, 172), 0},    {"Dusk", BGK_GRAD, RGB(54, 70, 128), RGB(214, 150, 120)},
    {"Ocean", BGK_GRAD, RGB(40, 110, 160), RGB(12, 30, 60)}, {"Aurora", BGK_GRAD, RGB(24, 160, 140), RGB(28, 32, 90)},
    {"Berry", BGK_GRAD, RGB(150, 60, 130), RGB(40, 20, 70)}, {"Ember", BGK_GRAD, RGB(240, 140, 60), RGB(120, 30, 40)},
};
#define NPRESETS ((int)(sizeof presets / sizeof *presets))

static const char *bg_key(const Bg *b) { return b->kind == BGK_FILE ? b->path : b->name; }
static int bg_cur_custom(void) { return !strncmp(bg_cur, "custom:", 7); }

static uint32_t hsv_rgb(float h, float s, float v) {
  h = fmodf(h, 360.f) / 60.f;
  int i = (int)h;
  float f = h - (float)i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f)), r, g, b;
  switch (i % 6) {
  case 0: r = v, g = t, b = p; break;
  case 1: r = q, g = v, b = p; break;
  case 2: r = p, g = v, b = t; break;
  case 3: r = p, g = q, b = v; break;
  case 4: r = t, g = p, b = v; break;
  default: r = v, g = p, b = q;
  }
  return RGB((int)(r * 255.f + .5f), (int)(g * 255.f + .5f), (int)(b * 255.f + .5f));
}

static void rgb_hsv(uint32_t c, float *h, float *s, float *v) {
  float r = (float)(c >> 16 & 255) / 255.f, g = (float)(c >> 8 & 255) / 255.f, b = (float)(c & 255) / 255.f;
  float mx = fmaxf(r, fmaxf(g, b)), d = mx - fminf(r, fminf(g, b)), hh = 0;
  if (d > 0) {
    hh = mx == r ? fmodf((g - b) / d, 6.f) : mx == g ? (b - r) / d + 2.f : (r - g) / d + 4.f;
    hh *= 60.f;
    if (hh < 0) hh += 360.f;
  }
  *h = hh, *s = mx > 0 ? d / mx : 0, *v = mx;
}

static uint32_t mix_rgb(uint32_t a, uint32_t b, int t) {
  uint32_t o = 0xff000000u;
  for (int sh = 0; sh < 24; sh += 8) o |= (((a >> sh & 255) * (256 - t) + (b >> sh & 255) * t) >> 8) << sh;
  return o;
}

static void swatch(Surface *s, float x, float y, float w, float h, float r, uint32_t top, uint32_t bot) {
  for (int k = 0; k < 8; k++) gfx_rrect_band(s, x, y, w, h, r, y + h * k / 8, y + h * (k + 1) / 8 + 0.5f, mix_rgb(top, bot, k * 36));
}

static int bg_is_image(const char *name) {
  const char *dot = strrchr(name, '.');
  return dot && (!strcasecmp(dot, ".jpg") || !strcasecmp(dot, ".jpeg") || !strcasecmp(dot, ".png"));
}

static void bg_add(const char *name, const char *path, int kind, int view, uint32_t c1, uint32_t c2) {
  if (nbg >= BG_MAX) return;
  Bg *b = &bgs[nbg++];
  memset(b, 0, sizeof *b);
  snprintf(b->name, sizeof b->name, "%s", name);
  snprintf(b->path, sizeof b->path, "%s", path ? path : "");
  b->kind = kind, b->view = view, b->c1 = c1, b->c2 = c2;
}

static uint32_t *bg_read_thumb(const char *path) {
  char tp[640];
  snprintf(tp, sizeof tp, "%s.thumb", path);
  FILE *f = fopen(tp, "rb");
  if (!f) return NULL;
  int w = 0, h = 0, mx = 0;
  uint32_t *px = NULL;
  if (fscanf(f, "P6 %d %d %d", &w, &h, &mx) == 3 && w == BG_TW && h == BG_TH && mx == 255 && fgetc(f) != EOF) {
    unsigned char rgb[BG_TW * BG_TH * 3];
    if (fread(rgb, 3, BG_TW * BG_TH, f) == BG_TW * BG_TH && (px = malloc(BG_TW * BG_TH * 4)))
      for (int i = 0; i < BG_TW * BG_TH; i++) px[i] = RGB(rgb[i * 3], rgb[i * 3 + 1], rgb[i * 3 + 2]);
  }
  fclose(f);
  return px;
}

static void bg_write_thumb(const char *path, const uint32_t *px, int w, int h) {
  char tp[640];
  snprintf(tp, sizeof tp, "%s.thumb", path);
  FILE *f = fopen(tp, "wb");
  if (!f) return;
  float sw = fminf((float)w, (float)h * BG_TW / BG_TH), sh = sw * BG_TH / BG_TW;
  float x0 = ((float)w - sw) * 0.5f, y0 = ((float)h - sh) * 0.5f;
  fprintf(f, "P6 %d %d 255\n", BG_TW, BG_TH);
  for (int y = 0; y < BG_TH; y++)
    for (int x = 0; x < BG_TW; x++) {
      int sum[3] = {0, 0, 0};
      for (int k = 0; k < 4; k++) {
        int sx = (int)(x0 + (x + 0.25f + 0.5f * (k & 1)) * sw / BG_TW), sy = (int)(y0 + (y + 0.25f + 0.5f * (k >> 1)) * sh / BG_TH);
        uint32_t c = px[(size_t)(sy < h ? sy : h - 1) * w + (sx < w ? sx : w - 1)];
        sum[0] += c >> 16 & 255, sum[1] += c >> 8 & 255, sum[2] += c & 255;
      }
      fputc(sum[0] / 4, f), fputc(sum[1] / 4, f), fputc(sum[2] / 4, f);
    }
  fclose(f);
}

static void bg_clear(void) {
  for (int i = 0; i < nbg; i++) free(bgs[i].thumb);
  nbg = 0;
}

static int bg_cmp(const void *a, const void *b) { return strcasecmp(((const Bg *)a)->name, ((const Bg *)b)->name); }

static void bg_scan_dir(const char *dir, int view) {
  DIR *d = opendir(dir);
  if (!d) return;
  int first = nbg;
  struct dirent *e;
  while ((e = readdir(d)) && nbg < BG_MAX) {
    if (e->d_name[0] == '.' || !bg_is_image(e->d_name)) continue;
    char path[600], name[40];
    snprintf(path, sizeof path, "%s/%s", dir, e->d_name);
    if (!strcmp(path, scene_sky_path())) continue;
    const char *dot = strrchr(e->d_name, '.');
    snprintf(name, sizeof name, "%.*s", (int)(dot - e->d_name) < 39 ? (int)(dot - e->d_name) : 39, e->d_name);
    for (char *c = name; *c; c++)
      if (*c == '_' || *c == '-') *c = ' ';
    if (name[0] >= 'a' && name[0] <= 'z') name[0] -= 32;
    bg_add(name, path, BGK_FILE, view, 0, 0);
    bgs[nbg - 1].thumb = bg_read_thumb(path);
  }
  closedir(d);
  qsort(bgs + first, (size_t)(nbg - first), sizeof *bgs, bg_cmp);
}

static const char *bg_mine_dir(void) {
  static char p[600];
  const char *e = getenv("OREONVR_USER_BG_DIR");
  if (e && *e) return e;
  snprintf(p, sizeof p, "%s/.local/share/oreonvr/wallpapers", user_home());
  return p;
}

static void bg_scan(void) {
  char exe[512] = {0}, dir[600];
  bg_clear();
  if (scene_sky_path()[0]) bg_add("Sky", scene_sky_path(), BGK_FILE, BGV_WALL, 0, 0);
  const char *env = getenv("OREONVR_BG_DIR");
  if (env && *env) bg_scan_dir(env, BGV_WALL);
  ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
  char *sl = n > 0 ? strrchr(exe, '/') : NULL;
  if (sl) {
    *sl = 0;
    snprintf(dir, sizeof dir, "%s/res/backgrounds", exe);
    bg_scan_dir(dir, BGV_WALL);
  }
  bg_scan_dir("/usr/share/oreonvr/backgrounds", BGV_WALL);
  for (int i = 0; i < NPRESETS; i++) bg_add(presets[i].name, NULL, presets[i].kind, BGV_COLOR, presets[i].c1, presets[i].c2);
  bg_scan_dir(bg_mine_dir(), BGV_MINE);
}

static int bg_rows(void) { return bg_view == BGV_MINE ? 3 : 4; }
static int bg_row_y(void) { return bg_view == BGV_MINE ? 142 : 100; }
static int bg_pager_y(void) { return 276; }

static int bg_count(int view) {
  int n = 0;
  for (int i = 0; i < nbg; i++) n += bgs[i].view == view;
  return n;
}

static int bg_nth(int view, int n) {
  for (int i = 0; i < nbg; i++)
    if (bgs[i].view == view && n-- == 0) return i;
  return -1;
}

static const char *bg_cfg(void) {
  static char p[600];
  const char *e = getenv("OREONVR_BG_FILE");
  if (e && *e) return e;
  snprintf(p, sizeof p, "%s/.config/oreonvr/background", user_home());
  return p;
}

static void bg_save(void) {
  char dir[600];
  snprintf(dir, sizeof dir, "%s", bg_cfg());
  char *sl = strrchr(dir, '/');
  if (sl) {
    *sl = 0;
    office_mkdirs(dir);
  }
  FILE *f = fopen(bg_cfg(), "w");
  if (!f) return;
  fprintf(f, "%s\n", bg_cur);
  fclose(f);
}

static void bg_apply(int i, int save) {
  const Bg *b = &bgs[i];
  if (b->kind == BGK_SOLID) scene_bg_solid(b->c1);
  else if (b->kind == BGK_GRAD) scene_bg_gradient(b->c1, b->c2);
  else if (!(!strcmp(b->path, scene_sky_path()) ? scene_load_sky(b->path) : scene_load_image(b->path))) return;
  snprintf(bg_cur, sizeof bg_cur, "%s", bg_key(b));
  if (save) bg_save();
}

static void bg_custom_apply(int save) {
  if (cc_grad) scene_bg_gradient(cc_col[0], cc_col[1]);
  else scene_bg_solid(cc_col[0]);
  snprintf(bg_cur, sizeof bg_cur, "custom:%d:%06X:%06X", cc_grad ? 2 : 1, cc_col[0] & 0xffffff, cc_col[1] & 0xffffff);
  if (save) bg_save();
}

void bg_restore(void) {
  bg_scan();
  snprintf(bg_cur, sizeof bg_cur, "%s", scene_sky_path());
  FILE *f = fopen(bg_cfg(), "r");
  if (!f) return;
  char line[640];
  if (fgets(line, sizeof line, f)) {
    line[strcspn(line, "\n")] = 0;
    unsigned kind, a, b;
    if (sscanf(line, "custom:%u:%x:%x", &kind, &a, &b) == 3 && (kind == 1 || kind == 2)) {
      cc_grad = kind == 2, cc_col[0] = RGB(a >> 16 & 255, a >> 8 & 255, a & 255), cc_col[1] = RGB(b >> 16 & 255, b >> 8 & 255, b & 255);
      bg_custom_apply(0);
    } else {
      for (int i = 0; i < nbg; i++)
        if (!strcmp(bg_key(&bgs[i]), line)) {
          bg_apply(i, 0);
          break;
        }
    }
  }
  fclose(f);
}

static void bg_import(const char *src) {
  int w = 0, h = 0;
  uint32_t *px = img_decode_file(src, &w, &h);
  if (!px || w < 2 || h < 2) {
    free(px);
    office_toast("That image could not be opened");
    return;
  }
  const char *base = strrchr(src, '/');
  base = base ? base + 1 : src;
  char name[100], dst[600];
  snprintf(name, sizeof name, "%s", base);
  for (char *c = name; *c; c++)
    if (!((*c >= '0' && *c <= '9') || (*c >= 'a' && *c <= 'z') || (*c >= 'A' && *c <= 'Z') || *c == '.' || *c == '_' || *c == '-')) *c = '_';
  office_mkdirs(bg_mine_dir());
  snprintf(dst, sizeof dst, "%s/%s", bg_mine_dir(), name);
  for (int n = 2; !access(dst, F_OK) && n < 1000; n++) snprintf(dst, sizeof dst, "%s/%d_%s", bg_mine_dir(), n, name);
  FILE *in = fopen(src, "rb"), *out = fopen(dst, "wb");
  int ok = in && out;
  char buf[65536];
  size_t n;
  while (ok && (n = fread(buf, 1, sizeof buf, in)) > 0) ok = fwrite(buf, 1, n, out) == n;
  if (in) fclose(in);
  if (out) fclose(out);
  if (!ok) {
    unlink(dst);
    free(px);
    office_toast("Could not save the wallpaper");
    return;
  }
  bg_write_thumb(dst, px, w, h);
  free(px);
  bg_scan();
  bg_view = BGV_MINE, bg_edit = 0, bg_page = 0;
  for (int i = 0, k = 0; i < nbg; i++) {
    if (bgs[i].view != BGV_MINE) continue;
    if (!strcmp(bgs[i].path, dst)) {
      bg_page = k / bg_rows();
      bg_apply(i, 1);
      break;
    }
    k++;
  }
  for (int i = 0; i < MAXP; i++)
    if (P[i].used) P[i].dirty = 1;
}

static void bg_remove(int i) {
  char tp[640];
  int was_cur = !strcmp(bg_key(&bgs[i]), bg_cur);
  snprintf(tp, sizeof tp, "%s.thumb", bgs[i].path);
  unlink(bgs[i].path);
  unlink(tp);
  bg_scan();
  if (was_cur && nbg && bgs[0].view == BGV_WALL) bg_apply(0, 1);
  int last = (bg_count(bg_view) - 1) / bg_rows();
  if (bg_page > last) bg_page = last < 0 ? 0 : last;
}

static void cc_load_slot(void) { rgb_hsv(cc_col[cc_slot], &cc_h, &cc_s, &cc_v); }

static void cc_update(void) {
  cc_col[cc_slot] = hsv_rgb(cc_h, cc_s, cc_v);
  bg_custom_apply(1);
}

#define SV_X 0
#define SV_Y 100
#define SV_W 152
#define SV_H 120
#define HUE_Y 228
#define HUE_H 18
#define ED_X 172

static void bg_draw(Panel *p, Surface *s, float ox, float oy, int hot, float cx) {
  static const char *const views[] = {"Wallpapers", "Colors", "Yours"};
  static const float vx[] = {0, 118, 206}, vw[] = {110, 80, 70};
  for (int i = 0; i < 3; i++) {
    float x = cx + vx[i], y = oy + 60;
    if (i == bg_view) gfx_rrect(s, x, y, vw[i], 28, 14, THEME(RGB(222, 233, 255), RGB(48, 66, 104)));
    else if (hot == 40 + i) gfx_rrect(s, x, y, vw[i], 28, 14, C_HOVER);
    gfx_text_c(s, F_UI_MED, x + vw[i] * 0.5f, y + (28 - line_h(F_UI_MED)) * 0.5f, views[i], i == bg_view ? C_ACCENT : C_TEXT);
  }
  float rw = BG_PANE_W;
  if (bg_view == BGV_COLOR && bg_edit) {
    for (int sy = 0; sy < SV_H / 4; sy++)
      for (int sx = 0; sx < SV_W / 4; sx++)
        gfx_rect(s, cx + SV_X + sx * 4, oy + SV_Y + sy * 4, 4, 4, hsv_rgb(cc_h, (float)sx / (SV_W / 4 - 1), 1.f - (float)sy / (SV_H / 4 - 1)));
    for (int i = 0; i < SV_W / 2; i++) gfx_rect(s, cx + i * 2, oy + HUE_Y, 2, HUE_H, hsv_rgb((float)i / (SV_W / 2) * 360.f, 1, 1));
    float mx = cx + cc_s * (SV_W - 1), my = oy + SV_Y + (1 - cc_v) * (SV_H - 1);
    gfx_ring(s, mx, my, 6, 2, RGB(255, 255, 255));
    gfx_ring(s, mx, my, 8, 1, RGB(30, 33, 39));
    gfx_rrect(s, cx + cc_h / 360.f * (SV_W - 4), oy + HUE_Y - 3, 4, HUE_H + 6, 2, RGB(255, 255, 255));
    float ex = cx + ED_X;
    swatch(s, ex, oy + 100, 200, 44, 10, cc_col[0], cc_grad ? cc_col[1] : cc_col[0]);
    button(s, ex, oy + 152, 96, 30, "Solid", hot == 82, !cc_grad);
    button(s, ex + 104, oy + 152, 96, 30, "Gradient", hot == 83, cc_grad);
    if (cc_grad) {
      static const char *const slots[] = {"Top", "Bottom"};
      for (int i = 0; i < 2; i++) {
        float x = ex + i * 104, y = oy + 192;
        button(s, x, y, 96, 30, slots[i], hot == 84 + i, cc_slot == i);
        gfx_disc(s, x + 14, y + 15, 7, cc_col[i]);
        gfx_ring(s, x + 14, y + 15, 7, 1, RGB(255, 255, 255));
      }
    }
    button(s, ex, oy + 240, 96, 32, "Done", hot == 86, 0);
    return;
  }
  if (bg_view == BGV_COLOR) {
    for (int k = 0; k <= NPRESETS; k++) {
      float x = cx + (k % 6) * 66, y = oy + 100 + (k / 6) * 66;
      int i = k < NPRESETS ? bg_nth(BGV_COLOR, k) : -1;
      int sel = k == NPRESETS ? bg_cur_custom() : i >= 0 && !strcmp(bg_key(&bgs[i]), bg_cur);
      if (sel) gfx_rrect(s, x - 3, y - 3, 64, 46, 11, C_ACCENT);
      else if (hot == 60 + k) gfx_rrect(s, x - 3, y - 3, 64, 46, 11, C_WIN_EDGE);
      if (k == NPRESETS) {
        for (int j = 0; j < 8; j++) gfx_rrect_band(s, x, y, 58, 40, 8, y + j * 5, y + j * 5 + 5.5f, hsv_rgb((float)j * 45.f, 0.55f, 0.95f));
      } else if (i >= 0) {
        swatch(s, x, y, 58, 40, 8, bgs[i].c1, bgs[i].kind == BGK_GRAD ? bgs[i].c2 : bgs[i].c1);
      }
      gfx_text_c(s, F_SMALL, x + 29, y + 46, k == NPRESETS ? "Custom" : bgs[i >= 0 ? i : 0].name, C_TEXT);
    }
    return;
  }
  int rows = bg_rows(), total = bg_count(bg_view);
  if (bg_view == BGV_MINE) {
    button(s, cx, oy + 100, 130, 34, "Add image...", hot == 32, 1);
    gfx_text(s, F_SMALL, cx + 142, oy + 100 + (34 - line_h(F_SMALL)) * 0.5f, "JPG or PNG from your files", C_MUTED);
    if (!total) gfx_text(s, F_UI, cx, oy + bg_row_y() + 12, "Your own wallpapers will show up here.", C_MUTED);
  }
  for (int r = 0; r < rows; r++) {
    int i = bg_nth(bg_view, bg_page * rows + r);
    if (i < 0) break;
    const Bg *b = &bgs[i];
    float y = oy + bg_row_y() + r * 42;
    int sel = !strcmp(bg_key(b), bg_cur);
    if (sel) gfx_rrect(s, cx - 10, y, rw + 20, 38, 10, THEME(RGB(222, 233, 255), RGB(48, 66, 104)));
    else if (hot == 20 + r) gfx_rrect(s, cx - 10, y, rw + 20, 38, 10, C_HOVER);
    if (b->thumb) gfx_blit_bilinear(s, b->thumb, BG_TW, BG_TH, cx, y + 5, 48, 28, 0);
    else swatch(s, cx, y + 5, 48, 28, 6, RGB(150, 190, 215), RGB(86, 118, 92));
    gfx_text(s, F_UI_MED, cx + 62, y + (38 - line_h(F_UI_MED)) * 0.5f, b->name, sel ? C_ACCENT : C_TEXT);
    if (bg_view == BGV_MINE) {
      if (hot == 50 + r) gfx_rrect(s, cx + rw - 70, y + 6, 70, 26, 13, C_WIN_EDGE);
      gfx_text_c(s, F_SMALL, cx + rw - 35, y + (38 - line_h(F_SMALL)) * 0.5f, "Remove", C_MUTED);
    }
  }
  if (total > rows) {
    char pg[24];
    snprintf(pg, sizeof pg, "%d / %d", bg_page + 1, (total + rows - 1) / rows);
    button(s, cx, oy + bg_pager_y(), 80, 30, "Back", hot == 30, 0);
    button(s, cx + 92, oy + bg_pager_y(), 80, 30, "Next", hot == 31, 0);
    gfx_text(s, F_UI, cx + 188, oy + bg_pager_y() + 5, pg, C_MUTED);
  }
  (void)p;
}

static int bg_zone(Panel *p, float x, float y, float cx) {
  static const float vx[] = {0, 118, 206}, vw[] = {110, 80, 70};
  for (int i = 0; i < 3; i++)
    if (in_rect(x, y, cx + vx[i], 60, vw[i], 28)) return 40 + i;
  if (bg_view == BGV_COLOR && bg_edit) {
    if (in_rect(x, y, cx + SV_X, SV_Y, SV_W, SV_H)) return 80;
    if (in_rect(x, y, cx, HUE_Y - 3, SV_W, HUE_H + 6)) return 81;
    float ex = cx + ED_X;
    if (in_rect(x, y, ex, 152, 96, 30)) return 82;
    if (in_rect(x, y, ex + 104, 152, 96, 30)) return 83;
    if (cc_grad && in_rect(x, y, ex, 192, 96, 30)) return 84;
    if (cc_grad && in_rect(x, y, ex + 104, 192, 96, 30)) return 85;
    if (in_rect(x, y, ex, 240, 96, 32)) return 86;
    return 0;
  }
  if (bg_view == BGV_COLOR) {
    for (int k = 0; k <= NPRESETS; k++)
      if (in_rect(x, y, cx + (k % 6) * 66, 100 + (k / 6) * 66, 58, 58)) return 60 + k;
    return 0;
  }
  int rows = bg_rows(), total = bg_count(bg_view);
  if (bg_view == BGV_MINE && in_rect(x, y, cx, 100, 130, 34)) return 32;
  for (int r = 0; r < rows; r++) {
    if (bg_page * rows + r >= total) break;
    float ry = (float)bg_row_y() + r * 42;
    if (bg_view == BGV_MINE && in_rect(x, y, cx + BG_PANE_W - 70, ry + 6, 70, 26)) return 50 + r;
    if (in_rect(x, y, cx - 10, ry, BG_PANE_W + 20, 38)) return 20 + r;
  }
  if (total > rows) {
    if (in_rect(x, y, cx, bg_pager_y(), 80, 30)) return 30;
    if (in_rect(x, y, cx + 92, bg_pager_y(), 80, 30)) return 31;
  }
  (void)p;
  return 0;
}

static float clamp01(float v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

static void bg_click(float x, float y, int z) {
  float cx = S_SIDE + 30;
  int rows = bg_rows();
  if (z >= 40 && z < 43) bg_view = z - 40, bg_page = 0, bg_edit = 0;
  else if (z >= 20 && z < 24) {
    int i = bg_nth(bg_view, bg_page * rows + z - 20);
    if (i >= 0) bg_apply(i, 1);
  } else if (z == 30 && bg_page > 0) bg_page--;
  else if (z == 31 && (bg_page + 1) * rows < bg_count(bg_view)) bg_page++;
  else if (z == 32) files_pick_wallpaper();
  else if (z >= 50 && z < 53) {
    int i = bg_nth(bg_view, bg_page * rows + z - 50);
    if (i >= 0) bg_remove(i);
  } else if (z >= 60 && z <= 60 + NPRESETS) {
    if (z == 60 + NPRESETS) {
      bg_edit = 1;
      if (!cc_grad) cc_slot = 0;
      cc_load_slot();
      bg_custom_apply(1);
    } else {
      int i = bg_nth(BGV_COLOR, z - 60);
      if (i >= 0) bg_apply(i, 1);
    }
  } else if (z == 80) {
    cc_s = clamp01((x - cx - SV_X) / (SV_W - 1)), cc_v = 1.f - clamp01((y - SV_Y) / (SV_H - 1));
    cc_update();
  } else if (z == 81) {
    cc_h = clamp01((x - cx) / (SV_W - 1)) * 359.f;
    cc_update();
  } else if (z == 82 || z == 83) {
    cc_grad = z == 83;
    if (!cc_grad) cc_slot = 0;
    cc_load_slot();
    bg_custom_apply(1);
  } else if (z == 84 || z == 85) {
    cc_slot = z - 84;
    cc_load_slot();
  } else if (z == 86) bg_edit = 0;
}

static void settings_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = hot_of(p);
  float h = (float)(p->lh - BAR_H);
  gfx_rect(s, ox, oy, S_SIDE, h, THEME(RGB(238, 240, 244), RGB(26, 29, 34)));
  gfx_rect(s, ox + S_SIDE, oy, 1, h, C_BAR_LINE);
  for (int i = 0; i < NTABS; i++) {
    float y = oy + S_TAB_Y + i * (S_TAB_H + 8);
    if (i == set_tab) gfx_rrect(s, ox + 10, y, S_SIDE - 20, S_TAB_H, 8, THEME(RGB(222, 233, 255), RGB(48, 66, 104)));
    else if (hot == 1 + i) gfx_rrect(s, ox + 10, y, S_SIDE - 20, S_TAB_H, 8, C_HOVER);
    gfx_text(s, F_UI_MED, ox + 26, y + (S_TAB_H - line_h(F_UI_MED)) * 0.5f, set_tabs[i], i == set_tab ? C_ACCENT : C_TEXT);
  }
  float cx = ox + S_SIDE + 30;
  gfx_text(s, F_H1, cx, oy + 22, set_tabs[set_tab], C_TEXT);
  if (set_tab == T_THEME) {
    gfx_text(s, F_UI_MED, cx, oy + 78, "Appearance", C_MUTED);
    for (int d = 0; d < 2; d++) {
      float x = cx + d * (S_CARD_W + 24), y = oy + S_CARD_Y;
      int sel = g_dark == d;
      if (sel) gfx_rrect(s, x - 3, y - 3, S_CARD_W + 6, S_CARD_H + 6, 13, C_ACCENT);
      else if (hot == 7 + d) gfx_rrect(s, x - 3, y - 3, S_CARD_W + 6, S_CARD_H + 6, 13, C_WIN_EDGE);
      gfx_rrect(s, x, y, S_CARD_W, S_CARD_H, 10, d ? RGB(30, 33, 39) : RGB(247, 248, 250));
      gfx_rrect_band(s, x, y, S_CARD_W, S_CARD_H, 10, y, y + 22, d ? RGB(38, 42, 49) : RGB(255, 255, 255));
      gfx_rrect(s, x + 14, y + 38, 90, 8, 4, d ? RGB(232, 235, 240) : RGB(42, 47, 54));
      gfx_rrect(s, x + 14, y + 54, 60, 8, 4, d ? RGB(150, 157, 168) : RGB(108, 115, 125));
      gfx_rrect(s, x + 14, y + 74, 48, 16, 8, C_ACCENT);
      gfx_text_c(s, F_UI_MED, x + S_CARD_W * 0.5f, y + S_CARD_H + 14, d ? "Dark" : "Light", C_TEXT);
    }
  } else if (set_tab == T_TRAY) {
    gfx_text(s, F_UI, cx, oy + 64, "Choose what shows at the right end of the dock.", C_MUTED);
    float rw = (float)p->lw - S_SIDE - 56;
    for (int i = 0; i < 4; i++) {
      float y = oy + S_ROW_Y + i * S_ROW_H;
      if (hot == 10 + i) gfx_rrect(s, cx - 10, y, rw + 20, S_ROW_H - 4, 10, C_HOVER);
      int present = tray_present(i);
      gfx_text(s, F_UI_MED, cx, y + (present ? 10.f : 4.f), tray_names[i], C_TEXT);
      if (!present) gfx_text(s, F_SMALL, cx, y + 22, "not detected on this device", C_MUTED);
      toggle(s, cx + rw - 44, y + 8, *tray_flag(i));
    }
  } else if (set_tab == T_BG) {
    bg_draw(p, s, ox, oy, hot, cx);
  } else {
    button(s, cx, oy + S_PWR_Y, 150, 38, "Shut Down", hot == 6, 1);
  }
}

static int settings_zone(Panel *p, float x, float y) {
  for (int i = 0; i < NTABS; i++)
    if (in_rect(x, y, 10, S_TAB_Y + i * (S_TAB_H + 8), S_SIDE - 20, S_TAB_H)) return 1 + i;
  float cx = S_SIDE + 30;
  if (set_tab == T_THEME) {
    for (int d = 0; d < 2; d++)
      if (in_rect(x, y, cx + d * (S_CARD_W + 24), S_CARD_Y, S_CARD_W, S_CARD_H + 24)) return 7 + d;
  } else if (set_tab == T_TRAY) {
    for (int i = 0; i < 4; i++)
      if (in_rect(x, y, cx - 10, S_ROW_Y + i * S_ROW_H, p->lw - S_SIDE - 36, S_ROW_H - 4)) return 10 + i;
  } else if (set_tab == T_BG) {
    return bg_zone(p, x, y, cx);
  } else if (in_rect(x, y, cx, S_PWR_Y, 150, 38)) {
    return 6;
  }
  return 0;
}

static void settings_click(Panel *p, float x, float y) {
  int z = settings_zone(p, x, y);
  if (z >= 1 && z <= NTABS) set_tab = z - 1;
  else if (z == 7 || z == 8) set_theme(z - 7);
  else if (z >= 10 && z < 14) {
    int *f = tray_flag(z - 10);
    *f = !*f;
    dock_rebuild();
  } else if (z >= 20 && z < 100) bg_click(x, y, z);
  else if (z == 6) shell_power("poweroff");
  p->dirty = 1;
}

static void settings_open(Panel *p) {
  (void)p;
  set_tab = 0;
  bg_page = 0;
  bg_edit = 0;
  bg_scan();
}


static App settings = {"settings", "Settings", IC_SETTINGS, 620, 380, settings_open, settings_draw, settings_click, NULL, NULL,
                       settings_zone, NULL, NULL};

#define POWER_W 380
#define POWER_H (BAR_H + 130)

static void power_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = hot_of(p);
  gfx_text(s, F_BODY, ox + 28, oy + 24, "Shut down the device?", C_TEXT);
  gfx_text(s, F_UI, ox + 28, oy + 52, "Unsaved work in open apps will be lost.", C_MUTED);
  button(s, ox + 28, oy + 82, 130, 36, "Shut Down", hot == 1, 1);
  button(s, ox + 170, oy + 82, 80, 36, "Lock", hot == 3, 0);
  button(s, ox + 262, oy + 82, 90, 36, "Cancel", hot == 2, 0);
}

static int power_zone(Panel *p, float x, float y) {
  (void)p;
  if (in_rect(x, y, 28, 82, 130, 36)) return 1;
  if (in_rect(x, y, 170, 82, 80, 36)) return 3;
  if (in_rect(x, y, 262, 82, 90, 36)) return 2;
  return 0;
}

static void power_click(Panel *p, float x, float y) {
  int z = power_zone(p, x, y);
  if (z == 1) shell_power("poweroff");
  else if (z == 2) panel_close((int)(p - P));
  else if (z == 3) {
    panel_close((int)(p - P));
    lock_start();
  }
}

static void power_key(Panel *p, int code, int mods) {
  (void)mods;
  if (code == KEY_ESC) panel_close((int)(p - P));
  else if (code == KEY_ENTER) shell_power("poweroff");
}

static App power = {"power", "Shut down", IC_SETTINGS, POWER_W, POWER_H, NULL, power_draw, power_click, NULL, power_key,
                    power_zone, NULL, NULL};

App *APPS[] = {&launcher, &desktop_app, &terminal, &files, &welcome, &settings, &power, &tasks_app, &keyboard_app, &notes_app, &store_app, &surf_app, &install_app};
int NAPPS = sizeof APPS / sizeof *APPS;

App *app_by_id(const char *id) {
  for (int i = 0; i < NAPPS; i++)
    if (!strcmp(APPS[i]->id, id)) return APPS[i];
  return NULL;
}

int panel_zone(Panel *p, float x, float y) {
  int z = chrome_zone(p, x, y);
  if (z) return z;
  if (p->kind == PK_WINDOW && y < BARH(p)) return 0;
  if (p->app && p->app->zone) {
    float by = p->kind == PK_WINDOW ? y - BARH(p) : y;
    int a = p->app->zone(p, x, by);
    return a ? 100 + a : 0;
  }
  return 0;
}

void shell_power(const char *what) {
  if (g_dev) return;
  sync();
  pid_t pid = fork();
  if (pid == 0) {
    execlp("systemctl", "systemctl", what, (char *)NULL);
    _exit(127);
  }
  int st = 0;
  if (pid > 0) waitpid(pid, &st, 0);
  if (pid < 0 || !WIFEXITED(st) || WEXITSTATUS(st)) reboot(!strcmp(what, "reboot") ? RB_AUTOBOOT : RB_POWER_OFF);
}
