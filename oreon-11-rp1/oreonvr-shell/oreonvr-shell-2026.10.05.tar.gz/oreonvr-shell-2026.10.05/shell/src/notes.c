#include <ctype.h>
#include <dirent.h>
#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "office.h"

#define NW 1080
#define NH 720
#define HEAD_H 56
#define TOOL_Y 68
#define TOOL_H 44
#define BODY_Y 56
#define HOME_HEAD 64
#define HERO_H 112
#define TPL_W 124
#define TPL_H 160
#define TPL_GAP 18
#define CARD_W 176
#define CARD_GAP 24
#define CARD_TH 200
#define CARD_STEP 278
#define NTPL 7
#define MAXPV 18
#define PAGE_W 640
#define PAGE_PAD 68
#define TEXT_W (PAGE_W - 2 * PAGE_PAD)
#define PAGE_TOP 84
#define MAXDOCS 256
#define MAXUNDO 80

enum { F_BOLD = 1, F_ITAL = 2, F_UNDER = 4, F_STRIKE = 8 };
enum { ST_NORMAL, ST_H2, ST_H1, ST_TITLE };
enum { L_NONE, L_BULLET, L_NUMBER, L_CHECK };
enum { A_LEFT, A_CENTER, A_RIGHT };

enum {
  T_UNDO = 1, T_REDO, T_STYLE, T_BOLD, T_ITAL, T_UNDER, T_STRIKE, T_COLOR, T_ALEFT, T_ACENTER, T_ARIGHT, T_CHECK,
  T_BULLET, T_NUMBER, T_OUTDENT, T_INDENT, T_CLEAR, T_FIND, T_COUNT
};

enum {
  Z_MENU = 40, Z_TITLE = 50, Z_PAGE = 52, Z_EMB_OPEN = 58, Z_FIND_FIELD = 53, Z_FIND_PREV, Z_FIND_NEXT, Z_FIND_CLOSE,
  Z_POPUP = 100, Z_POPUP_END = 300, Z_HOME = 1000, Z_TPL = 1100, Z_CARD = 1200, Z_CARD_DEL = 1500, Z_SEG = 1900, SEG_W = 112, Z_IMPORT = 1950, Z_NEWBLANK = 1951
};

enum {
  CM_NONE, CM_NEWDOC, CM_COPYDOC, CM_RENAME, CM_DELETE, CM_EXPORT_MD, CM_EXPORT_TXT, CM_EXPORT_DOCX, CM_EXPORT_RTF, CM_UNDO, CM_REDO, CM_CUT, CM_COPY, CM_PASTE,
  CM_SELALL, CM_FIND, CM_INS_CHECK, CM_INS_HR, CM_INS_DATE, CM_BOLD, CM_ITAL, CM_UNDER, CM_STRIKE, CM_TITLE, CM_H1, CM_H2,
  CM_NORMAL, CM_ALEFT, CM_ACENTER, CM_ARIGHT, CM_CLEAR, CM_BULLET, CM_NUMBER, CM_EMB_DOC, CM_EMB_SHEET, CM_EMB_SLIDE
};

typedef struct {
  char *t;
  unsigned char *f;
  int n, cap;
  unsigned char style, list, check, indent, align, hr;
  char ref[48];
} Para;

typedef struct {
  int para, off;
} Pos;

typedef struct {
  int para, start, end;
  float x, y, h, top;
} Line;

typedef struct {
  unsigned char style, list, check, hr;
  short len;
} Pv;

typedef struct {
  char id[40];
  char title[96];
  long mtime;
  Pv pv[MAXPV];
  int npv;
} DocInfo;

typedef struct {
  const char *label, *key;
  int cmd;
} Item;

const uint32_t OFF_COLORS[8] = {0, RGB(32, 33, 36), RGB(95, 99, 104), RGB(217, 48, 37), RGB(232, 113, 10),
                                   RGB(24, 128, 56), RGB(26, 115, 232), RGB(147, 52, 230)};
static const char *STYLE_NAMES[4] = {"Normal text", "Heading 2", "Heading 1", "Title"};

static const Item MENU_FILE[] = {{"New document", "Ctrl+N", CM_NEWDOC}, {"Make a copy", "", CM_COPYDOC},
                                 {"Rename", "", CM_RENAME}, {NULL, NULL, 0},
                                 {"Download as Markdown (.md)", "", CM_EXPORT_MD},
                                 {"Download as plain text (.txt)", "", CM_EXPORT_TXT},
                                 {"Download as Word (.docx)", "", CM_EXPORT_DOCX},
                                 {"Download as Rich Text (.rtf)", "", CM_EXPORT_RTF}, {NULL, NULL, 0},
                                 {"Move to trash", "", CM_DELETE}};
static const Item MENU_EDIT[] = {{"Undo", "Ctrl+Z", CM_UNDO}, {"Redo", "Ctrl+Y", CM_REDO}, {NULL, NULL, 0},
                                 {"Cut", "Ctrl+X", CM_CUT}, {"Copy", "Ctrl+C", CM_COPY}, {"Paste", "Ctrl+V", CM_PASTE},
                                 {NULL, NULL, 0}, {"Select all", "Ctrl+A", CM_SELALL},
                                 {"Find", "Ctrl+F", CM_FIND}};
static const Item MENU_INSERT[] = {{"Checklist", "Ctrl+Shift+9", CM_INS_CHECK}, {"Bulleted list", "Ctrl+Shift+8", CM_BULLET},
                                   {"Numbered list", "Ctrl+Shift+7", CM_NUMBER}, {NULL, NULL, 0},
                                   {"Horizontal line", "", CM_INS_HR}, {"Today's date", "", CM_INS_DATE},
                                   {NULL, NULL, 0}, {"Document...", "", CM_EMB_DOC},
                                   {"Spreadsheet...", "", CM_EMB_SHEET}, {"Slide...", "", CM_EMB_SLIDE}};
static const Item MENU_FORMAT[] = {{"Bold", "Ctrl+B", CM_BOLD}, {"Italic", "Ctrl+I", CM_ITAL},
                                   {"Underline", "Ctrl+U", CM_UNDER}, {"Strikethrough", "Alt+Shift+5", CM_STRIKE},
                                   {NULL, NULL, 0}, {"Title", "", CM_TITLE}, {"Heading 1", "Ctrl+Alt+1", CM_H1},
                                   {"Heading 2", "Ctrl+Alt+2", CM_H2}, {"Normal text", "Ctrl+Alt+0", CM_NORMAL},
                                   {NULL, NULL, 0}, {"Align left", "Ctrl+Shift+L", CM_ALEFT},
                                   {"Center", "Ctrl+Shift+E", CM_ACENTER}, {"Align right", "Ctrl+Shift+R", CM_ARIGHT},
                                   {NULL, NULL, 0}, {"Clear formatting", "Ctrl+\\", CM_CLEAR}};
static const char *MENU_NAMES[4] = {"File", "Edit", "Insert", "Format"};
static const Item *MENUS[4] = {MENU_FILE, MENU_EDIT, MENU_INSERT, MENU_FORMAT};
static const int MENU_LEN[4] = {10, 9, 10, 15};

enum { POP_NONE, POP_MENU0, POP_MENU1, POP_MENU2, POP_MENU3, POP_STYLE, POP_COLOR };

static struct {
  Para *p;
  int np, pcap;
  char id[40], title[96];
  Pos cur, anc;
  int fmt;
  float want_x;
  int dirty, loaded;
  uint32_t dirty_at;
  float scroll;
  int title_edit;
  char title_buf[96];
  int find_on, find_focus;
  char find[64];
  int popup;
  char *undo[MAXUNDO], *redo[MAXUNDO];
  int nundo, nredo, last_kind;
  uint32_t last_edit;
  DocInfo docs[MAXDOCS];
  int ndocs, confirm_del;
  int home, mode;
  float home_scroll;
  int blink;
  uint32_t blink_t;
  int press_zone, dragging;
  uint32_t last_click;
  int clicks;
  Pos click_pos;
  char toast[96];
  uint32_t toast_t;
  char *clip;
  int panel;
  int eb_on;
  float eb_x, eb_y, eb_w, eb_h;
} N;

static void export_docx(void);
static void export_rtf(void);

static Line *lines;
static int nlines, lcap, layout_ok;
static float doc_h;


static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static int keyboard_open(void) {
  for (int i = 0; i < MAXP; i++)
    if (P[i].used && P[i].app == &keyboard_app) return 1;
  return 0;
}

static void show_keyboard(void) {
  if (!keyboard_open()) panel_open_app("keyboard");
}

static void toast(const char *m) {
  snprintf(N.toast, sizeof N.toast, "%.95s", m);
  N.toast_t = now_ms();
}

static void para_reserve(Para *p, int n) {
  if (n <= p->cap) return;
  int c = p->cap ? p->cap : 16;
  while (c < n) c *= 2;
  p->t = realloc(p->t, (size_t)c + 1);
  p->f = realloc(p->f, (size_t)c + 1);
  p->cap = c;
}

static void para_free(Para *p) {
  free(p->t);
  free(p->f);
  memset(p, 0, sizeof *p);
}

static Para *para_insert(int at) {
  if (N.np + 1 > N.pcap) {
    N.pcap = N.pcap ? N.pcap * 2 : 32;
    N.p = realloc(N.p, sizeof(Para) * (size_t)N.pcap);
  }
  memmove(&N.p[at + 1], &N.p[at], sizeof(Para) * (size_t)(N.np - at));
  N.np++;
  memset(&N.p[at], 0, sizeof(Para));
  para_reserve(&N.p[at], 8);
  N.p[at].t[0] = 0;
  return &N.p[at];
}

static void para_remove(int at) {
  para_free(&N.p[at]);
  memmove(&N.p[at], &N.p[at + 1], sizeof(Para) * (size_t)(N.np - at - 1));
  N.np--;
}

static void doc_clear(void) {
  for (int i = 0; i < N.np; i++) para_free(&N.p[i]);
  N.np = 0;
}

static void para_put(Para *p, int at, const char *s, const unsigned char *f, int n) {
  para_reserve(p, p->n + n);
  memmove(p->t + at + n, p->t + at, (size_t)(p->n - at));
  memmove(p->f + at + n, p->f + at, (size_t)(p->n - at));
  memcpy(p->t + at, s, (size_t)n);
  memcpy(p->f + at, f, (size_t)n);
  p->n += n;
  p->t[p->n] = 0;
}

static void para_cut(Para *p, int a, int b) {
  memmove(p->t + a, p->t + b, (size_t)(p->n - b));
  memmove(p->f + a, p->f + b, (size_t)(p->n - b));
  p->n -= b - a;
  p->t[p->n] = 0;
}

static int pos_cmp(Pos a, Pos b) { return a.para != b.para ? a.para - b.para : a.off - b.off; }

static int has_sel(void) { return pos_cmp(N.cur, N.anc) != 0; }

static void sel_range(Pos *a, Pos *b) {
  if (pos_cmp(N.cur, N.anc) <= 0) *a = N.cur, *b = N.anc;
  else *a = N.anc, *b = N.cur;
}

static const char *hexd = "0123456789abcdef";

static char *serialize(int with_cursor) {
  size_t cap = 256;
  for (int i = 0; i < N.np; i++) cap += (size_t)N.p[i].n * 3 + 64;
  char *s = malloc(cap + strlen(N.title) + 64);
  size_t k = (size_t)sprintf(s, "ODOC1\ntitle\t%s\n", N.title);
  if (with_cursor) k += (size_t)sprintf(s + k, "cursor\t%d\t%d\t%d\t%d\n", N.cur.para, N.cur.off, N.anc.para, N.anc.off);
  for (int i = 0; i < N.np; i++) {
    Para *p = &N.p[i];
    k += (size_t)sprintf(s + k, "p\t%d\t%d\t%d\t%d\t%d\t%d\t", p->style, p->list, p->check, p->indent, p->align, p->hr);
    for (int j = 0; j < p->n; j++) s[k++] = hexd[p->f[j] >> 4], s[k++] = hexd[p->f[j] & 15];
    s[k++] = '\t';
    if (p->hr == 2) {
      size_t rl = strlen(p->ref);
      memcpy(s + k, p->ref, rl);
      k += rl;
    } else {
      memcpy(s + k, p->t, (size_t)p->n);
      k += (size_t)p->n;
    }
    s[k++] = '\n';
  }
  s[k] = 0;
  return s;
}

static int parse_head(const char *s, const char *end, int v[6], const char **rest) {
  if (end - s < 2 || s[0] != 'p' || s[1] != '\t') return 0;
  const char *q = s + 2;
  for (int i = 0; i < 6; i++) {
    char *e;
    long x = strtol(q, &e, 10);
    if (e == q || e >= end || *e != '\t') return 0;
    v[i] = (int)x;
    q = e + 1;
  }
  *rest = q;
  return 1;
}

static int hexv(char c) { return c >= 'a' ? c - 'a' + 10 : c - '0'; }

static Para *para_push(Para **a, int *n, int *cap) {
  if (*n + 1 > *cap) {
    *cap = *cap ? *cap * 2 : 32;
    *a = realloc(*a, sizeof(Para) * (size_t)*cap);
  }
  Para *p = &(*a)[(*n)++];
  memset(p, 0, sizeof *p);
  para_reserve(p, 8);
  p->t[0] = 0;
  return p;
}

static void parse_doc(const char *src, Para **a, int *np, int *cap, char *title, int tn, Pos *cur, Pos *anc) {
  const char *s = src;
  while (*s) {
    const char *e = strchr(s, '\n');
    int len = e ? (int)(e - s) : (int)strlen(s);
    if (!strncmp(s, "title\t", 6)) {
      int n = len - 6;
      if (n > tn - 1) n = tn - 1;
      memcpy(title, s + 6, (size_t)n);
      title[n] = 0;
    } else if (!strncmp(s, "cursor\t", 7)) {
      if (cur) sscanf(s + 7, "%d\t%d\t%d\t%d", &cur->para, &cur->off, &anc->para, &anc->off);
    } else if (!strncmp(s, "p\t", 2)) {
      int v[6];
      const char *fx;
      if (parse_head(s, s + len, v, &fx)) {
        int st = v[0], li = v[1], ch = v[2], in = v[3], al = v[4], hr = v[5];
        const char *tab = memchr(fx, '\t', (size_t)(s + len - fx));
        if (tab) {
          int n = (int)((s + len) - (tab + 1));
          int nf = (int)(tab - fx) / 2;
          Para *p = para_push(a, np, cap);
          p->style = (unsigned char)(st & 3), p->list = (unsigned char)(li & 3), p->check = (unsigned char)(ch & 1);
          p->indent = (unsigned char)(in > 6 ? 6 : in < 0 ? 0 : in), p->align = (unsigned char)(al % 3);
          p->hr = (unsigned char)(hr == 2 ? 2 : hr & 1);
          if (p->hr == 2) {
            snprintf(p->ref, sizeof p->ref, "%.*s", n, tab + 1);
            n = 0;
          }
          if (nf < n) n = nf;
          para_reserve(p, n);
          for (int j = 0; j < n; j++) {
            char c = tab[1 + j];
            p->t[j] = (c >= 32 && c < 127) ? c : '?';
            p->f[j] = (unsigned char)(hexv(fx[j * 2]) << 4 | hexv(fx[j * 2 + 1]));
          }
          p->n = n;
          p->t[n] = 0;
        }
      }
    }
    s += len + (e ? 1 : 0);
  }
}

static void deserialize(const char *src, int with_cursor) {
  doc_clear();
  N.title[0] = 0;
  Pos cur = {0, 0}, anc = {0, 0};
  parse_doc(src, &N.p, &N.np, &N.pcap, N.title, sizeof N.title, &cur, &anc);
  if (!N.np) para_insert(0);
  if (!N.title[0]) snprintf(N.title, sizeof N.title, "Untitled document");
  if (with_cursor) {
    N.cur = cur, N.anc = anc;
  }
  if (N.cur.para >= N.np) N.cur.para = N.np - 1;
  if (N.anc.para >= N.np) N.anc.para = N.np - 1;
  if (N.cur.para < 0) N.cur.para = 0;
  if (N.anc.para < 0) N.anc.para = 0;
  if (N.cur.off > N.p[N.cur.para].n) N.cur.off = N.p[N.cur.para].n;
  if (N.anc.off > N.p[N.anc.para].n) N.anc.off = N.p[N.anc.para].n;
  if (N.cur.off < 0) N.cur.off = 0;
  if (N.anc.off < 0) N.anc.off = 0;
  layout_ok = 0;
}

void office_dirs(char *out, size_t n, const char *sub, const char *env) {
  const char *e = getenv(env);
  if (e && *e) snprintf(out, n, "%s", e);
  else snprintf(out, n, "%s/Documents/Office/%s", user_home(), sub);
}

static const char *notes_dir(void) {
  static char d[512];
  office_dirs(d, sizeof d, "Docs", "OREONVR_DOCS_DIR");
  return d;
}

static void mkdirs(const char *path) {
  char tmp[512];
  snprintf(tmp, sizeof tmp, "%s", path);
  /* the shell runs as root: directories it makes inside the desktop user's home belong to that user */
  const char *home = user_home();
  struct stat hs;
  int own = geteuid() == 0 && !strncmp(path, home, strlen(home)) && !stat(home, &hs) && hs.st_uid != 0;
  for (char *q = tmp + 1;; q++) {
    if (*q == '/' || !*q) {
      char c = *q;
      *q = 0;
      if (!mkdir(tmp, 0755) && own && strlen(tmp) > strlen(home) && chown(tmp, hs.st_uid, hs.st_gid)) {}
      *q = c;
      if (!c) break;
    }
  }
}

static void doc_path(const char *id, char *out, size_t n) { snprintf(out, n, "%s/%s.odoc", notes_dir(), id); }

static char *read_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  fseek(f, 0, SEEK_END);
  long n = ftell(f);
  fseek(f, 0, SEEK_SET);
  char *b = malloc((size_t)n + 1);
  if (fread(b, 1, (size_t)n, f) != (size_t)n) n = 0;
  b[n] = 0;
  fclose(f);
  return b;
}

static int doc_cmp(const void *a, const void *b) {
  long x = ((const DocInfo *)a)->mtime, y = ((const DocInfo *)b)->mtime;
  return x < y ? 1 : x > y ? -1 : 0;
}

static void scan_docs(void) {
  N.ndocs = 0;
  DIR *d = opendir(notes_dir());
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d)) && N.ndocs < MAXDOCS) {
    size_t l = strlen(e->d_name);
    if (l < 6 || strcmp(e->d_name + l - 5, ".odoc")) continue;
    DocInfo *di = &N.docs[N.ndocs];
    snprintf(di->id, sizeof di->id, "%.*s", (int)(l - 5), e->d_name);
    char path[600];
    doc_path(di->id, path, sizeof path);
    struct stat st;
    di->mtime = stat(path, &st) ? 0 : (long)st.st_mtime;
    snprintf(di->title, sizeof di->title, "Untitled document");
    di->npv = 0;
    char *body = read_file(path);
    if (body) {
      char *q = body;
      while (*q) {
        char *e = strchr(q, '\n');
        int len = e ? (int)(e - q) : (int)strlen(q);
        int v[6];
        const char *fx;
        if (!strncmp(q, "title\t", 6) && len > 6) snprintf(di->title, sizeof di->title, "%.*s", len - 6 > 95 ? 95 : len - 6, q + 6);
        else if (di->npv < MAXPV && parse_head(q, q + len, v, &fx)) {
          const char *tab = memchr(fx, '\t', (size_t)(q + len - fx));
          int n = tab ? (int)((q + len) - (tab + 1)) : 0;
          di->pv[di->npv++] = (Pv){(unsigned char)(v[0] & 3), (unsigned char)(v[1] & 3), (unsigned char)(v[2] & 1), (unsigned char)(v[5] ? 1 : 0), (short)(n > 999 ? 999 : n)};
        }
        q += len + (e ? 1 : 0);
      }
      free(body);
    }
    N.ndocs++;
  }
  closedir(d);
  qsort(N.docs, (size_t)N.ndocs, sizeof(DocInfo), doc_cmp);
}

static void save_doc(void) {
  if (!N.id[0]) return;
  mkdirs(notes_dir());
  char path[600], tmp[620];
  doc_path(N.id, path, sizeof path);
  snprintf(tmp, sizeof tmp, "%s.tmp", path);
  char *s = serialize(0);
  FILE *f = fopen(tmp, "w");
  if (f) {
    fputs(s, f);
    fclose(f);
    rename(tmp, path);
  }
  free(s);
  N.dirty = 0;
  scan_docs();
}

static void clear_history(void) {
  for (int i = 0; i < N.nundo; i++) free(N.undo[i]);
  for (int i = 0; i < N.nredo; i++) free(N.redo[i]);
  N.nundo = N.nredo = 0;
  N.last_kind = 0;
}

static void set_panel_title(void);

static void open_doc(const char *idp) {
  char id[40];
  snprintf(id, sizeof id, "%s", idp);
  if (N.dirty) save_doc();
  char path[600];
  doc_path(id, path, sizeof path);
  char *s = read_file(path);
  snprintf(N.id, sizeof N.id, "%s", id);
  N.cur = N.anc = (Pos){0, 0};
  deserialize(s ? s : "", 0);
  free(s);
  clear_history();
  N.scroll = 0;
  N.fmt = 0;
  N.title_edit = 0;
  N.confirm_del = -1;
  N.home = 0;
  set_panel_title();
}

static void new_doc(const char *title, const char *body) {
  if (N.dirty) save_doc();
  static int seq;
  snprintf(N.id, sizeof N.id, "doc%ld%03d", (long)time(NULL), (seq++ + rand()) % 1000);
  doc_clear();
  N.cur = N.anc = (Pos){0, 0};
  if (body) deserialize(body, 0);
  else para_insert(0);
  snprintf(N.title, sizeof N.title, "%s", title);
  clear_history();
  N.scroll = 0;
  N.fmt = 0;
  layout_ok = 0;
  save_doc();
  open_doc(N.id);
}

typedef struct {
  unsigned char style, list, check, fmt;
  const char *text;
} TplPara;

typedef struct {
  const char *name, *title;
  const TplPara *p;
  int n;
} Tpl;

static const TplPara T_MEETING[] = {
    {ST_TITLE, 0, 0, 0, "Meeting notes"},
    {ST_NORMAL, 0, 0, F_ITAL, "Date: March 12  |  Time: 10:00  |  Location: Room 4B"},
    {ST_H1, 0, 0, 0, "Attendees"},
    {ST_NORMAL, L_BULLET, 0, 0, "Sarah Chen, Product"},
    {ST_NORMAL, L_BULLET, 0, 0, "Marcus Webb, Engineering"},
    {ST_NORMAL, L_BULLET, 0, 0, "Priya Natarajan, Design"},
    {ST_H1, 0, 0, 0, "Agenda"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Review last week's action items"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Q2 roadmap priorities"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Open questions"},
    {ST_H1, 0, 0, 0, "Notes"},
    {ST_NORMAL, 0, 0, 0, "Summarise the discussion here. Capture decisions, open questions and anything that needs a follow-up."},
    {ST_H1, 0, 0, 0, "Action items"},
    {ST_NORMAL, L_CHECK, 0, 0, "Share the updated roadmap with the team"},
    {ST_NORMAL, L_CHECK, 0, 0, "Schedule a design review for next week"},
    {ST_NORMAL, L_CHECK, 0, 0, "Send meeting notes to all attendees"},
};

static const TplPara T_PROPOSAL[] = {
    {ST_TITLE, 0, 0, 0, "Project proposal"},
    {ST_NORMAL, 0, 0, F_ITAL, "Prepared by Your Name for Client Name"},
    {ST_H1, 0, 0, 0, "Overview"},
    {ST_NORMAL, 0, 0, 0, "Describe the project in two or three sentences. What problem does it solve, and who is it for?"},
    {ST_H1, 0, 0, 0, "Goals"},
    {ST_NORMAL, L_BULLET, 0, 0, "Increase customer sign-ups by 20% within six months"},
    {ST_NORMAL, L_BULLET, 0, 0, "Reduce average support response time to under four hours"},
    {ST_NORMAL, L_BULLET, 0, 0, "Launch the new onboarding flow before the end of the quarter"},
    {ST_H1, 0, 0, 0, "Timeline"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Research and discovery: 2 weeks"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Design and prototyping: 3 weeks"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Development and testing: 6 weeks"},
    {ST_NORMAL, L_NUMBER, 0, 0, "Launch and review: 1 week"},
    {ST_H1, 0, 0, 0, "Budget"},
    {ST_NORMAL, 0, 0, 0, "Outline the estimated costs, including people, tools and any third-party services."},
    {ST_H1, 0, 0, 0, "Next steps"},
    {ST_NORMAL, 0, 0, 0, "List what needs to happen for the project to be approved and started."},
};

static const TplPara T_WEEK[] = {
    {ST_TITLE, 0, 0, 0, "Weekly planner"},
    {ST_NORMAL, 0, 0, F_ITAL, "Week of June 3"},
    {ST_H2, 0, 0, 0, "Monday"},
    {ST_NORMAL, L_CHECK, 0, 0, "Plan the week and set top three priorities"},
    {ST_NORMAL, L_CHECK, 0, 0, "Gym, 7:00"},
    {ST_H2, 0, 0, 0, "Tuesday"},
    {ST_NORMAL, L_CHECK, 0, 0, "Dentist appointment, 14:30"},
    {ST_H2, 0, 0, 0, "Wednesday"},
    {ST_NORMAL, L_CHECK, 0, 0, "Call the bank about the mortgage"},
    {ST_H2, 0, 0, 0, "Thursday"},
    {ST_NORMAL, L_CHECK, 0, 0, "Pick up dry cleaning"},
    {ST_H2, 0, 0, 0, "Friday"},
    {ST_NORMAL, L_CHECK, 0, 0, "Review the week"},
    {ST_H2, 0, 0, 0, "Weekend"},
    {ST_NORMAL, L_CHECK, 0, 0, "Farmers market"},
    {ST_H2, 0, 0, 0, "Notes"},
    {ST_NORMAL, 0, 0, 0, ""},
};

static const TplPara T_TODO[] = {
    {ST_TITLE, 0, 0, 0, "To-do list"},
    {ST_H2, 0, 0, 0, "Today"},
    {ST_NORMAL, L_CHECK, 0, 0, "Reply to emails"},
    {ST_NORMAL, L_CHECK, 0, 0, "Buy groceries"},
    {ST_NORMAL, L_CHECK, 0, 0, "Water the plants"},
    {ST_H2, 0, 0, 0, "This week"},
    {ST_NORMAL, L_CHECK, 0, 0, "Book flights for the summer trip"},
    {ST_NORMAL, L_CHECK, 0, 0, "Renew car insurance"},
    {ST_NORMAL, L_CHECK, 0, 0, "Finish reading the book club pick"},
    {ST_H2, 0, 0, 0, "Someday"},
    {ST_NORMAL, L_CHECK, 0, 0, "Learn to make sourdough"},
    {ST_NORMAL, L_CHECK, 0, 0, "Repaint the spare room"},
};

static const TplPara T_LETTER[] = {
    {ST_NORMAL, 0, 0, F_BOLD, "Your Name"},
    {ST_NORMAL, 0, 0, 0, "123 Your Street, Your City, ST 12345"},
    {ST_NORMAL, 0, 0, 0, "you@email.com  |  (555) 123-4567"},
    {ST_NORMAL, 0, 0, 0, ""},
    {ST_NORMAL, 0, 0, 0, "September 4"},
    {ST_NORMAL, 0, 0, 0, ""},
    {ST_NORMAL, 0, 0, 0, "Recipient Name"},
    {ST_NORMAL, 0, 0, 0, "Company Name"},
    {ST_NORMAL, 0, 0, 0, "456 Company Avenue, City, ST 67890"},
    {ST_NORMAL, 0, 0, 0, ""},
    {ST_NORMAL, 0, 0, 0, "Dear Recipient Name,"},
    {ST_NORMAL, 0, 0, 0, "I am writing to express my interest in the role advertised on your website. With five years of experience in a similar position, I believe I would be a strong addition to your team."},
    {ST_NORMAL, 0, 0, 0, "In my current role I lead a team of six and have delivered several projects on time and under budget. I would welcome the chance to bring that experience to your organisation."},
    {ST_NORMAL, 0, 0, 0, "Thank you for your time and consideration. I look forward to hearing from you."},
    {ST_NORMAL, 0, 0, 0, "Sincerely,"},
    {ST_NORMAL, 0, 0, 0, "Your Name"},
};

static const TplPara T_RESUME[] = {
    {ST_TITLE, 0, 0, 0, "Your Name"},
    {ST_NORMAL, 0, 0, 0, "City, ST  |  you@email.com  |  (555) 123-4567"},
    {ST_H1, 0, 0, 0, "Experience"},
    {ST_H2, 0, 0, 0, "Senior Designer, Company Name"},
    {ST_NORMAL, 0, 0, F_ITAL, "2021 - Present"},
    {ST_NORMAL, L_BULLET, 0, 0, "Led the redesign of the main product, increasing retention by 15%"},
    {ST_NORMAL, L_BULLET, 0, 0, "Mentored three junior designers"},
    {ST_H2, 0, 0, 0, "Designer, Previous Company"},
    {ST_NORMAL, 0, 0, F_ITAL, "2018 - 2021"},
    {ST_NORMAL, L_BULLET, 0, 0, "Built and maintained the company design system"},
    {ST_H1, 0, 0, 0, "Education"},
    {ST_NORMAL, 0, 0, 0, "B.A. in Graphic Design, State University, 2018"},
    {ST_H1, 0, 0, 0, "Skills"},
    {ST_NORMAL, 0, 0, 0, "Product design, prototyping, user research, design systems"},
};

static const Tpl TPLS[NTPL] = {
    {"Blank document", "Untitled document", NULL, 0},
    {"Meeting notes", "Meeting notes", T_MEETING, sizeof T_MEETING / sizeof *T_MEETING},
    {"Project proposal", "Project proposal", T_PROPOSAL, sizeof T_PROPOSAL / sizeof *T_PROPOSAL},
    {"Weekly planner", "Weekly planner", T_WEEK, sizeof T_WEEK / sizeof *T_WEEK},
    {"To-do list", "To-do list", T_TODO, sizeof T_TODO / sizeof *T_TODO},
    {"Letter", "Letter", T_LETTER, sizeof T_LETTER / sizeof *T_LETTER},
    {"Resume", "Resume", T_RESUME, sizeof T_RESUME / sizeof *T_RESUME},
};

static void set_panel_title(void) {
  if (N.panel < 0 || !P[N.panel].used || P[N.panel].app != &notes_app) return;
  if (N.home) snprintf(P[N.panel].title, sizeof P[N.panel].title, "Office");
  else if (N.mode == 2) snprintf(P[N.panel].title, sizeof P[N.panel].title, "%.50s - Slides", slides_title());
  else if (N.mode) snprintf(P[N.panel].title, sizeof P[N.panel].title, "%.50s - Sheets", sheets_title());
  else snprintf(P[N.panel].title, sizeof P[N.panel].title, "%.50s - Docs", N.title);
  P[N.panel].chrome_key = -1;
}

static void from_template(int t) {
  const Tpl *tp = &TPLS[t];
  new_doc(tp->title, NULL);
  if (tp->n) {
    doc_clear();
    for (int i = 0; i < tp->n; i++) {
      const TplPara *q = &tp->p[i];
      Para *p = para_insert(N.np);
      p->style = q->style, p->list = q->list, p->check = q->check;
      for (int j = 0; q->text[j]; j++) para_put(p, p->n, q->text + j, &q->fmt, 1);
    }
    N.cur = N.anc = (Pos){0, 0};
    layout_ok = 0;
    save_doc();
  }
  N.home = 0;
  set_panel_title();
}

static void ensure_loaded(void) {
  if (N.loaded) return;
  N.loaded = 1;
  N.confirm_del = -1;
  N.panel = -1;
  N.home = 1;
  if (!N.np) para_insert(0);
  scan_docs();
}

static void push_undo(int kind) {
  uint32_t now = now_ms();
  if (kind && kind == N.last_kind && now - N.last_edit < 1500) {
    N.last_edit = now;
    return;
  }
  N.last_kind = kind;
  N.last_edit = now;
  if (N.nundo == MAXUNDO) {
    free(N.undo[0]);
    memmove(N.undo, N.undo + 1, sizeof(char *) * (MAXUNDO - 1));
    N.nundo--;
  }
  N.undo[N.nundo++] = serialize(1);
  for (int i = 0; i < N.nredo; i++) free(N.redo[i]);
  N.nredo = 0;
}

static void changed(void) {
  N.dirty = 1;
  N.dirty_at = now_ms();
  layout_ok = 0;
  N.blink = 1;
  N.blink_t = now_ms();
}

static void undo_redo(int redo) {
  char **from = redo ? N.redo : N.undo, **to = redo ? N.undo : N.redo;
  int *nf = redo ? &N.nredo : &N.nundo, *nt = redo ? &N.nundo : &N.nredo;
  if (!*nf) return;
  char *cur = serialize(1);
  if (*nt == MAXUNDO) {
    free(to[0]);
    memmove(to, to + 1, sizeof(char *) * (MAXUNDO - 1));
    (*nt)--;
  }
  to[(*nt)++] = cur;
  char *s = from[--(*nf)];
  char title[96];
  snprintf(title, sizeof title, "%s", N.title);
  deserialize(s, 1);
  snprintf(N.title, sizeof N.title, "%s", title);
  free(s);
  N.last_kind = 0;
  changed();
}

static int fmt_at(Pos p) {
  Para *q = &N.p[p.para];
  if (p.off > 0) return q->f[p.off - 1];
  if (q->n) return q->f[0];
  return 0;
}

static void sync_fmt(void) { N.fmt = fmt_at(N.cur); }

static void delete_range(Pos a, Pos b) {
  if (pos_cmp(a, b) >= 0) return;
  if (a.para == b.para) {
    para_cut(&N.p[a.para], a.off, b.off);
  } else {
    Para *pa = &N.p[a.para], *pb = &N.p[b.para];
    pa->n = a.off;
    pa->t[pa->n] = 0;
    para_put(pa, pa->n, pb->t + b.off, pb->f + b.off, pb->n - b.off);
    for (int i = b.para; i > a.para; i--) para_remove(i);
  }
  N.cur = N.anc = a;
}

static void delete_sel(void) {
  if (!has_sel()) return;
  Pos a, b;
  sel_range(&a, &b);
  delete_range(a, b);
}

static void split_para(void) {
  Para *p = &N.p[N.cur.para];
  Para *q = para_insert(N.cur.para + 1);
  p = &N.p[N.cur.para];
  q->list = p->list;
  q->indent = p->indent;
  q->align = p->align;
  q->style = (p->style != ST_NORMAL && N.cur.off < p->n) ? p->style : ST_NORMAL;
  para_put(q, 0, p->t + N.cur.off, p->f + N.cur.off, p->n - N.cur.off);
  p->n = N.cur.off;
  p->t[p->n] = 0;
  N.cur.para++;
  N.cur.off = 0;
  N.anc = N.cur;
}

static void autoformat(void) {
  Para *p = &N.p[N.cur.para];
  if (N.cur.off != p->n || p->list) return;
  struct {
    const char *pre;
    int list, style;
  } rules[] = {{"- ", L_BULLET, -1}, {"* ", L_BULLET, -1}, {"1. ", L_NUMBER, -1}, {"[] ", L_CHECK, -1},
               {"[ ] ", L_CHECK, -1}, {"# ", 0, ST_H1}, {"## ", 0, ST_H2}};
  for (unsigned i = 0; i < sizeof rules / sizeof *rules; i++) {
    int l = (int)strlen(rules[i].pre);
    if (p->n == l && !memcmp(p->t, rules[i].pre, (size_t)l)) {
      para_cut(p, 0, l);
      if (rules[i].style >= 0) p->style = (unsigned char)rules[i].style;
      else p->list = (unsigned char)rules[i].list;
      N.cur.off = N.anc.off = 0;
      return;
    }
  }
}

static void leave_block(void) {
  if (!N.p[N.cur.para].hr) return;
  if (N.cur.para + 1 >= N.np || N.p[N.cur.para + 1].n || N.p[N.cur.para + 1].hr) para_insert(N.cur.para + 1);
  N.cur.para++;
  N.cur.off = 0;
  N.anc = N.cur;
}

static void insert_text(const char *s, int kind) {
  push_undo(kind);
  delete_sel();
  leave_block();
  for (; *s; s++) {
    if (*s == '\n') {
      split_para();
      continue;
    }
    unsigned char f = (unsigned char)N.fmt;
    para_put(&N.p[N.cur.para], N.cur.off, s, &f, 1);
    N.cur.off++;
    N.anc = N.cur;
    if (*s == ' ') autoformat();
  }
  changed();
}

static void press_enter(void) {
  push_undo(0);
  delete_sel();
  Para *p = &N.p[N.cur.para];
  if (p->list && p->n == 0) {
    p->list = L_NONE;
    p->indent = 0;
    changed();
    return;
  }
  if (p->hr) {
    Para *q = para_insert(N.cur.para + 1);
    (void)q;
    N.cur.para++;
    N.cur.off = 0;
    N.anc = N.cur;
    changed();
    return;
  }
  split_para();
  if (N.p[N.cur.para].list == L_CHECK) N.p[N.cur.para].check = 0;
  changed();
}

static int is_word(char c) { return isalnum((unsigned char)c) || c == '\'' || c == '_'; }

static Pos move_word(Pos p, int dir) {
  Para *q = &N.p[p.para];
  if (dir < 0) {
    if (p.off == 0) {
      if (p.para > 0) return (Pos){p.para - 1, N.p[p.para - 1].n};
      return p;
    }
    int o = p.off;
    while (o > 0 && !is_word(q->t[o - 1])) o--;
    while (o > 0 && is_word(q->t[o - 1])) o--;
    return (Pos){p.para, o};
  }
  if (p.off >= q->n) {
    if (p.para + 1 < N.np) return (Pos){p.para + 1, 0};
    return p;
  }
  int o = p.off;
  while (o < q->n && is_word(q->t[o])) o++;
  while (o < q->n && !is_word(q->t[o])) o++;
  return (Pos){p.para, o};
}

static void backspace(int word) {
  if (has_sel()) {
    push_undo(0);
    delete_sel();
    changed();
    return;
  }
  Para *p = &N.p[N.cur.para];
  if (p->hr) {
    if (N.np < 2) return;
    push_undo(0);
    para_remove(N.cur.para);
    if (N.cur.para > 0) N.cur.para--;
    if (N.cur.para >= N.np) N.cur.para = N.np - 1;
    N.cur.off = N.p[N.cur.para].n;
    N.anc = N.cur;
    changed();
    return;
  }
  if (N.cur.off == 0) {
    if (p->list || p->indent) {
      push_undo(0);
      if (p->list) p->list = L_NONE;
      else p->indent--;
      changed();
      return;
    }
    if (p->style != ST_NORMAL && p->n == 0 && N.cur.para == 0) {
      push_undo(0);
      p->style = ST_NORMAL;
      changed();
      return;
    }
    if (N.cur.para == 0) return;
    push_undo(0);
    if (N.p[N.cur.para - 1].hr) {
      para_remove(N.cur.para - 1);
      N.cur.para--;
      N.anc = N.cur;
      changed();
      return;
    }
    Pos a = {N.cur.para - 1, N.p[N.cur.para - 1].n};
    delete_range(a, N.cur);
    changed();
    return;
  }
  push_undo(word ? 0 : 2);
  Pos a = word ? move_word(N.cur, -1) : (Pos){N.cur.para, N.cur.off - 1};
  delete_range(a, N.cur);
  changed();
}

static void delete_fwd(int word) {
  if (has_sel()) {
    backspace(0);
    return;
  }
  Para *p = &N.p[N.cur.para];
  if (p->hr && N.np > 1) {
    push_undo(0);
    para_remove(N.cur.para);
    if (N.cur.para >= N.np) N.cur.para = N.np - 1;
    N.cur.off = 0;
    N.anc = N.cur;
    changed();
    return;
  }
  if (N.cur.off >= p->n) {
    if (N.cur.para + 1 >= N.np) return;
    push_undo(0);
    if (N.p[N.cur.para + 1].hr) para_remove(N.cur.para + 1);
    else delete_range(N.cur, (Pos){N.cur.para + 1, 0});
    changed();
    return;
  }
  push_undo(word ? 0 : 3);
  Pos b = word ? move_word(N.cur, 1) : (Pos){N.cur.para, N.cur.off + 1};
  delete_range(N.cur, b);
  changed();
}

static void sel_paras(int *a, int *b) {
  *a = N.cur.para < N.anc.para ? N.cur.para : N.anc.para;
  *b = N.cur.para > N.anc.para ? N.cur.para : N.anc.para;
}

static void toggle_fmt(int bit) {
  if (!has_sel()) {
    N.fmt ^= bit;
    return;
  }
  push_undo(0);
  Pos a, b;
  sel_range(&a, &b);
  int all = 1;
  for (int i = a.para; i <= b.para; i++) {
    Para *p = &N.p[i];
    int s = i == a.para ? a.off : 0, e = i == b.para ? b.off : p->n;
    for (int j = s; j < e; j++)
      if (!(p->f[j] & bit)) all = 0;
  }
  for (int i = a.para; i <= b.para; i++) {
    Para *p = &N.p[i];
    int s = i == a.para ? a.off : 0, e = i == b.para ? b.off : p->n;
    for (int j = s; j < e; j++) p->f[j] = (unsigned char)(all ? p->f[j] & ~bit : p->f[j] | bit);
  }
  N.fmt = all ? N.fmt & ~bit : N.fmt | bit;
  changed();
}

static void set_color(int c) {
  if (!has_sel()) {
    N.fmt = (N.fmt & 15) | (c << 4);
    return;
  }
  push_undo(0);
  Pos a, b;
  sel_range(&a, &b);
  for (int i = a.para; i <= b.para; i++) {
    Para *p = &N.p[i];
    int s = i == a.para ? a.off : 0, e = i == b.para ? b.off : p->n;
    for (int j = s; j < e; j++) p->f[j] = (unsigned char)((p->f[j] & 15) | (c << 4));
  }
  N.fmt = (N.fmt & 15) | (c << 4);
  changed();
}

static void clear_fmt(void) {
  push_undo(0);
  if (has_sel()) {
    Pos a, b;
    sel_range(&a, &b);
    for (int i = a.para; i <= b.para; i++) {
      Para *p = &N.p[i];
      int s = i == a.para ? a.off : 0, e = i == b.para ? b.off : p->n;
      for (int j = s; j < e; j++) p->f[j] = 0;
    }
  }
  N.fmt = 0;
  changed();
}

static void set_style(int st) {
  push_undo(0);
  int a, b;
  sel_paras(&a, &b);
  for (int i = a; i <= b; i++) {
    N.p[i].style = (unsigned char)st;
    if (st != ST_NORMAL) N.p[i].list = L_NONE;
  }
  changed();
}

static void set_align(int al) {
  push_undo(0);
  int a, b;
  sel_paras(&a, &b);
  for (int i = a; i <= b; i++) N.p[i].align = (unsigned char)al;
  changed();
}

static void set_list(int li) {
  push_undo(0);
  int a, b;
  sel_paras(&a, &b);
  int all = 1;
  for (int i = a; i <= b; i++)
    if (N.p[i].list != li) all = 0;
  for (int i = a; i <= b; i++) {
    N.p[i].list = (unsigned char)(all ? L_NONE : li);
    if (!all) N.p[i].style = ST_NORMAL;
    N.p[i].check = 0;
  }
  changed();
}

static void indent(int d) {
  push_undo(0);
  int a, b;
  sel_paras(&a, &b);
  for (int i = a; i <= b; i++) {
    int v = N.p[i].indent + d;
    N.p[i].indent = (unsigned char)(v < 0 ? 0 : v > 6 ? 6 : v);
  }
  changed();
}

static Para *block_at_cursor(void) {
  Para *c = &N.p[N.cur.para];
  int at;
  if (!c->n && !c->hr) at = N.cur.para;
  else if (c->hr || N.cur.off >= c->n) at = N.cur.para + 1, para_insert(at);
  else {
    if (N.cur.off > 0) split_para();
    at = N.cur.para;
    para_insert(at);
  }
  Para *h = &N.p[at];
  h->list = L_NONE;
  h->style = ST_NORMAL;
  h->indent = 0;
  h->align = A_LEFT;
  h->check = 0;
  h->n = 0;
  h->t[0] = 0;
  if (at + 1 >= N.np) para_insert(at + 1);
  N.cur = N.anc = (Pos){at, 0};
  return &N.p[at];
}

static void insert_hr(void) {
  push_undo(0);
  delete_sel();
  block_at_cursor()->hr = 1;
  N.cur.para++;
  N.anc = N.cur;
  changed();
}

static void insert_embed(int kind, const char *id, int sub) {
  push_undo(0);
  delete_sel();
  Para *h = block_at_cursor();
  h->hr = 2;
  office_embed_ref(h->ref, sizeof h->ref, kind, id, sub);
  changed();
}

static float embed_h(const Para *p) {
  int k = 0, sub;
  char id[40];
  office_embed_parse(p->ref, &k, id, sizeof id, &sub);
  float nw, nh;
  if (k == 1 && sheets_embed_size(id, &nw, &nh)) {
    float u = (TEXT_W - 2) / nw;
    if (u > 1.4f) u = 1.4f;
    return nh * u + 38 + 18;
  }
  return k == 2 ? TEXT_W * 9.f / 16.f + 38 + 18 : k == 1 ? 290 : 340;
}

static char *copy_sel(void) {
  if (!has_sel()) return NULL;
  Pos a, b;
  sel_range(&a, &b);
  size_t cap = 64;
  for (int i = a.para; i <= b.para; i++) cap += (size_t)N.p[i].n * 3 + 48;
  char *s = malloc(cap);
  size_t k = 0;
  for (int i = a.para; i <= b.para; i++) {
    Para *p = &N.p[i];
    int st = i == a.para ? a.off : 0, e = i == b.para ? b.off : p->n;
    k += (size_t)sprintf(s + k, "p\t%d\t%d\t%d\t%d\t%d\t%d\t", p->style, p->list, p->check, p->indent, p->align, p->hr);
    for (int j = st; j < e; j++) s[k++] = hexd[p->f[j] >> 4], s[k++] = hexd[p->f[j] & 15];
    s[k++] = '\t';
    memcpy(s + k, p->t + st, (size_t)(e - st));
    k += (size_t)(e - st);
    s[k++] = '\n';
  }
  s[k] = 0;
  return s;
}

static void paste(void) {
  if (!N.clip) return;
  push_undo(0);
  delete_sel();
  const char *s = N.clip;
  int first = 1;
  while (*s) {
    const char *e = strchr(s, '\n');
    int len = e ? (int)(e - s) : (int)strlen(s);
    int v[6];
    const char *fx;
    if (parse_head(s, s + len, v, &fx)) {
      int st = v[0], li = v[1], ch = v[2], in = v[3], al = v[4];
      const char *tab = memchr(fx, '\t', (size_t)(s + len - fx));
      if (tab) {
        int n = (int)((s + len) - (tab + 1));
        if (!first) {
          split_para();
          Para *p = &N.p[N.cur.para];
          p->style = (unsigned char)st, p->list = (unsigned char)li, p->check = (unsigned char)ch;
          p->indent = (unsigned char)in, p->align = (unsigned char)al;
        }
        for (int j = 0; j < n; j++) {
          unsigned char f = (unsigned char)(hexv(fx[j * 2]) << 4 | hexv(fx[j * 2 + 1]));
          para_put(&N.p[N.cur.para], N.cur.off, tab + 1 + j, &f, 1);
          N.cur.off++;
        }
        first = 0;
      }
    }
    s += len + (e ? 1 : 0);
  }
  N.anc = N.cur;
  changed();
}

static int para_size(Para *p) { return p->style; }

static const Font *char_font(Para *p, int fmt) { return doc_font(para_size(p), fmt & F_BOLD || p->style == ST_H1 || p->style == ST_H2, fmt & F_ITAL); }

static float para_lh(Para *p) {
  const Font *f = doc_font(para_size(p), 0, 0);
  return line_h(f) * (p->style == ST_NORMAL ? 1.32f : 1.18f);
}

static float space_before(Para *p) {
  static const float v[4] = {0, 14, 20, 4};
  return v[p->style];
}

static float space_after(Para *p) {
  if (p->list && p->style == ST_NORMAL) return 3;
  static const float v[4] = {9, 6, 8, 12};
  return v[p->style];
}

static float marker_w(Para *p) { return p->indent * 36.f + (p->list ? 30.f : 0.f); }

static void add_line(int para, int s, int e, float x, float y, float h) {
  if (nlines == lcap) {
    lcap = lcap ? lcap * 2 : 128;
    lines = realloc(lines, sizeof(Line) * (size_t)lcap);
  }
  lines[nlines++] = (Line){para, s, e, x, y, h, 0};
}

static float run_w(Para *p, int s, int e) {
  float w = 0;
  for (int i = s; i < e; i++) w += doc_char_w(char_font(p, p->f[i]), p->t[i]);
  return w;
}

static void layout(void) {
  if (layout_ok) return;
  nlines = 0;
  float y = 0;
  for (int i = 0; i < N.np; i++) {
    Para *p = &N.p[i];
    if (i > 0) y += space_before(p);
    float lh = para_lh(p);
    if (p->hr == 2) {
      float eh = embed_h(p);
      add_line(i, 0, 0, 0, y, eh);
      y += eh;
      continue;
    }
    if (p->hr) {
      add_line(i, 0, 0, 0, y, 26);
      y += 26;
      continue;
    }
    float mw = marker_w(p), avail = TEXT_W - mw;
    int s = 0;
    do {
      float w = 0;
      int e = s, brk = -1;
      while (e < p->n) {
        float cw = doc_char_w(char_font(p, p->f[e]), p->t[e]);
        if (w + cw > avail && e > s) break;
        w += cw;
        if (p->t[e] == ' ') brk = e + 1;
        e++;
      }
      if (e < p->n && brk > s) e = brk;
      float lw = run_w(p, s, e);
      float x = mw;
      if (p->align == A_CENTER) x = mw + (avail - lw) * 0.5f;
      else if (p->align == A_RIGHT) x = mw + (avail - lw);
      add_line(i, s, e, x, y, lh);
      y += lh;
      s = e;
    } while (s < p->n);
    y += space_after(p);
  }
  doc_h = y;
  layout_ok = 1;
}

static float page_x(void) { return (NW - PAGE_W) * 0.5f; }

static float view_top(void) { return BODY_Y; }

static float view_h(void) { return (NH - BAR_H) - BODY_Y; }

static float text_origin_y(void) { return view_top() + PAGE_TOP + PAGE_PAD * 0.72f - N.scroll; }

static int line_of(Pos p) {
  int best = 0;
  for (int i = 0; i < nlines; i++) {
    if (lines[i].para != p.para) continue;
    best = i;
    if (p.off < lines[i].end || (p.off == lines[i].end && (i + 1 >= nlines || lines[i + 1].para != p.para))) return i;
  }
  return best;
}

static void pos_xy(Pos p, float *x, float *y, float *h) {
  layout();
  int li = line_of(p);
  Line *l = &lines[li];
  Para *q = &N.p[p.para];
  *x = l->x + run_w(q, l->start, p.off < l->start ? l->start : p.off);
  *y = l->y;
  *h = l->h;
}

static Pos xy_pos(float x, float y) {
  layout();
  if (!nlines) return (Pos){0, 0};
  int li = 0;
  for (int i = 0; i < nlines; i++) {
    if (y >= lines[i].y) li = i;
    else break;
  }
  if (y > lines[li].y + lines[li].h + 8) {
    for (int i = li + 1; i < nlines; i++)
      if (lines[i].para != lines[li].para) break;
  }
  Line *l = &lines[li];
  Para *p = &N.p[l->para];
  float cx = l->x;
  int o = l->start;
  while (o < l->end) {
    float w = doc_char_w(char_font(p, p->f[o]), p->t[o]);
    if (x < cx + w * 0.5f) break;
    cx += w;
    o++;
  }
  if (o == l->end && l->end < p->n && o > l->start && p->t[o - 1] == ' ') o--;
  return (Pos){l->para, o};
}

static void ensure_visible(void) {
  float x, y, h;
  pos_xy(N.cur, &x, &y, &h);
  float top = PAGE_TOP + PAGE_PAD * 0.72f + y, vh = view_h();
  if (top - N.scroll < 30) N.scroll = top - 30;
  if (top + h - N.scroll > vh - 30) N.scroll = top + h - vh + 30;
  float maxs = PAGE_TOP * 2 + PAGE_PAD * 1.5f + doc_h - vh + 120;
  if (N.scroll > maxs) N.scroll = maxs;
  if (N.scroll < 0) N.scroll = 0;
}

static void move_cursor(Pos p, int extend) {
  N.cur = p;
  if (!extend) N.anc = p;
  sync_fmt();
  N.blink = 1;
  N.blink_t = now_ms();
  ensure_visible();
}

static void move_vert(int dir, int extend) {
  layout();
  float x, y, h;
  pos_xy(N.cur, &x, &y, &h);
  if (N.want_x < 0) N.want_x = x;
  int li = line_of(N.cur) + dir;
  if (li < 0) {
    move_cursor((Pos){0, 0}, extend);
    return;
  }
  if (li >= nlines) {
    move_cursor((Pos){N.np - 1, N.p[N.np - 1].n}, extend);
    return;
  }
  float wx = N.want_x;
  Pos p = xy_pos(wx, lines[li].y + 1);
  if (p.para != lines[li].para) p = (Pos){lines[li].para, lines[li].start};
  move_cursor(p, extend);
  N.want_x = wx;
}

typedef struct {
  int id;
  float x, w;
} Tool;

static Tool tools[T_COUNT];
static float seps[10];
static float pill_x, pill_w;
static int nseps;

static void tool_layout(void) {
  static const int order[] = {T_UNDO, T_REDO, 0, T_STYLE, 0, T_BOLD, T_ITAL, T_UNDER, T_STRIKE, T_COLOR, 0, T_ALEFT,
                              T_ACENTER, T_ARIGHT, 0, T_CHECK, T_BULLET, T_NUMBER, 0, T_OUTDENT, T_INDENT, 0, T_CLEAR};
  float x = 0;
  nseps = 0;
  for (unsigned i = 0; i < sizeof order / sizeof *order; i++) {
    if (!order[i]) {
      seps[nseps++] = x + 5;
      x += 12;
      continue;
    }
    float w = order[i] == T_STYLE ? 136 : 34;
    tools[order[i]] = (Tool){order[i], x, w};
    x += w + 3;
  }
  seps[nseps++] = x + 5;
  x += 12;
  tools[T_FIND] = (Tool){T_FIND, x, 34};
  x += 34;
  float off = (NW - x) * 0.5f;
  for (int i = 1; i < T_COUNT; i++) tools[i].x += off;
  for (int i = 0; i < nseps; i++) seps[i] += off;
  pill_x = off - 10, pill_w = x + 20;
}

static float menu_x(int i) {
  float total = 0;
  for (int k = 0; k < 4; k++) total += gfx_text_w(F_UI, MENU_NAMES[k]) + 22;
  float x = NW - 18 - total + 11;
  for (int k = 0; k < i; k++) x += gfx_text_w(F_UI, MENU_NAMES[k]) + 22;
  return x;
}

static void popup_rect(float *x, float *y, float *w, float *h) {
  if (N.popup >= POP_MENU0 && N.popup <= POP_MENU3) {
    int m = N.popup - POP_MENU0;
    *x = menu_x(m) - 10, *y = HEAD_H - 4, *w = 300;
    if (*x > NW - 312) *x = NW - 312;
    float hh = 8;
    for (int i = 0; i < MENU_LEN[m]; i++) hh += MENUS[m][i].label ? 34 : 9;
    *h = hh;
  } else if (N.popup == POP_STYLE) {
    *x = tools[T_STYLE].x, *y = TOOL_Y + TOOL_H - 4, *w = 250, *h = 8 + 4 * 52;
  } else {
    *x = tools[T_COLOR].x - 8, *y = TOOL_Y + TOOL_H - 4, *w = 212, *h = 108;
  }
}

static int popup_zone(float x, float y) {
  float px, py, pw, ph;
  popup_rect(&px, &py, &pw, &ph);
  if (x < px || x >= px + pw || y < py || y >= py + ph) return -1;
  if (N.popup <= POP_MENU3) {
    int m = N.popup - POP_MENU0;
    float yy = py + 4;
    for (int i = 0; i < MENU_LEN[m]; i++) {
      float hh = MENUS[m][i].label ? 34 : 9;
      if (y >= yy && y < yy + hh) return MENUS[m][i].label ? Z_POPUP + i : 0;
      yy += hh;
    }
    return 0;
  }
  if (N.popup == POP_STYLE) {
    int i = (int)((y - py - 4) / 52);
    return i >= 0 && i < 4 ? Z_POPUP + i : 0;
  }
  float gx = px + 14, gy = py + 40;
  for (int i = 0; i < 8; i++) {
    float cx = gx + (i % 4) * 48, cy = gy + (i / 4) * 32;
    if (x >= cx - 2 && x < cx + 40 && y >= cy - 2 && y < cy + 28) return Z_POPUP + i;
  }
  return 0;
}

static float find_x(void) { return NW - 24 - 360; }


static void fmt_date(long t, char *out, size_t n);
static void commit_title(void);

static float tpl_x(int i) { return (NW - (NTPL * TPL_W + (NTPL - 1) * TPL_GAP)) * 0.5f + i * (TPL_W + TPL_GAP); }

static float tpl_y(void) { return HOME_HEAD + HERO_H + 52 - N.home_scroll; }

static float band_bottom(void) { return HOME_HEAD + HERO_H + 52 + TPL_H + 52 - N.home_scroll + 4; }

static int card_cols(void) { return 5; }

static float card_x(int i) { return (NW - (card_cols() * CARD_W + (card_cols() - 1) * CARD_GAP)) * 0.5f + (i % card_cols()) * (CARD_W + CARD_GAP); }

static float card_y(int i) { return band_bottom() + 64 + (i / card_cols()) * CARD_STEP; }

static float home_content_h(void) {
  if (N.mode == 2) return HERO_H + slides_home_h();
  if (N.mode) return HERO_H + sheets_home_h();
  int rows = N.ndocs ? (N.ndocs + card_cols() - 1) / card_cols() : 1;
  return HERO_H + 52 + TPL_H + 56 + 64 + rows * CARD_STEP + 20;
}

static float imp_btn_w(void) { return gfx_text_w(F_UI_MED, "Import file") + 56; }

static float new_btn_w(void) { return gfx_text_w(F_UI_MED, "New blank") + 52; }

static void hero_btns(float *ix, float *nx, float *y) {
  *nx = NW - 24 - 22 - new_btn_w();
  *ix = *nx - 10 - imp_btn_w();
  *y = HOME_HEAD - N.home_scroll + 37;
}

static int home_zone(float x, float y) {
  if (y < HOME_HEAD) {
    float sx = (NW - SEG_W * 3) * 0.5f;
    if (y >= 14 && y < 50 && x >= sx && x < sx + SEG_W * 3) return Z_SEG + (int)((x - sx) / SEG_W);
    return 0;
  }
  {
    float ix, nx, by;
    hero_btns(&ix, &nx, &by);
    if (y >= by && y < by + 38) {
      if (x >= nx && x < nx + new_btn_w()) return Z_NEWBLANK;
      if (x >= ix && x < ix + imp_btn_w()) return Z_IMPORT;
    }
  }
  if (N.mode == 2) return slides_home_zone(x, y, HOME_HEAD + HERO_H - N.home_scroll);
  if (N.mode) return sheets_home_zone(x, y, HOME_HEAD + HERO_H - N.home_scroll);
  for (int i = 0; i < NTPL; i++) {
    float tx = tpl_x(i), ty = tpl_y();
    if (x >= tx && x < tx + TPL_W && y >= ty && y < ty + TPL_H + 30) return Z_TPL + i;
  }
  for (int i = 0; i < N.ndocs; i++) {
    float cx = card_x(i), cy = card_y(i);
    if (x >= cx && x < cx + CARD_W && y >= cy && y < cy + CARD_TH + 58) {
      if (x >= cx + CARD_W - 40 && y < cy + 40) return Z_CARD_DEL + i;
      return Z_CARD + i;
    }
  }
  return 0;
}

static void draw_preview(Surface *s, float x, float y, float w, float h, const Pv *pv, int n) {
  uint32_t dark = THEME(RGB(60, 64, 67), RGB(200, 204, 210)), light = THEME(RGB(208, 212, 218), RGB(84, 90, 100));
  float m = w * 0.11f, lx = x + m, ly = y + m, lw = w - 2 * m, bottom = y + h - m * 0.6f;
  float u = w / 124.f;
  for (int i = 0; i < n && ly < bottom; i++) {
    const Pv *q = &pv[i];
    if (q->hr) {
      gfx_rect(s, lx, ly + 2 * u, lw, 0.8f * u, light);
      ly += 6 * u;
      continue;
    }
    if (i > 0 && (q->style == ST_H1 || q->style == ST_H2)) ly += 3 * u;
    float th = q->style == ST_TITLE ? 4.2f * u : q->style == ST_H1 ? 3.2f * u : q->style == ST_H2 ? 2.8f * u : 1.9f * u;
    float step = q->style == ST_TITLE ? 9 * u : q->style == ST_NORMAL ? 4.6f * u : 7 * u;
    uint32_t c = q->style == ST_NORMAL ? light : dark;
    float indent = 0;
    if (q->list) {
      indent = 5 * u;
      if (q->list == L_CHECK) gfx_rrect(s, lx, ly - 0.2f * u, 2.6f * u, 2.6f * u, 0.6f * u, q->check ? RGB(84, 76, 230) : dark);
      else gfx_disc(s, lx + 1.2f * u, ly + th * 0.5f, 1.0f * u, dark);
    }
    int len = q->len;
    float cw = (q->style == ST_TITLE ? 2.6f : q->style == ST_NORMAL ? 1.25f : 1.9f) * u;
    if (len == 0) {
      ly += step;
      continue;
    }
    while (len > 0 && ly < bottom) {
      float avail = lw - indent, wdt = len * cw;
      if (wdt > avail) wdt = avail;
      gfx_rrect(s, lx + indent, ly, wdt, th, th * 0.5f, c);
      len -= (int)(avail / cw);
      ly += step;
    }
    if (q->style == ST_TITLE) ly += 2 * u;
  }
}

static void tpl_preview(int t, Pv *pv, int *n) {
  const Tpl *tp = &TPLS[t];
  *n = 0;
  for (int i = 0; i < tp->n && *n < MAXPV; i++)
    pv[(*n)++] = (Pv){tp->p[i].style, tp->p[i].list, tp->p[i].check, 0, (short)strlen(tp->p[i].text)};
}


static void hero_button(Surface *s, float x, float y, float w, int primary, int hv, uint32_t acc, const char *label, int icon) {
  uint32_t bg = primary ? (hv ? acc : acc) : THEME(RGB(255, 255, 255), RGB(52, 54, 62));
  if (primary) gfx_shadow(s, x, y + 3, w, 38, 19, hv ? 14 : 8, RGBA(30, 28, 60, hv ? 70 : 45));
  else gfx_rrect(s, x - 1, y - 1, w + 2, 40, 20, hv ? acc : THEME(RGB(224, 222, 228), RGB(66, 68, 76)));
  gfx_rrect(s, x, y, w, 38, 19, bg);
  if (primary && hv) gfx_rrect(s, x, y, w, 38, 19, RGBA(255, 255, 255, 30));
  uint32_t c = primary ? RGB(255, 255, 255) : hv ? acc : C_TEXT;
  float ix = x + 24, iy = y + 19;
  if (icon == 0) {
    gfx_rect(s, ix - 6, iy - 0.9f, 12, 1.8f, c);
    gfx_rect(s, ix - 0.9f, iy - 6, 1.8f, 12, c);
  } else {
    gfx_line(s, ix, iy + 3, ix, iy - 6, 1.8f, c);
    gfx_line(s, ix, iy + 3, ix - 4, iy - 1, 1.8f, c);
    gfx_line(s, ix, iy + 3, ix + 4, iy - 1, 1.8f, c);
    gfx_rect(s, ix - 7, iy + 6.5f, 14, 1.8f, c);
  }
  gfx_text(s, F_UI_MED, x + 40, y + 19 - line_h(F_UI_MED) / 2, label, c);
}

static void draw_hero(Surface *s, float ox, float oy, int hot) {
  static const char *const NAME[3] = {"Docs", "Sheets", "Slides"};
  static const char *const DESC[3] = {"Write, format and share documents", "Organise numbers with formulas and formats",
                                      "Build slides and present them fullscreen"};
  int m = N.mode;
  uint32_t acc = m == 2 ? P_ACC : m ? S_ACC : N_ACC, tint = m == 2 ? P_TINT : m ? S_TINT : N_TINT;
  float top = oy + HOME_HEAD - N.home_scroll, x = ox + 24, y = top + 14, w = NW - 48, h = 84;
  gfx_rrect(s, x, y, w, h, 20, tint);
  gfx_rrect(s, x + w - 190, y, 190, h, 20, RGBA(255, 255, 255, 26));
  gfx_disc(s, x + w - 24, y + 8, 56, RGBA(255, 255, 255, 30));
  gfx_clip(s, x, y, w, h);
  gfx_disc(s, x + w - 24, y + 8, 56, RGBA(255, 255, 255, 30));
  gfx_disc(s, x + w - 100, y + h + 6, 38, RGBA(255, 255, 255, 22));
  gfx_clip(s, ox, oy + HOME_HEAD, NW, NH - BAR_H - HOME_HEAD);
  gfx_shadow(s, x + 18, y + 14, 56, 56, 16, 10, RGBA(30, 28, 60, 40));
  gfx_rrect(s, x + 18, y + 14, 56, 56, 16, THEME(RGB(255, 255, 255), RGB(44, 46, 54)));
  office_mark_k(s, x + 18 + 10, y + 14 + 10, 2.0f, m == 2 ? 3 : m);
  gfx_text(s, F_H1, x + 92, y + 16, NAME[m], C_TEXT);
  gfx_text(s, F_UI, x + 92, y + 16 + line_h(F_H1) + 1, DESC[m], C_MUTED);
  float ix, nx, bty;
  hero_btns(&ix, &nx, &bty);
  bty = y + (h - 38) / 2;
  hero_button(s, ox + ix, bty, imp_btn_w(), 0, hot == Z_IMPORT, acc, "Import file", 1);
  hero_button(s, ox + nx, bty, new_btn_w(), 1, hot == Z_NEWBLANK, acc, "New blank", 0);
}

static void draw_home(Panel *p, Surface *s, float ox, float oy, int hot) {
  (void)p;
  float ch = NH - BAR_H;
  gfx_rect(s, ox, oy, NW, ch, N_CANVAS);
  gfx_clip(s, ox, oy + HOME_HEAD, NW, ch - HOME_HEAD);
  float by = oy + HOME_HEAD + HERO_H - N.home_scroll, bb = oy + band_bottom();
  float lx = ox + tpl_x(0);
  draw_hero(s, ox, oy, hot);
  if (N.mode == 2) {
    slides_home_draw(s, ox, oy, hot, HOME_HEAD + HERO_H - N.home_scroll);
    goto header;
  }
  if (N.mode) {
    sheets_home_draw(s, ox, oy, hot, HOME_HEAD + HERO_H - N.home_scroll);
    goto header;
  }
  gfx_text(s, F_UI_MED, lx, by + 18, "Start something new", C_TEXT);
  for (int i = 0; i < NTPL; i++) {
    float x = ox + tpl_x(i), y = oy + tpl_y();
    int h = hot == Z_TPL + i;
    office_card(s, x, y, TPL_W, TPL_H, h, N_ACC);
    if (i == 0) {
      float cx = x + TPL_W / 2, cy = y + TPL_H / 2;
      gfx_disc(s, cx, cy, 24, N_TINT);
      gfx_rrect(s, cx - 10, cy - 1.5f, 20, 3, 1.5f, N_ACC);
      gfx_rrect(s, cx - 1.5f, cy - 10, 3, 20, 1.5f, N_ACC);
    } else {
      Pv pv[MAXPV];
      int n;
      tpl_preview(i, pv, &n);
      draw_preview(s, x, y, TPL_W, TPL_H, pv, n);
    }
    gfx_text_fit(s, F_UI, x + 4, y + TPL_H + 10, TPL_W - 8, TPLS[i].name, h ? N_ACC : C_TEXT);
  }
  float ry = bb + 24;
  gfx_rect(s, lx, bb + 4, NW - 2 * (lx - ox), 1, THEME(RGB(226, 224, 220), RGB(44, 46, 52)));
  gfx_text(s, F_UI_MED, lx, ry, "Recent", C_TEXT);
  if (!N.ndocs) {
    gfx_text(s, F_UI, lx, ry + 44, "No documents yet. Choose a template above to get started.", C_MUTED);
  }
  for (int i = 0; i < N.ndocs; i++) {
    float x = ox + card_x(i), y = oy + card_y(i);
    if (y > oy + ch || y + CARD_STEP < oy + HOME_HEAD) continue;
    int h = hot == Z_CARD + i || hot == Z_CARD_DEL + i;
    gfx_shadow(s, x, y + (h ? 8 : 4), CARD_W, CARD_TH + 58, 14, h ? 22 : 14, RGBA(30, 28, 60, h ? 60 : 30));
    if (h) gfx_rrect(s, x - 2.5f, y - 2.5f, CARD_W + 5, CARD_TH + 63, 16, N_ACC);
    gfx_rrect(s, x, y, CARD_W, CARD_TH + 58, 14, N_PAGE);
    gfx_rect(s, x + 12, y + CARD_TH, CARD_W - 24, 1, THEME(RGB(236, 234, 232), RGB(52, 54, 62)));
    gfx_clip(s, x, y > oy + HOME_HEAD ? y : oy + HOME_HEAD, CARD_W, CARD_TH);
    draw_preview(s, x + 16, y + 14, CARD_W - 32, CARD_TH + 40, N.docs[i].pv, N.docs[i].npv);
    gfx_clip(s, ox, oy + HOME_HEAD, NW, ch - HOME_HEAD);
    gfx_text_fit(s, F_UI_MED, x + 14, y + CARD_TH + 9, CARD_W - 28, N.docs[i].title, C_TEXT);
    char d[48];
    fmt_date(N.docs[i].mtime, d, sizeof d);
    gfx_text(s, F_SMALL, x + 14, y + CARD_TH + 34, d, C_MUTED);
    if (N.confirm_del == i) {
      gfx_rrect(s, x + CARD_W - 86, y + 8, 78, 28, 14, RGB(217, 48, 37));
      gfx_text_c(s, F_SMALL, x + CARD_W - 47, y + 22 - line_h(F_SMALL) / 2, "Delete?", RGB(255, 255, 255));
    } else if (h) {
      float tx = x + CARD_W - 22, ty = y + 22;
      int dh = hot == Z_CARD_DEL + i;
      gfx_disc(s, tx, ty, 15, dh ? RGB(252, 232, 230) : THEME(RGB(241, 243, 244), RGB(56, 60, 68)));
      uint32_t tc = dh ? RGB(217, 48, 37) : C_MUTED;
      gfx_rect(s, tx - 6, ty - 6, 12, 1.6f, tc);
      gfx_rect(s, tx - 2, ty - 8, 4, 1.6f, tc);
      gfx_rrect(s, tx - 4.5f, ty - 4, 9, 10, 1.5f, tc);
      gfx_rrect(s, tx - 3, ty - 2.5f, 6, 7, 1, dh ? RGB(252, 232, 230) : THEME(RGB(241, 243, 244), RGB(56, 60, 68)));
    }
  }
header:
  gfx_noclip(s);
  gfx_rect(s, ox, oy, NW, HOME_HEAD, N_HEAD);
  gfx_rect(s, ox, oy + HOME_HEAD - 1, NW, 1, N_LINE);
  office_mark(s, ox + 20, oy + 16, 2);
  gfx_text(s, F_H1, ox + 64, oy + HOME_HEAD / 2 - line_h(F_H1) / 2, "Office", C_TEXT);
  {
    float sx = ox + (NW - SEG_W * 3) * 0.5f, sy = oy + 14;
    gfx_rrect(s, sx, sy, SEG_W * 3, 36, 18, THEME(RGB(236, 234, 230), RGB(40, 42, 48)));
    float kx = sx + 3 + N.mode * SEG_W - (N.mode == 2 ? 3 : 0);
    gfx_shadow(s, kx, sy + 4, SEG_W - 3, 30, 15, 6, RGBA(30, 28, 60, 30));
    gfx_rrect(s, kx, sy + 3, SEG_W - 3, 30, 15, N_PAGE);
    static const char *const labs[3] = {"Docs", "Sheets", "Slides"};
    for (int i = 0; i < 3; i++) {
      float cx = sx + SEG_W / 2 + i * SEG_W;
      const char *lab = labs[i];
      float tw = gfx_text_w(F_UI_MED, lab);
      int on = N.mode == i;
      uint32_t acc = i == 2 ? P_ACC : i ? S_ACC : N_ACC;
      office_mark(s, cx - tw / 2 - 13, sy + 9, i == 2 ? 3 : i);
      gfx_text(s, F_UI_MED, cx - tw / 2 + 9, sy + 18 - line_h(F_UI_MED) / 2, lab, on ? acc : (hot == Z_SEG + i ? C_TEXT : C_MUTED));
    }
  }
  if (N.toast[0]) gfx_text(s, F_SMALL, ox + NW - 24 - gfx_text_w(F_SMALL, N.toast), oy + HOME_HEAD / 2 - line_h(F_SMALL) / 2, N.toast, N.mode == 2 ? P_ACC : N.mode ? S_ACC : N_ACC);
}

static void go_home(void) {
  office_picker_close();
  commit_title();
  if (N.dirty) save_doc();
  sheets_save_now();
  sheets_home_scan();
  slides_save_now();
  slides_home_scan();
  N.home = 1;
  N.popup = 0;
  N.find_on = N.find_focus = 0;
  N.confirm_del = -1;
  scan_docs();
  set_panel_title();
}

static void home_press(int z, int down) {
  if (down) {
    N.press_zone = z;
    return;
  }
  int pz = N.press_zone;
  N.press_zone = 0;
  if (!z || z != pz) {
    N.confirm_del = -1;
    sheets_home_reset();
    slides_home_reset();
    return;
  }
  if (z == Z_IMPORT) {
    N.confirm_del = -1;
    office_import_open(N.mode);
    return;
  }
  if (z == Z_NEWBLANK) {
    N.confirm_del = -1;
    if (N.mode == 2) slides_new();
    else if (N.mode) sheets_new_from_template(0);
    else from_template(0), show_keyboard();
    N.home = 0;
    set_panel_title();
    return;
  }
  if (z >= Z_SEG && z < Z_SEG + 3) {
    N.mode = z - Z_SEG;
    N.home_scroll = 0;
    N.confirm_del = -1;
    sheets_home_reset();
    slides_home_reset();
    if (N.mode == 2) slides_home_scan();
    else if (N.mode) sheets_home_scan();
    else scan_docs();
    return;
  }
  if (N.mode == 2) {
    if (slides_home_press(z)) {
      N.home = 0;
      set_panel_title();
    }
    return;
  }
  if (N.mode) {
    if (sheets_home_press(z)) {
      N.home = 0;
      set_panel_title();
    }
    return;
  }
  if (z >= Z_TPL && z < Z_TPL + NTPL) {
    N.confirm_del = -1;
    from_template(z - Z_TPL);
    show_keyboard();
  } else if (z >= Z_CARD_DEL && z < Z_CARD_DEL + MAXDOCS) {
    int i = z - Z_CARD_DEL;
    if (N.confirm_del == i) {
      char path[600];
      doc_path(N.docs[i].id, path, sizeof path);
      unlink(path);
      if (!strcmp(N.docs[i].id, N.id)) N.id[0] = 0;
      N.confirm_del = -1;
      scan_docs();
      toast("Moved to trash");
    } else N.confirm_del = i;
  } else if (z >= Z_CARD && z < Z_CARD + MAXDOCS) {
    int i = z - Z_CARD;
    if (N.confirm_del == i) {
      N.confirm_del = -1;
      return;
    }
    N.confirm_del = -1;
    open_doc(N.docs[i].id);
  }
}

void office_go_home(void) { go_home(); }

void office_toast(const char *m) { toast(m); }

void office_show_keyboard(void) { show_keyboard(); }

void office_set_title(void) { set_panel_title(); }

void office_mkdirs(const char *path) { mkdirs(path); }

char *office_read_file(const char *path) { return read_file(path); }

void office_fmt_date(long t, char *out, size_t n) { fmt_date(t, out, n); }

float office_tpl_x(int i, int n) { return (NW - (n * TPL_W + (n - 1) * TPL_GAP)) * 0.5f + i * (TPL_W + TPL_GAP); }

void office_card(Surface *s, float x, float y, float w, float h, int hot, uint32_t acc) {
  gfx_shadow(s, x, y + (hot ? 8 : 4), w, h, 12, hot ? 22 : 14, RGBA(30, 28, 60, hot ? 60 : 32));
  if (hot) gfx_rrect(s, x - 2.5f, y - 2.5f, w + 5, h + 5, 14, acc);
  gfx_rrect(s, x, y, w, h, 12, N_PAGE);
}

void office_trash(Surface *s, float tx, float ty, int dh) {
  gfx_disc(s, tx, ty, 15, dh ? RGB(252, 232, 230) : THEME(RGB(241, 243, 244), RGB(56, 60, 68)));
  uint32_t tc = dh ? RGB(217, 48, 37) : C_MUTED;
  gfx_rect(s, tx - 6, ty - 6, 12, 1.6f, tc);
  gfx_rect(s, tx - 2, ty - 8, 4, 1.6f, tc);
  gfx_rrect(s, tx - 4.5f, ty - 4, 9, 10, 1.5f, tc);
  gfx_rrect(s, tx - 3, ty - 2.5f, 6, 7, 1, dh ? RGB(252, 232, 230) : THEME(RGB(241, 243, 244), RGB(56, 60, 68)));
}

void office_mark_k(Surface *s, float x, float y, float k, int app) {
  if (app == 2) {
    gfx_icon(s, IC_OFFICE, x - 2.3f * k, y - 2.3f * k, 36.6f * k);
    return;
  }
  uint32_t c = app == 3 ? RGB(232, 108, 36) : app ? RGB(16, 150, 98) : RGB(84, 76, 230);
  uint32_t w = RGB(255, 255, 255);
#define MX(v) (x + (v) * k)
#define MY(v) (y + (v) * k)
  gfx_rrect(s, x, y, 18 * k, 18 * k, 5 * k, c);
  if (app == 3) {
    gfx_rrect(s, MX(3.5f), MY(4.5f), 11 * k, 7.5f * k, 1.6f * k, w);
    gfx_rect(s, MX(5.5f), MY(6.6f), 5 * k, 1.2f * k, c);
    gfx_rect(s, MX(8.4f), MY(12), 1.2f * k, 2.4f * k, w);
    gfx_rect(s, MX(6.2f), MY(13.6f), 5.6f * k, 1.2f * k, w);
  } else if (app) {
    gfx_rrect(s, MX(3.5f), MY(3.5f), 11 * k, 11 * k, 1.8f * k, w);
    gfx_rect(s, MX(3.5f), MY(7.1f), 11 * k, 1.1f * k, c);
    gfx_rect(s, MX(3.5f), MY(10.7f), 11 * k, 1.1f * k, c);
    gfx_rect(s, MX(7.1f), MY(3.5f), 1.1f * k, 11 * k, c);
  } else {
    gfx_rrect(s, MX(4.5f), MY(3), 9 * k, 12 * k, 1.6f * k, w);
    gfx_rect(s, MX(6.2f), MY(6), 5.6f * k, 1.2f * k, c);
    gfx_rect(s, MX(6.2f), MY(8.6f), 5.6f * k, 1.2f * k, c);
    gfx_rect(s, MX(6.2f), MY(11.2f), 3.6f * k, 1.2f * k, c);
  }
#undef MX
#undef MY
}

void office_mark(Surface *s, float x, float y, int app) { office_mark_k(s, x, y, 1.f, app); }

static int notes_zone(Panel *p, float x, float y) {
  (void)p;
  if (office_picker_on()) return office_picker_zone(x, y, NW, NH - BAR_H);
  if (N.home) return home_zone(x, y);
  if (N.mode == 2) return slides_zone(x, y);
  if (N.mode) return sheets_zone(x, y);
  if (N.popup) {
    int z = popup_zone(x, y);
    if (z >= 0) return z;
  }
  if (y < HEAD_H) {
    if (x >= 10 && x < 50 && y >= 8 && y < 48) return Z_HOME;
    if (x >= 56 && x < 56 + 480 && y >= 10 && y < 46) return Z_TITLE;
    for (int i = 0; i < 4; i++) {
      float mx = menu_x(i);
      if (x >= mx - 10 && x < mx + gfx_text_w(F_UI, MENU_NAMES[i]) + 10 && y >= 12 && y < 44) return Z_MENU + i;
    }
    return 0;
  }
  if (y >= TOOL_Y && y < TOOL_Y + TOOL_H && x >= pill_x && x < pill_x + pill_w) {
    for (int i = 1; i < T_COUNT; i++)
      if (tools[i].w > 0 && x >= tools[i].x && x < tools[i].x + tools[i].w && y >= TOOL_Y + 5 && y < TOOL_Y + TOOL_H - 5) return i;
    return 0;
  }
  float bottom = NH - BAR_H;
  if (y >= bottom) return 0;
  if (N.eb_on && x >= N.eb_x && x < N.eb_x + N.eb_w && y >= N.eb_y && y < N.eb_y + N.eb_h) return Z_EMB_OPEN;
  if (N.find_on) {
    float fx = find_x(), fy = TOOL_Y + TOOL_H + 10;
    if (x >= fx && x < fx + 360 && y >= fy && y < fy + 44) {
      if (x < fx + 214) return Z_FIND_FIELD;
      if (x >= fx + 262 && x < fx + 294) return Z_FIND_PREV;
      if (x >= fx + 294 && x < fx + 326) return Z_FIND_NEXT;
      if (x >= fx + 326) return Z_FIND_CLOSE;
      return Z_FIND_FIELD;
    }
  }
  return Z_PAGE;
}

static void count_words(int *words, int *chars) {
  int w = 0, c = 0;
  for (int i = 0; i < N.np; i++) {
    Para *p = &N.p[i];
    int in = 0;
    for (int j = 0; j < p->n; j++) {
      if (p->t[j] != ' ') c++;
      if (is_word(p->t[j])) {
        if (!in) w++;
        in = 1;
      } else in = 0;
    }
  }
  *words = w, *chars = c;
}

typedef struct {
  int para, off;
} Match;

static Match matches[512];
static int nmatch, cur_match;

static void find_all(void) {
  nmatch = 0;
  int ql = (int)strlen(N.find);
  if (!ql) return;
  for (int i = 0; i < N.np && nmatch < 512; i++) {
    Para *p = &N.p[i];
    for (int j = 0; j + ql <= p->n && nmatch < 512; j++) {
      int k = 0;
      while (k < ql && tolower((unsigned char)p->t[j + k]) == tolower((unsigned char)N.find[k])) k++;
      if (k == ql) matches[nmatch++] = (Match){i, j};
    }
  }
  if (cur_match >= nmatch) cur_match = 0;
}

static void goto_match(int d) {
  find_all();
  if (!nmatch) return;
  cur_match = (cur_match + d + nmatch) % nmatch;
  N.anc = (Pos){matches[cur_match].para, matches[cur_match].off};
  N.cur = (Pos){matches[cur_match].para, matches[cur_match].off + (int)strlen(N.find)};
  ensure_visible();
}

static void icon_lines(Surface *s, float cx, float cy, int align, uint32_t c) {
  float ws[4] = {16, 11, 16, 11};
  for (int i = 0; i < 4; i++) {
    float w = ws[i], x0 = align == A_LEFT ? cx - 8 : align == A_CENTER ? cx - w / 2 : cx + 8 - w;
    gfx_rect(s, x0, cy - 7 + i * 4.6f, w, 1.8f, c);
  }
}

static void draw_tool(Surface *s, int id, float ox, float oy, int hot, int active) {
  Tool *t = &tools[id];
  float x = ox + t->x, y = oy + TOOL_Y + 5, h = TOOL_H - 10, cx = x + t->w / 2, cy = y + h / 2;
  uint32_t ic = active ? N_ACC : THEME(RGB(64, 64, 72), RGB(220, 222, 230));
  if (active) gfx_rrect(s, x, y, t->w, h, 9, N_TINT);
  else if (hot) gfx_rrect(s, x, y, t->w, h, 9, N_TINT_HOT);
  switch (id) {
  case T_UNDO:
  case T_REDO: {
    float d = id == T_UNDO ? 1.f : -1.f, r = 6.f, acx = cx + d * 1.f, acy = cy + 3.f;
    for (int i = 0; i < 10; i++) {
      float a0 = PI_F + PI_F * i / 10.f, a1 = PI_F + PI_F * (i + 1) / 10.f;
      gfx_line(s, acx + cosf(a0) * r * d, acy + sinf(a0) * r, acx + cosf(a1) * r * d, acy + sinf(a1) * r, 1.7f, ic);
    }
    float hx = acx - d * r, hy = acy;
    gfx_line(s, hx, hy + 0.6f, hx - d * 3.4f, hy - 3.4f, 1.7f, ic);
    gfx_line(s, hx, hy + 0.6f, hx + d * 3.6f, hy - 3.0f, 1.7f, ic);
    break;
  }
  case T_STYLE:
    gfx_text_fit(s, F_UI, x + 10, y + (h - line_h(F_UI)) / 2, t->w - 30, STYLE_NAMES[N.p[N.cur.para].style], ic);
    gfx_tri(s, x + t->w - 18, cy - 2, x + t->w - 10, cy - 2, x + t->w - 14, cy + 3, ic);
    break;
  case T_BOLD:
    gfx_text_c(s, doc_font(0, 1, 0), cx, y + (h - line_h(doc_font(0, 1, 0))) / 2, "B", ic);
    break;
  case T_ITAL:
    gfx_text_c(s, doc_font(0, 0, 1), cx, y + (h - line_h(doc_font(0, 0, 1))) / 2, "I", ic);
    break;
  case T_UNDER:
    gfx_text_c(s, doc_font(0, 0, 0), cx, y + (h - line_h(doc_font(0, 0, 0))) / 2 - 2, "U", ic);
    gfx_rect(s, cx - 6, cy + 8, 12, 1.6f, ic);
    break;
  case T_STRIKE:
    gfx_text_c(s, doc_font(0, 0, 0), cx, y + (h - line_h(doc_font(0, 0, 0))) / 2, "S", ic);
    gfx_rect(s, cx - 7, cy, 14, 1.6f, ic);
    break;
  case T_COLOR: {
    gfx_text_c(s, doc_font(0, 0, 0), cx, y + (h - line_h(doc_font(0, 0, 0))) / 2 - 3, "A", ic);
    int c = (N.fmt >> 4) & 7;
    gfx_rect(s, cx - 8, cy + 8, 16, 3, c ? OFF_COLORS[c] : THEME(RGB(32, 33, 36), RGB(230, 232, 236)));
    break;
  }
  case T_ALEFT:
    icon_lines(s, cx, cy, A_LEFT, ic);
    break;
  case T_ACENTER:
    icon_lines(s, cx, cy, A_CENTER, ic);
    break;
  case T_ARIGHT:
    icon_lines(s, cx, cy, A_RIGHT, ic);
    break;
  case T_CHECK:
    for (int i = 0; i < 2; i++) {
      float ry = cy - 6 + i * 8;
      gfx_rrect(s, cx - 8, ry - 2.5f, 5, 5, 1, ic);
      gfx_rect(s, cx - 1, ry - 0.8f, 9, 1.6f, ic);
    }
    gfx_line(s, cx - 7.2f, cy - 6.2f, cx - 5.6f, cy - 4.8f, 1.2f, THEME(RGB(255, 255, 255), RGB(30, 33, 39)));
    break;
  case T_BULLET:
    for (int i = 0; i < 3; i++) {
      gfx_disc(s, cx - 6, cy - 6 + i * 6, 1.6f, ic);
      gfx_rect(s, cx - 2, cy - 6.8f + i * 6, 10, 1.6f, ic);
    }
    break;
  case T_NUMBER:
    for (int i = 0; i < 3; i++) {
      char d[2] = {(char)('1' + i), 0};
      gfx_text(s, F_SMALL, cx - 9, cy - 11 + i * 6.5f, d, ic);
      gfx_rect(s, cx - 2, cy - 6.8f + i * 6, 10, 1.6f, ic);
    }
    break;
  case T_OUTDENT:
  case T_INDENT:
    for (int i = 0; i < 4; i++) gfx_rect(s, cx - (i == 1 || i == 2 ? 2 : 8), cy - 7 + i * 4.6f, i == 1 || i == 2 ? 10 : 16, 1.6f, ic);
    if (id == T_INDENT) gfx_tri(s, cx - 8, cy - 3.6f, cx - 8, cy + 3.6f, cx - 4.5f, cy, ic);
    else gfx_tri(s, cx - 4.5f, cy - 3.6f, cx - 4.5f, cy + 3.6f, cx - 8, cy, ic);
    break;
  case T_CLEAR:
    gfx_text_c(s, doc_font(0, 0, 1), cx - 1, y + (h - line_h(doc_font(0, 0, 1))) / 2, "T", ic);
    gfx_line(s, cx - 7, cy + 7, cx + 7, cy - 7, 1.6f, ic);
    break;
  case T_FIND:
    gfx_ring(s, cx - 2, cy - 2, 5.5f, 1.8f, ic);
    gfx_line(s, cx + 2, cy + 2, cx + 7, cy + 7, 2.f, ic);
    break;
  }
}

static int sel_all_have(int bit) {
  if (!has_sel()) return (N.fmt & bit) != 0;
  Pos a, b;
  sel_range(&a, &b);
  for (int i = a.para; i <= b.para; i++) {
    Para *p = &N.p[i];
    int s = i == a.para ? a.off : 0, e = i == b.para ? b.off : p->n;
    for (int j = s; j < e; j++)
      if (!(p->f[j] & bit)) return 0;
  }
  return 1;
}


static void fmt_date(long t, char *out, size_t n) {
  time_t tt = (time_t)t, now = time(NULL);
  struct tm a, b;
  localtime_r(&tt, &a);
  localtime_r(&now, &b);
  if (a.tm_year == b.tm_year && a.tm_yday == b.tm_yday) strftime(out, n, "Edited %H:%M", &a);
  else strftime(out, n, "Edited %b %d", &a);
}

static void draw_page(Panel *p, Surface *s, float ox, float oy, int hot) {
  layout();
  N.eb_on = 0;
  float vx = ox, vy = oy + BODY_Y, vw = NW, vh = view_h();
  gfx_rect(s, vx, vy, vw, vh, N_CANVAS);
  gfx_clip(s, vx, vy, vw, vh);
  float px = ox + page_x(), py = vy + PAGE_TOP - N.scroll;
  float ph = doc_h + PAGE_PAD * 1.6f + 40;
  if (ph < vh + 200) ph = vh + 200;
  gfx_shadow(s, px, py + 6, PAGE_W, ph, 10, 26, RGBA(30, 28, 60, 34));
  gfx_rrect(s, px, py, PAGE_W, ph, 10, N_PAGE);
  float tx = px + PAGE_PAD, ty = oy + text_origin_y();
  uint32_t ink = THEME(RGB(32, 33, 36), RGB(230, 232, 236));
  Pos sa, sb;
  sel_range(&sa, &sb);
  int sel = has_sel();
  int focused = W.focus == (int)(p - P) && !N.title_edit && !N.find_focus;
  int numbers[8] = {0};
  int prev_para = -1;
  for (int li = 0; li < nlines; li++) {
    Line *l = &lines[li];
    Para *q = &N.p[l->para];
    float ly = ty + l->y;
    if (l->para != prev_para) {
      if (q->list == L_NUMBER) {
        numbers[q->indent > 7 ? 7 : q->indent]++;
        for (int k = q->indent + 1; k < 8; k++) numbers[k] = 0;
      } else if (!q->list) memset(numbers, 0, sizeof numbers);
    }
    if (ly > vy + vh + 40 || ly + l->h < vy - 40) {
      prev_para = l->para;
      continue;
    }
    const Font *bf = doc_font(para_size(q), 0, 0);
    float fh = line_h(bf), tyy = ly + (l->h - fh) * 0.5f;
    if (q->hr == 2) {
      int k, sub;
      char id[40];
      int on = N.cur.para == l->para && !sel;
      if (office_embed_parse(q->ref, &k, id, sizeof id, &sub)) {
        float ey = ly + 9, eh = l->h - 18;
        office_embed_draw(s, k, id, sub, tx, ey, TEXT_W, eh, EMB_CHROME | (on ? EMB_SEL : 0));
        if (sel && l->para >= sa.para && l->para <= sb.para) gfx_rect(s, tx, ey, TEXT_W, eh, RGBA(84, 76, 230, 50));
        if (on) {
          static const char *const lab[3] = {"Open in Docs", "Open in Sheets", "Open in Slides"};
          float bw = gfx_text_w(F_SMALL, lab[k]) + 30, bx = tx + TEXT_W - bw - 8, by = ey + 6;
          int bh = hot == Z_EMB_OPEN;
          gfx_rrect(s, bx, by, bw, 24, 12, bh ? office_acc(k) : THEME(RGB(255, 255, 255), RGB(56, 58, 66)));
          if (!bh) gfx_rrect(s, bx + 0.5f, by + 0.5f, bw - 1, 23, 11.5f, THEME(RGB(255, 255, 255), RGB(56, 58, 66)));
          gfx_text(s, F_SMALL, bx + 12, by + 12 - line_h(F_SMALL) / 2, lab[k], bh ? RGB(255, 255, 255) : office_acc(k));
          gfx_line(s, bx + bw - 15, by + 9, bx + bw - 10, by + 9, 1.4f, bh ? RGB(255, 255, 255) : office_acc(k));
          gfx_line(s, bx + bw - 10, by + 9, bx + bw - 10, by + 14, 1.4f, bh ? RGB(255, 255, 255) : office_acc(k));
          gfx_line(s, bx + bw - 10, by + 9, bx + bw - 16, by + 15, 1.4f, bh ? RGB(255, 255, 255) : office_acc(k));
          N.eb_on = 1, N.eb_x = bx - ox, N.eb_y = by - oy, N.eb_w = bw, N.eb_h = 24;
        }
      }
      prev_para = l->para;
      continue;
    }
    if (q->hr) {
      gfx_rect(s, tx, ly + 12, TEXT_W, 1.4f, THEME(RGB(196, 199, 205), RGB(80, 85, 95)));
      if (sel && l->para >= sa.para && l->para <= sb.para && pos_cmp(sa, sb)) gfx_rect(s, tx, ly + 4, TEXT_W, 18, N_SEL);
      prev_para = l->para;
      continue;
    }
    if (l->para != prev_para && q->list) {
      float mx = tx + q->indent * 36.f, my = tyy + fh * 0.55f;
      if (q->list == L_BULLET) {
        int k = q->indent % 3;
        if (k == 0) gfx_disc(s, mx + 12, my, 2.8f, ink);
        else if (k == 1) gfx_ring(s, mx + 12, my, 2.6f, 1.2f, ink);
        else gfx_rect(s, mx + 9.5f, my - 2.5f, 5, 5, ink);
      } else if (q->list == L_NUMBER) {
        char num[16];
        snprintf(num, sizeof num, "%d.", numbers[q->indent > 7 ? 7 : q->indent]);
        const Font *nf = doc_font(para_size(q), 0, 0);
        gfx_text(s, nf, mx + 24 - gfx_text_w(nf, num), tyy, num, ink);
      } else {
        float bs = 15, bx = mx + 4, by = my - bs * 0.5f;
        if (q->check) {
          gfx_rrect(s, bx, by, bs, bs, 4, N_ACC);
          gfx_line(s, bx + 3.5f, by + 7.8f, bx + 6.4f, by + 10.6f, 2.f, RGB(255, 255, 255));
          gfx_line(s, bx + 6.4f, by + 10.6f, bx + 11.8f, by + 4.6f, 2.f, RGB(255, 255, 255));
        } else {
          gfx_rrect(s, bx, by, bs, bs, 3, THEME(RGB(95, 99, 104), RGB(160, 166, 176)));
          gfx_rrect(s, bx + 1.8f, by + 1.8f, bs - 3.6f, bs - 3.6f, 1.6f, THEME(RGB(255, 255, 255), RGB(36, 39, 45)));
        }
      }
    }
    float cx = tx + l->x;
    for (int j = l->start; j < l->end; j++) {
      const Font *f = char_font(q, q->f[j]);
      float w = doc_char_w(f, q->t[j]);
      if (sel) {
        Pos cp = {l->para, j};
        if (pos_cmp(cp, sa) >= 0 && pos_cmp(cp, sb) < 0) gfx_rect(s, cx, ly, w + 0.5f, l->h, N_SEL);
      }
      cx += w;
    }
    if (sel && l->end == q->n && l->para >= sa.para && l->para < sb.para) gfx_rect(s, cx, ly, 6, l->h, N_SEL);
    if (N.find_on && nmatch) {
      int ql = (int)strlen(N.find);
      for (int m = 0; m < nmatch; m++) {
        if (matches[m].para != l->para || matches[m].off + ql <= l->start || matches[m].off >= l->end) continue;
        int a = matches[m].off < l->start ? l->start : matches[m].off;
        int b = matches[m].off + ql > l->end ? l->end : matches[m].off + ql;
        float x0 = tx + l->x + run_w(q, l->start, a), x1 = x0 + run_w(q, a, b);
        gfx_rect(s, x0, ly + 1, x1 - x0, l->h - 2, m == cur_match ? RGBA(255, 160, 40, 170) : RGBA(255, 214, 70, 140));
      }
    }
    cx = tx + l->x;
    for (int j = l->start; j < l->end; j++) {
      int fm = q->f[j];
      const Font *f = char_font(q, fm);
      float w = doc_char_w(f, q->t[j]);
      int col = (fm >> 4) & 7;
      uint32_t c = col ? OFF_COLORS[col] : ink;
      if (!col && q->style == ST_TITLE) c = ink;
      if (q->list == L_CHECK && q->check) c = THEME(RGB(128, 134, 139), RGB(140, 146, 156));
      if (g_dark && col == 1) c = ink;
      char ch[2] = {q->t[j], 0};
      if (q->t[j] != ' ') gfx_text(s, f, cx, tyy, ch, c);
      if (fm & F_UNDER) gfx_rect(s, cx, tyy + (float)f->ascent / SCALE + 2.2f, w + 0.4f, 1.2f, c);
      if ((fm & F_STRIKE) || (q->list == L_CHECK && q->check)) gfx_rect(s, cx, tyy + (float)f->ascent / SCALE * 0.66f, w + 0.4f, 1.2f, c);
      cx += w;
    }
    prev_para = l->para;
  }
  if (focused && N.blink && !sel && !N.p[N.cur.para].hr) {
    float x, y, h;
    pos_xy(N.cur, &x, &y, &h);
    gfx_rect(s, tx + x - 0.6f, ty + y + 2, 1.8f, h - 4, THEME(RGB(32, 33, 36), RGB(230, 232, 236)));
  }
  gfx_noclip(s);
  float total = doc_h + PAGE_PAD * 2 + 200, frac = vh / total;
  if (frac < 1) {
    float th = vh * frac, tyb = vy + (vh - th) * (N.scroll / (total - vh));
    gfx_rrect(s, ox + NW - 10, tyb, 5, th, 2.5f, THEME(RGBA(0, 0, 0, 60), RGBA(255, 255, 255, 60)));
  }
}

static void draw_popup(Surface *s, float ox, float oy, int hot) {
  float px, py, pw, ph;
  popup_rect(&px, &py, &pw, &ph);
  px += ox, py += oy;
  gfx_shadow(s, px, py + 6, pw, ph, 14, 22, RGBA(30, 28, 60, 50));
  gfx_rrect(s, px - 1, py - 1, pw + 2, ph + 2, 15, THEME(RGB(230, 228, 236), RGB(58, 60, 68)));
  gfx_rrect(s, px, py, pw, ph, 14, THEME(RGB(255, 255, 255), RGB(40, 42, 50)));
  if (N.popup <= POP_MENU3) {
    int m = N.popup - POP_MENU0;
    float y = py + 4;
    for (int i = 0; i < MENU_LEN[m]; i++) {
      const Item *it = &MENUS[m][i];
      if (!it->label) {
        gfx_rect(s, px + 8, y + 4, pw - 16, 1, C_BAR_LINE);
        y += 9;
        continue;
      }
      if (hot == Z_POPUP + i) gfx_rrect(s, px + 6, y + 1, pw - 12, 32, 8, N_TINT_HOT);
      gfx_text(s, F_UI, px + 18, y + (34 - line_h(F_UI)) / 2, it->label, C_TEXT);
      if (it->key[0]) gfx_text(s, F_SMALL, px + pw - 14 - gfx_text_w(F_SMALL, it->key), y + (34 - line_h(F_SMALL)) / 2, it->key, C_MUTED);
      y += 34;
    }
  } else if (N.popup == POP_STYLE) {
    for (int i = 0; i < 4; i++) {
      int st = 3 - i;
      float y = py + 4 + i * 52;
      if (N.p[N.cur.para].style == st) gfx_rrect(s, px + 6, y + 2, pw - 12, 48, 9, N_TINT);
      else if (hot == Z_POPUP + i) gfx_rrect(s, px + 6, y + 2, pw - 12, 48, 9, N_TINT_HOT);
      const Font *f = doc_font(st, st == ST_H1 || st == ST_H2, 0);
      gfx_text_fit(s, f, px + 18, y + (52 - line_h(f)) / 2, pw - 30, STYLE_NAMES[st], C_TEXT);
    }
  } else {
    gfx_text(s, F_SMALL, px + 14, py + 12, "Text color", C_MUTED);
    for (int i = 0; i < 8; i++) {
      float cx = px + 14 + (i % 4) * 48, cy = py + 40 + (i / 4) * 32;
      if (hot == Z_POPUP + i) gfx_rrect(s, cx - 3, cy - 3, 46, 30, 6, C_HOVER);
      if (i == 0) {
        gfx_rrect(s, cx, cy, 40, 24, 5, C_WIN_EDGE);
        gfx_rrect(s, cx + 1.5f, cy + 1.5f, 37, 21, 4, THEME(RGB(255, 255, 255), RGB(40, 44, 52)));
        gfx_line(s, cx + 4, cy + 20, cx + 36, cy + 4, 1.4f, RGB(217, 48, 37));
      } else gfx_rrect(s, cx, cy, 40, 24, 5, OFF_COLORS[i]);
      if (((N.fmt >> 4) & 7) == i) gfx_ring(s, cx + 20, cy + 12, 5, 1.6f, i ? RGB(255, 255, 255) : C_TEXT);
    }
  }
}

static void notes_draw(Panel *p, Surface *s, float ox, float oy) {
  ensure_loaded();
  N.panel = (int)(p - P);
  int hot = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  float ch = NH - BAR_H;
  if (N.home) {
    draw_home(p, s, ox, oy, hot);
    office_picker_draw(s, ox, oy, NW, ch, hot);
    return;
  }
  if (N.mode == 2) {
    slides_draw(p, s, ox, oy, hot);
    if (N.toast[0] && !slides_presenting()) {
      float tw = gfx_text_w(F_SMALL, N.toast);
      gfx_rrect(s, ox + NW - 16 - tw - 28, oy + ch - 44, tw + 28, 30, 15, P_TINT);
      gfx_text(s, F_SMALL, ox + NW - 16 - tw - 14, oy + ch - 29 - line_h(F_SMALL) / 2, N.toast, P_ACC);
    }
    office_picker_draw(s, ox, oy, NW, ch, hot);
    return;
  }
  if (N.mode) {
    sheets_draw(p, s, ox, oy, hot);
    if (N.toast[0]) {
      float tw = gfx_text_w(F_SMALL, N.toast);
      gfx_rrect(s, ox + NW - 16 - tw - 28, oy + ch - 41, tw + 28, 30, 15, S_TINT);
      gfx_text(s, F_SMALL, ox + NW - 16 - tw - 14, oy + ch - 26 - line_h(F_SMALL) / 2, N.toast, S_ACC);
    }
    return;
  }
  draw_page(p, s, ox, oy, hot);
  gfx_rect(s, ox, oy, NW, HEAD_H, N_HEAD);
  gfx_rect(s, ox, oy + HEAD_H - 1, NW, 1, THEME(RGB(232, 230, 226), RGB(44, 46, 52)));
  if (hot == Z_HOME) gfx_rrect(s, ox + 12, oy + 10, 36, 36, 10, N_TINT_HOT);
  uint32_t chev = THEME(RGB(64, 64, 72), RGB(220, 222, 230));
  gfx_line(s, ox + 33, oy + 20, ox + 26, oy + 28, 2.2f, chev);
  gfx_line(s, ox + 26, oy + 28, ox + 33, oy + 36, 2.2f, chev);
  if (N.title_edit) {
    float tw = gfx_text_w(F_UI_MED, N.title_buf), bw = tw + 28 > 260 ? tw + 28 : 260;
    gfx_rrect(s, ox + 56, oy + 12, bw, 32, 9, N_ACC);
    gfx_rrect(s, ox + 57.5f, oy + 13.5f, bw - 3, 29, 8, N_PAGE);
    gfx_text(s, F_UI_MED, ox + 68, oy + 28 - line_h(F_UI_MED) / 2, N.title_buf, C_TEXT);
    if (N.blink) gfx_rect(s, ox + 69 + tw, oy + 19, 1.6f, 18, N_ACC);
  } else {
    float tw = gfx_text_w(F_UI_MED, N.title);
    if (tw > 460) tw = 460;
    if (hot == Z_TITLE) gfx_rrect(s, ox + 56, oy + 12, tw + 24, 32, 9, N_TINT_HOT);
    gfx_text_fit(s, F_UI_MED, ox + 68, oy + 28 - line_h(F_UI_MED) / 2, 460, N.title, C_TEXT);
  }
  for (int i = 0; i < 4; i++) {
    float mx = ox + menu_x(i);
    int open = N.popup == POP_MENU0 + i;
    if (open || hot == Z_MENU + i) gfx_rrect(s, mx - 10, oy + 12, gfx_text_w(F_UI, MENU_NAMES[i]) + 20, 32, 9, open ? N_TINT : N_TINT_HOT);
    gfx_text(s, F_UI, mx, oy + 28 - line_h(F_UI) / 2, MENU_NAMES[i], open ? N_ACC : C_TEXT);
  }
  gfx_shadow(s, ox + pill_x, oy + TOOL_Y + 3, pill_w, TOOL_H, 22, 16, RGBA(30, 28, 60, 40));
  gfx_rrect(s, ox + pill_x - 1, oy + TOOL_Y - 1, pill_w + 2, TOOL_H + 2, 23, THEME(RGB(230, 228, 236), RGB(54, 56, 64)));
  gfx_rrect(s, ox + pill_x, oy + TOOL_Y, pill_w, TOOL_H, 22, N_PAGE);
  for (int i = 0; i < nseps; i++) gfx_rect(s, ox + seps[i], oy + TOOL_Y + 13, 1, TOOL_H - 26, THEME(RGB(226, 224, 230), RGB(66, 68, 76)));
  Para *cp = &N.p[N.cur.para];
  for (int i = 1; i < T_COUNT; i++) {
    int active = 0;
    if (i == T_BOLD) active = sel_all_have(F_BOLD);
    else if (i == T_ITAL) active = sel_all_have(F_ITAL);
    else if (i == T_UNDER) active = sel_all_have(F_UNDER);
    else if (i == T_STRIKE) active = sel_all_have(F_STRIKE);
    else if (i == T_ALEFT) active = cp->align == A_LEFT;
    else if (i == T_ACENTER) active = cp->align == A_CENTER;
    else if (i == T_ARIGHT) active = cp->align == A_RIGHT;
    else if (i == T_CHECK) active = cp->list == L_CHECK;
    else if (i == T_BULLET) active = cp->list == L_BULLET;
    else if (i == T_NUMBER) active = cp->list == L_NUMBER;
    else if (i == T_FIND) active = N.find_on;
    else if (i == T_STYLE) active = N.popup == POP_STYLE;
    else if (i == T_COLOR) active = N.popup == POP_COLOR;
    draw_tool(s, i, ox, oy, hot == i, active);
  }
  if (N.find_on) {
    float fx = ox + find_x(), fy = oy + TOOL_Y + TOOL_H + 10;
    gfx_shadow(s, fx, fy + 4, 360, 44, 14, 16, RGBA(30, 28, 60, 40));
    gfx_rrect(s, fx, fy, 360, 44, 14, THEME(RGB(255, 255, 255), RGB(40, 44, 52)));
    gfx_rrect(s, fx + 8, fy + 7, 206, 30, 8, N.find_focus ? N_ACC : C_WIN_EDGE);
    gfx_rrect(s, fx + 9.5f, fy + 8.5f, 203, 27, 5, THEME(RGB(255, 255, 255), RGB(36, 39, 45)));
    const char *q = N.find[0] ? N.find : "Find in document";
    gfx_text_fit(s, F_UI, fx + 18, fy + 22 - line_h(F_UI) / 2, 186, q, N.find[0] ? C_TEXT : C_MUTED);
    if (N.find_focus && N.blink) gfx_rect(s, fx + 19 + (N.find[0] ? gfx_text_w(F_UI, N.find) : 0), fy + 13, 1.5f, 18, C_ACCENT);
    char cnt[32];
    if (N.find[0]) snprintf(cnt, sizeof cnt, "%d of %d", nmatch ? cur_match + 1 : 0, nmatch);
    else cnt[0] = 0;
    gfx_text(s, F_SMALL, fx + 222, fy + 22 - line_h(F_SMALL) / 2, cnt, C_MUTED);
    uint32_t ic = C_TEXT;
    float ax = fx + 278, ay = fy + 22;
    if (hot == Z_FIND_PREV) gfx_disc(s, ax, ay, 14, C_HOVER);
    gfx_line(s, ax - 5, ay + 2.5f, ax, ay - 2.5f, 1.8f, ic);
    gfx_line(s, ax, ay - 2.5f, ax + 5, ay + 2.5f, 1.8f, ic);
    ax += 32;
    if (hot == Z_FIND_NEXT) gfx_disc(s, ax, ay, 14, C_HOVER);
    gfx_line(s, ax - 5, ay - 2.5f, ax, ay + 2.5f, 1.8f, ic);
    gfx_line(s, ax, ay + 2.5f, ax + 5, ay - 2.5f, 1.8f, ic);
    ax += 32;
    if (hot == Z_FIND_CLOSE) gfx_disc(s, ax, ay, 14, C_HOVER);
    gfx_line(s, ax - 5, ay - 5, ax + 5, ay + 5, 1.8f, ic);
    gfx_line(s, ax + 5, ay - 5, ax - 5, ay + 5, 1.8f, ic);
  }
  int w, c;
  count_words(&w, &c);
  char st[48];
  snprintf(st, sizeof st, "%d word%s", w, w == 1 ? "" : "s");
  const char *status = N.dirty ? "Saving" : "Saved";
  float sw = gfx_text_w(F_SMALL, status), ww = gfx_text_w(F_SMALL, st);
  float pw = 18 + 10 + sw + 21 + ww + 14, ph = 30, px = ox + 16, py = oy + ch - ph - 14;
  gfx_rrect(s, px - 1, py - 1, pw + 2, ph + 2, 16, THEME(RGB(230, 228, 236), RGB(50, 52, 60)));
  gfx_rrect(s, px, py, pw, ph, 15, N_HEAD);
  float ty = py + ph / 2 - line_h(F_SMALL) / 2;
  if (N.dirty) gfx_ring(s, px + 16, py + ph / 2, 4, 1.6f, C_MUTED);
  else {
    gfx_line(s, px + 12, py + ph / 2, px + 15, py + ph / 2 + 3, 1.7f, N_ACC);
    gfx_line(s, px + 15, py + ph / 2 + 3, px + 20.5f, py + ph / 2 - 3.5f, 1.7f, N_ACC);
  }
  gfx_text(s, F_SMALL, px + 28, ty, status, C_MUTED);
  gfx_disc(s, px + 28 + sw + 10, py + ph / 2, 1.5f, C_MUTED);
  gfx_text(s, F_SMALL, px + 28 + sw + 21, ty, st, C_MUTED);
  if (N.toast[0]) {
    float tw = gfx_text_w(F_SMALL, N.toast), tx = ox + NW - 16 - tw - 28;
    gfx_rrect(s, tx, py, tw + 28, ph, 15, N_TINT);
    gfx_text(s, F_SMALL, tx + 14, ty, N.toast, N_ACC);
  }
  if (N.popup) draw_popup(s, ox, oy, hot);
  office_picker_draw(s, ox, oy, NW, ch, hot);
}

static void begin_title_edit(void) {
  N.title_edit = 1;
  snprintf(N.title_buf, sizeof N.title_buf, "%s", N.title);
  N.find_focus = 0;
  show_keyboard();
}

static void commit_title(void) {
  if (!N.title_edit) return;
  N.title_edit = 0;
  char *t = N.title_buf;
  while (*t == ' ') t++;
  if (*t && strcmp(t, N.title)) {
    snprintf(N.title, sizeof N.title, "%s", t);
    save_doc();
    if (N.panel >= 0) {
      snprintf(P[N.panel].title, sizeof P[N.panel].title, "%.50s - Notes", N.title);
      P[N.panel].chrome_key = -1;
    }
  }
}

static void export_doc(int md) {
  char dir[512], path[700], name[96];
  snprintf(dir, sizeof dir, "%s/Documents", user_home());
  mkdirs(dir);
  int k = 0;
  for (const char *t = N.title; *t && k < 80; t++) name[k++] = (isalnum((unsigned char)*t) || *t == '-' || *t == '_') ? *t : (*t == ' ' ? ' ' : '_');
  name[k] = 0;
  if (!k) snprintf(name, sizeof name, "Untitled");
  snprintf(path, sizeof path, "%s/%s.%s", dir, name, md ? "md" : "txt");
  FILE *f = fopen(path, "w");
  if (!f) {
    toast("Could not save the file");
    return;
  }
  int num[8] = {0};
  for (int i = 0; i < N.np; i++) {
    Para *p = &N.p[i];
    if (p->hr == 2) {
      int ek, sub;
      char id[40], t[96] = "";
      if (office_embed_parse(p->ref, &ek, id, sizeof id, &sub) && office_embed_title(ek, id, sub, t, sizeof t))
        fprintf(f, md ? "> %s: %s\n\n" : "[%s: %s]\n", ek == 0 ? "Document" : ek == 1 ? "Spreadsheet" : "Slide", t);
      continue;
    }
    if (p->hr) {
      fputs(md ? "---\n\n" : "----------\n", f);
      continue;
    }
    if (p->list == L_NUMBER) {
      num[p->indent]++;
      for (int j = p->indent + 1; j < 8; j++) num[j] = 0;
    } else if (!p->list) memset(num, 0, sizeof num);
    for (int j = 0; j < p->indent; j++) fputs(md ? "    " : "  ", f);
    if (md && p->style == ST_TITLE) fputs("# ", f);
    if (md && p->style == ST_H1) fputs("## ", f);
    if (md && p->style == ST_H2) fputs("### ", f);
    if (p->list == L_BULLET) fputs(md ? "- " : "* ", f);
    if (p->list == L_NUMBER) fprintf(f, "%d. ", num[p->indent]);
    if (p->list == L_CHECK) fputs(p->check ? "- [x] " : "- [ ] ", f);
    int open = 0;
    for (int j = 0; j <= p->n; j++) {
      int fm = j < p->n ? p->f[j] & 15 : 0;
      if (md && fm != open) {
        if (open & F_UNDER) fputs("</u>", f);
        if (open & F_STRIKE) fputs("~~", f);
        if (open & F_ITAL) fputs("*", f);
        if (open & F_BOLD) fputs("**", f);
        if (fm & F_BOLD) fputs("**", f);
        if (fm & F_ITAL) fputs("*", f);
        if (fm & F_STRIKE) fputs("~~", f);
        if (fm & F_UNDER) fputs("<u>", f);
        open = fm;
      }
      if (j < p->n) fputc(p->t[j], f);
    }
    fputc('\n', f);
    int next_list = i + 1 < N.np && N.p[i + 1].list && p->list;
    if (md && !next_list) fputc('\n', f);
  }
  fclose(f);
  char m[200];
  snprintf(m, sizeof m, "Saved to Documents/%s.%s", name, md ? "md" : "txt");
  toast(m);
}

static void run_cmd(int c) {
  N.popup = 0;
  switch (c) {
  case CM_NEWDOC:
    new_doc("Untitled document", NULL);
    show_keyboard();
    break;
  case CM_COPYDOC: {
    char *s = serialize(0), t[120];
    snprintf(t, sizeof t, "Copy of %.80s", N.title);
    new_doc(t, s);
    free(s);
    toast("Copy created");
    break;
  }
  case CM_RENAME:
    begin_title_edit();
    break;
  case CM_DELETE: {
    char path[600];
    doc_path(N.id, path, sizeof path);
    unlink(path);
    N.dirty = 0;
    N.id[0] = 0;
    go_home();
    toast("Moved to trash");
    break;
  }
  case CM_EXPORT_MD:
    export_doc(1);
    break;
  case CM_EXPORT_TXT:
    export_doc(0);
    break;
  case CM_EXPORT_DOCX:
    commit_title();
    export_docx();
    break;
  case CM_EXPORT_RTF:
    commit_title();
    export_rtf();
    break;
  case CM_UNDO:
    undo_redo(0);
    break;
  case CM_REDO:
    undo_redo(1);
    break;
  case CM_CUT:
  case CM_COPY: {
    char *s = copy_sel();
    if (s) {
      free(N.clip);
      N.clip = s;
      if (c == CM_CUT) {
        push_undo(0);
        delete_sel();
        changed();
      }
    }
    break;
  }
  case CM_PASTE:
    paste();
    break;
  case CM_SELALL:
    N.anc = (Pos){0, 0};
    N.cur = (Pos){N.np - 1, N.p[N.np - 1].n};
    break;
  case CM_FIND:
    N.find_on = 1;
    N.find_focus = 1;
    N.title_edit = 0;
    find_all();
    show_keyboard();
    break;
  case CM_INS_CHECK:
    set_list(L_CHECK);
    break;
  case CM_BULLET:
    set_list(L_BULLET);
    break;
  case CM_NUMBER:
    set_list(L_NUMBER);
    break;
  case CM_INS_HR:
    insert_hr();
    break;
  case CM_EMB_DOC:
  case CM_EMB_SHEET:
  case CM_EMB_SLIDE:
    commit_title();
    if (N.dirty) save_doc();
    office_picker_open(c - CM_EMB_DOC, 0, N.id);
    break;
  case CM_INS_DATE: {
    char d[64];
    time_t t = time(NULL);
    struct tm tm;
    localtime_r(&t, &tm);
    strftime(d, sizeof d, "%B %d, %Y", &tm);
    insert_text(d, 0);
    break;
  }
  case CM_BOLD:
    toggle_fmt(F_BOLD);
    break;
  case CM_ITAL:
    toggle_fmt(F_ITAL);
    break;
  case CM_UNDER:
    toggle_fmt(F_UNDER);
    break;
  case CM_STRIKE:
    toggle_fmt(F_STRIKE);
    break;
  case CM_TITLE:
    set_style(ST_TITLE);
    break;
  case CM_H1:
    set_style(ST_H1);
    break;
  case CM_H2:
    set_style(ST_H2);
    break;
  case CM_NORMAL:
    set_style(ST_NORMAL);
    break;
  case CM_ALEFT:
    set_align(A_LEFT);
    break;
  case CM_ACENTER:
    set_align(A_CENTER);
    break;
  case CM_ARIGHT:
    set_align(A_RIGHT);
    break;
  case CM_CLEAR:
    clear_fmt();
    break;
  }
  if (N.find_on) find_all();
  layout_ok = 0;
  ensure_visible();
}

static void tool_click(int t) {
  switch (t) {
  case T_UNDO: run_cmd(CM_UNDO); break;
  case T_REDO: run_cmd(CM_REDO); break;
  case T_STYLE: N.popup = N.popup == POP_STYLE ? 0 : POP_STYLE; break;
  case T_BOLD: run_cmd(CM_BOLD); break;
  case T_ITAL: run_cmd(CM_ITAL); break;
  case T_UNDER: run_cmd(CM_UNDER); break;
  case T_STRIKE: run_cmd(CM_STRIKE); break;
  case T_COLOR: N.popup = N.popup == POP_COLOR ? 0 : POP_COLOR; break;
  case T_ALEFT: run_cmd(CM_ALEFT); break;
  case T_ACENTER: run_cmd(CM_ACENTER); break;
  case T_ARIGHT: run_cmd(CM_ARIGHT); break;
  case T_CHECK: run_cmd(CM_INS_CHECK); break;
  case T_BULLET: run_cmd(CM_BULLET); break;
  case T_NUMBER: run_cmd(CM_NUMBER); break;
  case T_OUTDENT: indent(-1); break;
  case T_INDENT: indent(1); break;
  case T_CLEAR: run_cmd(CM_CLEAR); break;
  case T_FIND:
    if (N.find_on) N.find_on = N.find_focus = 0;
    else run_cmd(CM_FIND);
    break;
  }
}

static Pos page_pos(float x, float y) {
  float tx = page_x() + PAGE_PAD, ty = text_origin_y();
  return xy_pos(x - tx, y - ty);
}

static int check_hit(float x, float y) {
  layout();
  float tx = page_x() + PAGE_PAD, ty = text_origin_y();
  for (int i = 0; i < nlines; i++) {
    Line *l = &lines[i];
    Para *q = &N.p[l->para];
    if (q->list != L_CHECK || l->start != 0) continue;
    float bx = tx + q->indent * 36.f + 4, by = ty + l->y;
    if (x >= bx - 6 && x < bx + 22 && y >= by && y < by + l->h) return l->para;
  }
  return -1;
}

static void select_word(Pos p) {
  Para *q = &N.p[p.para];
  int a = p.off, b = p.off;
  while (a > 0 && is_word(q->t[a - 1])) a--;
  while (b < q->n && is_word(q->t[b])) b++;
  N.anc = (Pos){p.para, a};
  N.cur = (Pos){p.para, b};
}

static void notes_press(Panel *p, float x, float y, int button, int down) {
  ensure_loaded();
  N.panel = (int)(p - P);
  if (office_picker_on()) {
    p->dirty = 1;
    if (button != 1) return;
    int z = notes_zone(p, x, y);
    if (down) {
      N.press_zone = z;
      return;
    }
    int pz = N.press_zone;
    N.press_zone = 0;
    int k, sub;
    char id[40];
    int r = z == pz ? office_picker_press(z, &k, id, sizeof id, &sub) : 0;
    if (r == 1) {
      if (N.mode == 2) slides_insert_embed(k, id, sub);
      else if (!N.mode) insert_embed(k, id, sub);
    } else if (r == 2) {
      const char *path = office_import_path();
      int ok = N.mode == 2 ? slides_import(path) : N.mode ? sheets_import(path) : docs_import(path);
      if (ok) {
        N.home = 0;
        set_panel_title();
        toast("Imported");
      } else toast("Could not open that file");
    }
    return;
  }
  if (!N.home && N.mode == 2) {
    slides_press(p, x, y, button, down);
    p->dirty = 1;
    return;
  }
  if (!N.home && N.mode) {
    sheets_press(p, x, y, button, down);
    p->dirty = 1;
    return;
  }
  if (button != 1) return;
  int z = notes_zone(p, x, y);
  if (N.home) {
    home_press(z, down);
    p->dirty = 1;
    return;
  }
  if (down) {
    N.press_zone = z;
    if (z == Z_PAGE) {
      if (N.popup) {
        N.popup = 0;
        N.press_zone = 0;
        p->dirty = 1;
        return;
      }
      commit_title();
      N.find_focus = 0;
      int cp = check_hit(x, y);
      if (cp >= 0) {
        push_undo(0);
        N.p[cp].check ^= 1;
        changed();
        N.press_zone = 0;
        p->dirty = 1;
        return;
      }
      Pos ps = page_pos(x, y);
      uint32_t now = now_ms();
      if (now - N.last_click < 420 && ps.para == N.click_pos.para && abs(ps.off - N.click_pos.off) <= 2) N.clicks++;
      else N.clicks = 1;
      N.last_click = now;
      N.click_pos = ps;
      if (N.p[ps.para].hr == 2) {
        int k, sub;
        char id[40];
        N.cur = N.anc = (Pos){ps.para, 0};
        N.press_zone = 0;
        if (N.clicks >= 2 && office_embed_parse(N.p[ps.para].ref, &k, id, sizeof id, &sub)) office_embed_open(k, id, sub);
        p->dirty = 1;
        return;
      }
      if (N.clicks == 2) select_word(ps);
      else if (N.clicks >= 3) {
        N.anc = (Pos){ps.para, 0};
        N.cur = (Pos){ps.para, N.p[ps.para].n};
      } else move_cursor(ps, input_mods() & MOD_SHIFT);
      N.want_x = -1;
      N.dragging = N.clicks == 1;
      show_keyboard();
    }
    p->dirty = 1;
    return;
  }
  int pz = N.press_zone;
  N.press_zone = 0;
  if (pz == Z_PAGE && N.dragging) {
    N.dragging = 0;
    if (z == Z_PAGE) {
      Pos ps = page_pos(x, y);
      if (pos_cmp(ps, N.cur)) {
        N.cur = ps;
        sync_fmt();
      }
    }
    p->dirty = 1;
    return;
  }
  if (!pz || z != pz) {
    if (N.popup && z <= 0) N.popup = 0;
    p->dirty = 1;
    return;
  }
  if (N.popup && z >= Z_POPUP && z < Z_POPUP_END) {
    int i = z - Z_POPUP;
    if (N.popup <= POP_MENU3) run_cmd(MENUS[N.popup - POP_MENU0][i].cmd);
    else if (N.popup == POP_STYLE) {
      N.popup = 0;
      set_style(3 - i);
    } else {
      N.popup = 0;
      set_color(i);
    }
    p->dirty = 1;
    return;
  }
  if (z != Z_TITLE) commit_title();
  if (z >= Z_MENU && z < Z_MENU + 4) {
    int m = POP_MENU0 + z - Z_MENU;
    N.popup = N.popup == m ? 0 : m;
  } else if (z > 0 && z < T_COUNT) {
    if (z != T_STYLE && z != T_COLOR) N.popup = 0;
    tool_click(z);
  } else {
    N.popup = 0;
    if (z == Z_TITLE) begin_title_edit();
    else if (z == Z_FIND_FIELD) {
      N.find_focus = 1;
      show_keyboard();
    } else if (z == Z_FIND_PREV) goto_match(-1);
    else if (z == Z_FIND_NEXT) goto_match(1);
    else if (z == Z_FIND_CLOSE) N.find_on = N.find_focus = 0;
    else if (z == Z_HOME) go_home();
    else if (z == Z_EMB_OPEN && N.p[N.cur.para].hr == 2) {
      int k, sub;
      char id[40];
      if (office_embed_parse(N.p[N.cur.para].ref, &k, id, sizeof id, &sub)) office_embed_open(k, id, sub);
    }
  }
  p->dirty = 1;
}

static void notes_scroll(Panel *p, float x, float y, int steps) {
  if (office_picker_on()) {
    office_picker_scroll(steps);
    p->dirty = 1;
    return;
  }
  if (!N.home && N.mode == 2) {
    slides_scroll(x, y, steps);
    p->dirty = 1;
    return;
  }
  if (!N.home && N.mode) {
    sheets_scroll(x, y, steps);
    p->dirty = 1;
    return;
  }
  (void)y, (void)x;
  if (N.home) {
    N.home_scroll -= steps * 60;
    float maxs = home_content_h() - (NH - BAR_H - HOME_HEAD);
    if (N.home_scroll > maxs) N.home_scroll = maxs;
    if (N.home_scroll < 0) N.home_scroll = 0;
  } else {
    layout();
    N.scroll -= steps * 48;
    float maxs = PAGE_TOP * 2 + PAGE_PAD * 1.5f + doc_h - view_h() + 120;
    if (N.scroll > maxs) N.scroll = maxs;
    if (N.scroll < 0) N.scroll = 0;
  }
  p->dirty = 1;
}

static void edit_line(char *buf, int cap, int code, int mods) {
  char b[8];
  int n = key_to_bytes(code, mods & ~MOD_CTRL, b);
  int len = (int)strlen(buf);
  if (code == KEY_BACKSPACE) {
    if (len) buf[len - 1] = 0;
  } else if (n == 1 && b[0] >= 32 && b[0] < 127 && len < cap - 1) {
    buf[len] = b[0];
    buf[len + 1] = 0;
  }
}

static void notes_key(Panel *p, int code, int mods) {
  ensure_loaded();
  N.panel = (int)(p - P);
  int ctrl = mods & MOD_CTRL, shift = mods & MOD_SHIFT, alt = mods & MOD_ALT;
  if (office_picker_on()) {
    if (code == KEY_ESC) office_picker_close();
    p->dirty = 1;
    return;
  }
  if (N.home) {
    if (ctrl && code == KEY_N) {
      if (N.mode == 2) {
        slides_new();
        N.home = 0;
        set_panel_title();
      } else if (N.mode) {
        sheets_new_from_template(0);
        N.home = 0;
        set_panel_title();
      } else from_template(0), show_keyboard();
    }
    p->dirty = 1;
    return;
  }
  if (office_picker_on()) {
    if (code == KEY_ESC) office_picker_close();
    p->dirty = 1;
    return;
  }
  if (N.mode == 2) {
    slides_key(p, code, mods);
    p->dirty = 1;
    return;
  }
  if (N.mode) {
    sheets_key(p, code, mods);
    p->dirty = 1;
    return;
  }
  N.blink = 1;
  N.blink_t = now_ms();
  p->dirty = 1;
  if (code == KEY_ESC && N.popup) {
    N.popup = 0;
    return;
  }
  if (N.title_edit) {
    if (code == KEY_ENTER || code == KEY_KPENTER || code == KEY_TAB) commit_title();
    else if (code == KEY_ESC) N.title_edit = 0;
    else if (!ctrl) edit_line(N.title_buf, sizeof N.title_buf, code, mods);
    return;
  }
  if (N.find_on && N.find_focus) {
    if (code == KEY_ENTER || code == KEY_KPENTER) goto_match(shift ? -1 : 1);
    else if (code == KEY_ESC) N.find_on = N.find_focus = 0;
    else if (ctrl && code == KEY_F) N.find_focus = 1;
    else if (!ctrl) {
      edit_line(N.find, sizeof N.find, code, mods);
      cur_match = 0;
      find_all();
      if (nmatch) {
        cur_match = nmatch - 1;
        goto_match(1);
      }
    }
    return;
  }
  if (ctrl) {
    int cmd = CM_NONE;
    if (alt) {
      if (code == KEY_1) cmd = CM_H1;
      else if (code == KEY_2) cmd = CM_H2;
      else if (code == KEY_0) cmd = CM_NORMAL;
    } else if (shift) {
      if (code == KEY_7) cmd = CM_NUMBER;
      else if (code == KEY_8) cmd = CM_BULLET;
      else if (code == KEY_9) cmd = CM_INS_CHECK;
      else if (code == KEY_L) cmd = CM_ALEFT;
      else if (code == KEY_E) cmd = CM_ACENTER;
      else if (code == KEY_R) cmd = CM_ARIGHT;
      else if (code == KEY_Z) cmd = CM_REDO;
    } else {
      switch (code) {
      case KEY_B: cmd = CM_BOLD; break;
      case KEY_I: cmd = CM_ITAL; break;
      case KEY_U: cmd = CM_UNDER; break;
      case KEY_Z: cmd = CM_UNDO; break;
      case KEY_Y: cmd = CM_REDO; break;
      case KEY_A: cmd = CM_SELALL; break;
      case KEY_C: cmd = CM_COPY; break;
      case KEY_X: cmd = CM_CUT; break;
      case KEY_V: cmd = CM_PASTE; break;
      case KEY_F: cmd = CM_FIND; break;
      case KEY_N: cmd = CM_NEWDOC; break;
      case KEY_BACKSLASH: cmd = CM_CLEAR; break;
      case KEY_S:
        save_doc();
        toast("Saved");
        return;
      }
    }
    if (cmd) {
      run_cmd(cmd);
      return;
    }
  }
  if (alt && shift && code == KEY_5) {
    run_cmd(CM_STRIKE);
    return;
  }
  int vert = code == KEY_UP || code == KEY_DOWN || code == KEY_PAGEUP || code == KEY_PAGEDOWN;
  if (!vert) N.want_x = -1;
  switch (code) {
  case KEY_LEFT:
    if (has_sel() && !shift) {
      Pos a, b;
      sel_range(&a, &b);
      move_cursor(a, 0);
    } else if (ctrl) move_cursor(move_word(N.cur, -1), shift);
    else if (N.cur.off > 0) move_cursor((Pos){N.cur.para, N.cur.off - 1}, shift);
    else if (N.cur.para > 0) move_cursor((Pos){N.cur.para - 1, N.p[N.cur.para - 1].n}, shift);
    return;
  case KEY_RIGHT:
    if (has_sel() && !shift) {
      Pos a, b;
      sel_range(&a, &b);
      move_cursor(b, 0);
    } else if (ctrl) move_cursor(move_word(N.cur, 1), shift);
    else if (N.cur.off < N.p[N.cur.para].n) move_cursor((Pos){N.cur.para, N.cur.off + 1}, shift);
    else if (N.cur.para + 1 < N.np) move_cursor((Pos){N.cur.para + 1, 0}, shift);
    return;
  case KEY_UP: move_vert(-1, shift); return;
  case KEY_DOWN: move_vert(1, shift); return;
  case KEY_PAGEUP:
    for (int i = 0; i < 12; i++) move_vert(-1, shift);
    return;
  case KEY_PAGEDOWN:
    for (int i = 0; i < 12; i++) move_vert(1, shift);
    return;
  case KEY_HOME: {
    layout();
    Line *l = &lines[line_of(N.cur)];
    move_cursor(ctrl ? (Pos){0, 0} : (Pos){l->para, l->start}, shift);
    return;
  }
  case KEY_END: {
    layout();
    Line *l = &lines[line_of(N.cur)];
    int e = l->end;
    if (e < N.p[l->para].n && e > l->start && N.p[l->para].t[e - 1] == ' ') e--;
    move_cursor(ctrl ? (Pos){N.np - 1, N.p[N.np - 1].n} : (Pos){l->para, e}, shift);
    return;
  }
  case KEY_BACKSPACE:
    backspace(ctrl);
    break;
  case KEY_DELETE:
    delete_fwd(ctrl);
    break;
  case KEY_ENTER:
  case KEY_KPENTER:
    if (shift) insert_text("\n", 0);
    else press_enter();
    break;
  case KEY_TAB:
    if (N.p[N.cur.para].list || has_sel()) indent(shift ? -1 : 1);
    else if (!shift) insert_text("    ", 1);
    break;
  case KEY_ESC:
    if (has_sel()) N.anc = N.cur;
    if (N.find_on) N.find_on = 0;
    return;
  default: {
    if (ctrl || alt) return;
    char b[8];
    int n = key_to_bytes(code, mods, b);
    if (n == 1 && b[0] >= 32 && b[0] < 127) {
      b[1] = 0;
      insert_text(b, 1);
    } else return;
  }
  }
  if (N.find_on) find_all();
  ensure_visible();
}

static int notes_tick(Panel *p, uint32_t now) {
  N.panel = (int)(p - P);
  int r = 0;
  if (N.toast[0] && now - N.toast_t > 3500) N.toast[0] = 0, r = 1;
  if (N.home) return r;
  if (N.mode == 2) return slides_tick(p, now) | r;
  if (N.mode) return sheets_tick(p, now) | r;
  if (N.dirty && now - N.dirty_at > 900) {
    save_doc();
    r = 1;
  }
  if (now - N.blink_t > 530) {
    N.blink_t = now;
    N.blink = !N.blink;
    if (W.focus == (int)(p - P)) r = 1;
  }
  if (N.toast[0] && now - N.toast_t > 3500) {
    N.toast[0] = 0;
    r = 1;
  }
  return r;
}

static void notes_open(Panel *p) {
  N.panel = (int)(p - P);
  tool_layout();
  N.want_x = -1;
  ensure_loaded();
  commit_title();
  if (N.dirty) save_doc();
  N.home = 1;
  N.home_scroll = 0;
  N.confirm_del = -1;
  scan_docs();
  sheets_home_scan();
  slides_home_scan();
  set_panel_title();
}

static void notes_close(Panel *p) {
  (void)p;
  commit_title();
  if (N.dirty) save_doc();
  slides_stop_present();
  sheets_save_now();
  slides_save_now();
  N.popup = 0;
  N.panel = -1;
}

App notes_app = {"office", "Office", IC_OFFICE, NW, NH, notes_open, notes_draw, NULL, notes_scroll, notes_key, notes_zone,
                 notes_tick, notes_close, notes_press};

void office_embed_open(int kind, const char *idp, int sub) {
  char id[40];
  snprintf(id, sizeof id, "%s", idp);
  office_picker_close();
  commit_title();
  if (N.dirty) save_doc();
  sheets_save_now();
  slides_save_now();
  N.popup = 0;
  N.mode = kind;
  N.home = 0;
  if (kind == 0) open_doc(id);
  else if (kind == 1) sheets_open(id);
  else slides_open(id, sub);
  set_panel_title();
}

void office_new(int kind) {
  office_picker_close();
  commit_title();
  if (N.dirty) save_doc();
  sheets_save_now();
  slides_save_now();
  N.popup = 0;
  N.confirm_del = -1;
  N.mode = kind;
  if (kind == 2) slides_new();
  else if (kind) sheets_new_from_template(0);
  else from_template(0), show_keyboard();
  N.home = 0;
  set_panel_title();
}

typedef struct {
  char id[40], title[96];
  long mtime;
  uint32_t at;
  int ok;
  Para *p;
  int np, cap;
} DocSnap;

static DocSnap DSN[4];
static int dsn_next;

static DocSnap *doc_snap(const char *id) {
  DocSnap *d = NULL;
  for (int i = 0; i < 4; i++)
    if (!strcmp(DSN[i].id, id)) d = &DSN[i];
  uint32_t now = now_ms();
  if (d && now - d->at < 700) return d;
  char path[600];
  doc_path(id, path, sizeof path);
  struct stat st;
  long mt = stat(path, &st) ? -1 : (long)st.st_mtime;
  if (d && d->mtime == mt) {
    d->at = now;
    return d;
  }
  if (!d) {
    d = &DSN[dsn_next];
    dsn_next = (dsn_next + 1) % 4;
  }
  for (int i = 0; i < d->np; i++) para_free(&d->p[i]);
  d->np = 0;
  snprintf(d->id, sizeof d->id, "%s", id);
  d->at = now, d->mtime = mt, d->ok = 0;
  snprintf(d->title, sizeof d->title, "Untitled document");
  char *body = mt < 0 ? NULL : read_file(path);
  if (body) {
    parse_doc(body, &d->p, &d->np, &d->cap, d->title, sizeof d->title, NULL, NULL);
    free(body);
    d->ok = 1;
  }
  return d;
}

static void render_doc(Surface *s, Para *pa, int np, float x, float y, float w, float h) {
  float k = w / PAGE_W, pad = 44 * k, q = k * s->scale / SCALE;
  uint32_t ink = THEME(RGB(32, 33, 36), RGB(230, 232, 236));
  gfx_rect(s, x, y, w, h, N_PAGE);
  float cy = y + pad * 0.8f, avail = PAGE_W - 88;
  int numbers[8] = {0};
  for (int i = 0; i < np && cy < y + h; i++) {
    Para *p = &pa[i];
    if (i > 0) cy += space_before(p) * k;
    if (p->hr == 2) {
      int ek, sub;
      char id[40];
      float eh = embed_h(p) * k;
      if (office_embed_parse(p->ref, &ek, id, sizeof id, &sub)) office_embed_draw(s, ek, id, sub, x + pad, cy + 6 * k, (PAGE_W - 88) * k, eh - 12 * k, 0);
      cy += eh;
      continue;
    }
    if (p->hr) {
      gfx_rect(s, x + pad, cy + 12 * k, avail * k, 1.2f * k + 0.4f, THEME(RGB(196, 199, 205), RGB(80, 85, 95)));
      cy += 26 * k;
      continue;
    }
    if (p->list == L_NUMBER) {
      numbers[p->indent > 7 ? 7 : p->indent]++;
      for (int j = p->indent + 1; j < 8; j++) numbers[j] = 0;
    } else if (!p->list) memset(numbers, 0, sizeof numbers);
    float lh = para_lh(p) * k, mw = marker_w(p), aw = avail - mw;
    const Font *bf = doc_font(para_size(p), 0, 0);
    int st = 0;
    int first = 1;
    do {
      float lw = 0;
      int e = st, brk = -1;
      while (e < p->n) {
        float cw = doc_char_w(char_font(p, p->f[e]), p->t[e]);
        if (lw + cw > aw && e > st) break;
        if (p->t[e] == ' ') brk = e;
        lw += cw;
        e++;
      }
      if (e < p->n && brk > st) e = brk + 1;
      float rw = 0;
      for (int j = st; j < e; j++) rw += doc_char_w(char_font(p, p->f[j]), p->t[j]);
      float lx = mw + (p->align == A_CENTER ? (aw - rw) / 2 : p->align == A_RIGHT ? aw - rw : 0);
      float ty = cy + (lh - line_h(bf) * k) * 0.5f;
      if (first && p->list) {
        float mx = x + pad + p->indent * 36.f * k, my = ty + line_h(bf) * k * 0.55f;
        if (p->list == L_BULLET) gfx_disc(s, mx + 12 * k, my, 2.8f * k, ink);
        else if (p->list == L_NUMBER) {
          char num[16];
          snprintf(num, sizeof num, "%d.", numbers[p->indent > 7 ? 7 : p->indent]);
          float nw = 0;
          for (const char *c = num; *c; c++) nw += doc_char_w(bf, *c);
          gfx_text_scaled(s, bf, mx + (24 - nw) * k, ty, num, -1, ink, q);
        } else {
          gfx_rrect(s, mx + 4 * k, my - 7.5f * k, 15 * k, 15 * k, 3 * k, p->check ? N_ACC : C_MUTED);
          if (!p->check) gfx_rrect(s, mx + 5.6f * k, my - 5.9f * k, 11.8f * k, 11.8f * k, 2 * k, N_PAGE);
        }
      }
      float cx = x + pad + lx * k;
      for (int j = st; j < e; j++) {
        int fm = p->f[j];
        const Font *f = char_font(p, fm);
        int col = (fm >> 4) & 7;
        uint32_t c = col && !(g_dark && col == 1) ? OFF_COLORS[col] : ink;
        if (p->list == L_CHECK && p->check) c = C_MUTED;
        if (p->t[j] != ' ') gfx_text_scaled(s, f, cx, ty, p->t + j, 1, c, q);
        float cw = doc_char_w(f, p->t[j]) * k;
        if (fm & F_UNDER) gfx_rect(s, cx, ty + (float)f->ascent / SCALE * k + 2 * k, cw, 1.2f * k, c);
        cx += cw;
      }
      cy += lh;
      st = e;
      first = 0;
    } while (st < p->n && cy < y + h);
  }
}

int docs_embed(Surface *s, const char *id, float x, float y, float w, float h, char *title, int tn) {
  if (N.id[0] && !strcmp(N.id, id) && N.np) {
    snprintf(title, (size_t)tn, "%s", N.title);
    if (s) render_doc(s, N.p, N.np, x, y, w, h);
    return 1;
  }
  DocSnap *d = doc_snap(id);
  if (!d->ok) return 0;
  snprintf(title, (size_t)tn, "%s", d->title);
  if (s) render_doc(s, d->p, d->np, x, y, w, h);
  return 1;
}

static const char *const DOCX_HEX[8] = {"", "202124", "5F6368", "D93025", "E8710A", "188038", "1A73E8", "9334E6"};

static int near_color(unsigned r, unsigned g, unsigned b) {
  if (r + g + b < 200) return 0;
  int best = 0;
  long bd = 1L << 40;
  for (int i = 2; i < 8; i++) {
    uint32_t c = OFF_COLORS[i];
    long dr = (long)((c >> 16) & 255) - r, dg = (long)((c >> 8) & 255) - g, db = (long)(c & 255) - b;
    long d = dr * dr + dg * dg + db * db;
    if (d < bd) bd = d, best = i;
  }
  return bd < 60L * 60 * 3 ? best : 0;
}

static int hex_color(const char *h) {
  if (strlen(h) < 6 || !strcmp(h, "auto")) return 0;
  unsigned v = (unsigned)strtoul(h, NULL, 16);
  return near_color(v >> 16 & 255, v >> 8 & 255, v & 255);
}

static int embed_label(const Para *p, char *out, int n) {
  int k, sub;
  char id[40], t[96] = "";
  if (!office_embed_parse(p->ref, &k, id, sizeof id, &sub)) return -1;
  office_embed_title(k, id, sub, t, sizeof t);
  snprintf(out, (size_t)n, "[%s: %s]", k == 0 ? "Document" : k == 1 ? "Spreadsheet" : "Slide", t[0] ? t : "missing");
  return k == 1 && sheets_embed_dims(id, &(int){0}, &(int){0}) ? 1 : 0;
}

static void docx_run(Buf *b, const char *t, int n, int fm) {
  buf_printf(b, "<w:r>");
  if (fm & 0x7f) {
    buf_printf(b, "<w:rPr>");
    if (fm & F_BOLD) buf_printf(b, "<w:b/>");
    if (fm & F_ITAL) buf_printf(b, "<w:i/>");
    if (fm & F_UNDER) buf_printf(b, "<w:u w:val=\"single\"/>");
    if (fm & F_STRIKE) buf_printf(b, "<w:strike/>");
    if ((fm >> 4) & 7) buf_printf(b, "<w:color w:val=\"%s\"/>", DOCX_HEX[(fm >> 4) & 7]);
    buf_printf(b, "</w:rPr>");
  }
  buf_printf(b, "<w:t xml:space=\"preserve\">");
  buf_esc(b, t, n);
  buf_printf(b, "</w:t></w:r>");
}

static void docx_sheet(Buf *b, const Para *p) {
  int k, sub, nc, nr;
  char id[40];
  if (!office_embed_parse(p->ref, &k, id, sizeof id, &sub) || !sheets_embed_dims(id, &nc, &nr)) return;
  int cw = 9000 / nc;
  buf_printf(b, "<w:tbl><w:tblPr><w:tblStyle w:val=\"TableGrid\"/><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblBorders>");
  static const char *const sides[6] = {"top", "left", "bottom", "right", "insideH", "insideV"};
  for (int i = 0; i < 6; i++) buf_printf(b, "<w:%s w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"BFC3C9\"/>", sides[i]);
  buf_printf(b, "</w:tblBorders></w:tblPr><w:tblGrid>");
  for (int c = 0; c < nc; c++) buf_printf(b, "<w:gridCol w:w=\"%d\"/>", cw);
  buf_printf(b, "</w:tblGrid>");
  for (int r = 0; r < nr; r++) {
    buf_printf(b, "<w:tr>");
    for (int c = 0; c < nc; c++) {
      int bold = 0, right = 0;
      const char *t = sheets_embed_cell(id, r, c, &bold, &right);
      buf_printf(b, "<w:tc><w:tcPr><w:tcW w:w=\"%d\" w:type=\"dxa\"/></w:tcPr><w:p>", cw);
      if (right) buf_printf(b, "<w:pPr><w:jc w:val=\"right\"/></w:pPr>");
      if (t[0]) docx_run(b, t, (int)strlen(t), bold ? F_BOLD : 0);
      buf_printf(b, "</w:p></w:tc>");
    }
    buf_printf(b, "</w:tr>");
  }
  buf_printf(b, "</w:tbl><w:p/>");
}

static void export_docx(void) {
  char path[700], shown[200];
  office_export_path(N.title, "docx", path, sizeof path, shown, sizeof shown);
  ZipW *z = zw_open(path);
  if (!z) {
    toast("Could not save the file");
    return;
  }
  zw_adds(z, "[Content_Types].xml",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
          "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
          "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
          "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
          "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>"
          "<Override PartName=\"/word/numbering.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml\"/>"
          "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
          "</Types>");
  zw_adds(z, "_rels/.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
          "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
          "</Relationships>");
  zw_adds(z, "word/_rels/document.xml.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
          "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering\" Target=\"numbering.xml\"/>"
          "</Relationships>");
  Buf b = {0};
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>");
  buf_esc(&b, N.title, -1);
  buf_printf(&b, "</dc:title><dc:creator>Oreon Office</dc:creator></cp:coreProperties>");
  zw_add(z, "docProps/core.xml", b.s, b.n);
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">"
                 "<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/><w:sz w:val=\"22\"/><w:szCs w:val=\"22\"/></w:rPr></w:rPrDefault>"
                 "<w:pPrDefault><w:pPr><w:spacing w:after=\"80\" w:line=\"300\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>"
                 "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>"
                 "<w:style w:type=\"paragraph\" w:styleId=\"Title\"><w:name w:val=\"Title\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/>"
                 "<w:pPr><w:spacing w:after=\"120\"/></w:pPr><w:rPr><w:sz w:val=\"52\"/><w:szCs w:val=\"52\"/></w:rPr></w:style>"
                 "<w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/>"
                 "<w:pPr><w:keepNext/><w:spacing w:before=\"280\" w:after=\"120\"/><w:outlineLvl w:val=\"0\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"40\"/><w:szCs w:val=\"40\"/></w:rPr></w:style>"
                 "<w:style w:type=\"paragraph\" w:styleId=\"Heading2\"><w:name w:val=\"heading 2\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/>"
                 "<w:pPr><w:keepNext/><w:spacing w:before=\"220\" w:after=\"80\"/><w:outlineLvl w:val=\"1\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"32\"/><w:szCs w:val=\"32\"/></w:rPr></w:style>"
                 "<w:style w:type=\"table\" w:styleId=\"TableGrid\"><w:name w:val=\"Table Grid\"/><w:tblPr><w:tblCellMar><w:left w:w=\"108\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr></w:style>"
                 "</w:styles>");
  zw_add(z, "word/styles.xml", b.s, b.n);
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<w:numbering xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">");
  for (int a = 0; a < 2; a++) {
    buf_printf(&b, "<w:abstractNum w:abstractNumId=\"%d\"><w:multiLevelType w:val=\"hybridMultilevel\"/>", a);
    for (int l = 0; l < 7; l++) {
      static const char *const bul[3] = {"\xE2\x80\xA2", "\xE2\x97\xA6", "\xE2\x96\xAA"};
      if (a == 0)
        buf_printf(&b, "<w:lvl w:ilvl=\"%d\"><w:start w:val=\"1\"/><w:numFmt w:val=\"bullet\"/><w:lvlText w:val=\"%s\"/><w:lvlJc w:val=\"left\"/>"
                       "<w:pPr><w:ind w:left=\"%d\" w:hanging=\"360\"/></w:pPr></w:lvl>", l, bul[l % 3], 720 * (l + 1));
      else
        buf_printf(&b, "<w:lvl w:ilvl=\"%d\"><w:start w:val=\"1\"/><w:numFmt w:val=\"decimal\"/><w:lvlText w:val=\"%%%d.\"/><w:lvlJc w:val=\"left\"/>"
                       "<w:pPr><w:ind w:left=\"%d\" w:hanging=\"360\"/></w:pPr></w:lvl>", l, l + 1, 720 * (l + 1));
    }
    buf_printf(&b, "</w:abstractNum>");
  }
  buf_printf(&b, "<w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num><w:num w:numId=\"2\"><w:abstractNumId w:val=\"1\"/></w:num></w:numbering>");
  zw_add(z, "word/numbering.xml", b.s, b.n);
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
                 "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><w:body>");
  static const char *const STY[4] = {NULL, "Heading2", "Heading1", "Title"};
  static const char *const JC[3] = {NULL, "center", "right"};
  for (int i = 0; i < N.np; i++) {
    Para *p = &N.p[i];
    if (p->hr == 1) {
      buf_printf(&b, "<w:p><w:pPr><w:pBdr><w:bottom w:val=\"single\" w:sz=\"6\" w:space=\"1\" w:color=\"C4C7CD\"/></w:pBdr></w:pPr></w:p>");
      continue;
    }
    if (p->hr == 2) {
      char lab[160];
      if (embed_label(p, lab, sizeof lab) == 1) docx_sheet(&b, p);
      else {
        buf_printf(&b, "<w:p>");
        docx_run(&b, lab, (int)strlen(lab), F_ITAL | 2 << 4);
        buf_printf(&b, "</w:p>");
      }
      continue;
    }
    buf_printf(&b, "<w:p><w:pPr>");
    if (STY[p->style]) buf_printf(&b, "<w:pStyle w:val=\"%s\"/>", STY[p->style]);
    if (p->list == L_BULLET || p->list == L_NUMBER)
      buf_printf(&b, "<w:numPr><w:ilvl w:val=\"%d\"/><w:numId w:val=\"%d\"/></w:numPr>", p->indent, p->list == L_NUMBER ? 2 : 1);
    else if (p->indent || p->list == L_CHECK) buf_printf(&b, "<w:ind w:left=\"%d\"/>", 720 * (p->indent + (p->list == L_CHECK)));
    if (JC[p->align]) buf_printf(&b, "<w:jc w:val=\"%s\"/>", JC[p->align]);
    buf_printf(&b, "</w:pPr>");
    if (p->list == L_CHECK) docx_run(&b, p->check ? "\xE2\x98\x92 " : "\xE2\x98\x90 ", 4, 0);
    for (int j = 0; j < p->n;) {
      int k = j;
      while (k < p->n && p->f[k] == p->f[j]) k++;
      docx_run(&b, p->t + j, k - j, p->f[j]);
      j = k;
    }
    buf_printf(&b, "</w:p>");
  }
  buf_printf(&b, "<w:sectPr><w:pgSz w:w=\"12240\" w:h=\"15840\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>");
  zw_add(z, "word/document.xml", b.s, b.n);
  free(b.s);
  toast(zw_close(z) ? "Could not save the file" : shown);
}

static void rtf_text(Buf *b, const char *t, int n) {
  for (int i = 0; i < n; i++) {
    char c = t[i];
    if (c == '\\' || c == '{' || c == '}') buf_printf(b, "\\%c", c);
    else buf_put(b, &c, 1);
  }
}

static void export_rtf(void) {
  char path[700], shown[200];
  office_export_path(N.title, "rtf", path, sizeof path, shown, sizeof shown);
  FILE *f = fopen(path, "wb");
  if (!f) {
    toast("Could not save the file");
    return;
  }
  Buf b = {0};
  buf_printf(&b, "{\\rtf1\\ansi\\ansicpg1252\\deff0\\uc1{\\fonttbl{\\f0\\fswiss\\fcharset0 Arial;}}{\\colortbl;");
  for (int i = 1; i < 8; i++) buf_printf(&b, "\\red%d\\green%d\\blue%d;", (int)(OFF_COLORS[i] >> 16 & 255), (int)(OFF_COLORS[i] >> 8 & 255), (int)(OFF_COLORS[i] & 255));
  buf_printf(&b, "\\red196\\green199\\blue205;}{\\info{\\title ");
  rtf_text(&b, N.title, (int)strlen(N.title));
  buf_printf(&b, "}}\\viewkind4\\paperw12240\\paperh15840\\margl1440\\margr1440\\margt1440\\margb1440\n");
  static const int FS[4] = {22, 32, 40, 52};
  static const char *const Q[3] = {"\\ql", "\\qc", "\\qr"};
  int num[8] = {0};
  for (int i = 0; i < N.np; i++) {
    Para *p = &N.p[i];
    if (p->hr == 1) {
      buf_printf(&b, "\\pard\\plain\\brdrb\\brdrs\\brdrw10\\brsp20\\brdrcf8\\par\n");
      continue;
    }
    if (p->hr == 2) {
      char lab[160];
      int k, sub, nc, nr;
      char id[40];
      if (embed_label(p, lab, sizeof lab) == 1 && office_embed_parse(p->ref, &k, id, sizeof id, &sub) && sheets_embed_dims(id, &nc, &nr)) {
        for (int r = 0; r < nr; r++) {
          buf_printf(&b, "\\trowd\\trgaph108");
          for (int c = 0; c < nc; c++)
            buf_printf(&b, "\\clbrdrt\\brdrs\\brdrw10\\clbrdrl\\brdrs\\brdrw10\\clbrdrb\\brdrs\\brdrw10\\clbrdrr\\brdrs\\brdrw10\\cellx%d", (c + 1) * (9000 / nc));
          buf_printf(&b, "\n");
          for (int c = 0; c < nc; c++) {
            int bold = 0, right = 0;
            const char *t = sheets_embed_cell(id, r, c, &bold, &right);
            buf_printf(&b, "\\pard\\intbl\\plain\\fs22%s%s ", right ? "\\qr" : "", bold ? "\\b" : "");
            rtf_text(&b, t, (int)strlen(t));
            buf_printf(&b, "\\cell");
          }
          buf_printf(&b, "\\row\n");
        }
        buf_printf(&b, "\\pard\\plain\\par\n");
      } else {
        buf_printf(&b, "\\pard\\plain\\fs22{\\i\\cf2 ");
        rtf_text(&b, lab, (int)strlen(lab));
        buf_printf(&b, "}\\par\n");
      }
      continue;
    }
    if (p->list == L_NUMBER) {
      num[p->indent > 7 ? 7 : p->indent]++;
      for (int k = p->indent + 1; k < 8; k++) num[k] = 0;
    } else if (!p->list) memset(num, 0, sizeof num);
    buf_printf(&b, "\\pard\\plain%s\\fs%d\\sa120", Q[p->align], FS[p->style]);
    if (p->style == ST_H1 || p->style == ST_H2) buf_printf(&b, "\\sb240\\b");
    if (p->list) buf_printf(&b, "\\fi-360\\li%d", 720 * (p->indent + 1));
    else if (p->indent) buf_printf(&b, "\\li%d", 720 * p->indent);
    buf_printf(&b, " ");
    if (p->list == L_BULLET) buf_printf(&b, "\\bullet\\tab ");
    else if (p->list == L_NUMBER) buf_printf(&b, "%d.\\tab ", num[p->indent > 7 ? 7 : p->indent]);
    else if (p->list == L_CHECK) buf_printf(&b, "%s\\tab ", p->check ? "\\u9746?" : "\\u9744?");
    for (int j = 0; j < p->n;) {
      int k = j;
      while (k < p->n && p->f[k] == p->f[j]) k++;
      int fm = p->f[j];
      buf_printf(&b, "{%s%s%s%s", fm & F_BOLD ? "\\b" : "", fm & F_ITAL ? "\\i" : "", fm & F_UNDER ? "\\ul" : "", fm & F_STRIKE ? "\\strike" : "");
      if ((fm >> 4) & 7) buf_printf(&b, "\\cf%d", (fm >> 4) & 7);
      if (fm & 0x7f) buf_printf(&b, " ");
      rtf_text(&b, p->t + j, k - j);
      buf_printf(&b, "}");
      j = k;
    }
    buf_printf(&b, "\\par\n");
  }
  buf_printf(&b, "}\n");
  int ok = fwrite(b.s, 1, b.n, f) == b.n;
  if (fclose(f)) ok = 0;
  free(b.s);
  toast(ok ? shown : "Could not save the file");
}

static Para *imp_para(int style, int list, int indent, int align) {
  Para *p = para_insert(N.np);
  p->style = (unsigned char)style, p->list = (unsigned char)list, p->indent = (unsigned char)(indent > 6 ? 6 : indent < 0 ? 0 : indent);
  p->align = (unsigned char)align;
  return p;
}

static void imp_add(Para *p, const char *t, int fm) {
  for (; *t; t++) {
    unsigned char f = (unsigned char)fm;
    para_put(p, p->n, t, &f, 1);
  }
}

static void imp_strip(Para *p, int k) {
  memmove(p->t, p->t + k, (size_t)(p->n - k));
  memmove(p->f, p->f + k, (size_t)(p->n - k));
  p->n -= k;
  p->t[p->n] = 0;
}

static void imp_finish(Para *p) {
  if (!p || p->list || p->n < 3) return;
  int k = 0;
  while (k < p->n && isdigit((unsigned char)p->t[k])) k++;
  int num = k > 0 && k < 4 && k < p->n && (p->t[k] == '.' || p->t[k] == ')') && k + 1 < p->n && p->t[k + 1] == ' ';
  if ((p->t[0] == '*' && p->t[1] == ' ') || num) {
    int j = num ? k + 1 : 1;
    while (j < p->n && p->t[j] == ' ') j++;
    if (j - (num ? k + 1 : 1) >= 2 || p->t[0] == '*') {
      p->list = (unsigned char)(num ? L_NUMBER : L_BULLET);
      if (p->indent) p->indent--;
      imp_strip(p, j);
      return;
    }
  }
  if (p->n < 4) return;
  if (!strncmp(p->t, "[ ] ", 4) || !strncmp(p->t, "[x] ", 4)) {
    p->list = L_CHECK;
    p->check = p->t[1] == 'x';
    if (p->indent) p->indent--;
    imp_strip(p, 4);
    while (p->n && p->t[0] == ' ') imp_strip(p, 1);
  }
}

typedef struct {
  char id[48];
  int style, list;
} DStyle;

static void docx_import(Zip *z) {
  int numfmt[64] = {0}, absfmt[64] = {0};
  DStyle sty[96];
  int nsty = 0;
  char v[128], v2[64];
  size_t n;
  char *x = zip_read(z, "word/numbering.xml", &n);
  if (x) {
    Xml X;
    xml_init(&X, x, n);
    int cur_abs = -1, cur_num = -1, lvl = -1;
    while (xml_next(&X) != X_EOF) {
      if (X.type != X_OPEN) continue;
      if (xml_is(&X, "abstractNum")) xml_attr(&X, "abstractNumId", v, sizeof v), cur_abs = atoi(v), cur_num = -1;
      else if (xml_is(&X, "lvl")) xml_attr(&X, "ilvl", v, sizeof v), lvl = atoi(v);
      else if (xml_is(&X, "numFmt") && lvl == 0 && cur_abs >= 0 && cur_abs < 64) {
        xml_attr(&X, "val", v, sizeof v);
        absfmt[cur_abs] = !strcmp(v, "bullet") ? L_BULLET : !strcmp(v, "none") ? 0 : L_NUMBER;
      } else if (xml_is(&X, "num")) xml_attr(&X, "numId", v, sizeof v), cur_num = atoi(v), cur_abs = -1;
      else if (xml_is(&X, "abstractNumId") && cur_num >= 0 && cur_num < 64) {
        xml_attr(&X, "val", v, sizeof v);
        int a = atoi(v);
        numfmt[cur_num] = a >= 0 && a < 64 ? absfmt[a] : L_BULLET;
      }
    }
    free(x);
  }
  x = zip_read(z, "word/styles.xml", &n);
  if (x) {
    Xml X;
    xml_init(&X, x, n);
    DStyle *cs = NULL;
    while (xml_next(&X) != X_EOF) {
      if (X.type != X_OPEN) continue;
      if (xml_is(&X, "style") && nsty < 96) {
        cs = &sty[nsty++];
        memset(cs, 0, sizeof *cs);
        xml_attr(&X, "styleId", cs->id, sizeof cs->id);
      } else if (cs && xml_is(&X, "name")) {
        xml_attr(&X, "val", v, sizeof v);
        for (char *q = v; *q; q++) *q = (char)tolower((unsigned char)*q);
        if (!strcmp(v, "title")) cs->style = ST_TITLE;
        else if (!strcmp(v, "heading 1")) cs->style = ST_H1;
        else if (!strncmp(v, "heading", 7) || !strcmp(v, "subtitle")) cs->style = ST_H2;
        else if (strstr(v, "list bullet")) cs->list = L_BULLET;
        else if (strstr(v, "list number")) cs->list = L_NUMBER;
      } else if (cs && xml_is(&X, "numId")) {
        xml_attr(&X, "val", v, sizeof v);
        int id = atoi(v);
        if (id > 0 && id < 64 && numfmt[id]) cs->list = numfmt[id];
      }
    }
    free(x);
  }
  x = zip_read(z, "word/document.xml", &n);
  if (!x) return;
  Xml X;
  xml_init(&X, x, n);
  Para *p = NULL;
  int in_rpr = 0, in_ppr = 0, fm = 0, numid = -1, ilvl = 0, tbl = 0, in_t = 0, bdr = 0, cells = 0, rsz = 0, psz = 0, pstyled = 0;
  Para *row = NULL;
  while (xml_next(&X) != X_EOF) {
    if (X.type == X_OPEN) {
      if (xml_is(&X, "drawing") || xml_is(&X, "pict") || xml_is(&X, "object") || xml_is(&X, "sectPr") || xml_is(&X, "instrText") ||
          xml_is(&X, "delText") || xml_is(&X, "footnoteReference")) {
        xml_skip(&X);
        continue;
      }
      if (xml_is(&X, "tbl")) tbl++;
      else if (xml_is(&X, "tr") && tbl == 1) {
        row = imp_para(ST_NORMAL, L_NONE, 0, A_LEFT);
        cells = 0;
      } else if (xml_is(&X, "tc") && tbl == 1 && row) {
        if (cells++) imp_add(row, "  |  ", 0);
      } else if (xml_is(&X, "p")) {
        if (tbl && row) p = row;
        else p = imp_para(ST_NORMAL, L_NONE, 0, A_LEFT);
        numid = -1, ilvl = 0, bdr = 0, psz = 0, pstyled = 0;
        if (X.empty && !tbl) p = NULL;
      } else if (xml_is(&X, "pPr")) in_ppr = !X.empty;
      else if (xml_is(&X, "rPr")) in_rpr = !X.empty;
      else if (xml_is(&X, "r")) fm = 0, rsz = 0;
      else if (p && p != row && in_ppr && !in_rpr) {
        if (xml_is(&X, "pStyle")) {
          xml_attr(&X, "val", v, sizeof v);
          for (int i = 0; i < nsty; i++)
            if (!strcmp(sty[i].id, v)) {
              pstyled = sty[i].style != ST_NORMAL;
              p->style = (unsigned char)sty[i].style;
              if (sty[i].list && !p->list) p->list = (unsigned char)sty[i].list;
            }
        } else if (xml_is(&X, "numId")) xml_attr(&X, "val", v, sizeof v), numid = atoi(v);
        else if (xml_is(&X, "ilvl")) xml_attr(&X, "val", v, sizeof v), ilvl = atoi(v);
        else if (xml_is(&X, "jc")) {
          xml_attr(&X, "val", v, sizeof v);
          p->align = !strcmp(v, "center") ? A_CENTER : (!strcmp(v, "right") || !strcmp(v, "end")) ? A_RIGHT : A_LEFT;
        } else if (xml_is(&X, "ind") && !p->list) {
          if (xml_attr(&X, "left", v, sizeof v) || xml_attr(&X, "start", v, sizeof v)) {
            int ind = atoi(v) / 720;
            p->indent = (unsigned char)(ind > 6 ? 6 : ind < 0 ? 0 : ind);
          }
        } else if (xml_is(&X, "bottom")) bdr = 1;
      } else if (in_rpr) {
        int on = !xml_attr(&X, "val", v, sizeof v) || (strcmp(v, "0") && strcmp(v, "false") && strcmp(v, "none"));
        if (xml_is(&X, "b") && on) fm |= F_BOLD;
        else if (xml_is(&X, "i") && on) fm |= F_ITAL;
        else if (xml_is(&X, "u") && on) fm |= F_UNDER;
        else if ((xml_is(&X, "strike") || xml_is(&X, "dstrike")) && on) fm |= F_STRIKE;
        else if (xml_is(&X, "color")) fm = (fm & 0x0f) | hex_color(v) << 4;
        else if (xml_is(&X, "sz")) rsz = atoi(v);
      } else if (xml_is(&X, "t")) in_t = !X.empty;
      else if (p && (xml_is(&X, "tab") || xml_is(&X, "ptab"))) imp_add(p, "    ", fm);
      else if (p && (xml_is(&X, "br") || xml_is(&X, "cr")) && p != row) {
        xml_attr(&X, "type", v2, sizeof v2);
        if (strcmp(v2, "page") && strcmp(v2, "column")) {
          imp_finish(p);
          Para *q = imp_para(p->style, p->list, p->indent, p->align);
          p = q;
        }
      }
    } else if (X.type == X_CLOSE) {
      if (xml_is(&X, "tbl")) {
        if (tbl) tbl--;
        if (!tbl) row = NULL;
      } else if (xml_is(&X, "pPr")) {
        in_ppr = 0;
        if (p && p != row && numid > 0) {
          int lt = numid < 64 ? numfmt[numid] : L_BULLET;
          if (lt) p->list = (unsigned char)lt, p->indent = (unsigned char)(ilvl > 6 ? 6 : ilvl);
        }
      } else if (xml_is(&X, "rPr")) in_rpr = 0;
      else if (xml_is(&X, "t")) in_t = 0;
      else if (xml_is(&X, "p") && p) {
        if (p != row) {
          if (!pstyled && p->style == ST_NORMAL && psz) p->style = (unsigned char)(psz >= 48 ? ST_TITLE : psz >= 36 ? ST_H1 : psz >= 30 ? ST_H2 : ST_NORMAL);
          imp_finish(p);
          if (bdr && !p->n) p->hr = 1;
        }
        p = NULL;
      }
    } else if (X.type == X_TEXT && in_t && p) {
      char *t = malloc((size_t)X.tlen * 3 + 8);
      xml_text(&X, t, X.tlen * 3 + 8);
      imp_add(p, t, fm);
      if (rsz > psz && strspn(t, " ") != strlen(t)) psz = rsz;
      free(t);
    }
  }
  free(x);
}

typedef struct {
  int fm, fs, skip, list_dest, field_inst;
} RState;

static int cp1252(int c, char *o) {
  static const unsigned short hi[32] = {0x20AC, 0, 0x201A, 0x192, 0x201E, 0x2026, 0x2020, 0x2021, 0x2C6, 0x2030, 0x160, 0x2039, 0x152, 0, 0x17D, 0,
                                        0, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x2DC, 0x2122, 0x161, 0x203A, 0x153, 0, 0x17E, 0x178};
  unsigned cp = c >= 0x80 && c < 0xA0 ? hi[c - 0x80] : (unsigned)c;
  char u[4];
  int l;
  if (cp < 0x80) u[0] = (char)cp, l = 1;
  else if (cp < 0x800) u[0] = (char)(0xC0 | cp >> 6), u[1] = (char)(0x80 | (cp & 63)), l = 2;
  else u[0] = (char)(0xE0 | cp >> 12), u[1] = (char)(0x80 | ((cp >> 6) & 63)), u[2] = (char)(0x80 | (cp & 63)), l = 3;
  return office_ascii(u, l, o, 8);
}

static void rtf_import(const char *s, size_t n) {
  RState st[64];
  int sp = 0;
  memset(&st[0], 0, sizeof st[0]);
  st[0].fs = 24;
  int colors[64], ncol = 0, cr = 0, cg = 0, cb = 0, in_ctbl = 0;
  int align = A_LEFT, li = 0, maxfs = 0, uc = 1, skipn = 0, cells = 0, intbl = 0, ptype = 0, brdr = 0, sep = 0, olvl = -1;
  Para *p = NULL;
  char ltxt[32];
  int ll = 0;
  for (size_t i = 0; i < n; i++) {
    char c = s[i];
    RState *S = &st[sp];
    if (c == '{') {
      if (sp < 63) st[sp + 1] = st[sp], sp++;
      st[sp].list_dest = 0;
      continue;
    }
    if (c == '}') {
      if (st[sp].list_dest) {
        ltxt[ll] = 0;
        ptype = 0;
        for (int k = 0; k < ll; k++)
          if (isdigit((unsigned char)ltxt[k]) || (ltxt[k] >= 'a' && ltxt[k] <= 'z' && ll > 1)) ptype = L_NUMBER;
        if (!ptype && ll) ptype = L_BULLET;
      }
      if (in_ctbl && sp > 0 && st[sp - 1].skip == 0) in_ctbl = 0;
      if (sp > 0) sp--;
      continue;
    }
    if (c == '\r' || c == '\n') continue;
    char out[16];
    int ol = 0;
    if (c == '\\' && i + 1 < n) {
      char d = s[i + 1];
      if (d == '\\' || d == '{' || d == '}') {
        out[0] = d, ol = 1, i++;
      } else if (d == '\'' && i + 3 < n) {
        char h[3] = {s[i + 2], s[i + 3], 0};
        ol = cp1252((int)strtol(h, NULL, 16), out);
        i += 3;
        if (skipn > 0) {
          skipn--;
          ol = 0;
        }
      } else if (d == '~') out[0] = ' ', ol = 1, i++;
      else if (d == '*') {
        S->skip = 1, i++;
        continue;
      } else if (d == '-' || d == '_' || d == ':' || d == '|') {
        if (d == '_') out[0] = '-', ol = 1;
        i++;
      } else if (isalpha((unsigned char)d)) {
        size_t j = i + 1;
        char w[32];
        int wl = 0;
        while (j < n && isalpha((unsigned char)s[j]) && wl < 31) w[wl++] = s[j++];
        w[wl] = 0;
        int has = 0, neg = 0;
        long arg = 0;
        if (j < n && s[j] == '-') neg = 1, j++;
        while (j < n && isdigit((unsigned char)s[j])) arg = arg * 10 + (s[j++] - '0'), has = 1;
        if (neg) arg = -arg;
        if (j < n && s[j] == ' ') j++;
        i = j - 1;
        if (!strcmp(w, "fonttbl") || !strcmp(w, "stylesheet") || !strcmp(w, "info") || !strcmp(w, "pict") || !strcmp(w, "header") ||
            !strcmp(w, "footer") || !strcmp(w, "footnote") || !strcmp(w, "object") || !strcmp(w, "fldinst") || !strcmp(w, "listtable") ||
            !strcmp(w, "listoverridetable") || !strcmp(w, "rsidtbl") || !strcmp(w, "generator") || !strcmp(w, "themedata") ||
            !strcmp(w, "colorschememapping") || !strcmp(w, "latentstyles") || !strcmp(w, "datastore") || !strcmp(w, "xmlnstbl") ||
            !strcmp(w, "headerl") || !strcmp(w, "headerr") || !strcmp(w, "footerl") || !strcmp(w, "footerr") || !strcmp(w, "bkmkstart") ||
            !strcmp(w, "bkmkend") || !strcmp(w, "shp") || !strcmp(w, "nonshppict") || !strcmp(w, "shppict"))
          S->skip = 1;
        else if (!strcmp(w, "colortbl")) S->skip = 1, in_ctbl = 1, ncol = 0, cr = cg = cb = 0;
        else if (!strcmp(w, "red")) cr = (int)arg;
        else if (!strcmp(w, "green")) cg = (int)arg;
        else if (!strcmp(w, "blue")) cb = (int)arg;
        else if (!strcmp(w, "listtext") || !strcmp(w, "pntext")) S->skip = 1, S->list_dest = 1, ll = 0;
        else if (S->skip) continue;
        else if (!strcmp(w, "par") || !strcmp(w, "line") || (!strcmp(w, "row"))) {
          if (!strcmp(w, "row")) cells = 0;
          if (!strcmp(w, "par") && intbl) continue;
          int was_row = !strcmp(w, "row");
          if (!p) {
            if (was_row) continue;
            p = imp_para(ST_NORMAL, L_NONE, 0, A_LEFT);
          }
          if (brdr && !p->n && !was_row) p->hr = 1;
          int style = maxfs >= 48 ? ST_TITLE : maxfs >= 36 ? ST_H1 : maxfs >= 30 ? ST_H2 : ST_NORMAL;
          if (style == ST_NORMAL && olvl >= 0) style = olvl == 0 ? ST_H1 : ST_H2;
          p->style = (unsigned char)style;
          p->align = (unsigned char)(was_row ? A_LEFT : align);
          if (ptype) p->list = (unsigned char)ptype, p->indent = (unsigned char)(li > 1080 ? (li - 360) / 720 > 6 ? 6 : (li - 360) / 720 : 0);
          else if (li >= 720) p->indent = (unsigned char)(li / 720 > 6 ? 6 : li / 720);
          imp_finish(p);
          p = NULL, maxfs = 0;
          if (strcmp(w, "line")) ptype = 0;
          if (!strcmp(w, "row")) intbl = 0;
          sep = 0;
        } else if (!strcmp(w, "pard")) align = A_LEFT, li = 0, ptype = 0, intbl = 0, brdr = 0, olvl = -1;
        else if (!strcmp(w, "outlinelevel")) olvl = (int)arg;
        else if (!strcmp(w, "brdrb")) brdr = 1;
        else if (!strcmp(w, "intbl")) intbl = 1;
        else if (!strcmp(w, "cell")) {
          if (!p) p = imp_para(ST_NORMAL, L_NONE, 0, A_LEFT);
          sep = 1;
          cells++;
          continue;
        } else if (!strcmp(w, "plain")) S->fm = 0, S->fs = 24;
        else if (!strcmp(w, "b")) S->fm = has && !arg ? S->fm & ~F_BOLD : S->fm | F_BOLD;
        else if (!strcmp(w, "i")) S->fm = has && !arg ? S->fm & ~F_ITAL : S->fm | F_ITAL;
        else if (!strcmp(w, "ul")) S->fm = has && !arg ? S->fm & ~F_UNDER : S->fm | F_UNDER;
        else if (!strcmp(w, "ulnone")) S->fm &= ~F_UNDER;
        else if (!strcmp(w, "strike")) S->fm = has && !arg ? S->fm & ~F_STRIKE : S->fm | F_STRIKE;
        else if (!strcmp(w, "cf")) S->fm = (S->fm & 0x0f) | ((arg > 0 && arg < ncol ? colors[arg] : 0) << 4);
        else if (!strcmp(w, "fs")) S->fs = (int)arg;
        else if (!strcmp(w, "qc")) align = A_CENTER;
        else if (!strcmp(w, "qr")) align = A_RIGHT;
        else if (!strcmp(w, "ql") || !strcmp(w, "qj")) align = A_LEFT;
        else if (!strcmp(w, "li")) li = (int)arg;
        else if (!strcmp(w, "uc")) uc = (int)arg;
        else if (!strcmp(w, "u")) {
          unsigned cp = (unsigned)(arg < 0 ? arg + 65536 : arg);
          char u[4];
          int l2;
          if (cp < 0x80) u[0] = (char)cp, l2 = 1;
          else if (cp < 0x800) u[0] = (char)(0xC0 | cp >> 6), u[1] = (char)(0x80 | (cp & 63)), l2 = 2;
          else u[0] = (char)(0xE0 | cp >> 12), u[1] = (char)(0x80 | ((cp >> 6) & 63)), u[2] = (char)(0x80 | (cp & 63)), l2 = 3;
          ol = office_ascii(u, l2, out, sizeof out);
          skipn = uc;
        } else if (!strcmp(w, "tab")) out[0] = out[1] = out[2] = out[3] = ' ', ol = 4;
        else if (!strcmp(w, "bullet")) out[0] = '*', ol = 1;
        else if (!strcmp(w, "emdash") || !strcmp(w, "endash")) out[0] = '-', ol = 1;
        else if (!strcmp(w, "lquote") || !strcmp(w, "rquote")) out[0] = '\'', ol = 1;
        else if (!strcmp(w, "ldblquote") || !strcmp(w, "rdblquote")) out[0] = '"', ol = 1;
        else if (!strcmp(w, "emspace") || !strcmp(w, "enspace")) out[0] = ' ', ol = 1;
        if (!ol) continue;
      } else {
        i++;
        continue;
      }
    } else if (in_ctbl && st[sp].skip) {
      if (c == ';') {
        if (ncol < 64) colors[ncol++] = near_color((unsigned)cr, (unsigned)cg, (unsigned)cb);
        cr = cg = cb = 0;
      }
      continue;
    } else {
      if (skipn > 0) {
        skipn--;
        continue;
      }
      out[0] = c, ol = 1;
    }
    if (in_ctbl && ncol == 0 && st[sp].skip) continue;
    if (st[sp].list_dest) {
      for (int k = 0; k < ol && ll < 30; k++)
        if (out[k] != ' ') ltxt[ll++] = out[k];
      continue;
    }
    if (st[sp].skip) continue;
    if (!p) p = imp_para(ST_NORMAL, L_NONE, 0, A_LEFT);
    if (sep && p->n) imp_add(p, "  |  ", 0);
    sep = 0;
    out[ol] = 0;
    if (st[sp].fs > maxfs && strspn(out, " ") != (size_t)ol) maxfs = st[sp].fs;
    imp_add(p, out, st[sp].fm);
  }
  if (p) imp_finish(p);
  (void)cells;
}

int docs_import(const char *path) {
  ensure_loaded();
  char title[96];
  office_title_from_path(path, title, sizeof title);
  size_t l = strlen(path);
  int rtf = l > 4 && !strcasecmp(path + l - 4, ".rtf");
  Zip *z = NULL;
  char *body = NULL;
  size_t n = 0;
  if (rtf) {
    body = read_file(path);
    if (!body || strncmp(body, "{\\rtf", 5)) {
      free(body);
      return 0;
    }
    n = strlen(body);
  } else {
    z = zip_open(path);
    char *chk = z ? zip_read(z, "word/document.xml", NULL) : NULL;
    if (!chk) {
      zip_close(z);
      return 0;
    }
    free(chk);
  }
  commit_title();
  if (N.dirty) save_doc();
  new_doc(title, NULL);
  doc_clear();
  if (rtf) rtf_import(body, n);
  else docx_import(z);
  free(body);
  zip_close(z);
  while (N.np > 1 && !N.p[N.np - 1].n && !N.p[N.np - 1].hr && !N.p[N.np - 2].n && !N.p[N.np - 2].hr) para_remove(N.np - 1);
  if (!N.np) para_insert(0);
  N.cur = N.anc = (Pos){0, 0};
  N.mode = 0;
  N.home = 0;
  layout_ok = 0;
  save_doc();
  set_panel_title();
  return 1;
}
