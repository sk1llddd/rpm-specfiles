#include <ctype.h>
#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "store.h"

#define NW 1080
#define NH 720
#define HEAD 64
#define SIDE 208
#define MW (NW - SIDE)
#define PADX 28
#define COLS 3
#define CARD_W 262
#define CARD_H 96
#define GAP 14
#define API "https://flathub.org/api/v2"

#define T_ACC THEME(RGB(14, 116, 224), RGB(88, 166, 255))
#define T_TINT THEME(RGB(224, 238, 253), RGB(28, 52, 86))
#define T_OK THEME(RGB(24, 140, 84), RGB(92, 205, 140))
#define T_WARN THEME(RGB(214, 120, 12), RGB(255, 178, 84))
#define T_BAD THEME(RGB(206, 52, 40), RGB(255, 120, 108))

enum { V_HOME, V_LIST, V_APP, V_INST, V_UPD };
enum { L_COLL, L_CAT, L_SEARCH };
enum {
  Z_SEARCH = 50, Z_CLEAR, Z_BACK, Z_SIDE = 100, Z_CARD = 1000, Z_GET = 2000, Z_SEE = 3000, Z_HERO = 3100, Z_HERO_GET, Z_HERO_DOT = 3110,
  Z_ACT = 3200, Z_RM, Z_SHOT, Z_SHOT_L, Z_SHOT_R, Z_DOT = 3210, Z_LINK = 3300, Z_REL_MORE = 3350, Z_PERM_MORE, Z_DESC_MORE,
  Z_CATTILE = 3500, Z_LB_X = 3400, Z_LB_L, Z_LB_R, Z_LB_BG, Z_IROW = 4000, Z_IOPEN = 4300, Z_IUPD = 4600, Z_IRM = 4900, Z_UPDALL = 5200, Z_RETRY
};

typedef struct {
  char id[96], name[64], summary[128], dev[56], icon[260], license[40];
  int verified;
  long installs, updated, added;
} Hit;

typedef struct {
  Hit *h;
  int n, cap, total, pages, page, err, loaded, kind;
  char arg[96], title[80];
  NetReq *req;
  int req_page;
} Lst;

typedef struct {
  char kind;
  int num;
  char *t;
} Blk;

typedef struct {
  char ver[40], date[24], type[16];
  long ts;
  Blk *b;
  int nb;
} Rel;

typedef struct {
  char text[120];
  int risk;
} Perm;

typedef struct {
  char id[96], name[96], summary[200], dev[80], license[60], vweb[80], vlogin[60], runtime[80], sdk[80], branch[24], arches[48], cmd[60],
      ref[120], brand[2][10], rating_title[40];
  char urls[9][240];
  char cats[8][28], keys[8][28], mime[8][40], shots[12][300], shots_big[12][300], shot_cap[12][100], rating[12][70];
  int ncat, nkey, nmime, nshot, nrating, nrel, nperm, nblk, eol, free_lic, verified, shot_cur, spark[60], nspark, spark_max;
  long installs_total, installs_month, installs_week, ts, added;
  double dl, inst;
  int a_ok, s_ok, t_ok, err, rel_all, perm_all, desc_all;
  Blk *blk;
  Rel rel[8];
  Perm perm[48];
  Hit hit;
  int have_hit;
  NetReq *ra, *rs, *rt;
} Det;

typedef struct {
  char id[96], name[64], ver[28], size[20];
  int upd;
} Inst;

typedef struct {
  char id[96], name[64];
  int kind;
} Op;

typedef struct {
  int view, side, scroll[5], hero, lb, hero_t;
  uint32_t hero_at, q_at, toast_t, blink_t;
  int q_dirty, focus, blink, press, back_n, panel;
  char q[96], toast[120], cur_id[96];
  struct {
    int view, side, scroll;
    char id[96];
  } back[10];
  float content_h;
} St;

static St S;
static Lst SEC[4], BR;
static Det D;
static const char *const SEC_KEY[4] = {"trending", "popular", "recently-updated", "recently-added"};
static const char *const SEC_TITLE[4] = {"Trending now", "Most popular", "Recently updated", "New arrivals"};
static const char *const CAT_KEY[11] = {"AudioVideo", "Development", "Education", "Game", "Graphics", "Network", "Office", "Science", "System", "Utility", "HealthFitness"};
static const char *const CAT_NAME[11] = {"Audio & Video", "Development", "Education", "Games", "Graphics", "Internet", "Office", "Science", "System", "Utility", "Health & Fitness"};
static const uint32_t CAT_COL[11] = {RGB(232, 72, 108), RGB(76, 90, 232), RGB(232, 156, 24), RGB(124, 72, 224), RGB(222, 96, 24), RGB(14, 148, 200), RGB(36, 130, 220), RGB(24, 160, 120), RGB(96, 108, 124), RGB(0, 150, 136), RGB(220, 60, 90)};

static Inst INST[500];
static int ninst, inst_loaded;
static char upd_ids[300][96];
static int nupd, upd_loaded;
static int fp_state;
static NetReq *fp_ver, *fp_list, *fp_upd, *fp_op;
static Op OPS[10];
static int nops;
static float op_prog;
static char op_text[96];
static uint32_t op_t0;

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static void toast(const char *m) {
  snprintf(S.toast, sizeof S.toast, "%.119s", m);
  S.toast_t = now_ms();
}

static void fmt_count(long n, char *o, int cap) {
  if (n >= 1000000) snprintf(o, (size_t)cap, "%.1fM", n / 1e6);
  else if (n >= 10000) snprintf(o, (size_t)cap, "%.0fK", n / 1e3);
  else if (n >= 1000) snprintf(o, (size_t)cap, "%.1fK", n / 1e3);
  else snprintf(o, (size_t)cap, "%ld", n);
}

static void fmt_bytes(double b, char *o, int cap) {
  if (b >= 1073741824.0) snprintf(o, (size_t)cap, "%.1f GB", b / 1073741824.0);
  else if (b >= 1048576.0) snprintf(o, (size_t)cap, "%.1f MB", b / 1048576.0);
  else if (b >= 1024.0) snprintf(o, (size_t)cap, "%.0f KB", b / 1024.0);
  else snprintf(o, (size_t)cap, "%.0f B", b);
}

static void fmt_day(long t, char *o, int cap) {
  if (t <= 0) {
    snprintf(o, (size_t)cap, "-");
    return;
  }
  time_t tt = (time_t)t;
  struct tm tm;
  gmtime_r(&tt, &tm);
  strftime(o, (size_t)cap, "%b %d, %Y", &tm);
}

static void cpy(char *d, size_t n, const char *s) { snprintf(d, n, "%s", s ? s : ""); }

static int lum(uint32_t c) { return (int)(((c >> 16) & 255) * 0.299 + ((c >> 8) & 255) * 0.587 + (c & 255) * 0.114); }

static uint32_t mixc(uint32_t a, uint32_t b, float t) {
  int r = (int)(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int)(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t),
      bl = (int)((a & 255) * (1 - t) + (b & 255) * t);
  return RGB(r, g, bl);
}

static uint32_t hex_color(const char *h) {
  if (!h || h[0] != '#' || strlen(h) < 7) return 0;
  return 0xff000000u | (uint32_t)strtoul(h + 1, NULL, 16);
}

static void blk_free(Blk *b, int n) {
  for (int i = 0; i < n; i++) free(b[i].t);
  free(b);
}

static void html_blocks(const char *h, Blk **out, int *nout, int max) {
  Blk *b = calloc((size_t)max, sizeof *b);
  int n = 0, ordered = 0, num = 0;
  char kind = 'p';
  Buf cur = {0};
  buf_put(&cur, "", 0);
  int sp = 1;
  for (const char *p = h ? h : ""; *p; p++) {
    if (*p == '<') {
      const char *e = strchr(p, '>');
      if (!e) break;
      char name[16] = {0};
      int cl = p[1] == '/', k = 0;
      for (const char *q = p + 1 + cl; q < e && k < 15 && (isalnum((unsigned char)*q)); q++) name[k++] = (char)tolower((unsigned char)*q);
      int block = !strcmp(name, "p") || !strcmp(name, "li") || !strcmp(name, "ul") || !strcmp(name, "ol") || !strcmp(name, "br") ||
                  (name[0] == 'h' && isdigit((unsigned char)name[1]));
      if (block) {
        while (cur.n && cur.s[cur.n - 1] == ' ') cur.s[--cur.n] = 0;
        if (cur.n && n < max) {
          b[n].kind = kind;
          b[n].num = kind == 'o' ? ++num : 0;
          b[n].t = strdup(cur.s);
          n++;
        }
        cur.n = 0;
        buf_put(&cur, "", 0);
        sp = 1;
        if (!cl) {
          if (!strcmp(name, "li")) kind = ordered ? 'o' : 'l';
          else if (name[0] == 'h') kind = 'h';
          else if (!strcmp(name, "ol")) ordered = 1, num = 0;
          else if (!strcmp(name, "ul")) ordered = 0;
          else if (strcmp(name, "br")) kind = 'p';
        } else if (!strcmp(name, "ul") || !strcmp(name, "ol") || !strcmp(name, "li") || name[0] == 'h') kind = 'p';
      }
      p = e;
      continue;
    }
    if (*p == '&') {
      const char *semi = strchr(p, ';');
      if (semi && semi - p < 9) {
        char ent[12] = {0};
        memcpy(ent, p + 1, (size_t)(semi - p - 1));
        char c = 0;
        if (!strcmp(ent, "amp")) c = '&';
        else if (!strcmp(ent, "lt")) c = '<';
        else if (!strcmp(ent, "gt")) c = '>';
        else if (!strcmp(ent, "quot")) c = '"';
        else if (!strcmp(ent, "apos") || !strcmp(ent, "#39")) c = '\'';
        else if (!strcmp(ent, "nbsp")) c = ' ';
        if (c) {
          if (!(c == ' ' && sp)) buf_put(&cur, &c, 1), sp = c == ' ';
          p = semi;
          continue;
        }
      }
    }
    char c = *p;
    if (c == ' ') {
      if (sp) continue;
      sp = 1;
    } else sp = 0;
    buf_put(&cur, &c, 1);
  }
  while (cur.n && cur.s[cur.n - 1] == ' ') cur.s[--cur.n] = 0;
  if (cur.n && n < max) {
    b[n].kind = kind;
    b[n].num = kind == 'o' ? ++num : 0;
    b[n].t = strdup(cur.s);
    n++;
  }
  free(cur.s);
  *out = b;
  *nout = n;
}

static void hit_from_json(Hit *h, const J *j) {
  memset(h, 0, sizeof *h);
  const char *id = jstr(j, "app_id", jstr(j, "id", ""));
  cpy(h->id, sizeof h->id, id);
  cpy(h->name, sizeof h->name, jstr(j, "name", id));
  cpy(h->summary, sizeof h->summary, jstr(j, "summary", ""));
  cpy(h->dev, sizeof h->dev, jstr(j, "developer_name", ""));
  cpy(h->icon, sizeof h->icon, jstr(j, "icon", ""));
  cpy(h->license, sizeof h->license, jstr(j, "project_license", ""));
  h->verified = jbool(j, "verification_verified", 0);
  h->installs = (long)jnum(j, "installs_last_month", 0);
  h->updated = (long)jnum(j, "updated_at", 0);
  h->added = (long)jnum(j, "added_at", 0);
}

static void lst_reset(Lst *l, int kind, const char *arg, const char *title) {
  free(l->h);
  memset(l, 0, sizeof *l);
  l->kind = kind;
  cpy(l->arg, sizeof l->arg, arg);
  cpy(l->title, sizeof l->title, title);
}

static void json_escape_q(const char *in, char *out, int cap) {
  int k = 0;
  for (; *in && k < cap - 2; in++)
    if (isalnum((unsigned char)*in) || *in == ' ' || *in == '-' || *in == '.' || *in == '+' || *in == '_') out[k++] = *in;
  out[k] = 0;
}

static void lst_request(Lst *l, int page, int per) {
  if (l->req || l->err) return;
  char url[560], post[360] = "";
  if (l->kind == L_COLL) snprintf(url, sizeof url, API "/collection/%s?page=%d&per_page=%d", l->arg, page, per);
  else if (l->kind == L_CAT) snprintf(url, sizeof url, API "/collection/category/%s?page=%d&per_page=%d", l->arg, page, per);
  else {
    char q[120];
    json_escape_q(l->arg, q, sizeof q);
    snprintf(url, sizeof url, API "/search");
    snprintf(post, sizeof post, "{\"query\":\"%s\",\"hits_per_page\":%d,\"page\":%d,\"filters\":[]}", q, per, page);
  }
  l->req = net_http(url, post[0] ? post : NULL, l->kind == L_SEARCH ? 300 : 900);
  l->req_page = page;
}

static int lst_ingest(Lst *l) {
  NetReq *r = l->req;
  if (!r) return 0;
  if (r->state == NET_FAIL) {
    l->req = NULL;
    l->err = 1;
    return 1;
  }
  if (r->state != NET_OK) return 0;
  J *j = json_parse(r->out.s, r->out.n);
  l->req = NULL;
  J *hits = jget(j, "hits");
  if (!hits) l->err = 1;
  int add = jlen(hits);
  if (l->n + add > l->cap) {
    l->cap = l->n + add + 24;
    l->h = realloc(l->h, sizeof(Hit) * (size_t)l->cap);
  }
  for (int i = 0; i < add; i++) {
    Hit *h = &l->h[l->n];
    hit_from_json(h, jat(hits, i));
    int dup = 0;
    for (int k = 0; k < l->n; k++)
      if (!strcmp(l->h[k].id, h->id)) dup = 1;
    if (h->id[0] && !dup) l->n++;
  }
  l->total = (int)jnum(j, "totalHits", l->n);
  l->pages = (int)jnum(j, "totalPages", 1);
  l->page = l->req_page;
  l->loaded = 1;
  json_free(j);
  return 1;
}

static void det_free(void) {
  blk_free(D.blk, D.nblk);
  for (int i = 0; i < D.nrel; i++) blk_free(D.rel[i].b, D.rel[i].nb);
  memset(&D, 0, sizeof D);
}

static const char *url_label[9] = {"Homepage", "Help", "Bug tracker", "Source code", "Donate", "Translate", "FAQ", "Contact", "Contribute"};
static const char *url_key[9] = {"homepage", "help", "bugtracker", "vcs_browser", "donation", "translate", "faq", "contact", "contribute"};

static void det_parse_appstream(J *j) {
  cpy(D.name, sizeof D.name, jstr(j, "name", D.id));
  cpy(D.summary, sizeof D.summary, jstr(j, "summary", ""));
  cpy(D.dev, sizeof D.dev, jstr(j, "developer_name", ""));
  cpy(D.license, sizeof D.license, jstr(j, "project_license", ""));
  D.free_lic = jbool(j, "is_free_license", 0);
  D.eol = jbool(j, "is_eol", 0);
  J *md = jget(j, "metadata");
  D.verified = jbool(md, "flathub::verification::verified", 0);
  cpy(D.vweb, sizeof D.vweb, jstr(md, "flathub::verification::website", ""));
  cpy(D.vlogin, sizeof D.vlogin, jstr(md, "flathub::verification::login_name", ""));
  J *urls = jget(j, "urls");
  for (int i = 0; i < 9; i++) cpy(D.urls[i], sizeof D.urls[i], jstr(urls, url_key[i], ""));
  J *cats = jget(j, "categories");
  for (int i = 0; i < jlen(cats) && D.ncat < 8; i++) cpy(D.cats[D.ncat++], 28, jval(jat(cats, i), ""));
  J *kw = jget(j, "keywords");
  for (int i = 0; i < jlen(kw) && D.nkey < 8; i++) cpy(D.keys[D.nkey++], 28, jval(jat(kw, i), ""));
  J *mt = jget(j, "mimetypes");
  for (int i = 0; i < jlen(mt) && D.nmime < 8; i++) cpy(D.mime[D.nmime++], 40, jval(jat(mt, i), ""));
  J *bundle = jget(j, "bundle");
  cpy(D.runtime, sizeof D.runtime, jstr(bundle, "runtime", ""));
  cpy(D.sdk, sizeof D.sdk, jstr(bundle, "sdk", ""));
  cpy(D.ref, sizeof D.ref, jstr(bundle, "value", ""));
  for (int i = 0; i < jlen(j); i++) {
    const char *k = jkey(j, i);
    if (!strcmp(k, "launchable")) cpy(D.cmd, sizeof D.cmd, jstr(jat(j, i), "value", ""));
  }
  J *br = jget(j, "branding");
  for (int i = 0; i < jlen(br); i++) {
    J *b = jat(br, i);
    if (strcmp(jstr(b, "type", ""), "primary")) continue;
    int dark = !strcmp(jstr(b, "scheme_preference", ""), "dark");
    cpy(D.brand[dark], 10, jstr(b, "value", ""));
  }
  J *sc = jget(j, "screenshots");
  for (int i = 0; i < jlen(sc) && D.nshot < 12; i++) {
    J *sizes = jget(jat(sc, i), "sizes");
    const char *pick = NULL, *big = NULL;
    double bw = 1e9, bb = 0;
    for (int k = 0; k < jlen(sizes); k++) {
      J *z = jat(sizes, k);
      double w = jnum(z, "width", 0);
      const char *src = jstr(z, "src", "");
      if (w >= 600 && w < bw) bw = w, pick = src;
      if (w <= 1300 && w > bb) bb = w, big = src;
    }
    if (!pick) pick = big;
    if (!pick) continue;
    cpy(D.shots[D.nshot], 300, pick);
    cpy(D.shots_big[D.nshot], 300, big ? big : pick);
    cpy(D.shot_cap[D.nshot], 100, jstr(jat(sc, i), "caption", ""));
    D.nshot++;
  }
  html_blocks(jstr(j, "description", ""), &D.blk, &D.nblk, 80);
  J *rel = jget(j, "releases");
  for (int i = 0; i < jlen(rel) && D.nrel < 8; i++) {
    J *r = jat(rel, i);
    Rel *o = &D.rel[D.nrel++];
    cpy(o->ver, sizeof o->ver, jstr(r, "version", ""));
    cpy(o->date, sizeof o->date, jstr(r, "date", ""));
    o->ts = (long)jnum(r, "timestamp", 0);
    if (!o->date[0] && o->ts > 0) fmt_day(o->ts, o->date, sizeof o->date);
    cpy(o->type, sizeof o->type, jstr(r, "type", ""));
    html_blocks(jstr(r, "description", ""), &o->b, &o->nb, 40);
  }
  J *cr = jget(j, "content_rating_details");
  J *first = jat(cr, 0);
  J *crc = jget(first, "categories");
  int worst = 0;
  for (int i = 0; i < jlen(crc) && D.nrating < 12; i++) {
    J *c = jat(crc, i);
    const char *lv = jstr(c, "level", "none");
    int l = !strcmp(lv, "mild") ? 1 : !strcmp(lv, "moderate") ? 2 : !strcmp(lv, "intense") ? 3 : 0;
    if (!l) continue;
    if (l > worst) worst = l;
    snprintf(D.rating[D.nrating++], 70, "%.50s (%s)", jstr(c, "description", jstr(c, "id", "")), lv);
  }
  snprintf(D.rating_title, sizeof D.rating_title, "%s", !jlen(crc) ? "Not rated" : worst == 0 ? "Suitable for everyone" : worst == 1 ? "Mild content" : worst == 2 ? "Moderate content" : "Mature content");
  D.ts = 0;
  for (int i = 0; i < jlen(rel); i++) {
    long t = (long)jnum(jat(rel, i), "timestamp", 0);
    if (t > D.ts) D.ts = t;
  }
  D.a_ok = 1;
}

static void perm_add(const char *t, int risk) {
  if (D.nperm < 48) cpy(D.perm[D.nperm].text, 120, t), D.perm[D.nperm++].risk = risk;
}

static void det_parse_summary(J *j) {
  D.dl = jnum(j, "download_size", 0);
  D.inst = jnum(j, "installed_size", 0);
  cpy(D.branch, sizeof D.branch, jstr(j, "branch", ""));
  J *ar = jget(j, "arches");
  D.arches[0] = 0;
  for (int i = 0; i < jlen(ar); i++) {
    size_t l = strlen(D.arches);
    snprintf(D.arches + l, sizeof D.arches - l, "%s%s", l ? ", " : "", jval(jat(ar, i), ""));
  }
  J *md = jget(j, "metadata");
  if (!D.runtime[0]) cpy(D.runtime, sizeof D.runtime, jstr(md, "runtime", ""));
  if (!D.sdk[0]) cpy(D.sdk, sizeof D.sdk, jstr(md, "sdk", ""));
  if (jstr(md, "command", "")[0]) cpy(D.cmd, sizeof D.cmd, jstr(md, "command", ""));
  J *pm = jget(md, "permissions");
  J *sh = jget(pm, "shared");
  for (int i = 0; i < jlen(sh); i++) {
    const char *v = jval(jat(sh, i), "");
    if (!strcmp(v, "network")) perm_add("Network access", 1);
    else if (!strcmp(v, "ipc")) perm_add("Inter-process communication", 0);
  }
  J *so = jget(pm, "sockets");
  for (int i = 0; i < jlen(so); i++) {
    const char *v = jval(jat(so, i), "");
    if (!strcmp(v, "x11")) perm_add("Uses the X11 window system", 1);
    else if (!strcmp(v, "fallback-x11")) perm_add("X11 fallback", 0);
    else if (!strcmp(v, "wayland")) perm_add("Wayland windowing", 0);
    else if (!strcmp(v, "pulseaudio")) perm_add("Audio playback and recording", 0);
    else if (!strcmp(v, "session-bus")) perm_add("Full access to the session bus", 2);
    else if (!strcmp(v, "system-bus")) perm_add("Full access to the system bus", 2);
    else if (!strcmp(v, "ssh-auth")) perm_add("SSH keys agent", 1);
    else if (!strcmp(v, "gpg-agent")) perm_add("GPG agent", 1);
    else if (!strcmp(v, "cups")) perm_add("Printing", 0);
    else if (!strcmp(v, "pcsc")) perm_add("Smart card readers", 1);
  }
  J *dv = jget(pm, "devices");
  for (int i = 0; i < jlen(dv); i++) {
    const char *v = jval(jat(dv, i), "");
    if (!strcmp(v, "all")) perm_add("Access to all devices", 2);
    else if (!strcmp(v, "dri")) perm_add("GPU acceleration", 0);
    else if (!strcmp(v, "kvm")) perm_add("Virtualization", 1);
    else if (!strcmp(v, "usb")) perm_add("USB devices", 1);
    else if (!strcmp(v, "input")) perm_add("Input devices", 1);
    else if (!strcmp(v, "shm")) perm_add("Shared memory", 0);
  }
  J *fs = jget(pm, "filesystems");
  for (int i = 0; i < jlen(fs); i++) {
    char v[120];
    cpy(v, sizeof v, jval(jat(fs, i), ""));
    int ro = strstr(v, ":ro") != NULL;
    char *c = strchr(v, ':');
    if (c) *c = 0;
    char t[120];
    int risk = 1;
    if (!strcmp(v, "host") || !strcmp(v, "host-os") || !strcmp(v, "host-etc")) snprintf(t, sizeof t, "%s files", !strcmp(v, "host") ? "All" : "System"), risk = 2;
    else if (!strcmp(v, "home") || !strcmp(v, "~")) snprintf(t, sizeof t, "Your home folder"), risk = 2;
    else if (!strncmp(v, "xdg-", 4) && !strchr(v + 4, '/')) snprintf(t, sizeof t, "Your %.80s folder", v + 4), risk = 1;
    else if (!strncmp(v, "xdg-", 4)) snprintf(t, sizeof t, "%.100s", v), risk = 0;
    else snprintf(t, sizeof t, "Folder %.90s", v), risk = v[0] == '/' && strlen(v) < 6 ? 1 : 0;
    if (ro) strncat(t, " (read-only)", sizeof t - strlen(t) - 1), risk = risk > 0 ? risk - 1 : 0;
    perm_add(t, risk);
  }
  J *sb = jget(pm, "session-bus");
  int nt = jlen(jget(sb, "talk")), no = jlen(jget(sb, "own"));
  if (nt) {
    char t[100];
    snprintf(t, sizeof t, "Talks to %d session bus service%s", nt, nt == 1 ? "" : "s");
    perm_add(t, 0);
  }
  if (no) {
    char t[100];
    snprintf(t, sizeof t, "Owns %d session bus name%s", no, no == 1 ? "" : "s");
    perm_add(t, 0);
  }
  int ns = jlen(jget(jget(pm, "system-bus"), "talk"));
  if (ns) {
    char t[100];
    snprintf(t, sizeof t, "Talks to %d system bus service%s", ns, ns == 1 ? "" : "s");
    perm_add(t, 1);
  }
  J *pe = jget(pm, "persistent");
  if (jlen(pe)) {
    char t[100];
    snprintf(t, sizeof t, "Keeps data in %d private location%s", jlen(pe), jlen(pe) == 1 ? "" : "s");
    perm_add(t, 0);
  }
  J *ft = jget(pm, "features");
  for (int i = 0; i < jlen(ft); i++) {
    const char *v = jval(jat(ft, i), "");
    if (!strcmp(v, "bluetooth")) perm_add("Bluetooth", 1);
    else if (!strcmp(v, "devel")) perm_add("Development syscalls", 1);
    else if (!strcmp(v, "canbus")) perm_add("CAN bus", 1);
    else if (!strcmp(v, "multiarch")) perm_add("32-bit libraries", 0);
  }
  D.s_ok = 1;
}

static int cmp_str(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

static void det_parse_stats(J *j) {
  D.installs_total = (long)jnum(j, "installs_total", 0);
  D.installs_month = (long)jnum(j, "installs_last_month", 0);
  D.installs_week = (long)jnum(j, "installs_last_7_days", 0);
  J *pd = jget(j, "installs_per_day");
  int n = jlen(pd);
  char **keys = malloc(sizeof(char *) * (size_t)(n ? n : 1));
  for (int i = 0; i < n; i++) keys[i] = (char *)jkey(pd, i);
  qsort(keys, (size_t)n, sizeof(char *), cmp_str);
  int from = n > 60 ? n - 60 : 0;
  D.nspark = 0, D.spark_max = 1;
  for (int i = from; i < n && D.nspark < 60; i++) {
    int v = (int)jnum(pd, keys[i], 0);
    D.spark[D.nspark++] = v;
    if (v > D.spark_max) D.spark_max = v;
  }
  free(keys);
  D.t_ok = 1;
}

static void det_open(const char *id, const Hit *h) {
  det_free();
  cpy(D.id, sizeof D.id, id);
  if (h) D.hit = *h, D.have_hit = 1;
  char url[300];
  snprintf(url, sizeof url, API "/appstream/%s", id);
  D.ra = net_http(url, NULL, 3600);
  snprintf(url, sizeof url, API "/summary/%s", id);
  D.rs = net_http(url, NULL, 3600);
  snprintf(url, sizeof url, API "/stats/%s", id);
  D.rt = net_http(url, NULL, 3600);
  cpy(D.name, sizeof D.name, h ? h->name : id);
  cpy(D.summary, sizeof D.summary, h ? h->summary : "");
  cpy(D.dev, sizeof D.dev, h ? h->dev : "");
}

static int det_poll(void) {
  int ch = 0;
  NetReq **rq[3] = {&D.ra, &D.rs, &D.rt};
  for (int i = 0; i < 3; i++) {
    NetReq *r = *rq[i];
    if (!r) continue;
    if (r->state == NET_FAIL) {
      if (i == 0) D.err = 1;
      *rq[i] = NULL;
      ch = 1;
    } else if (r->state == NET_OK) {
      J *j = json_parse(r->out.s, r->out.n);
      if (j) {
        if (i == 0) det_parse_appstream(j);
        else if (i == 1) det_parse_summary(j);
        else det_parse_stats(j);
      } else if (i == 0) D.err = 1;
      json_free(j);
      *rq[i] = NULL;
      ch = 1;
    }
  }
  return ch;
}

static const char *fpbin(void) {
  const char *e = getenv("OREONVR_FLATPAK");
  return e && *e ? e : "flatpak";
}

static int safe_id(const char *id) {
  if (!*id) return 0;
  for (; *id; id++)
    if (!isalnum((unsigned char)*id) && *id != '.' && *id != '_' && *id != '-') return 0;
  return 1;
}

static void fp_refresh(void) {
  if (fp_state != 1) return;
  if (!fp_list) {
    char *av[] = {(char *)fpbin(), "list", "--app", "--columns=application,name,version,size", NULL};
    fp_list = net_proc("fp:list", av, 0);
  }
  if (!fp_upd) {
    char *av[] = {(char *)fpbin(), "remote-ls", "--updates", "--app", "--columns=application", NULL};
    fp_upd = net_proc("fp:upd", av, 0);
  }
}

static void fp_check(void) {
  if (fp_state || fp_ver) return;
  char *av[] = {(char *)fpbin(), "--version", NULL};
  fp_ver = net_proc("fp:ver", av, 0);
}

static int cmp_inst(const void *a, const void *b) { return strcasecmp(((const Inst *)a)->name, ((const Inst *)b)->name); }

static int is_updatable(const char *id) {
  for (int i = 0; i < nupd; i++)
    if (!strcmp(upd_ids[i], id)) return 1;
  return 0;
}

static void parse_installed(const char *s) {
  ninst = 0;
  while (*s && ninst < 500) {
    const char *e = strchr(s, '\n');
    int len = e ? (int)(e - s) : (int)strlen(s);
    char line[400];
    snprintf(line, sizeof line, "%.*s", len > 399 ? 399 : len, s);
    char *f[4] = {line, NULL, NULL, NULL};
    int nf = 1;
    for (char *c = line; *c && nf < 4; c++)
      if (*c == '\t') *c = 0, f[nf++] = c + 1;
    while (len > 0 && (line[strlen(line) - 1] == '\r')) line[strlen(line) - 1] = 0, len--;
    if (nf >= 2 && f[0][0] && safe_id(f[0])) {
      Inst *in = &INST[ninst++];
      memset(in, 0, sizeof *in);
      cpy(in->id, sizeof in->id, f[0]);
      char nm[64];
      office_ascii(f[1], (int)strlen(f[1]), nm, sizeof nm);
      cpy(in->name, sizeof in->name, nm);
      if (nf > 2) cpy(in->ver, sizeof in->ver, f[2]);
      if (nf > 3) {
        char sz[20];
        office_ascii(f[3], (int)strlen(f[3]), sz, sizeof sz);
        cpy(in->size, sizeof in->size, sz);
      }
    }
    s += len + (e ? 1 : 0);
    if (!e) break;
  }
  qsort(INST, (size_t)ninst, sizeof(Inst), cmp_inst);
  inst_loaded = 1;
}

static void parse_updates(const char *s) {
  nupd = 0;
  while (*s && nupd < 300) {
    const char *e = strchr(s, '\n');
    int len = e ? (int)(e - s) : (int)strlen(s);
    char id[96];
    snprintf(id, sizeof id, "%.*s", len > 95 ? 95 : len, s);
    char *tab = strchr(id, '\t');
    if (tab) *tab = 0;
    for (char *c = id; *c; c++)
      if (*c == '\r' || *c == ' ') *c = 0;
    if (safe_id(id)) cpy(upd_ids[nupd++], 96, id);
    s += len + (e ? 1 : 0);
    if (!e) break;
  }
  upd_loaded = 1;
}

static const char *op_verb(int k) { return k == 0 ? "Installing" : k == 1 ? "Removing" : "Updating"; }

static int app_state(const char *id) {
  for (int i = 0; i < nops; i++)
    if (!strcmp(OPS[i].id, id)) return i == 0 && fp_op ? 4 : 3;
  for (int i = 0; i < ninst; i++)
    if (!strcmp(INST[i].id, id)) return is_updatable(id) ? 2 : 1;
  return 0;
}

static void op_start_next(void) {
  if (fp_op || !nops || fp_state != 1) return;
  Op *o = &OPS[0];
  const char *scope = getuid() == 0 ? "--system" : "--user";
  const char *pre = "FP=${OREONVR_FLATPAK:-flatpak}; ";
  static char script[1900];
  char *av[6];
  if (o->kind == 0)
    snprintf(script, sizeof script,
             "%sS=%s; URL=https://dl.flathub.org/repo/flathub.flatpakrepo; "
             "\"$FP\" remote-add $S --if-not-exists flathub $URL >/dev/null 2>&1 || "
             "\"$FP\" remotes $S 2>/dev/null | grep -q flathub || "
             "{ \"$FP\" remote-add $S --if-not-exists flathub $URL 2>&1 | tail -n 1; echo \"Could not reach Flathub. Check the network connection.\"; exit 1; }; "
             "if [ \"$S\" = --system ]; then D=/var/lib/flatpak; else D=${HOME:-/}; fi; "
             "F=$(df -Pk \"$D\" 2>/dev/null | awk 'NR==2{print $4}'); "
             "if [ -n \"$F\" ] && [ \"$F\" -lt 700000 ]; then echo \"Not enough free space: $((F/1024)) MB left, apps need more. Install Oreon VR to disk or free memory.\"; exit 1; fi; "
             "N=0; while [ $N -lt 3 ]; do \"$FP\" install $S -y --noninteractive flathub \"$0\" && exit 0; N=$((N+1)); sleep 2; \"$FP\" repair $S >/dev/null 2>&1; done; exit 1",
             pre, scope);
  else if (o->kind == 1) snprintf(script, sizeof script, "%sexec \"$FP\" uninstall -y --noninteractive \"$0\"", pre);
  else if (o->id[0]) snprintf(script, sizeof script, "%sexec \"$FP\" update -y --noninteractive \"$0\"", pre);
  else snprintf(script, sizeof script, "%sexec \"$FP\" update -y --noninteractive", pre);
  int n = 0;
  av[n++] = "sh", av[n++] = "-c", av[n++] = script;
  if (o->id[0]) av[n++] = o->id;
  av[n] = NULL;
  fp_op = net_proc("fp:op", av, 1);
  op_prog = 0;
  op_t0 = now_ms();
  snprintf(op_text, sizeof op_text, "%s %s", op_verb(o->kind), o->name[0] ? o->name : "all apps");
}

static int op_add(const char *id, const char *name, int kind) {
  if (fp_state != 1) {
    toast("Flatpak is not available on this system");
    return 0;
  }
  if (kind != 3 && !safe_id(id)) return 0;
  for (int i = 0; i < nops; i++)
    if (!strcmp(OPS[i].id, id) && OPS[i].kind == kind) return 0;
  if (nops >= 10) {
    toast("Too many tasks queued");
    return 0;
  }
  Op *o = &OPS[nops++];
  cpy(o->id, sizeof o->id, kind == 3 ? "" : id);
  cpy(o->name, sizeof o->name, name);
  o->kind = kind;
  op_start_next();
  return 1;
}

static void run_app(const char *id, const char *name) {
  if (!safe_id(id)) return;
  char *av[] = {"sh", "-c",
                "FP=${OREONVR_FLATPAK:-flatpak}; if command -v dbus-run-session >/dev/null 2>&1; then exec dbus-run-session -- \"$FP\" run \"$0\"; fi; exec \"$FP\" run \"$0\"",
                (char *)id, NULL};
  if (wl_spawn(av)) {
    char m[120];
    snprintf(m, sizeof m, "Opening %.80s", name && *name ? name : id);
    toast(m);
  } else toast("Could not start the app");
}

static void open_url(const char *url) {
  if (strncmp(url, "http", 4)) return;
  char *av[] = {"xdg-open", (char *)url, NULL};
  wl_spawn(av);
  toast("Opening link in the browser");
}

static int op_poll(void) {
  int ch = 0;
  if (fp_ver && fp_ver->state >= NET_OK) {
    fp_state = fp_ver->state == NET_OK ? 1 : 2;
    net_drop(fp_ver);
    fp_ver = NULL;
    fp_refresh();
    ch = 1;
  }
  if (fp_list && fp_list->state >= NET_OK) {
    if (fp_list->state == NET_OK) parse_installed(fp_list->out.s ? fp_list->out.s : "");
    else inst_loaded = 1;
    net_drop(fp_list);
    fp_list = NULL;
    ch = 1;
  }
  if (fp_upd && fp_upd->state >= NET_OK) {
    if (fp_upd->state == NET_OK) parse_updates(fp_upd->out.s ? fp_upd->out.s : "");
    else upd_loaded = 1;
    net_drop(fp_upd);
    fp_upd = NULL;
    ch = 1;
  }
  if (fp_op) {
    const char *s = fp_op->out.s ? fp_op->out.s : "";
    size_t n = fp_op->out.n;
    for (size_t i = n; i > 0; i--)
      if (s[i - 1] == '%') {
        size_t j = i - 1;
        while (j > 0 && isdigit((unsigned char)s[j - 1])) j--;
        if (j < i - 1) {
          int pc = atoi(s + j);
          if (pc >= 0 && pc <= 100) op_prog = pc / 100.f;
        }
        break;
      }
    if (fp_op->state >= NET_OK) {
      Op o = OPS[0];
      int ok = fp_op->state == NET_OK;
      char errl[100] = "";
      if (!ok) {
        size_t e = n;
        while (e > 0 && (s[e - 1] == '\n' || s[e - 1] == '\r' || s[e - 1] == ' ')) e--;
        size_t b = e;
        while (b > 0 && s[b - 1] != '\n' && s[b - 1] != '\r') b--;
        snprintf(errl, sizeof errl, "%.*s", (int)(e - b > 99 ? 99 : e - b), s + b);
        char *rs = strrchr(errl, ':');
        if (rs && rs[1] == ' ' && strlen(rs + 2) > 6) memmove(errl, rs + 2, strlen(rs + 2) + 1);
      }
      net_drop(fp_op);
      fp_op = NULL;
      memmove(&OPS[0], &OPS[1], sizeof(Op) * (size_t)(nops - 1));
      nops--;
      char m[160];
      if (ok) snprintf(m, sizeof m, "%s %s", o.kind == 0 ? "Installed" : o.kind == 1 ? "Removed" : "Updated", o.name[0] ? o.name : "all apps");
      else snprintf(m, sizeof m, "%s failed%s%.80s", op_verb(o.kind), errl[0] ? ": " : "", errl);
      toast(m);
      fp_refresh();
      op_start_next();
      ch = 1;
    } else ch = 1;
  }
  return ch;
}

static Surface *SF;
static float OX, OY;
static int DRY;
static int HOT;
static struct {
  float x, y, w, h;
  int z;
} HR[1400];
static int nhr;
static float hy0, hy1;
static char CARDID[800][96];
static int ncard;

static void hit(int z, float x, float y, float w, float h) {
  if (DRY) return;
  float y0 = y < hy0 ? hy0 : y, y1 = y + h > hy1 ? hy1 : y + h;
  if (nhr >= 1400 || w <= 0 || y1 <= y0) return;
  HR[nhr].x = x, HR[nhr].y = y0, HR[nhr].w = w, HR[nhr].h = y1 - y0, HR[nhr].z = z;
  nhr++;
}

static void rc(float x, float y, float w, float h, uint32_t c) { if (DRY) return; gfx_rect(SF, OX + x, OY + y, w, h, c); }
static void rr(float x, float y, float w, float h, float r, uint32_t c) { if (DRY) return; gfx_rrect(SF, OX + x, OY + y, w, h, r, c); }
static void dsc(float x, float y, float r, uint32_t c) { if (DRY) return; gfx_disc(SF, OX + x, OY + y, r, c); }
static void tx(const Font *f, float x, float y, const char *t, uint32_t c) { if (DRY) return; gfx_text(SF, f, OX + x, OY + y, t, c); }
static void tf(const Font *f, float x, float y, float w, const char *t, uint32_t c) { if (DRY) return; gfx_text_fit(SF, f, OX + x, OY + y, w, t, c); }
static void tcn(const Font *f, float cx, float y, const char *t, uint32_t c) { if (DRY) return; gfx_text_c(SF, f, OX + cx, OY + y, t, c); }
static void ln(float x0, float y0, float x1, float y1, float th, uint32_t c) { if (DRY) return; gfx_line(SF, OX + x0, OY + y0, OX + x1, OY + y1, th, c); }
static void tri(float x0, float y0, float x1, float y1, float x2, float y2, uint32_t c) { if (DRY) return; gfx_tri(SF, OX + x0, OY + y0, OX + x1, OY + y1, OX + x2, OY + y2, c); }
static void ring(float x, float y, float r, float th, uint32_t c) { if (DRY) return; gfx_ring(SF, OX + x, OY + y, r, th, c); }

static Hit *hit_find(const char *id) {
  for (int i = 0; i < 4; i++)
    for (int k = 0; k < SEC[i].n; k++)
      if (!strcmp(SEC[i].h[k].id, id)) return &SEC[i].h[k];
  for (int k = 0; k < BR.n; k++)
    if (!strcmp(BR.h[k].id, id)) return &BR.h[k];
  return NULL;
}

static const char *name_of(const char *id) {
  Hit *h = hit_find(id);
  if (h) return h->name;
  for (int i = 0; i < ninst; i++)
    if (!strcmp(INST[i].id, id)) return INST[i].name;
  return D.id[0] && !strcmp(D.id, id) ? D.name : id;
}

static void check_mark(float cx, float cy, float r, uint32_t bg) {
  dsc(cx, cy, r, bg);
  ln(cx - r * 0.45f, cy + r * 0.05f, cx - r * 0.1f, cy + r * 0.4f, r * 0.28f, RGB(255, 255, 255));
  ln(cx - r * 0.1f, cy + r * 0.4f, cx + r * 0.5f, cy - r * 0.35f, r * 0.28f, RGB(255, 255, 255));
}

static void draw_icon(const char *url, float x, float y, float sz, const char *name) {
  Img *im = url[0] ? img_get(url, 128, 0) : NULL;
  if (im && im->state == IMG_READY) {
    gfx_blit_premul(SF, im->px, im->w, im->h, OX + x, OY + y, sz, sz);
    return;
  }
  unsigned hsh = 7;
  for (const char *c = name; *c; c++) hsh = hsh * 31 + (unsigned char)*c;
  uint32_t base = CAT_COL[hsh % 11];
  rr(x, y, sz, sz, sz * 0.24f, mixc(base, g_dark ? RGB(30, 32, 38) : RGB(255, 255, 255), 0.6f));
  if (im && im->state == IMG_FAILED) {
    char l[2] = {name[0] ? (char)toupper((unsigned char)name[0]) : '?', 0};
    tcn(F_H1, x + sz / 2, y + sz / 2 - line_h(F_H1) / 2, l, base);
  }
}

static void btn(float x, float y, float w, float h, const char *label, int style, int z, float prog, uint32_t acc) {
  int hv = HOT == z;
  uint32_t bg, fg;
  if (style == 0) bg = hv ? mixc(acc, RGB(0, 0, 0), 0.12f) : acc, fg = RGB(255, 255, 255);
  else if (style == 1) bg = hv ? mixc(acc, g_dark ? RGB(40, 44, 54) : RGB(255, 255, 255), 0.72f) : mixc(acc, g_dark ? RGB(30, 33, 40) : RGB(255, 255, 255), 0.86f), fg = acc;
  else if (style == 2) bg = hv ? THEME(RGB(252, 232, 230), RGB(80, 40, 40)) : THEME(RGB(244, 242, 240), RGB(46, 49, 56)), fg = T_BAD;
  else if (style == 4) bg = hv ? RGB(236, 242, 252) : RGB(255, 255, 255), fg = RGB(24, 32, 48);
  else bg = THEME(RGB(236, 238, 242), RGB(50, 54, 62)), fg = C_MUTED;
  if (DRY) return;
  const Font *bf = h > 32 ? F_UI_MED : F_SMALL;
  rr(x, y, w, h, h / 2, bg);
  float ty = OY + y + h / 2 - line_h(bf) / 2;
  if (prog > 0) {
    float fw = w * (prog > 1 ? 1 : prog);
    gfx_clip(SF, OX + x, OY + y, fw, h);
    rr(x, y, w, h, h / 2, acc);
    gfx_text_c(SF, bf, OX + x + w / 2, ty, label, RGB(255, 255, 255));
    gfx_clip(SF, OX + x + fw, OY + y, w - fw, h);
    gfx_text_c(SF, bf, OX + x + w / 2, ty, label, fg);
    gfx_clip(SF, OX + SIDE, OY + HEAD, MW, NH - BAR_H - HEAD);
  } else gfx_text_c(SF, bf, OX + x + w / 2, ty, label, fg);
  hit(z, x, y, w, h);
}

static void app_btn(float x, float y, float w, float h, const char *id, int z) {
  int st = app_state(id);
  char lb[40];
  int style = 0;
  float prog = 0;
  if (st == 0) snprintf(lb, sizeof lb, "Get");
  else if (st == 1) snprintf(lb, sizeof lb, "Open"), style = 1;
  else if (st == 2) snprintf(lb, sizeof lb, "Update");
  else if (st == 3) snprintf(lb, sizeof lb, "Queued"), style = 3;
  else {
    int pc = (int)(op_prog * 100);
    style = 1, prog = op_prog > 0.04f ? op_prog : 0.04f;
    if (h <= 32) snprintf(lb, sizeof lb, "%d%%", pc);
    else snprintf(lb, sizeof lb, "%s %d%%", op_verb(OPS[0].kind), pc);
  }
  btn(x, y, w, h, lb, style, z, prog, T_ACC);
}

static void glyph_cat(int i, float cx, float cy, uint32_t c, float k, uint32_t bg) {
#define GX(v) (cx + (v) * k)
#define GY(v) (cy + (v) * k)
  switch (i) {
  case 0:
    tri(GX(-4), GY(-6), GX(-4), GY(6), GX(6), GY(0), c);
    break;
  case 1:
    ln(GX(-3), GY(-5), GX(-8), GY(0), 1.8f * k, c), ln(GX(-8), GY(0), GX(-3), GY(5), 1.8f * k, c);
    ln(GX(3), GY(-5), GX(8), GY(0), 1.8f * k, c), ln(GX(8), GY(0), GX(3), GY(5), 1.8f * k, c);
    if (k > 1.2f) ln(GX(1.5f), GY(-6), GX(-1.5f), GY(6), 1.5f * k, c);
    break;
  case 2:
    tri(GX(-9), GY(-1), GX(0), GY(-7), GX(9), GY(-1), c), tri(GX(-9), GY(-1), GX(0), GY(4), GX(9), GY(-1), c);
    rc(GX(7), GY(0), 1.6f * k, 6 * k, c);
    if (k > 1.2f) rr(GX(-5), GY(2), 10 * k, 4 * k, 1.5f * k, c);
    break;
  case 3:
    rr(GX(-9), GY(-5), 18 * k, 11 * k, 5 * k, c);
    dsc(GX(-4), GY(0), 1.7f * k, bg), dsc(GX(4), GY(-1.5f), 1.4f * k, bg), dsc(GX(6), GY(1.5f), 1.4f * k, bg);
    if (k > 1.2f) rc(GX(-6.4f), GY(-0.7f), 5.6f * k, 1.4f * k, bg), rc(GX(-4.7f), GY(-2.4f), 1.4f * k, 5.6f * k, bg);
    break;
  case 4:
    dsc(GX(0), GY(0), 8 * k, c);
    dsc(GX(-3), GY(-2), 1.8f * k, bg), dsc(GX(2), GY(-3), 1.8f * k, bg), dsc(GX(3), GY(2), 1.8f * k, bg);
    if (k > 1.2f) dsc(GX(-2), GY(3), 1.7f * k, bg);
    break;
  case 5: {
    ring(GX(0), GY(0), 8.4f * k, 1.6f * k, c);
    ln(GX(-8.4f), GY(0), GX(8.4f), GY(0), 1.3f * k, c);
    for (int sgn = -1; sgn <= 1; sgn += 2) {
      float yy = 4.3f * sgn, hw = sqrtf(8.4f * 8.4f - yy * yy) * 0.92f;
      ln(GX(-hw), GY(yy), GX(hw), GY(yy), 1.2f * k, c);
    }
    for (int a = 0; a < 16; a++) {
      float t0 = 6.2831853f * a / 16, t1 = 6.2831853f * (a + 1) / 16;
      ln(GX(3.8f * cosf(t0)), GY(8.4f * sinf(t0)), GX(3.8f * cosf(t1)), GY(8.4f * sinf(t1)), 1.3f * k, c);
    }
    break;
  }
  case 6:
    rr(GX(-6), GY(-8), 12 * k, 16 * k, 2.5f * k, c);
    rc(GX(-3), GY(-4), 6 * k, 1.4f * k, bg), rc(GX(-3), GY(0), 6 * k, 1.4f * k, bg), rc(GX(-3), GY(4), 4 * k, 1.4f * k, bg);
    break;
  case 7:
    ring(GX(0), GY(0), 8 * k, 1.5f * k, c), dsc(GX(0), GY(0), 2.2f * k, c), dsc(GX(7), GY(-3), 1.7f * k, c);
    if (k > 1.2f) ring(GX(0), GY(0), 4.5f * k, 1.2f * k, c), dsc(GX(-6), GY(3.5f), 1.5f * k, c);
    break;
  case 8:
    for (int a = 0; a < 8; a++) {
      float t = 6.2831853f * a / 8 + 0.3927f;
      ln(GX(5.6f * cosf(t)), GY(5.6f * sinf(t)), GX(9.2f * cosf(t)), GY(9.2f * sinf(t)), 3.2f * k, c);
    }
    dsc(GX(0), GY(0), 7 * k, c);
    dsc(GX(0), GY(0), 3 * k, bg);
    break;
  case 9:
    rc(GX(-8), GY(-4), 16 * k, 1.6f * k, c), rc(GX(-8), GY(4), 16 * k, 1.6f * k, c), dsc(GX(-3), GY(-3.2f), 2.6f * k, c), dsc(GX(3), GY(4.8f), 2.6f * k, c);
    break;
  default:
    dsc(GX(-3.2f), GY(-2.5f), 3.6f * k, c), dsc(GX(3.2f), GY(-2.5f), 3.6f * k, c), tri(GX(-6.6f), GY(-0.5f), GX(6.6f), GY(-0.5f), GX(0), GY(7), c);
    break;
  }
#undef GX
#undef GY
}

static void side_item(float y, int z, const char *label, int sel, int glyph, uint32_t col, int badge, int badge_warn) {
  int hv = HOT == z;
  if (sel) rr(12, y, SIDE - 24, 34, 12, T_TINT);
  else if (hv) rr(12, y, SIDE - 24, 34, 12, N_TINT_HOT);
  uint32_t c = sel ? T_ACC : col;
  float cx = 34, cy = y + 17;
  if (glyph < 11) glyph_cat(glyph, cx, cy, c, 1.f, N_PAGE);
  else if (glyph == 11) tri(cx - 9, cy, cx, cy - 8, cx + 9, cy, c), rc(cx - 6, cy, 12, 8, c);
  else if (glyph == 12) rc(cx - 1, cy - 8, 2, 9, c), tri(cx - 6, cy - 1, cx + 6, cy - 1, cx, cy + 6, c), rc(cx - 8, cy + 7, 16, 2, c);
  else ring(cx, cy, 7, 1.8f, c), tri(cx + 2, cy - 11, cx + 2, cy - 3, cx + 8, cy - 7, c);
  tx(F_UI_MED, 54, y + 17 - line_h(F_UI_MED) / 2, label, sel ? T_ACC : C_TEXT);
  if (badge > 0) {
    char b[12];
    snprintf(b, sizeof b, "%d", badge);
    float bw = gfx_text_w(F_SMALL, b) + 14;
    rr(SIDE - 22 - bw, y + 8, bw, 18, 9, badge_warn ? T_WARN : THEME(RGB(226, 228, 233), RGB(58, 62, 72)));
    tcn(F_SMALL, SIDE - 22 - bw / 2, y + 17 - line_h(F_SMALL) / 2, b, badge_warn ? RGB(255, 255, 255) : C_MUTED);
  }
  hit(z, 12, y, SIDE - 24, 34);
}

static void draw_sidebar(void) {
  float ch = NH - BAR_H;
  rc(0, HEAD, SIDE, ch - HEAD, N_HEAD);
  rc(SIDE - 1, HEAD, 1, ch - HEAD, N_LINE);
  float y = HEAD + 14;
  side_item(y, Z_SIDE, "Discover", S.side == 0 || S.side >= 10, 11, C_MUTED, 0, 0);
  y += 38;
  side_item(y, Z_SIDE + 1, "Installed", S.side == 1, 12, C_MUTED, ninst, 0);
  y += 38;
  side_item(y, Z_SIDE + 2, "Updates", S.side == 2, 13, C_MUTED, nupd, 1);
}

static void draw_header(void) {
  rc(0, 0, NW, HEAD, N_HEAD);
  rc(0, HEAD - 1, NW, 1, N_LINE);
  gfx_icon(SF, IC_STORE, OX + 18, OY + 14, 36);
  tx(F_H1, 64, HEAD / 2 - line_h(F_H1) / 2, "Store", C_TEXT);
  float sx = SIDE + PADX, sw = 480, sy = 12;
  int foc = S.focus;
  rr(sx - 1.5f, sy - 1.5f, sw + 3, 43, 21.5f, foc ? T_ACC : THEME(RGB(226, 224, 230), RGB(58, 62, 72)));
  rr(sx, sy, sw, 40, 20, foc ? N_PAGE : THEME(RGB(242, 241, 238), RGB(40, 43, 50)));
  ring(sx + 22, sy + 19, 6.5f, 1.8f, foc ? T_ACC : C_MUTED);
  ln(sx + 27, sy + 24, sx + 32, sy + 29, 2.2f, foc ? T_ACC : C_MUTED);
  if (S.q[0]) {
    tf(F_UI, sx + 44, sy + 20 - line_h(F_UI) / 2, sw - 100, S.q, C_TEXT);
    if (foc && S.blink) rc(sx + 44 + gfx_text_w(F_UI, S.q) + 1, sy + 10, 1.6f, 20, T_ACC);
    dsc(sx + sw - 24, sy + 20, 11, HOT == Z_CLEAR ? THEME(RGB(228, 230, 235), RGB(64, 68, 78)) : THEME(RGB(236, 238, 242), RGB(52, 56, 66)));
    ln(sx + sw - 28, sy + 16, sx + sw - 20, sy + 24, 1.6f, C_MUTED);
    ln(sx + sw - 20, sy + 16, sx + sw - 28, sy + 24, 1.6f, C_MUTED);
    hit(Z_CLEAR, sx + sw - 38, sy + 6, 28, 28);
  } else {
    tx(F_UI, sx + 44, sy + 20 - line_h(F_UI) / 2, "Search thousands of apps", C_MUTED);
    if (foc && S.blink) rc(sx + 44, sy + 10, 1.6f, 20, T_ACC);
  }
  hit(Z_SEARCH, sx, sy, sw, 40);
  if (fp_state == 2) {
    const char *st = "Flatpak missing";
    float cw = gfx_text_w(F_SMALL, st) + 34;
    rr(NW - 20 - cw, 20, cw, 26, 13, THEME(RGB(242, 241, 238), RGB(40, 43, 50)));
    dsc(NW - 20 - cw + 14, 33, 4, T_WARN);
    tx(F_SMALL, NW - 20 - cw + 25, 33 - line_h(F_SMALL) / 2, st, C_MUTED);
  }
}

static void stat_line(const Hit *h, float x, float y, float maxw) {
  char c[32], l[80];
  fmt_count(h->installs, c, sizeof c);
  snprintf(l, sizeof l, "%s installs", c);
  tf(F_SMALL, x, y, maxw, l, C_MUTED);
}

static void card(float x, float y, const Hit *h) {
  if (ncard >= 800) return;
  int k = ncard++;
  cpy(CARDID[k], sizeof CARDID[k], h->id);
  int hv = HOT == Z_CARD + k || HOT == Z_GET + k;
  gfx_shadow(SF, OX + x, OY + y + (hv ? 5 : 2), CARD_W, CARD_H, 14, hv ? 16 : 8, RGBA(24, 30, 60, hv ? 46 : 22));
  rr(x - 1, y - 1, CARD_W + 2, CARD_H + 2, 15, hv ? T_ACC : THEME(RGB(230, 228, 234), RGB(54, 58, 68)));
  rr(x, y, CARD_W, CARD_H, 14, N_PAGE);
  draw_icon(h->icon, x + 14, y + 18, 60, h->name);
  float tw = CARD_W - 86 - 14 - (h->verified ? 18 : 0);
  float nw = gfx_text_w(F_UI_MED, h->name);
  tf(F_UI_MED, x + 86, y + 16, tw, h->name, C_TEXT);
  if (h->verified) check_mark(x + 86 + (nw < tw ? nw : tw) + 11, y + 16 + line_h(F_UI_MED) / 2, 6.5f, T_ACC);
  tf(F_SMALL, x + 86, y + 40, CARD_W - 100, h->summary, C_MUTED);
  stat_line(h, x + 86, y + 70, CARD_W - 86 - 84);
  hit(Z_CARD + k, x, y, CARD_W, CARD_H);
  app_btn(x + CARD_W - 74, y + CARD_H - 38, 60, 26, h->id, Z_GET + k);
}

static void skeleton(float x, float y) {
  uint32_t c = THEME(RGB(232, 234, 238), RGB(44, 48, 56));
  rr(x, y, CARD_W, CARD_H, 14, N_PAGE);
  rr(x + 14, y + 18, 60, 60, 14, c);
  rr(x + 86, y + 20, 110, 12, 6, c);
  rr(x + 86, y + 44, 150, 9, 4.5f, c);
  rr(x + 86, y + 66, 70, 9, 4.5f, c);
}

static float grid(Lst *l, float x0, float y, int max) {
  int n = l->n < max ? l->n : max;
  if (!l->loaded) {
    int cnt = max > 12 ? 9 : max;
    for (int i = 0; i < cnt; i++) skeleton(x0 + (i % COLS) * (CARD_W + GAP), y + (i / COLS) * (CARD_H + GAP));
    return y + ((cnt + COLS - 1) / COLS) * (CARD_H + GAP);
  }
  for (int i = 0; i < n; i++) {
    float cy = y + (i / COLS) * (CARD_H + GAP);
    if (cy + CARD_H >= hy0 - 10 && cy <= hy1 + 10) card(x0 + (i % COLS) * (CARD_W + GAP), cy, &l->h[i]);
    else if (ncard < 800) cpy(CARDID[ncard++], 96, l->h[i].id);
  }
  return y + ((n + COLS - 1) / COLS) * (CARD_H + GAP);
}

static void err_box(float x, float y, float w, const char *msg) {
  rr(x, y, w, 120, 18, N_PAGE);
  tcn(F_UI_MED, x + w / 2, y + 28, msg, C_TEXT);
  tcn(F_SMALL, x + w / 2, y + 54, "Check your connection and try again", C_MUTED);
  btn(x + w / 2 - 48, y + 76, 96, 32, "Retry", 0, Z_RETRY, 0, T_ACC);
}

static void view_home(void) {
  float x0 = SIDE + PADX;
  float y = HEAD + 20 - S.scroll[V_HOME];
  if (SEC[1].err && !SEC[1].loaded) {
    err_box(x0, y, MW - 2 * PADX, "Could not reach Flathub");
    S.content_h = 200;
    return;
  }
  float hw = MW - 2 * PADX;
  tx(F_H1, x0, y, "Browse by category", C_TEXT);
  y += line_h(F_H1) + 14;
  float tw = (hw - 5 * 12) / 6.f, th = 92;
  for (int i = 0; i < 11; i++) {
    float cx = x0 + (i % 6) * (tw + 12), cy = y + (i / 6) * (th + 12);
    int hv = HOT == Z_CATTILE + i;
    uint32_t col = CAT_COL[i];
    gfx_shadow(SF, OX + cx, OY + cy + (hv ? 5 : 2), tw, th, 16, hv ? 14 : 6, RGBA(24, 30, 60, hv ? 40 : 18));
    rr(cx, cy, tw, th, 16, hv ? mixc(col, g_dark ? RGB(36, 40, 50) : RGB(255, 255, 255), 0.86f) : N_PAGE);
    if (hv) rr(cx + 1.5f, cy + 1.5f, tw - 3, th - 3, 15, mixc(col, g_dark ? RGB(36, 40, 50) : RGB(255, 255, 255), 0.88f));
    rr(cx + 14, cy + 14, 44, 44, 14, col);
    glyph_cat(i, cx + 36, cy + 36, RGB(255, 255, 255), 1.45f, col);
    tf(F_UI_MED, cx + 14, cy + th - 12 - line_h(F_UI_MED), tw - 24, CAT_NAME[i], C_TEXT);
    hit(Z_CATTILE + i, cx, cy, tw, th);
  }
  y += 2 * (th + 12) + 14;
  for (int s = 1; s < 4; s++) {
    tx(F_H1, x0, y, SEC_TITLE[s], C_TEXT);
    float sw = gfx_text_w(F_UI_MED, "See all") + 22;
    int hv = HOT == Z_SEE + s;
    tx(F_UI_MED, x0 + hw - sw + 4, y + 4, "See all", hv ? mixc(T_ACC, RGB(0, 0, 0), 0.2f) : T_ACC);
    hit(Z_SEE + s, x0 + hw - sw, y, sw, 30);
    y += line_h(F_H1) + 14;
    if (SEC[s].err && !SEC[s].loaded) {
      tx(F_UI, x0, y + 20, "Could not load this list", C_MUTED);
      y += 70;
    } else y = grid(&SEC[s], x0, y, 6);
    y += 16;
  }
  S.content_h = y + S.scroll[V_HOME] - HEAD + 20;
}

static void view_list(void) {
  float x0 = SIDE + PADX, hw = MW - 2 * PADX;
  float y = HEAD + 22 - S.scroll[V_LIST];
  if (S.back_n > 0) {
    int hv = HOT == Z_BACK;
    rr(x0, y, 76, 30, 15, hv ? N_TINT_HOT : THEME(RGB(236, 234, 230), RGB(44, 48, 56)));
    ln(x0 + 22, y + 15, x0 + 29, y + 9, 1.8f, C_TEXT), ln(x0 + 22, y + 15, x0 + 29, y + 21, 1.8f, C_TEXT);
    tx(F_UI_MED, x0 + 36, y + 15 - line_h(F_UI_MED) / 2, "Back", C_TEXT);
    hit(Z_BACK, x0, y, 76, 30);
    y += 44;
  }
  tf(F_H1, x0, y, hw, BR.title, C_TEXT);
  y += line_h(F_H1) + 4;
  char sub[100];
  if (BR.loaded) snprintf(sub, sizeof sub, "%d app%s", BR.total, BR.total == 1 ? "" : "s");
  else snprintf(sub, sizeof sub, BR.err ? "Could not load results" : "Loading");
  tx(F_UI, x0, y, sub, C_MUTED);
  y += line_h(F_UI) + 18;
  if (BR.err && !BR.loaded) {
    err_box(x0, y, hw, "Could not load apps");
    S.content_h = 300;
    return;
  }
  if (BR.loaded && BR.n == 0) {
    rr(x0, y, hw, 120, 18, N_PAGE);
    tcn(F_UI_MED, x0 + hw / 2, y + 40, "No apps found", C_TEXT);
    tcn(F_SMALL, x0 + hw / 2, y + 66, "Try a different search or category", C_MUTED);
    y += 140;
  } else y = grid(&BR, x0, y, 9999);
  if (BR.loaded && BR.page < BR.pages) {
    tcn(F_SMALL, x0 + hw / 2, y + 4, "Loading more", C_MUTED);
    y += 30;
  }
  S.content_h = y + S.scroll[V_LIST] - HEAD + 20;
}

static void section(float x, float *y, const char *t) {
  tx(F_H1, x, *y, t, C_TEXT);
  *y += line_h(F_H1) + 12;
}

static int wrap_text(const Font *f, float x, float y, float w, const char *t, uint32_t c, float lhh, int maxl, int draw) {
  int lines = 0;
  char buf[300];
  buf[0] = 0;
  int bl = 0;
  const char *p = t;
  while (*p) {
    while (*p == ' ') p++;
    const char *e = p;
    while (*e && *e != ' ') e++;
    int wl = (int)(e - p);
    if (wl > 120) wl = 120;
    char trial[460];
    snprintf(trial, sizeof trial, "%s%s%.*s", buf, bl ? " " : "", wl, p);
    if (bl && gfx_text_w(f, trial) > w) {
      if (draw && lines < maxl) tx(f, x, y + lines * lhh, buf, c);
      lines++;
      bl = 0;
      buf[0] = 0;
      continue;
    }
    bl = (int)strlen(trial);
    memcpy(buf, trial, (size_t)bl + 1);
    p = e;
  }
  if (bl) {
    if (draw && lines < maxl) tx(f, x, y + lines * lhh, buf, c);
    lines++;
  }
  return lines;
}

static float draw_blocks(Blk *b, int n, float x, float y, float w, int maxlines, int *clipped) {
  int used = 0;
  float lhh = line_h(F_UI) + 5;
  *clipped = 0;
  for (int i = 0; i < n; i++) {
    float ind = b[i].kind == 'p' || b[i].kind == 'h' ? 0 : 22;
    const Font *f = b[i].kind == 'h' ? F_UI_MED : F_UI;
    int need = wrap_text(f, 0, 0, w - ind, b[i].t, C_TEXT, lhh, 999, 0);
    if (maxlines > 0 && used + need > maxlines) {
      *clipped = 1;
      int room = maxlines - used;
      if (room > 0) {
        wrap_text(f, x + ind, y, w - ind, b[i].t, C_TEXT, lhh, room, 1);
        y += room * lhh;
      }
      return y;
    }
    if (b[i].kind == 'l') dsc(x + 8, y + lhh / 2 - 1, 2.4f, T_ACC);
    else if (b[i].kind == 'o') {
      char num[12];
      snprintf(num, sizeof num, "%d.", b[i].num);
      tx(F_UI, x + 18 - gfx_text_w(F_UI, num), y, num, C_MUTED);
    }
    wrap_text(f, x + ind, y, w - ind, b[i].t, b[i].kind == 'h' ? C_TEXT : C_TEXT, lhh, 999, 1);
    y += need * lhh + (b[i].kind == 'l' || b[i].kind == 'o' ? 2 : 9);
    used += need;
  }
  return y;
}

static void chip(float *x, float y, const char *t, uint32_t bg, uint32_t fg) {
  float w = gfx_text_w(F_SMALL, t) + 22;
  rr(*x, y, w, 24, 12, bg);
  tx(F_SMALL, *x + 11, y + 12 - line_h(F_SMALL) / 2, t, fg);
  *x += w + 8;
}

static const char *cat_pretty(const char *c) {
  static const char *const from[] = {"AudioVideo", "Audio", "Video", "Development", "Education", "Game", "Graphics", "Network", "Office", "Science", "System", "Utility", "HealthFitness"};
  static const char *const to[] = {"Audio & Video", "Audio", "Video", "Development", "Education", "Games", "Graphics", "Internet", "Office", "Science", "System", "Utility", "Health & Fitness"};
  for (int i = 0; i < 13; i++)
    if (!strcmp(c, from[i])) return to[i];
  return c;
}

static void kv(float x, float *y, float w, const char *k, const char *v) {
  tx(F_UI, x, *y, k, C_MUTED);
  tf(F_UI, x + 170, *y, w - 170, v, C_TEXT);
  *y += line_h(F_UI) + 11;
}

static float details_block(float x0, float y, float w, int dry) {
  DRY = dry;
  float yy = y + 18;
  char b1[160];
  kv(x0 + 22, &yy, w - 44, "Developer", D.dev[0] ? D.dev : "-");
  if (D.verified) {
    snprintf(b1, sizeof b1, "Verified%s%s", D.vweb[0] ? " via " : "", D.vweb);
    kv(x0 + 22, &yy, w - 44, "Verification", b1);
  }
  kv(x0 + 22, &yy, w - 44, "License", D.license[0] ? D.license : "Unknown");
  kv(x0 + 22, &yy, w - 44, "Free software", D.free_lic ? "Yes" : "No (proprietary or unknown license)");
  kv(x0 + 22, &yy, w - 44, "App ID", D.id);
  if (D.ref[0]) kv(x0 + 22, &yy, w - 44, "Flatpak ref", D.ref);
  if (D.branch[0]) kv(x0 + 22, &yy, w - 44, "Branch", D.branch);
  if (D.arches[0]) kv(x0 + 22, &yy, w - 44, "Architectures", D.arches);
  if (D.runtime[0]) kv(x0 + 22, &yy, w - 44, "Runtime", D.runtime);
  if (D.sdk[0]) kv(x0 + 22, &yy, w - 44, "SDK", D.sdk);
  if (D.cmd[0]) kv(x0 + 22, &yy, w - 44, "Command", D.cmd);
  if (D.ncat) {
    b1[0] = 0;
    for (int i = 0; i < D.ncat; i++) snprintf(b1 + strlen(b1), sizeof b1 - strlen(b1), "%s%s", i ? ", " : "", cat_pretty(D.cats[i]));
    kv(x0 + 22, &yy, w - 44, "Categories", b1);
  }
  if (D.nkey) {
    b1[0] = 0;
    for (int i = 0; i < D.nkey; i++) snprintf(b1 + strlen(b1), sizeof b1 - strlen(b1), "%s%s", i ? ", " : "", D.keys[i]);
    kv(x0 + 22, &yy, w - 44, "Keywords", b1);
  }
  if (D.nmime) {
    b1[0] = 0;
    for (int i = 0; i < D.nmime; i++) snprintf(b1 + strlen(b1), sizeof b1 - strlen(b1), "%s%s", i ? ", " : "", D.mime[i]);
    kv(x0 + 22, &yy, w - 44, "Opens", b1);
  }
  kv(x0 + 22, &yy, w - 44, "Age rating", D.rating_title[0] ? D.rating_title : "-");
  for (int i = 0; i < D.nrating && i < 6; i++) {
    tx(F_SMALL, x0 + 192, yy - 2, D.rating[i], C_MUTED);
    yy += line_h(F_SMALL) + 5;
  }
  DRY = 0;
  return yy - y + 8;
}

static void view_app(void) {
  float x0 = SIDE + PADX, w = MW - 2 * PADX;
  float y = HEAD + 18 - S.scroll[V_APP];
  int hv = HOT == Z_BACK;
  rr(x0, y, 76, 30, 15, hv ? N_TINT_HOT : THEME(RGB(236, 234, 230), RGB(44, 48, 56)));
  ln(x0 + 22, y + 15, x0 + 29, y + 9, 1.8f, C_TEXT), ln(x0 + 22, y + 15, x0 + 29, y + 21, 1.8f, C_TEXT);
  tx(F_UI_MED, x0 + 36, y + 15 - line_h(F_UI_MED) / 2, "Back", C_TEXT);
  hit(Z_BACK, x0, y, 76, 30);
  y += 44;
  const char *icon = D.have_hit ? D.hit.icon : "";
  char iconbuf[300];
  if (!icon[0]) snprintf(iconbuf, sizeof iconbuf, "https://dl.flathub.org/repo/appstream/x86_64/icons/128x128/%s.png", D.id), icon = iconbuf;
  Img *im = img_get(icon, 128, 0);
  uint32_t acc = im && im->state == IMG_READY ? im->accent : RGB(70, 110, 190);
  uint32_t brand = hex_color(D.brand[g_dark ? 1 : 0][0] ? D.brand[g_dark ? 1 : 0] : D.brand[g_dark ? 0 : 1]);
  uint32_t base = brand ? brand : mixc(acc, g_dark ? RGB(18, 20, 26) : RGB(255, 255, 255), g_dark ? 0.6f : 0.72f);
  int light = lum(base) > 140;
  uint32_t fg = light ? RGB(22, 26, 34) : RGB(255, 255, 255), fg2 = light ? RGB(64, 70, 82) : RGB(220, 226, 238);
  float bh = 176;
  rr(x0, y, w, bh, 24, base);
  gfx_clip(SF, OX + x0, OY + y, w, bh);
  dsc(x0 + w - 40, y + 20, 130, RGBA(255, 255, 255, light ? 40 : 16));
  dsc(x0 + w - 200, y + bh + 40, 100, RGBA(255, 255, 255, light ? 30 : 12));
  gfx_clip(SF, OX + SIDE, OY + HEAD, MW, NH - BAR_H - HEAD);
  rr(x0 + 26, y + 26, 124, 124, 30, RGBA(255, 255, 255, light ? 170 : 44));
  draw_icon(icon, x0 + 36, y + 36, 104, D.name);
  float tx0 = x0 + 172;
  tf(F_H1, tx0, y + 24, w - 172 - 220, D.name, fg);
  float dy = y + 24 + line_h(F_H1) + 4;
  if (D.dev[0]) {
    tf(F_UI_MED, tx0, dy, w - 172 - 260, D.dev, fg2);
    if (D.verified) check_mark(tx0 + gfx_text_w(F_UI_MED, D.dev) + 14, dy + line_h(F_UI_MED) / 2, 7.5f, T_ACC);
  }
  dy += line_h(F_UI_MED) + 6;
  wrap_text(F_UI, tx0, dy, w - 172 - 230, D.summary, fg2, line_h(F_UI) + 3, 2, 1);
  float cx = tx0, cy = y + bh - 44;
  for (int i = 0; i < D.ncat && i < 3; i++) chip(&cx, cy, cat_pretty(D.cats[i]), RGBA(255, 255, 255, light ? 130 : 36), fg);
  int st = app_state(D.id);
  app_btn(x0 + w - 190, y + 40, 160, 44, D.id, Z_ACT);
  if (st == 1 || st == 2) btn(x0 + w - 190, y + 94, 160, 36, "Uninstall", 2, Z_RM, 0, T_BAD);
  if (D.dl > 0 && st == 0) {
    char b[40];
    fmt_bytes(D.dl, b, sizeof b);
    char l[80];
    snprintf(l, sizeof l, "%s download", b);
    tcn(F_SMALL, x0 + w - 110, y + 98, l, fg2);
  }
  y += bh + 18;
  if (D.eol) {
    rr(x0, y, w, 40, 14, THEME(RGB(253, 236, 214), RGB(80, 56, 28)));
    tx(F_UI, x0 + 18, y + 20 - line_h(F_UI) / 2, "This app is end-of-life and no longer receives updates.", T_WARN);
    y += 54;
  }
  if (fp_state == 2) {
    rr(x0, y, w, 40, 14, THEME(RGB(253, 236, 214), RGB(80, 56, 28)));
    tx(F_UI, x0 + 18, y + 20 - line_h(F_UI) / 2, "Flatpak is not installed, so apps cannot be installed from here.", T_WARN);
    y += 54;
  }
  if (D.err && !D.a_ok) {
    err_box(x0, y, w, "Could not load app details");
    S.content_h = 420;
    return;
  }
  float tw = (w - 5 * 10) / 6.f;
  char v[6][40];
  const char *lb[6] = {"Total installs", "Last month", "Download", "Installed size", "Latest version", "Updated"};
  fmt_count(D.installs_total, v[0], 40);
  fmt_count(D.installs_month ? D.installs_month : D.hit.installs, v[1], 40);
  fmt_bytes(D.dl, v[2], 40);
  fmt_bytes(D.inst, v[3], 40);
  snprintf(v[4], 40, "%s", D.nrel ? D.rel[0].ver : "-");
  fmt_day(D.ts ? D.ts : D.have_hit ? D.hit.updated : 0, v[5], 40);
  if (!D.t_ok) snprintf(v[0], 40, "-"), snprintf(v[1], 40, "-");
  if (!D.s_ok) snprintf(v[2], 40, "-"), snprintf(v[3], 40, "-");
  for (int i = 0; i < 6; i++) {
    float tx1 = x0 + i * (tw + 10);
    rr(tx1, y, tw, 72, 16, N_PAGE);
    tcn(i >= 4 ? F_UI : F_UI_MED, tx1 + tw / 2, y + 18, v[i], C_TEXT);
    tcn(F_SMALL, tx1 + tw / 2, y + 44, lb[i], C_MUTED);
  }
  y += 72 + 22;
  if (D.nspark > 3) {
    rr(x0, y, w, 120, 18, N_PAGE);
    tx(F_UI_MED, x0 + 20, y + 14, "Installs per day", C_TEXT);
    char c[32];
    fmt_count(D.spark_max, c, sizeof c);
    char mx[48];
    snprintf(mx, sizeof mx, "peak %s", c);
    tx(F_SMALL, x0 + w - 20 - gfx_text_w(F_SMALL, mx), y + 17, mx, C_MUTED);
    float bw = (w - 40) / D.nspark;
    for (int i = 0; i < D.nspark; i++) {
      float bhh = 8 + (80 - 8) * D.spark[i] / (float)D.spark_max;
      rr(x0 + 20 + i * bw + 1, y + 106 - bhh, bw - 2, bhh, 2, i == D.nspark - 1 ? T_ACC : mixc(T_ACC, N_PAGE, 0.55f));
    }
    y += 142;
  }
  if (D.nshot) {
    section(x0, &y, "Screenshots");
    float ah = 320;
    rr(x0, y, w, ah, 20, THEME(RGB(236, 238, 243), RGB(30, 34, 42)));
    Img *si = img_get(D.shots[D.shot_cur], 752, 10);
    if (D.nshot > 1) {
      img_get(D.shots[(D.shot_cur + 1) % D.nshot], 752, 10);
      img_get(D.shots[(D.shot_cur + D.nshot - 1) % D.nshot], 752, 10);
    }
    if (si && si->state == IMG_READY) {
      float sc = fminf((w - 140) / si->w, (ah - 36) / si->h);
      float iw = si->w * sc, ih = si->h * sc, ix = x0 + (w - iw) / 2, iy = y + (ah - ih) / 2 - 6;
      gfx_shadow(SF, OX + ix, OY + iy + 6, iw, ih, 10, 16, RGBA(10, 14, 30, 60));
      gfx_blit_premul(SF, si->px, si->w, si->h, OX + ix, OY + iy, iw, ih);
      hit(Z_SHOT, ix, iy, iw, ih);
    } else tcn(F_UI, x0 + w / 2, y + ah / 2 - 10, si && si->state == IMG_FAILED ? "Screenshot unavailable" : "Loading screenshot", C_MUTED);
    if (D.nshot > 1) {
      for (int d = 0; d < 2; d++) {
        float cx2 = d ? x0 + w - 34 : x0 + 34, cy2 = y + ah / 2 - 6;
        dsc(cx2, cy2, 19, HOT == Z_SHOT_L + d ? N_PAGE : RGBA(255, 255, 255, 190));
        ln(cx2 + (d ? -3 : 3), cy2 - 7, cx2 + (d ? 4 : -4), cy2, 2.2f, RGB(40, 46, 58));
        ln(cx2 + (d ? 4 : -4), cy2, cx2 + (d ? -3 : 3), cy2 + 7, 2.2f, RGB(40, 46, 58));
        hit(Z_SHOT_L + d, cx2 - 22, cy2 - 22, 44, 44);
      }
      for (int i = 0; i < D.nshot; i++) {
        float dx = x0 + w / 2 - D.nshot * 8 + i * 16 + 4;
        rr(dx, y + ah - 22, i == D.shot_cur ? 14 : 8, 8, 4, i == D.shot_cur ? T_ACC : C_MUTED);
        hit(Z_DOT + i, dx - 4, y + ah - 30, 16, 22);
      }
    }
    if (D.shot_cap[D.shot_cur][0]) tcn(F_SMALL, x0 + w / 2, y + ah + 8, D.shot_cap[D.shot_cur], C_MUTED), y += 26;
    y += ah + 26;
  }
  if (D.nblk) {
    section(x0, &y, "About this app");
    int clipped = 0;
    y = draw_blocks(D.blk, D.nblk, x0, y, w, D.desc_all ? 0 : 14, &clipped);
    if (clipped || D.desc_all) {
      float bw = 110;
      btn(x0, y + 4, bw, 30, D.desc_all ? "Show less" : "Read more", 1, Z_DESC_MORE, 0, T_ACC);
      y += 40;
    }
    y += 16;
  }
  if (D.nrel) {
    section(x0, &y, "What's new");
    int show = D.rel_all ? D.nrel : (D.nrel < 2 ? D.nrel : 2);
    for (int i = 0; i < show; i++) {
      Rel *r = &D.rel[i];
      float cy = y;
      float hdr = line_h(F_UI_MED) + 10;
      int clipped = 0;
      DRY = 1;
      float ey = draw_blocks(r->b, r->nb, x0 + 20, cy + hdr + 14, w - 40, D.rel_all ? 8 : 6, &clipped);
      DRY = 0;
      float ch = ey - cy + 12;
      rr(x0, cy, w, ch, 16, N_PAGE);
      char vl[80];
      snprintf(vl, sizeof vl, "Version %s", r->ver[0] ? r->ver : "?");
      tx(F_UI_MED, x0 + 20, cy + 14, vl, C_TEXT);
      if (r->date[0]) {
        float dw = gfx_text_w(F_SMALL, r->date) + 20;
        rr(x0 + w - 20 - dw, cy + 12, dw, 22, 11, T_TINT);
        tcn(F_SMALL, x0 + w - 20 - dw / 2, cy + 23 - line_h(F_SMALL) / 2, r->date, T_ACC);
      }
      if (!r->nb) tx(F_UI, x0 + 20, cy + hdr + 14, "No release notes provided.", C_MUTED), ch += 24;
      draw_blocks(r->b, r->nb, x0 + 20, cy + hdr + 14, w - 40, D.rel_all ? 8 : 6, &clipped);
      y += ch + 10;
    }
    if (D.nrel > 2) {
      btn(x0, y + 2, 150, 30, D.rel_all ? "Show fewer releases" : "Show older releases", 1, Z_REL_MORE, 0, T_ACC);
      y += 40;
    }
    y += 12;
  }
  if (D.nperm) {
    section(x0, &y, "Permissions");
    int cnt = D.perm_all ? D.nperm : (D.nperm < 6 ? D.nperm : 6);
    float ph = cnt * 34 + 16;
    rr(x0, y, w, ph, 16, N_PAGE);
    for (int i = 0; i < cnt; i++) {
      float py = y + 14 + i * 34;
      int rk = D.perm[i].risk;
      dsc(x0 + 26, py + 10, 5.5f, rk == 2 ? T_BAD : rk == 1 ? T_WARN : T_OK);
      tf(F_UI, x0 + 44, py + 10 - line_h(F_UI) / 2, w - 200, D.perm[i].text, C_TEXT);
      const char *rl = rk == 2 ? "Broad access" : rk == 1 ? "Moderate" : "Standard";
      tx(F_SMALL, x0 + w - 20 - gfx_text_w(F_SMALL, rl), py + 10 - line_h(F_SMALL) / 2, rl, rk == 2 ? T_BAD : rk == 1 ? T_WARN : C_MUTED);
    }
    y += ph + 8;
    if (D.nperm > 6) {
      btn(x0, y, 150, 30, D.perm_all ? "Show fewer" : "Show all permissions", 1, Z_PERM_MORE, 0, T_ACC);
      y += 40;
    }
    y += 12;
  }
  section(x0, &y, "Details");
  float dh = details_block(x0, y, w, 1);
  rr(x0, y, w, dh, 16, N_PAGE);
  details_block(x0, y, w, 0);
  y += dh + 16;
  int any = 0;
  for (int i = 0; i < 9; i++)
    if (D.urls[i][0]) any = 1;
  if (any) {
    section(x0, &y, "Links");
    float lx = x0, ly = y;
    for (int i = 0; i < 9; i++) {
      if (!D.urls[i][0]) continue;
      float bw = gfx_text_w(F_UI_MED, url_label[i]) + 40;
      if (lx + bw > x0 + w) lx = x0, ly += 46;
      btn(lx, ly, bw, 36, url_label[i], 1, Z_LINK + i, 0, T_ACC);
      lx += bw + 10;
    }
    y = ly + 56;
  }
  S.content_h = y + S.scroll[V_APP] - HEAD + 24;
}

static void view_installed(int upd) {
  float x0 = SIDE + PADX, w = MW - 2 * PADX;
  float y = HEAD + 22 - S.scroll[upd ? V_UPD : V_INST];
  tx(F_H1, x0, y, upd ? "Updates" : "Installed apps", C_TEXT);
  if (upd && nupd && fp_state == 1) btn(x0 + w - 150, y - 2, 150, 36, "Update all", 0, Z_UPDALL, 0, T_ACC);
  y += line_h(F_H1) + 6;
  char sub[100];
  if (fp_state == 2) snprintf(sub, sizeof sub, "Flatpak is not installed on this system");
  else if (!inst_loaded) snprintf(sub, sizeof sub, "Reading installed apps");
  else if (upd) snprintf(sub, sizeof sub, nupd ? "%d update%s available" : "Everything is up to date", nupd, nupd == 1 ? "" : "s");
  else snprintf(sub, sizeof sub, "%d app%s installed through Flatpak", ninst, ninst == 1 ? "" : "s");
  tx(F_UI, x0, y, sub, C_MUTED);
  y += line_h(F_UI) + 20;
  int row = 0;
  for (int i = 0; i < ninst; i++) {
    Inst *in = &INST[i];
    int u = is_updatable(in->id);
    if (upd && !u) continue;
    float ry = y + row * 80;
    row++;
    if (ry + 72 < hy0 || ry > hy1) continue;
    int hv = HOT == Z_IROW + i || HOT == Z_IOPEN + i || HOT == Z_IUPD + i || HOT == Z_IRM + i;
    rr(x0 - 1, ry - 1, w + 2, 74, 17, hv ? T_ACC : THEME(RGB(230, 228, 234), RGB(54, 58, 68)));
    rr(x0, ry, w, 72, 16, N_PAGE);
    char url[300];
    Hit *h = hit_find(in->id);
    if (h && h->icon[0]) cpy(url, sizeof url, h->icon);
    else snprintf(url, sizeof url, "https://dl.flathub.org/repo/appstream/x86_64/icons/128x128/%s.png", in->id);
    draw_icon(url, x0 + 16, ry + 11, 50, in->name);
    tf(F_UI_MED, x0 + 82, ry + 14, w - 440, in->name, C_TEXT);
    char meta[120];
    snprintf(meta, sizeof meta, "%s%s%s%s", in->ver, in->ver[0] && in->size[0] ? "  -  " : "", in->size, u ? "  -  update available" : "");
    tf(F_SMALL, x0 + 82, ry + 42, w - 440, meta[0] ? meta : in->id, u ? T_WARN : C_MUTED);
    hit(Z_IROW + i, x0, ry, w, 72);
    int st = app_state(in->id);
    float bx = x0 + w - 16;
    if (st >= 3) {
      char l[40];
      snprintf(l, sizeof l, st == 4 ? "%s %d%%" : "Queued", op_verb(OPS[0].kind), (int)(op_prog * 100));
      bx -= 150;
      btn(bx, ry + 18, 150, 36, l, st == 4 ? 1 : 3, Z_IOPEN + i, st == 4 ? (op_prog > 0.04f ? op_prog : 0.04f) : 0, T_ACC);
    } else {
      bx -= 100;
      btn(bx, ry + 18, 100, 36, "Remove", 2, Z_IRM + i, 0, T_BAD);
      if (u) bx -= 100, btn(bx, ry + 18, 92, 36, "Update", 0, Z_IUPD + i, 0, T_ACC);
      bx -= 100;
      btn(bx, ry + 18, 92, 36, "Open", 1, Z_IOPEN + i, 0, T_ACC);
    }
  }
  if (!row && inst_loaded && fp_state == 1) {
    rr(x0, y, w, 130, 18, N_PAGE);
    tcn(F_UI_MED, x0 + w / 2, y + 40, upd ? "No updates right now" : "No apps installed yet", C_TEXT);
    tcn(F_SMALL, x0 + w / 2, y + 68, upd ? "Check again later" : "Browse Discover to find your first app", C_MUTED);
    y += 130;
  } else y += row * 80;
  S.content_h = y + S.scroll[upd ? V_UPD : V_INST] - HEAD + 20;
}

static void draw_lightbox(void) {
  float ch = NH - BAR_H;
  rc(0, 0, NW, ch, RGBA(6, 8, 14, 232));
  hit(Z_LB_BG, 0, 0, NW, ch);
  hy0 = 0, hy1 = ch;
  Img *si = img_get(D.shots_big[D.shot_cur], 1248, 8);
  float aw = NW - 190, ah = ch - 130;
  if (si && si->state == IMG_READY) {
    float sc = fminf(aw / si->w, ah / si->h);
    float iw = si->w * sc, ih = si->h * sc, ix = (NW - iw) / 2, iy = (ch - ih) / 2 - 8;
    gfx_blit_premul(SF, si->px, si->w, si->h, OX + ix, OY + iy, iw, ih);
    hit(Z_LB_R, ix, iy, iw, ih);
  } else tcn(F_UI, NW / 2, ch / 2 - 10, "Loading", RGB(200, 206, 218));
  char cap[160];
  snprintf(cap, sizeof cap, "%d / %d%s%s", D.shot_cur + 1, D.nshot, D.shot_cap[D.shot_cur][0] ? "   " : "", D.shot_cap[D.shot_cur]);
  tcn(F_UI, NW / 2, ch - 44, cap, RGB(214, 220, 232));
  dsc(40, 40, 22, HOT == Z_LB_X ? RGB(232, 72, 60) : RGBA(255, 255, 255, 40));
  ln(32, 32, 48, 48, 2.4f, RGB(255, 255, 255)), ln(48, 32, 32, 48, 2.4f, RGB(255, 255, 255));
  hit(Z_LB_X, 14, 14, 52, 52);
  if (D.nshot > 1)
    for (int d = 0; d < 2; d++) {
      float cx = d ? NW - 50 : 50, cy = ch / 2 - 8;
      dsc(cx, cy, 24, HOT == (d ? Z_LB_R : Z_LB_L) ? RGBA(255, 255, 255, 90) : RGBA(255, 255, 255, 50));
      ln(cx + (d ? -4 : 4), cy - 10, cx + (d ? 5 : -5), cy, 2.6f, RGB(255, 255, 255));
      ln(cx + (d ? 5 : -5), cy, cx + (d ? -4 : 4), cy + 10, 2.6f, RGB(255, 255, 255));
      hit(d ? Z_LB_R : Z_LB_L, cx - 28, cy - 28, 56, 56);
    }
}

static void go_home(void) {
  S.view = V_HOME, S.side = 0, S.back_n = 0, S.scroll[V_HOME] = 0, S.lb = 0;
}

static void nav_push(void) {
  if (S.back_n >= 10) {
    memmove(&S.back[0], &S.back[1], sizeof S.back[0] * 9);
    S.back_n = 9;
  }
  S.back[S.back_n].view = S.view;
  S.back[S.back_n].side = S.side;
  S.back[S.back_n].scroll = S.scroll[S.view];
  cpy(S.back[S.back_n].id, sizeof S.back[S.back_n].id, S.view == V_APP ? D.id : "");
  S.back_n++;
}

static void open_app(const char *id) {
  if (!safe_id(id)) return;
  nav_push();
  S.view = V_APP;
  S.scroll[V_APP] = 0;
  S.lb = 0;
  det_open(id, hit_find(id));
}

static void nav_back(void) {
  S.lb = 0;
  if (!S.back_n) {
    go_home();
    return;
  }
  S.back_n--;
  S.view = S.back[S.back_n].view;
  S.side = S.back[S.back_n].side;
  S.scroll[S.view] = S.back[S.back_n].scroll;
  if (S.view == V_APP) det_open(S.back[S.back_n].id, hit_find(S.back[S.back_n].id));
}

static void load_home(void) {
  for (int i = 1; i < 4; i++) {
    lst_reset(&SEC[i], L_COLL, SEC_KEY[i], SEC_TITLE[i]);
    lst_request(&SEC[i], 1, 12);
  }
}

static void open_cat(int i) {
  S.back_n = 0, S.view = V_LIST, S.side = 10 + i, S.scroll[V_LIST] = 0, S.lb = 0;
  lst_reset(&BR, L_CAT, CAT_KEY[i], CAT_NAME[i]);
  lst_request(&BR, 1, 24);
}

static void open_coll(int i) {
  nav_push();
  S.view = V_LIST, S.scroll[V_LIST] = 0;
  lst_reset(&BR, L_COLL, SEC_KEY[i], SEC_TITLE[i]);
  lst_request(&BR, 1, 24);
}

static void run_search(void) {
  if (strlen(S.q) < 2) return;
  char t[100];
  snprintf(t, sizeof t, "Results for \"%.60s\"", S.q);
  S.back_n = 0, S.view = V_LIST, S.side = -1, S.scroll[V_LIST] = 0, S.lb = 0;
  lst_reset(&BR, L_SEARCH, S.q, t);
  lst_request(&BR, 1, 24);
}

static void card_btn(const char *id, const char *name) {
  int st = app_state(id);
  if (st == 0) op_add(id, name, 0);
  else if (st == 1) run_app(id, name);
  else if (st == 2) op_add(id, name, 2);
}

static void side_click(int i) {
  S.lb = 0;
  if (i == 0) go_home();
  else if (i == 1 || i == 2) {
    S.view = i == 1 ? V_INST : V_UPD, S.side = i, S.back_n = 0;
    S.scroll[S.view] = 0;
    fp_refresh();
  } else if (i >= 10 && i < 21) open_cat(i - 10);
}

static void retry(void) {
  if (S.view == V_HOME) load_home();
  else if (S.view == V_LIST) {
    int pg = 1;
    char arg[96], title[80];
    int kind = BR.kind;
    cpy(arg, sizeof arg, BR.arg);
    cpy(title, sizeof title, BR.title);
    lst_reset(&BR, kind, arg, title);
    lst_request(&BR, pg, 24);
  } else if (S.view == V_APP) {
    char id[96];
    cpy(id, sizeof id, D.id);
    det_open(id, D.have_hit ? &D.hit : NULL);
  }
}

static void do_action(int z) {
  if (z != Z_SEARCH && z != Z_CLEAR) S.focus = 0;
  if (z == Z_SEARCH) {
    S.focus = 1;
    S.blink = 1;
    office_show_keyboard();
  } else if (z == Z_CLEAR) {
    S.q[0] = 0;
    S.q_dirty = 0;
    S.focus = 1;
    if (S.view == V_LIST && BR.kind == L_SEARCH) go_home();
  } else if (z == Z_BACK) nav_back();
  else if (z >= Z_SIDE && z < Z_SIDE + 30) side_click(z - Z_SIDE);
  else if (z >= Z_CARD && z < Z_CARD + 800) open_app(CARDID[z - Z_CARD]);
  else if (z >= Z_GET && z < Z_GET + 800) card_btn(CARDID[z - Z_GET], name_of(CARDID[z - Z_GET]));
  else if (z >= Z_SEE && z < Z_SEE + 4) open_coll(z - Z_SEE);
  else if (z >= Z_CATTILE && z < Z_CATTILE + 11) open_cat(z - Z_CATTILE);
  else if (z == Z_ACT) card_btn(D.id, D.name);
  else if (z == Z_RM) op_add(D.id, D.name, 1);
  else if (z == Z_SHOT) S.lb = 1;
  else if (z == Z_SHOT_L) D.shot_cur = (D.shot_cur + D.nshot - 1) % D.nshot;
  else if (z == Z_SHOT_R) D.shot_cur = (D.shot_cur + 1) % D.nshot;
  else if (z >= Z_DOT && z < Z_DOT + 12) D.shot_cur = z - Z_DOT;
  else if (z >= Z_LINK && z < Z_LINK + 9) open_url(D.urls[z - Z_LINK]);
  else if (z == Z_REL_MORE) D.rel_all = !D.rel_all;
  else if (z == Z_PERM_MORE) D.perm_all = !D.perm_all;
  else if (z == Z_DESC_MORE) D.desc_all = !D.desc_all;
  else if (z == Z_LB_X || z == Z_LB_BG) S.lb = 0;
  else if (z == Z_LB_L) D.shot_cur = (D.shot_cur + D.nshot - 1) % D.nshot;
  else if (z == Z_LB_R) D.shot_cur = (D.shot_cur + 1) % D.nshot;
  else if (z >= Z_IROW && z < Z_IROW + 300) open_app(INST[z - Z_IROW].id);
  else if (z >= Z_IOPEN && z < Z_IOPEN + 300) run_app(INST[z - Z_IOPEN].id, INST[z - Z_IOPEN].name);
  else if (z >= Z_IUPD && z < Z_IUPD + 300) op_add(INST[z - Z_IUPD].id, INST[z - Z_IUPD].name, 2);
  else if (z >= Z_IRM && z < Z_IRM + 300) op_add(INST[z - Z_IRM].id, INST[z - Z_IRM].name, 1);
  else if (z == Z_UPDALL) op_add("", "", 3);
  else if (z == Z_RETRY) retry();
}

static void clamp_scroll(void) {
  float maxs = S.content_h - (NH - BAR_H - HEAD);
  if (maxs < 0) maxs = 0;
  if (S.scroll[S.view] > maxs) S.scroll[S.view] = (int)maxs;
  if (S.scroll[S.view] < 0) S.scroll[S.view] = 0;
}

static void draw_scrollbar(void) {
  float vh = NH - BAR_H - HEAD;
  if (S.content_h <= vh + 4) return;
  float th = vh * vh / S.content_h, ty = HEAD + (vh - th) * ((float)S.scroll[S.view] / (S.content_h - vh));
  rr(NW - 9, ty, 5, th, 2.5f, THEME(RGBA(0, 0, 0, 60), RGBA(255, 255, 255, 60)));
}

static void draw_status(void) {
  float ch = NH - BAR_H;
  float cx = SIDE + MW / 2;
  float y = ch - 56;
  if (fp_op) {
    float w = 320;
    rr(cx - w / 2 - 1, y - 1, w + 2, 42, 21, THEME(RGB(226, 228, 236), RGB(60, 64, 76)));
    rr(cx - w / 2, y, w, 40, 20, N_PAGE);
    tf(F_SMALL, cx - w / 2 + 18, y + 9, w - 36, op_text, C_TEXT);
    rr(cx - w / 2 + 18, y + 27, w - 36, 5, 2.5f, THEME(RGB(230, 232, 238), RGB(50, 54, 64)));
    float p = op_prog > 0.02f ? op_prog : 0.02f;
    rr(cx - w / 2 + 18, y + 27, (w - 36) * p, 5, 2.5f, T_ACC);
    y -= 52;
  }
  if (S.toast[0]) {
    float w = gfx_text_w(F_UI, S.toast) + 40;
    rr(cx - w / 2, y, w, 38, 19, THEME(RGB(36, 40, 50), RGB(226, 230, 240)));
    tcn(F_UI, cx, y + 19 - line_h(F_UI) / 2, S.toast, THEME(RGB(255, 255, 255), RGB(28, 32, 40)));
  }
}

static void store_draw(Panel *p, Surface *s, float ox, float oy) {
  SF = s, OX = ox, OY = oy, S.panel = (int)(p - P);
  HOT = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  img_frame();
  nhr = 0, ncard = 0;
  float ch = NH - BAR_H;
  gfx_rect(s, ox, oy, NW, ch, N_CANVAS);
  hy0 = HEAD, hy1 = ch;
  gfx_clip(s, ox + SIDE, oy + HEAD, MW, ch - HEAD);
  switch (S.view) {
  case V_HOME: view_home(); break;
  case V_LIST: view_list(); break;
  case V_APP: view_app(); break;
  case V_INST: view_installed(0); break;
  default: view_installed(1); break;
  }
  gfx_noclip(s);
  clamp_scroll();
  hy0 = 0, hy1 = ch;
  draw_sidebar();
  draw_header();
  draw_scrollbar();
  draw_status();
  if (S.lb && D.nshot) draw_lightbox();
}

static int store_zone(Panel *p, float x, float y) {
  (void)p;
  for (int i = nhr - 1; i >= 0; i--)
    if (x >= HR[i].x && x < HR[i].x + HR[i].w && y >= HR[i].y && y < HR[i].y + HR[i].h) return HR[i].z;
  return 0;
}

static void store_press(Panel *p, float x, float y, int button, int down) {
  S.panel = (int)(p - P);
  int z = store_zone(p, x, y);
  if (button == 3 && !down) {
    if (S.lb) S.lb = 0;
    else nav_back();
    p->dirty = 1;
    return;
  }
  if (button != 1) return;
  if (down) {
    S.press = z;
    return;
  }
  int pz = S.press;
  S.press = 0;
  if (z && z == pz) do_action(z);
  else if (!z && !pz && S.focus) S.focus = 0;
  p->dirty = 1;
}

static void store_scroll(Panel *p, float x, float y, int steps) {
  (void)x, (void)y;
  if (S.lb) {
    if (D.nshot > 1) D.shot_cur = (D.shot_cur + (steps < 0 ? 1 : D.nshot - 1)) % D.nshot;
  } else {
    S.scroll[S.view] -= steps * 70;
    clamp_scroll();
  }
  p->dirty = 1;
}

static void store_key(Panel *p, int code, int mods) {
  S.panel = (int)(p - P);
  int ctrl = mods & MOD_CTRL, alt = mods & MOD_ALT;
  p->dirty = 1;
  if (S.lb) {
    if (code == KEY_ESC) S.lb = 0;
    else if (code == KEY_LEFT && D.nshot > 1) D.shot_cur = (D.shot_cur + D.nshot - 1) % D.nshot;
    else if ((code == KEY_RIGHT || code == KEY_SPACE) && D.nshot > 1) D.shot_cur = (D.shot_cur + 1) % D.nshot;
    return;
  }
  if (S.focus) {
    int l = (int)strlen(S.q);
    S.blink = 1, S.blink_t = now_ms();
    if (code == KEY_ESC) S.focus = 0;
    else if (code == KEY_ENTER || code == KEY_KPENTER) {
      S.q_dirty = 0;
      run_search();
    } else if (code == KEY_BACKSPACE) {
      if (l) S.q[l - 1] = 0, S.q_dirty = 1, S.q_at = now_ms();
      if (!S.q[0]) S.q_dirty = 0;
      if (!S.q[0] && S.view == V_LIST && BR.kind == L_SEARCH) go_home();
    } else if (!ctrl && !alt) {
      char b[8];
      int n = key_to_bytes(code, mods, b);
      if (n == 1 && b[0] >= 32 && b[0] < 127 && l < 80) S.q[l] = b[0], S.q[l + 1] = 0, S.q_dirty = 1, S.q_at = now_ms();
    }
    return;
  }
  if ((ctrl && code == KEY_F) || code == KEY_SLASH) {
    S.focus = 1, S.blink = 1;
    office_show_keyboard();
    return;
  }
  if (code == KEY_ESC || code == KEY_BACKSPACE || (alt && code == KEY_LEFT)) {
    if (S.view != V_HOME) nav_back();
    return;
  }
  int vh = NH - BAR_H - HEAD;
  if (code == KEY_DOWN) S.scroll[S.view] += 70;
  else if (code == KEY_UP) S.scroll[S.view] -= 70;
  else if (code == KEY_PAGEDOWN || code == KEY_SPACE) S.scroll[S.view] += vh - 60;
  else if (code == KEY_PAGEUP) S.scroll[S.view] -= vh - 60;
  else if (code == KEY_HOME) S.scroll[S.view] = 0;
  else if (code == KEY_END) S.scroll[S.view] = 1 << 20;
  else if (S.view == V_APP && D.nshot > 1 && code == KEY_LEFT) D.shot_cur = (D.shot_cur + D.nshot - 1) % D.nshot;
  else if (S.view == V_APP && D.nshot > 1 && code == KEY_RIGHT) D.shot_cur = (D.shot_cur + 1) % D.nshot;
  clamp_scroll();
}

static int store_tick(Panel *p, uint32_t now) {
  S.panel = (int)(p - P);
  int ch = 0;
  if (net_poll()) ch = 1;
  for (int i = 0; i < 4; i++)
    if (lst_ingest(&SEC[i])) ch = 1;
  if (lst_ingest(&BR)) ch = 1;
  if (det_poll()) ch = 1;
  if (op_poll()) ch = 1;
  if (!fp_state) fp_check();
  if (img_pending()) ch = 1;
  if (S.toast[0] && now - S.toast_t > 3800) S.toast[0] = 0, ch = 1;
  if (S.focus && now - S.blink_t > 530) S.blink = !S.blink, S.blink_t = now, ch = 1;
  if (S.q_dirty && now - S.q_at > 550) {
    S.q_dirty = 0;
    run_search();
    ch = 1;
  }
  if (S.view == V_LIST && BR.loaded && !BR.req && !BR.err && BR.page < BR.pages && S.scroll[V_LIST] + (NH - BAR_H - HEAD) > S.content_h - 520) {
    lst_request(&BR, BR.page + 1, 24);
    ch = 1;
  }
  return ch;
}

static void store_open(Panel *p) {
  memset(&S, 0, sizeof S);
  S.panel = (int)(p - P);
  S.hero_at = now_ms();
  S.side = 0;
  lst_reset(&BR, L_COLL, "popular", "");
  load_home();
  fp_check();
  if (fp_state == 1) fp_refresh();
  snprintf(p->title, sizeof p->title, "Store");
}

static void store_close(Panel *p) {
  (void)p;
  det_free();
}

App store_app = {"store", "Store", IC_STORE, NW, NH, store_open, store_draw, NULL, store_scroll, store_key, store_zone, store_tick, store_close, store_press};
