#include <ctype.h>
#include <dirent.h>
#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "office.h"

#define SW 1440
#define SH 810
#define STRIP_X 16
#define STRIP_W 164
#define BODY_Y 124
#define CANVAS_X 196
#define MAXSLIDES 200
#define MAXOBJ 80
#define MAXUNDO 50
#define MAXDECKS 256
#define PAD 18

enum { O_TEXT, O_RECT, O_ROUND, O_ELLIPSE, O_EMBED };
enum { AL_LEFT, AL_CENTER, AL_RIGHT };
enum { VA_TOP, VA_MID, VA_BOT };
enum { PH_NONE, PH_TITLE, PH_BODY };

enum {
  T_UNDO = 1, T_REDO, T_SLIDE, T_TEXT, T_RECT, T_ELLIPSE, T_EMBED, T_SIZEM, T_SIZE, T_SIZEP, T_BOLD, T_ITAL, T_UNDER, T_COLOR,
  T_FILL, T_ALEFT, T_ACENTER, T_ARIGHT, T_BULLET, T_FRONT, T_BACK, T_COUNT
};

enum {
  Z_MENU = 40, Z_TITLE = 50, Z_HOME = 51, Z_PRESENT = 54, Z_STRIP = 60, Z_CANVAS = 61, Z_AREA = 62, Z_HANDLE = 70,
  Z_POPUP = 100, Z_THUMB = 400
};

enum {
  C_NONE, C_NEW, C_COPYDOC, C_RENAME, C_OUTLINE, C_PPTX, C_DELETE, C_UNDO, C_REDO, C_CUT, C_COPY, C_PASTE, C_DUP, C_DEL,
  C_ITEXT, C_IRECT, C_IROUND, C_IELL, C_NEWSLIDE, C_DUPSLIDE, C_DELSLIDE, C_SUP, C_SDOWN, C_BG, C_FRONT, C_BACK,
  C_HCENTER, C_VCENTER, C_PRESENT, C_EDOC, C_ESHEET, C_ESLIDE
};

enum { POP_NONE, POP_M0, POP_M1, POP_M2, POP_M3, POP_M4, POP_COLOR, POP_FILL, POP_BG, POP_LAYOUT };

typedef struct {
  unsigned char type, bold, ital, under, align, valign, color, fill, line, bullets, ph;
  float x, y, w, h, size;
  char *text;
} Obj;

typedef struct {
  Obj *o;
  int n, cap;
  unsigned char bg;
} Slide;

typedef struct {
  const char *label, *key;
  int cmd;
} Item;

typedef struct {
  char id[40], title[96];
  long mtime;
  int nslides;
  Slide first;
} DeckInfo;

static const uint32_t PAL[16] = {0,
                                 RGB(255, 255, 255),
                                 RGB(241, 243, 244),
                                 RGB(95, 99, 104),
                                 RGB(32, 33, 36),
                                 RGB(217, 48, 37),
                                 RGB(232, 113, 10),
                                 RGB(249, 171, 0),
                                 RGB(24, 128, 56),
                                 RGB(0, 137, 123),
                                 RGB(26, 115, 232),
                                 RGB(84, 76, 230),
                                 RGB(147, 52, 230),
                                 RGB(214, 56, 140),
                                 RGB(210, 227, 252),
                                 RGB(254, 243, 214)};

static const float SIZES[] = {14, 18, 20, 24, 28, 32, 36, 40, 44, 50, 54, 60, 66, 72, 88, 96};
#define NSIZES ((int)(sizeof SIZES / sizeof *SIZES))

static const Item M_FILE[] = {{"New presentation", "", C_NEW}, {"Make a copy", "", C_COPYDOC}, {"Rename", "", C_RENAME},
                              {NULL, NULL, 0}, {"Download outline (.txt)", "", C_OUTLINE},
                              {"Download as PowerPoint (.pptx)", "", C_PPTX}, {NULL, NULL, 0},
                              {"Move to trash", "", C_DELETE}};
static const Item M_EDIT[] = {{"Undo", "Ctrl+Z", C_UNDO}, {"Redo", "Ctrl+Y", C_REDO}, {NULL, NULL, 0},
                              {"Cut", "Ctrl+X", C_CUT}, {"Copy", "Ctrl+C", C_COPY}, {"Paste", "Ctrl+V", C_PASTE},
                              {"Duplicate", "Ctrl+D", C_DUP}, {"Delete", "Del", C_DEL}};
static const Item M_INSERT[] = {{"Text box", "", C_ITEXT}, {"Rectangle", "", C_IRECT}, {"Rounded rectangle", "", C_IROUND},
                                {"Ellipse", "", C_IELL}, {NULL, NULL, 0}, {"Document...", "", C_EDOC},
                                {"Spreadsheet...", "", C_ESHEET}, {"Slide...", "", C_ESLIDE}, {NULL, NULL, 0},
                                {"New slide", "Ctrl+M", C_NEWSLIDE}};
static const Item M_SLIDE[] = {{"New slide", "Ctrl+M", C_NEWSLIDE}, {"Duplicate slide", "", C_DUPSLIDE},
                               {"Delete slide", "", C_DELSLIDE}, {NULL, NULL, 0}, {"Move slide up", "", C_SUP},
                               {"Move slide down", "", C_SDOWN}, {NULL, NULL, 0}, {"Change background", "", C_BG},
                               {NULL, NULL, 0}, {"Present from beginning", "F5", C_PRESENT}};
static const Item M_ARRANGE[] = {{"Bring to front", "", C_FRONT}, {"Send to back", "", C_BACK}, {NULL, NULL, 0},
                                 {"Center horizontally", "", C_HCENTER}, {"Center vertically", "", C_VCENTER}};
static const char *MENU_NAMES[5] = {"File", "Edit", "Insert", "Slide", "Arrange"};
static const Item *MENUS[5] = {M_FILE, M_EDIT, M_INSERT, M_SLIDE, M_ARRANGE};
static const int MENU_LEN[5] = {8, 8, 10, 10, 5};
static const char *LAYOUT_NAMES[6] = {"Title slide", "Title and content", "Section header", "Two content", "Title only", "Blank"};

static struct {
  char id[40], title[96];
  Slide sl[MAXSLIDES];
  int ns, cur;
  int sel, editing, caret;
  int popup;
  int dirty;
  uint32_t dirty_at;
  char *undo[MAXUNDO], *redo[MAXUNDO];
  int nundo, nredo;
  int press, drag, handle;
  float gx0, gy0, ox0, oy0, ow0, oh0;
  int moved, snapx, snapy;
  uint32_t last_click;
  int last_obj;
  int title_edit;
  char title_buf[96];
  int blink;
  uint32_t blink_t;
  float strip_scroll;
  int present, pend;
  Obj clip;
  int has_clip;
  DeckInfo list[MAXDECKS];
  int nlist, confirm_del, loaded;
} D;

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static float content_h(void) { return OFF_H - BAR_H; }

static void obj_free(Obj *o) {
  free(o->text);
  o->text = NULL;
}

static void slide_free(Slide *s) {
  for (int i = 0; i < s->n; i++) obj_free(&s->o[i]);
  free(s->o);
  memset(s, 0, sizeof *s);
}

static Obj *obj_add(Slide *s) {
  if (s->n >= MAXOBJ) return NULL;
  if (s->n == s->cap) {
    s->cap = s->cap ? s->cap * 2 : 8;
    s->o = realloc(s->o, sizeof(Obj) * (size_t)s->cap);
  }
  Obj *o = &s->o[s->n++];
  memset(o, 0, sizeof *o);
  o->text = strdup("");
  return o;
}

static void obj_copy(Obj *dst, const Obj *src) {
  *dst = *src;
  dst->text = strdup(src->text ? src->text : "");
}

static void deck_clear(void) {
  for (int i = 0; i < D.ns; i++) slide_free(&D.sl[i]);
  D.ns = 0;
}

static int lum(uint32_t c) { return (int)(((c >> 16) & 255) * 0.299 + ((c >> 8) & 255) * 0.587 + (c & 255) * 0.114); }

static uint32_t bg_col(const Slide *s) { return s->bg ? PAL[s->bg] : RGB(255, 255, 255); }

static uint32_t text_col(const Slide *s, const Obj *o) {
  if (o->color) return PAL[o->color];
  uint32_t under = o->fill ? PAL[o->fill] : bg_col(s);
  return lum(under) < 140 ? RGB(255, 255, 255) : RGB(32, 33, 36);
}

static const Font *src_font(float dev_px, int bold, int ital, float *q) {
  static const int px[4] = {30, 36, 44, 58};
  int k = 3;
  for (int i = 0; i < 4; i++)
    if (px[i] >= dev_px) {
      k = i;
      break;
    }
  *q = dev_px / px[k];
  return doc_font(k, bold, ital);
}

static float meas_w(const Obj *o, char c) {
  const Font *f = doc_font(3, o->bold, o->ital);
  return doc_char_w(f, c) * SCALE / 58.f * o->size;
}

typedef struct {
  int a, b;
  float w;
  int bullet;
} TLine;

static int layout_text(const Obj *o, TLine *ln, int max) {
  int n = 0;
  const char *t = o->text ? o->text : "";
  int len = (int)strlen(t);
  float avail = o->w - 2 * PAD - (o->bullets ? o->size * 1.1f : 0);
  if (avail < 10) avail = 10;
  int i = 0, para_start = 1;
  while (n < max) {
    int s = i;
    float w = 0;
    int brk = -1;
    float brkw = 0;
    while (i < len && t[i] != '\n') {
      float cw = meas_w(o, t[i]);
      if (w + cw > avail && i > s) break;
      w += cw;
      i++;
      if (t[i - 1] == ' ') brk = i, brkw = w;
    }
    int e = i;
    if (i < len && t[i] != '\n' && brk > s) e = brk, w = brkw, i = brk;
    ln[n++] = (TLine){s, e, w, para_start && o->bullets};
    para_start = 0;
    if (i >= len) break;
    if (t[i] == '\n') {
      i++;
      para_start = 1;
      if (i >= len) {
        ln[n++] = (TLine){i, i, 0, o->bullets};
        break;
      }
    }
  }
  return n;
}

static float text_top(const Obj *o, int nl) {
  float lh = o->size * 1.22f, th = nl * lh;
  if (o->valign == VA_MID) return o->y + (o->h - th) / 2;
  if (o->valign == VA_BOT) return o->y + o->h - PAD - th;
  return o->y + PAD * 0.7f;
}

static float line_x(const Obj *o, const TLine *l) {
  float ind = o->bullets ? o->size * 1.1f : 0;
  float avail = o->w - 2 * PAD - ind;
  if (o->align == AL_CENTER) return o->x + PAD + ind + (avail - l->w) / 2;
  if (o->align == AL_RIGHT) return o->x + PAD + ind + avail - l->w;
  return o->x + PAD + ind;
}

static void draw_obj(Surface *s, const Slide *sl, const Obj *o, float ox, float oy, float k, int mode, int caret) {
  float x = ox + o->x * k, y = oy + o->y * k, w = o->w * k, h = o->h * k;
  if (o->type == O_EMBED) {
    int ek = 0, sub;
    char id[40];
    if (office_embed_parse(o->text, &ek, id, sizeof id, &sub)) office_embed_draw(s, ek, id, sub, x, y, w, h, 0);
    if (ek != 2 || mode == 0) {
      uint32_t bc = THEME(RGB(218, 218, 224), RGB(70, 72, 80));
      float t = k * 2 > 0.6f ? k * 2 : 0.6f;
      gfx_rect(s, x, y, w, t, bc);
      gfx_rect(s, x, y + h - t, w, t, bc);
      gfx_rect(s, x, y, t, h, bc);
      gfx_rect(s, x + w - t, y, t, h, bc);
    }
    return;
  }
  uint32_t fill = o->fill ? PAL[o->fill] : 0, line = o->line ? PAL[o->line] : 0;
  float lw = (o->size > 0 ? 3.f : 3.f) * k;
  if (o->type == O_RECT || o->type == O_TEXT) {
    if (fill) gfx_rect(s, x, y, w, h, fill);
    if (line) {
      gfx_rect(s, x, y, w, lw, line);
      gfx_rect(s, x, y + h - lw, w, lw, line);
      gfx_rect(s, x, y, lw, h, line);
      gfx_rect(s, x + w - lw, y, lw, h, line);
    }
  } else if (o->type == O_ROUND) {
    float r = (w < h ? w : h) * 0.18f;
    if (line) {
      gfx_rrect(s, x, y, w, h, r, line);
      if (fill) gfx_rrect(s, x + lw, y + lw, w - 2 * lw, h - 2 * lw, r - lw > 0 ? r - lw : 0, fill);
    } else if (fill) gfx_rrect(s, x, y, w, h, r, fill);
  } else if (o->type == O_ELLIPSE) {
    float cx = x + w / 2, cy = y + h / 2, rx = w / 2, ry = h / 2;
    int steps = (int)(h * s->scale) + 2;
    for (int i = 0; i < steps; i++) {
      float t0 = (float)i / steps, t1 = (float)(i + 1) / steps;
      float yy0 = y + h * t0, yy1 = y + h * t1, ym = (yy0 + yy1) / 2;
      float dy = (ym - cy) / ry, half = dy * dy < 1 ? rx * sqrtf(1 - dy * dy) : 0;
      if (line) {
        gfx_rect(s, cx - half, yy0, half * 2, yy1 - yy0 + 0.05f, line);
        float ry2 = ry - lw, rx2 = rx - lw;
        float d2 = ry2 > 0 ? (ym - cy) / ry2 : 2;
        float h2 = d2 * d2 < 1 ? rx2 * sqrtf(1 - d2 * d2) : 0;
        if (fill && h2 > 0) gfx_rect(s, cx - h2, yy0, h2 * 2, yy1 - yy0 + 0.05f, fill);
      } else if (fill) gfx_rect(s, cx - half, yy0, half * 2, yy1 - yy0 + 0.05f, fill);
    }
  }
  const char *t = o->text ? o->text : "";
  int empty = !t[0];
  if (empty && !(mode == 0 && o->ph && caret < 0)) {
    if (mode == 0 && caret >= 0) {
      TLine ln[1] = {{0, 0, 0, o->bullets}};
      float ty = text_top(o, 1);
      float cxp = line_x(o, &ln[0]);
      float lh = o->size * 1.22f;
      if (o->bullets) gfx_disc(s, ox + (cxp - o->size * 0.7f) * k, oy + (ty + lh * 0.55f) * k, o->size * 0.12f * k, text_col(sl, o));
      gfx_rect(s, ox + cxp * k, oy + (ty + lh * 0.12f) * k, 2.f, lh * 0.8f * k, P_ACC);
    }
    return;
  }
  uint32_t col = text_col(sl, o);
  const char *show = t;
  Obj tmp;
  if (empty) {
    tmp = *o;
    tmp.text = (char *)(o->ph == PH_TITLE ? "Click to add title" : "Click to add text");
    o = &tmp;
    show = tmp.text;
    col = RGB(150, 154, 162);
  }
  TLine ln[128];
  int nl = layout_text(o, ln, 128);
  float lh = o->size * 1.22f, ty = text_top(o, nl);
  float dev = o->size * k * s->scale, q;
  const Font *f = src_font(dev, o->bold, o->ital, &q);
  float base_off = (lh - o->size * 1.15f) / 2;
  for (int i = 0; i < nl; i++) {
    float lx = line_x(o, &ln[i]), ly = ty + i * lh;
    if (ly * k + oy > s->cy1 / (float)s->scale + 4) break;
    if (ln[i].bullet && (ln[i].b > ln[i].a || (mode == 0 && caret >= 0)))
      gfx_disc(s, ox + (lx - o->size * 0.7f) * k, oy + (ly + lh * 0.55f) * k, o->size * 0.12f * k, col);
    float cx = lx;
    for (int j = ln[i].a; j < ln[i].b; j++) {
      gfx_text_scaled(s, f, ox + cx * k, oy + (ly + base_off) * k, show + j, 1, col, q);
      cx += meas_w(o, show[j]);
    }
    if (o->under && ln[i].b > ln[i].a) gfx_rect(s, ox + lx * k, oy + (ly + o->size * 1.0f + base_off) * k, ln[i].w * k, o->size * 0.06f * k, col);
  }
  if (mode == 0 && caret >= 0 && !empty) {
    int li = nl - 1;
    for (int i = 0; i < nl; i++)
      if (caret >= ln[i].a && (caret < ln[i].b || i == nl - 1 || ln[i + 1].a > caret)) {
        li = i;
        break;
      }
    float cx = line_x(o, &ln[li]);
    for (int j = ln[li].a; j < caret && j < ln[li].b; j++) cx += meas_w(o, show[j]);
    gfx_rect(s, ox + cx * k, oy + (ty + li * lh + lh * 0.12f) * k, 2.f, lh * 0.8f * k, P_ACC);
  }
}

static void render_slide(Surface *s, const Slide *sl, float ox, float oy, float k, int mode, int edit_obj, int caret) {
  gfx_rect(s, ox, oy, SW * k, SH * k, bg_col(sl));
  for (int i = 0; i < sl->n; i++) draw_obj(s, sl, &sl->o[i], ox, oy, k, mode, i == edit_obj ? caret : -1);
}

static void esc_text(const char *t, char *out, int cap) {
  int k = 0;
  for (; *t && k < cap - 3; t++) {
    if (*t == '\n') out[k++] = '\\', out[k++] = 'n';
    else if (*t == '\\') out[k++] = '\\', out[k++] = '\\';
    else if (*t == '\t') out[k++] = ' ';
    else out[k++] = *t;
  }
  out[k] = 0;
}

static char *unesc(const char *t) {
  char *o = malloc(strlen(t) + 1);
  int k = 0;
  for (; *t; t++) {
    if (*t == '\\' && t[1] == 'n') o[k++] = '\n', t++;
    else if (*t == '\\' && t[1] == '\\') o[k++] = '\\', t++;
    else o[k++] = *t;
  }
  o[k] = 0;
  return o;
}

static char *serialize(void) {
  size_t cap = 4096, k = 0;
  char *s = malloc(cap);
#define PUT(...)                                                       \
  do {                                                                 \
    int need = snprintf(NULL, 0, __VA_ARGS__);                         \
    while (k + (size_t)need + 1 >= cap) cap *= 2, s = realloc(s, cap); \
    k += (size_t)sprintf(s + k, __VA_ARGS__);                          \
  } while (0)
  PUT("SLIDES1\ntitle\t%s\ncur\t%d\n", D.title, D.cur);
  for (int i = 0; i < D.ns; i++) {
    Slide *sl = &D.sl[i];
    PUT("s\t%d\n", sl->bg);
    for (int j = 0; j < sl->n; j++) {
      Obj *o = &sl->o[j];
      char *e = malloc(strlen(o->text) * 2 + 4);
      esc_text(o->text, e, (int)strlen(o->text) * 2 + 4);
      PUT("o\t%d\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n", o->type, o->x, o->y, o->w,
          o->h, o->size, o->bold, o->ital, o->under, o->align, o->valign, o->color, o->fill, o->line, o->bullets, o->ph, e);
      free(e);
    }
  }
#undef PUT
  return s;
}

static int parse_obj(const char *line, Obj *o) {
  float f[5];
  int v[11];
  const char *q = line;
  char *e;
  memset(o, 0, sizeof *o);
  v[0] = (int)strtol(q, &e, 10);
  if (*e != '\t') return 0;
  q = e + 1;
  for (int i = 0; i < 5; i++) {
    f[i] = strtof(q, &e);
    if (*e != '\t') return 0;
    q = e + 1;
  }
  for (int i = 1; i < 11; i++) {
    v[i] = (int)strtol(q, &e, 10);
    if (*e != '\t') return 0;
    q = e + 1;
  }
  o->type = (unsigned char)(v[0] >= 0 && v[0] <= O_EMBED ? v[0] : 0);
  o->x = f[0], o->y = f[1], o->w = f[2], o->h = f[3], o->size = f[4] < 8 ? 8 : f[4] > 200 ? 200 : f[4];
  o->bold = (unsigned char)v[1], o->ital = (unsigned char)v[2], o->under = (unsigned char)v[3];
  o->align = (unsigned char)(v[4] % 3), o->valign = (unsigned char)(v[5] % 3);
  o->color = (unsigned char)(v[6] & 15), o->fill = (unsigned char)(v[7] & 15), o->line = (unsigned char)(v[8] & 15);
  o->bullets = (unsigned char)v[9], o->ph = (unsigned char)(v[10] % 3);
  o->text = unesc(q);
  return 1;
}

static void parse_deck(const char *src, Slide **a, int *n, int *cap, char *title, int tn, int *cur) {
  const char *s = src;
  while (s && *s) {
    const char *nl = strchr(s, '\n');
    int len = nl ? (int)(nl - s) : (int)strlen(s);
    char *line = malloc((size_t)len + 1);
    memcpy(line, s, (size_t)len);
    line[len] = 0;
    if (!strncmp(line, "title\t", 6)) snprintf(title, (size_t)tn, "%.95s", line + 6);
    else if (!strncmp(line, "cur\t", 4)) {
      if (cur) *cur = atoi(line + 4);
    } else if (line[0] == 's' && line[1] == '\t' && *n < MAXSLIDES) {
      if (*n == *cap) {
        *cap = *cap ? *cap * 2 : 16;
        *a = realloc(*a, sizeof(Slide) * (size_t)*cap);
      }
      memset(&(*a)[*n], 0, sizeof(Slide));
      (*a)[*n].bg = (unsigned char)(atoi(line + 2) & 15);
      (*n)++;
    } else if (line[0] == 'o' && line[1] == '\t' && *n > 0) {
      Obj tmp;
      if (parse_obj(line + 2, &tmp)) {
        Obj *o = obj_add(&(*a)[*n - 1]);
        if (o) {
          free(o->text);
          *o = tmp;
        } else free(tmp.text);
      }
    }
    free(line);
    s += len + (nl ? 1 : 0);
  }
}

static void deserialize(const char *src) {
  deck_clear();
  D.title[0] = 0;
  int cur = 0, n = 0, cap = 0;
  Slide *a = NULL;
  parse_deck(src, &a, &n, &cap, D.title, sizeof D.title, &cur);
  for (int i = 0; i < n; i++) D.sl[i] = a[i];
  D.ns = n;
  free(a);
  if (!D.title[0]) snprintf(D.title, sizeof D.title, "Untitled presentation");
  D.cur = cur < 0 ? 0 : cur;
  if (D.ns == 0) {
    memset(&D.sl[0], 0, sizeof(Slide));
    D.ns = 1;
  }
  if (D.cur >= D.ns) D.cur = D.ns - 1;
}

static void decks_dir(char *out, size_t n) { office_dirs(out, n, "Slides", "OREONVR_SLIDES_DIR"); }

static void deck_path(const char *id, char *out, size_t n) {
  char d[512];
  decks_dir(d, sizeof d);
  snprintf(out, n, "%s/%s.oslides", d, id);
}

static void save_deck(void) {
  if (!D.id[0]) return;
  char d[512], path[700], tmp[720];
  decks_dir(d, sizeof d);
  office_mkdirs(d);
  deck_path(D.id, path, sizeof path);
  snprintf(tmp, sizeof tmp, "%s.tmp", path);
  char *s = serialize();
  FILE *f = fopen(tmp, "w");
  if (f) {
    fputs(s, f);
    fclose(f);
    rename(tmp, path);
  }
  free(s);
  D.dirty = 0;
}

void slides_save_now(void) {
  D.editing = 0;
  if (D.dirty) save_deck();
}

static void scan_list(void) {
  for (int i = 0; i < D.nlist; i++) slide_free(&D.list[i].first);
  D.nlist = 0;
  char d[512];
  decks_dir(d, sizeof d);
  DIR *dir = opendir(d);
  if (!dir) return;
  struct dirent *e;
  while ((e = readdir(dir)) && D.nlist < MAXDECKS) {
    size_t l = strlen(e->d_name);
    if (l < 9 || strcmp(e->d_name + l - 8, ".oslides")) continue;
    DeckInfo *di = &D.list[D.nlist];
    memset(di, 0, sizeof *di);
    snprintf(di->id, sizeof di->id, "%.*s", (int)(l - 8), e->d_name);
    char path[700];
    deck_path(di->id, path, sizeof path);
    struct stat st;
    di->mtime = stat(path, &st) ? 0 : (long)st.st_mtime;
    snprintf(di->title, sizeof di->title, "Untitled presentation");
    char *body = office_read_file(path);
    if (body) {
      char *q = body;
      while (*q) {
        char *nl = strchr(q, '\n');
        int len = nl ? (int)(nl - q) : (int)strlen(q);
        if (nl) *nl = 0;
        if (!strncmp(q, "title\t", 6)) snprintf(di->title, sizeof di->title, "%.95s", q + 6);
        else if (q[0] == 's' && q[1] == '\t') {
          di->nslides++;
          if (di->nslides == 1) di->first.bg = (unsigned char)(atoi(q + 2) & 15);
        } else if (q[0] == 'o' && q[1] == '\t' && di->nslides == 1) {
          Obj tmp;
          if (parse_obj(q + 2, &tmp)) {
            Obj *o = obj_add(&di->first);
            if (o) {
              free(o->text);
              *o = tmp;
            } else free(tmp.text);
          }
        }
        q += len + (nl ? 1 : 0);
      }
      free(body);
    }
    D.nlist++;
  }
  closedir(dir);
  for (int i = 1; i < D.nlist; i++)
    for (int j = i; j > 0 && D.list[j].mtime > D.list[j - 1].mtime; j--) {
      DeckInfo t = D.list[j];
      D.list[j] = D.list[j - 1];
      D.list[j - 1] = t;
    }
}

static void clear_history(void) {
  for (int i = 0; i < D.nundo; i++) free(D.undo[i]);
  for (int i = 0; i < D.nredo; i++) free(D.redo[i]);
  D.nundo = D.nredo = 0;
}

static void changed(void) {
  D.dirty = 1;
  D.dirty_at = now_ms();
}

static void push_undo(void) {
  if (D.nundo == MAXUNDO) {
    free(D.undo[0]);
    memmove(D.undo, D.undo + 1, sizeof(char *) * (MAXUNDO - 1));
    D.nundo--;
  }
  D.undo[D.nundo++] = serialize();
  for (int i = 0; i < D.nredo; i++) free(D.redo[i]);
  D.nredo = 0;
}

static void undo_redo(int redo) {
  char **from = redo ? D.redo : D.undo, **to = redo ? D.undo : D.redo;
  int *nf = redo ? &D.nredo : &D.nundo, *nt = redo ? &D.nundo : &D.nredo;
  if (!*nf) return;
  if (*nt == MAXUNDO) {
    free(to[0]);
    memmove(to, to + 1, sizeof(char *) * (MAXUNDO - 1));
    (*nt)--;
  }
  to[(*nt)++] = serialize();
  char *s = from[--(*nf)];
  char title[96];
  snprintf(title, sizeof title, "%s", D.title);
  deserialize(s);
  snprintf(D.title, sizeof D.title, "%s", title);
  free(s);
  D.sel = -1;
  D.editing = 0;
  changed();
}

static Obj *mk_text(Slide *s, float x, float y, float w, float h, float size, int bold, int align, int valign, int ph) {
  Obj *o = obj_add(s);
  if (!o) return NULL;
  o->type = O_TEXT;
  o->x = x, o->y = y, o->w = w, o->h = h, o->size = size;
  o->bold = (unsigned char)bold, o->align = (unsigned char)align, o->valign = (unsigned char)valign, o->ph = (unsigned char)ph;
  return o;
}

static void apply_layout(Slide *s, int layout) {
  switch (layout) {
  case 0:
    mk_text(s, 120, 250, 1200, 160, 66, 1, AL_CENTER, VA_BOT, PH_TITLE);
    {
      Obj *o = mk_text(s, 120, 430, 1200, 100, 32, 0, AL_CENTER, VA_TOP, PH_BODY);
      if (o) o->color = 3;
    }
    break;
  case 1:
    mk_text(s, 96, 60, 1248, 130, 50, 1, AL_LEFT, VA_MID, PH_TITLE);
    {
      Obj *o = mk_text(s, 96, 210, 1248, 540, 30, 0, AL_LEFT, VA_TOP, PH_BODY);
      if (o) o->bullets = 1;
    }
    break;
  case 2:
    mk_text(s, 96, 290, 1248, 140, 60, 1, AL_LEFT, VA_BOT, PH_TITLE);
    {
      Obj *o = mk_text(s, 96, 450, 1248, 90, 28, 0, AL_LEFT, VA_TOP, PH_BODY);
      if (o) o->color = 3;
    }
    break;
  case 3:
    mk_text(s, 96, 60, 1248, 130, 50, 1, AL_LEFT, VA_MID, PH_TITLE);
    for (int i = 0; i < 2; i++) {
      Obj *o = mk_text(s, 96 + i * 640, 210, 608, 540, 28, 0, AL_LEFT, VA_TOP, PH_BODY);
      if (o) o->bullets = 1;
    }
    break;
  case 4: mk_text(s, 96, 60, 1248, 130, 50, 1, AL_LEFT, VA_MID, PH_TITLE); break;
  }
}

static void stop_present(void);
static void end_edit(void);
static void export_pptx(void);

static void reset_view(void) {
  D.sel = -1;
  D.editing = 0;
  D.popup = 0;
  D.title_edit = 0;
  stop_present();
  D.strip_scroll = 0;
  clear_history();
}

static void open_deck(const char *idp) {
  char id[40];
  snprintf(id, sizeof id, "%s", idp);
  if (D.dirty) save_deck();
  char path[700];
  deck_path(id, path, sizeof path);
  char *body = office_read_file(path);
  snprintf(D.id, sizeof D.id, "%s", id);
  deserialize(body ? body : "");
  free(body);
  reset_view();
}

static void new_deck(void) {
  if (D.dirty) save_deck();
  static int seq;
  snprintf(D.id, sizeof D.id, "deck%ld%03d", (long)time(NULL), (seq++ + rand()) % 1000);
  deck_clear();
  snprintf(D.title, sizeof D.title, "Untitled presentation");
  memset(&D.sl[0], 0, sizeof(Slide));
  D.ns = 1;
  D.cur = 0;
  apply_layout(&D.sl[0], 0);
  reset_view();
  save_deck();
}

const char *slides_title(void) { return D.title; }

static Slide *cur_slide(void) { return &D.sl[D.cur]; }

static Obj *sel_obj(void) {
  Slide *s = cur_slide();
  return D.sel >= 0 && D.sel < s->n ? &s->o[D.sel] : NULL;
}

static float canvas_k(void) {
  float aw = OFF_W - 16 - CANVAS_X, ah = content_h() - 16 - BODY_Y;
  float k = aw / SW;
  if (SH * k > ah) k = ah / SH;
  return k;
}

static void canvas_rect(float *x, float *y, float *k) {
  float kk = canvas_k();
  float aw = OFF_W - 16 - CANVAS_X, ah = content_h() - 16 - BODY_Y;
  *k = kk;
  *x = CANVAS_X + (aw - SW * kk) / 2;
  *y = BODY_Y + (ah - SH * kk) / 2;
}

static void to_units(float x, float y, float *ux, float *uy) {
  float cx, cy, k;
  canvas_rect(&cx, &cy, &k);
  *ux = (x - cx) / k, *uy = (y - cy) / k;
}

typedef struct {
  int id;
  float x, w;
} Tool;

static Tool tools[T_COUNT];
static float seps[10];
static int nseps;
static float pill_x, pill_w;

static void tool_layout(void) {
  static const int order[] = {T_UNDO, T_REDO, 0, T_SLIDE, 0, T_TEXT, T_RECT, T_ELLIPSE, T_EMBED, 0, T_SIZEM, T_SIZE, T_SIZEP, 0,
                              T_BOLD, T_ITAL, T_UNDER, T_COLOR, T_FILL, 0, T_ALEFT, T_ACENTER, T_ARIGHT, T_BULLET, 0, T_FRONT, T_BACK};
  float x = 0;
  nseps = 0;
  for (unsigned i = 0; i < sizeof order / sizeof *order; i++) {
    if (!order[i]) {
      seps[nseps++] = x + 5;
      x += 12;
      continue;
    }
    float w = order[i] == T_SIZE ? 40 : order[i] == T_SLIDE ? 44 : 34;
    tools[order[i]] = (Tool){order[i], x, w};
    x += w + 3;
  }
  float off = (OFF_W - x) * 0.5f;
  for (int i = 1; i < T_COUNT; i++) tools[i].x += off;
  for (int i = 0; i < nseps; i++) seps[i] += off;
  pill_x = off - 10, pill_w = x + 17;
}

static float present_w(void) { return gfx_text_w(F_UI_MED, "Present") + 50; }

static float menu_x(int i) {
  float total = 0;
  for (int k = 0; k < 5; k++) total += gfx_text_w(F_UI, MENU_NAMES[k]) + 22;
  float x = OFF_W - 18 - present_w() - 14 - total + 11;
  for (int k = 0; k < i; k++) x += gfx_text_w(F_UI, MENU_NAMES[k]) + 22;
  return x;
}

static void popup_rect(float *x, float *y, float *w, float *h) {
  if (D.popup >= POP_M0 && D.popup <= POP_M4) {
    int m = D.popup - POP_M0;
    *x = menu_x(m) - 10, *y = OFF_HEAD - 4, *w = 280;
    if (*x > OFF_W - 292) *x = OFF_W - 292;
    float hh = 8;
    for (int i = 0; i < MENU_LEN[m]; i++) hh += MENUS[m][i].label ? 34 : 9;
    *h = hh;
  } else if (D.popup == POP_LAYOUT) {
    *x = tools[T_SLIDE].x - 8, *y = OFF_TOOL_Y + OFF_TOOL_H + 2, *w = 3 * 132 + 20, *h = 2 * 116 + 44;
  } else {
    int t = D.popup == POP_COLOR ? T_COLOR : T_FILL;
    *x = D.popup == POP_BG ? tools[T_SLIDE].x - 8 : tools[t].x - 8;
    *y = OFF_TOOL_Y + OFF_TOOL_H + 2, *w = 8 * 40 + 24, *h = 2 * 40 + 46;
  }
}

static int popup_zone(float x, float y) {
  float px, py, pw, ph;
  popup_rect(&px, &py, &pw, &ph);
  if (x < px || x >= px + pw || y < py || y >= py + ph) return -1;
  if (D.popup <= POP_M4) {
    int m = D.popup - POP_M0;
    float yy = py + 4;
    for (int i = 0; i < MENU_LEN[m]; i++) {
      float hh = MENUS[m][i].label ? 34 : 9;
      if (y >= yy && y < yy + hh) return MENUS[m][i].label ? Z_POPUP + i : 0;
      yy += hh;
    }
    return 0;
  }
  if (D.popup == POP_LAYOUT) {
    for (int i = 0; i < 6; i++) {
      float cx = px + 10 + (i % 3) * 132, cy = py + 36 + (i / 3) * 116;
      if (x >= cx && x < cx + 124 && y >= cy && y < cy + 110) return Z_POPUP + i;
    }
    return 0;
  }
  for (int i = 0; i < 16; i++) {
    float cx = px + 12 + (i % 8) * 40, cy = py + 36 + (i / 8) * 40;
    if (x >= cx && x < cx + 36 && y >= cy && y < cy + 36) return Z_POPUP + i;
  }
  return 0;
}

static void handle_pos(const Obj *o, int i, float *hx, float *hy) {
  float xs[3] = {o->x, o->x + o->w / 2, o->x + o->w}, ys[3] = {o->y, o->y + o->h / 2, o->y + o->h};
  static const int map[8][2] = {{0, 0}, {1, 0}, {2, 0}, {2, 1}, {2, 2}, {1, 2}, {0, 2}, {0, 1}};
  *hx = xs[map[i][0]], *hy = ys[map[i][1]];
}

static int strip_slide(float y) {
  float sy = BODY_Y + 8 - D.strip_scroll;
  int i = (int)floorf((y - sy) / 92);
  return i >= 0 && i < D.ns ? i : -1;
}

static int hit_obj(float ux, float uy) {
  Slide *s = cur_slide();
  for (int i = s->n - 1; i >= 0; i--) {
    Obj *o = &s->o[i];
    if (ux >= o->x && ux < o->x + o->w && uy >= o->y && uy < o->y + o->h) {
      if (o->type == O_ELLIPSE) {
        float dx = (ux - (o->x + o->w / 2)) / (o->w / 2), dy = (uy - (o->y + o->h / 2)) / (o->h / 2);
        if (dx * dx + dy * dy > 1) continue;
      }
      return i;
    }
  }
  return -1;
}

int slides_zone(float x, float y) {
  if (D.popup) {
    int z = popup_zone(x, y);
    if (z >= 0) return z;
  }
  if (y < OFF_HEAD) {
    if (x >= 10 && x < 50 && y >= 8 && y < 48) return Z_HOME;
    float pw = present_w();
    if (x >= OFF_W - 18 - pw && x < OFF_W - 18 && y >= 12 && y < 44) return Z_PRESENT;
    if (x >= 56 && x < 56 + 360 && y >= 10 && y < 46) return Z_TITLE;
    for (int i = 0; i < 5; i++) {
      float mx = menu_x(i);
      if (x >= mx - 10 && x < mx + gfx_text_w(F_UI, MENU_NAMES[i]) + 10 && y >= 12 && y < 44) return Z_MENU + i;
    }
    return 0;
  }
  if (y >= OFF_TOOL_Y && y < OFF_TOOL_Y + OFF_TOOL_H && x >= pill_x && x < pill_x + pill_w) {
    for (int i = 1; i < T_COUNT; i++)
      if (x >= tools[i].x && x < tools[i].x + tools[i].w && y >= OFF_TOOL_Y + 5 && y < OFF_TOOL_Y + OFF_TOOL_H - 5) return i;
    return 0;
  }
  if (x >= STRIP_X && x < STRIP_X + STRIP_W && y >= BODY_Y) {
    int i = strip_slide(y);
    return i >= 0 ? Z_THUMB + i : Z_STRIP;
  }
  if (x >= CANVAS_X && y >= BODY_Y) {
    Obj *o = sel_obj();
    if (o && !D.editing) {
      float cx, cy, k;
      canvas_rect(&cx, &cy, &k);
      for (int i = 0; i < 8; i++) {
        float hx, hy;
        handle_pos(o, i, &hx, &hy);
        if (fabsf(x - (cx + hx * k)) <= 8 && fabsf(y - (cy + hy * k)) <= 8) return Z_HANDLE + i;
      }
    }
    return Z_AREA;
  }
  return 0;
}

static void icon_lines(Surface *s, float cx, float cy, int align, uint32_t c) {
  float ws[4] = {16, 11, 16, 11};
  for (int i = 0; i < 4; i++) {
    float w = ws[i], x0 = align == AL_LEFT ? cx - 8 : align == AL_CENTER ? cx - w / 2 : cx + 8 - w;
    gfx_rect(s, x0, cy - 7 + i * 4.6f, w, 1.8f, c);
  }
}

static float cur_size(void) {
  Obj *o = sel_obj();
  return o ? o->size : 0;
}

static void stroke_rrect(Surface *s, float x, float y, float w, float h, float r, float th, uint32_t c, uint32_t bg) {
  gfx_rrect(s, x, y, w, h, r, c);
  gfx_rrect(s, x + th, y + th, w - 2 * th, h - 2 * th, r - th > 0 ? r - th : 0, bg);
}

static void draw_tool(Surface *s, int id, float ox, float oy, int hot) {
  Tool *t = &tools[id];
  float x = ox + t->x, y = oy + OFF_TOOL_Y + 5, h = OFF_TOOL_H - 10, cx = x + t->w / 2, cy = y + h / 2;
  Obj *o = sel_obj();
  int active = 0;
  if (o) {
    if (id == T_BOLD) active = o->bold;
    else if (id == T_ITAL) active = o->ital;
    else if (id == T_UNDER) active = o->under;
    else if (id == T_ALEFT) active = o->align == AL_LEFT;
    else if (id == T_ACENTER) active = o->align == AL_CENTER;
    else if (id == T_ARIGHT) active = o->align == AL_RIGHT;
    else if (id == T_BULLET) active = o->bullets;
  }
  if ((id == T_COLOR && D.popup == POP_COLOR) || (id == T_FILL && D.popup == POP_FILL) || (id == T_SLIDE && D.popup == POP_LAYOUT)) active = 1;
  int dim = !o && (id >= T_SIZEM && id <= T_BACK);
  uint32_t ic = active ? P_ACC : dim ? C_MUTED : N_ICON;
  uint32_t bg = N_PAGE;
  if (active) gfx_rrect(s, x, y, t->w, h, 9, bg = P_TINT);
  else if (hot && !dim && id != T_SIZE) gfx_rrect(s, x, y, t->w, h, 9, bg = N_TINT_HOT);
  uint32_t soft = active ? RGBA(222, 96, 24, 60) : THEME(RGBA(64, 64, 72, 40), RGBA(220, 222, 230, 50));
  const Font *df = doc_font(0, 0, 0), *bf = doc_font(0, 1, 0), *itf = doc_font(0, 0, 1);
  float ty = y + (h - line_h(df)) / 2;
  switch (id) {
  case T_UNDO:
  case T_REDO: {
    float d = id == T_UNDO ? 1.f : -1.f, r = 6.f, acx = cx + d * 1.f, acy = cy + 3.f;
    for (int i = 0; i < 10; i++) {
      float a0 = PI_F + PI_F * i / 10.f, a1 = PI_F + PI_F * (i + 1) / 10.f;
      gfx_line(s, acx + cosf(a0) * r * d, acy + sinf(a0) * r, acx + cosf(a1) * r * d, acy + sinf(a1) * r, 1.7f, ic);
    }
    float hx = acx - d * r, hy = acy;
    gfx_line(s, hx, hy + 0.6f, hx - d * 3.4f, hy - 3.4f, 1.7f, ic);
    gfx_line(s, hx, hy + 0.6f, hx + d * 3.6f, hy - 3.0f, 1.7f, ic);
    break;
  }
  case T_SLIDE:
    stroke_rrect(s, cx - 13, cy - 8, 20, 14, 3, 1.7f, ic, bg);
    gfx_rect(s, cx - 9.5f, cy - 4.5f, 9, 1.6f, ic);
    gfx_rect(s, cx - 9.5f, cy - 1.2f, 6, 1.6f, soft);
    gfx_disc(s, cx + 8, cy + 6, 6.2f, bg);
    gfx_disc(s, cx + 8, cy + 6, 5, ic);
    gfx_rect(s, cx + 5.5f, cy + 5.3f, 5, 1.4f, bg);
    gfx_rect(s, cx + 7.3f, cy + 3.5f, 1.4f, 5, bg);
    break;
  case T_TEXT:
    gfx_rect(s, cx - 7, cy - 7.5f, 14, 2, ic);
    gfx_rect(s, cx - 1, cy - 7.5f, 2, 15, ic);
    gfx_rect(s, cx - 3.5f, cy + 6, 7, 1.6f, ic);
    gfx_rect(s, cx - 7, cy - 7.5f, 1.8f, 4, ic);
    gfx_rect(s, cx + 5.2f, cy - 7.5f, 1.8f, 4, ic);
    break;
  case T_RECT:
    stroke_rrect(s, cx - 9, cy - 7, 18, 14, 3, 1.7f, ic, bg);
    gfx_rrect(s, cx - 7.3f, cy - 5.3f, 14.6f, 10.6f, 1.5f, soft);
    break;
  case T_ELLIPSE:
    gfx_disc(s, cx, cy, 7.3f, soft);
    gfx_ring(s, cx, cy, 8.1f, 1.7f, ic);
    break;
  case T_EMBED: {
    uint32_t a = active || hot ? P_ACC : ic;
    stroke_rrect(s, cx - 9, cy - 8, 13, 16, 2.5f, 1.6f, ic, bg);
    gfx_rect(s, cx - 6, cy - 4, 7, 1.4f, ic);
    gfx_rect(s, cx - 6, cy - 1, 5, 1.4f, ic);
    gfx_rrect(s, cx - 1, cy - 1, 11, 10, 2.5f, bg);
    gfx_rrect(s, cx + 0.5f, cy + 0.5f, 9, 8, 2, a);
    gfx_rect(s, cx + 2.5f, cy + 3.8f, 5, 1.3f, bg);
    gfx_rect(s, cx + 4.35f, cy + 2, 1.3f, 5, bg);
    break;
  }
  case T_SIZEM:
    gfx_text_c(s, df, cx - 3, ty, "A", ic);
    gfx_rect(s, cx + 5, cy - 6, 6, 1.6f, ic);
    break;
  case T_SIZEP:
    gfx_text_c(s, df, cx - 3, ty, "A", ic);
    gfx_rect(s, cx + 5, cy - 6, 6, 1.6f, ic);
    gfx_rect(s, cx + 7.2f, cy - 8.2f, 1.6f, 6, ic);
    break;
  case T_SIZE: {
    gfx_rrect(s, x + 2, y + 3, t->w - 4, h - 6, 6, THEME(RGB(236, 234, 240), RGB(48, 50, 58)));
    char b[8];
    if (o) snprintf(b, sizeof b, "%d", (int)(cur_size() + 0.5f));
    else snprintf(b, sizeof b, "-");
    gfx_text_c(s, F_UI_MED, cx, cy - line_h(F_UI_MED) / 2, b, o ? C_TEXT : C_MUTED);
    break;
  }
  case T_BOLD: gfx_text_c(s, bf, cx, ty, "B", ic); break;
  case T_ITAL: gfx_text_c(s, itf, cx, ty, "I", ic); break;
  case T_UNDER:
    gfx_text_c(s, df, cx, ty - 2, "U", ic);
    gfx_rect(s, cx - 6, cy + 8, 12, 1.6f, ic);
    break;
  case T_COLOR:
    gfx_text_c(s, df, cx, ty - 3, "A", ic);
    gfx_rect(s, cx - 8, cy + 8, 16, 3, o && o->color ? PAL[o->color] : N_ICON);
    break;
  case T_FILL: {
    float bx = cx - 2, by = cy - 2;
    gfx_line(s, bx - 6, by, bx, by - 6, 1.7f, ic);
    gfx_line(s, bx, by - 6, bx + 6, by, 1.7f, ic);
    gfx_line(s, bx + 6, by, bx, by + 6, 1.7f, ic);
    gfx_line(s, bx, by + 6, bx - 6, by, 1.7f, ic);
    gfx_tri(s, bx - 5, by + 0.6f, bx + 5, by + 0.6f, bx, by + 5.4f, soft);
    gfx_line(s, bx - 3, by - 9, bx, by - 6, 1.5f, ic);
    gfx_disc(s, cx + 8, cy + 1.5f, 2.1f, ic);
    gfx_tri(s, cx + 6, cy + 1, cx + 10, cy + 1, cx + 8, cy - 2.5f, ic);
    gfx_rrect(s, cx - 9, cy + 8, 18, 3.2f, 1.6f, o && o->fill ? PAL[o->fill] : THEME(RGB(200, 200, 206), RGB(90, 92, 100)));
    break;
  }
  case T_ALEFT: icon_lines(s, cx, cy, AL_LEFT, ic); break;
  case T_ACENTER: icon_lines(s, cx, cy, AL_CENTER, ic); break;
  case T_ARIGHT: icon_lines(s, cx, cy, AL_RIGHT, ic); break;
  case T_BULLET:
    for (int i = 0; i < 3; i++) {
      gfx_disc(s, cx - 6, cy - 6 + i * 6, 1.6f, ic);
      gfx_rect(s, cx - 2, cy - 6.8f + i * 6, 10, 1.6f, ic);
    }
    break;
  case T_FRONT:
  case T_BACK: {
    int f = id == T_FRONT;
    float lx = cx - 4, ly0 = cy - 7;
    for (int k = 2; k >= 0; k--) {
      int top = f ? k == 0 : k == 2;
      float yy = ly0 + k * 4.6f;
      gfx_rrect(s, lx - 7, yy - 1.2f, 14, 7.4f, 2.4f, bg);
      if (top) gfx_rrect(s, lx - 6, yy, 12, 5, 1.8f, ic);
      else stroke_rrect(s, lx - 6, yy, 12, 5, 1.8f, 1.4f, ic, bg);
    }
    float ax = cx + 7.5f, ay0 = f ? cy + 5 : cy - 5, ay1 = f ? cy - 6 : cy + 6, d = f ? 1.f : -1.f;
    gfx_line(s, ax, ay0, ax, ay1, 1.6f, ic);
    gfx_line(s, ax, ay1, ax - 3, ay1 + 3 * d, 1.6f, ic);
    gfx_line(s, ax, ay1, ax + 3, ay1 + 3 * d, 1.6f, ic);
    break;
  }
  }
}

static void draw_popup(Surface *s, float ox, float oy, int hot) {
  float px, py, pw, ph;
  popup_rect(&px, &py, &pw, &ph);
  px += ox, py += oy;
  gfx_shadow(s, px, py + 6, pw, ph, 14, 22, RGBA(30, 28, 60, 50));
  gfx_rrect(s, px - 1, py - 1, pw + 2, ph + 2, 15, THEME(RGB(230, 228, 236), RGB(58, 60, 68)));
  gfx_rrect(s, px, py, pw, ph, 14, THEME(RGB(255, 255, 255), RGB(40, 42, 50)));
  if (D.popup <= POP_M4) {
    int m = D.popup - POP_M0;
    float y = py + 4;
    for (int i = 0; i < MENU_LEN[m]; i++) {
      const Item *it = &MENUS[m][i];
      if (!it->label) {
        gfx_rect(s, px + 10, y + 4, pw - 20, 1, N_LINE);
        y += 9;
        continue;
      }
      if (hot == Z_POPUP + i) gfx_rrect(s, px + 6, y + 1, pw - 12, 32, 8, N_TINT_HOT);
      gfx_text(s, F_UI, px + 18, y + (34 - line_h(F_UI)) / 2, it->label, C_TEXT);
      if (it->key[0]) gfx_text(s, F_SMALL, px + pw - 14 - gfx_text_w(F_SMALL, it->key), y + (34 - line_h(F_SMALL)) / 2, it->key, C_MUTED);
      y += 34;
    }
    return;
  }
  if (D.popup == POP_LAYOUT) {
    gfx_text(s, F_SMALL, px + 14, py + 12, "New slide", C_MUTED);
    for (int i = 0; i < 6; i++) {
      float cx = px + 10 + (i % 3) * 132, cy = py + 36 + (i / 3) * 116;
      if (hot == Z_POPUP + i) gfx_rrect(s, cx - 2, cy - 2, 128, 114, 10, P_TINT);
      Slide tmp = {0};
      apply_layout(&tmp, i);
      for (int j = 0; j < tmp.n; j++) {
        free(tmp.o[j].text);
        tmp.o[j].text = strdup(tmp.o[j].ph == PH_TITLE ? "Title" : tmp.o[j].bullets ? "Point one\nPoint two" : "Subtitle");
        if (tmp.o[j].ph == PH_BODY && !tmp.o[j].bullets) tmp.o[j].color = 3;
      }
      gfx_rrect(s, cx + 2, cy + 4, 120, 69, 4, THEME(RGB(220, 218, 226), RGB(60, 62, 70)));
      gfx_clip(s, cx + 3, cy + 5, 118, 67);
      render_slide(s, &tmp, cx + 3, cy + 5, 118.f / SW, 1, -1, -1);
      gfx_noclip(s);
      slide_free(&tmp);
      gfx_text_fit(s, F_SMALL, cx + 4, cy + 80, 120, LAYOUT_NAMES[i], C_TEXT);
    }
    return;
  }
  const char *lab = D.popup == POP_COLOR ? "Text color" : D.popup == POP_FILL ? "Shape fill" : "Slide background";
  gfx_text(s, F_SMALL, px + 14, py + 12, lab, C_MUTED);
  Obj *o = sel_obj();
  int cur = D.popup == POP_COLOR ? (o ? o->color : 0) : D.popup == POP_FILL ? (o ? o->fill : 0) : cur_slide()->bg;
  for (int i = 0; i < 16; i++) {
    float cx = px + 12 + (i % 8) * 40, cy = py + 36 + (i / 8) * 40;
    if (hot == Z_POPUP + i) gfx_rrect(s, cx - 2, cy - 2, 36, 36, 9, N_TINT_HOT);
    gfx_rrect(s, cx + 2, cy + 2, 28, 28, 7, THEME(RGB(220, 218, 226), RGB(70, 72, 80)));
    if (i == 0) {
      gfx_rrect(s, cx + 3, cy + 3, 26, 26, 6, THEME(RGB(255, 255, 255), RGB(40, 42, 50)));
      gfx_line(s, cx + 6, cy + 26, cx + 26, cy + 6, 1.4f, RGB(217, 48, 37));
    } else gfx_rrect(s, cx + 3, cy + 3, 26, 26, 6, PAL[i]);
    if (cur == i) gfx_ring(s, cx + 16, cy + 16, 16, 2, P_ACC);
  }
}

static void draw_strip(Surface *s, float ox, float oy, int hot) {
  float x0 = ox + STRIP_X, y0 = oy + BODY_Y, h = content_h() - 16 - BODY_Y;
  gfx_clip(s, x0 - 4, y0, STRIP_W + 8, h);
  float tw = STRIP_W - 36, th = tw * SH / SW;
  for (int i = 0; i < D.ns; i++) {
    float y = y0 + 8 + i * 92 - D.strip_scroll;
    if (y > y0 + h || y + 92 < y0) continue;
    float tx = x0 + 30;
    int on = i == D.cur;
    char n[16];
    snprintf(n, sizeof n, "%d", i + 1);
    gfx_text_c(s, F_SMALL, x0 + 12, y + 2, n, on ? P_ACC : C_MUTED);
    if (on) gfx_rrect(s, tx - 3, y - 3, tw + 6, th + 6, 8, P_ACC);
    else if (hot == Z_THUMB + i) gfx_rrect(s, tx - 2, y - 2, tw + 4, th + 4, 7, THEME(RGB(210, 208, 216), RGB(70, 72, 80)));
    else gfx_shadow(s, tx, y + 2, tw, th, 4, 6, RGBA(30, 28, 60, 30));
    gfx_rect(s, tx, y, tw, th, N_PAGE);
    gfx_clip(s, tx, y > y0 ? y : y0, tw, th);
    render_slide(s, &D.sl[i], tx, y, tw / SW, 1, -1, -1);
    gfx_clip(s, x0 - 4, y0, STRIP_W + 8, h);
  }
  gfx_noclip(s);
}

static void draw_selection(Surface *s, const Obj *o, float cx, float cy, float k, int hot) {
  float x = cx + o->x * k, y = cy + o->y * k, w = o->w * k, h = o->h * k;
  uint32_t c = P_ACC;
  if (D.editing) {
    for (float xx = x; xx < x + w; xx += 8) gfx_rect(s, xx, y - 1, 4, 1.5f, c), gfx_rect(s, xx, y + h - 0.5f, 4, 1.5f, c);
    for (float yy = y; yy < y + h; yy += 8) gfx_rect(s, x - 1, yy, 1.5f, 4, c), gfx_rect(s, x + w - 0.5f, yy, 1.5f, 4, c);
    return;
  }
  gfx_rect(s, x, y - 1, w, 1.6f, c);
  gfx_rect(s, x, y + h - 0.6f, w, 1.6f, c);
  gfx_rect(s, x - 1, y, 1.6f, h, c);
  gfx_rect(s, x + w - 0.6f, y, 1.6f, h, c);
  for (int i = 0; i < 8; i++) {
    float hx, hy;
    handle_pos(o, i, &hx, &hy);
    float px = cx + hx * k, py = cy + hy * k;
    gfx_disc(s, px, py, hot == Z_HANDLE + i ? 7 : 5.5f, c);
    gfx_disc(s, px, py, hot == Z_HANDLE + i ? 5 : 3.8f, RGB(255, 255, 255));
  }
}

void slides_draw(Panel *p, Surface *s, float ox, float oy, int hot) {
  (void)p;
  float ch = content_h();
  gfx_rect(s, ox, oy, OFF_W, ch, N_CANVAS);
  draw_strip(s, ox, oy, hot);
  float cx, cy, k;
  canvas_rect(&cx, &cy, &k);
  cx += ox, cy += oy;
  gfx_shadow(s, cx, cy + 8, SW * k, SH * k, 6, 26, RGBA(30, 28, 60, 40));
  gfx_clip(s, cx, cy, SW * k, SH * k);
  render_slide(s, cur_slide(), cx, cy, k, 0, D.editing ? D.sel : -1, D.caret);
  if (D.drag == 1 && D.snapx) gfx_rect(s, cx + SW / 2 * k - 0.5f, cy, 1, SH * k, P_ACC);
  if (D.drag == 1 && D.snapy) gfx_rect(s, cx, cy + SH / 2 * k - 0.5f, SW * k, 1, P_ACC);
  gfx_noclip(s);
  Obj *o = sel_obj();
  if (o) draw_selection(s, o, cx, cy, k, hot);
  gfx_rect(s, ox, oy, OFF_W, OFF_HEAD, N_HEAD);
  gfx_rect(s, ox, oy + OFF_HEAD - 1, OFF_W, 1, N_LINE);
  if (hot == Z_HOME) gfx_rrect(s, ox + 12, oy + 10, 36, 36, 10, N_TINT_HOT);
  gfx_line(s, ox + 33, oy + 20, ox + 26, oy + 28, 2.2f, N_ICON);
  gfx_line(s, ox + 26, oy + 28, ox + 33, oy + 36, 2.2f, N_ICON);
  if (D.title_edit) {
    float tw = gfx_text_w(F_UI_MED, D.title_buf), bw = tw + 28 > 260 ? tw + 28 : 260;
    gfx_rrect(s, ox + 56, oy + 12, bw, 32, 9, P_ACC);
    gfx_rrect(s, ox + 57.5f, oy + 13.5f, bw - 3, 29, 8, N_PAGE);
    gfx_text(s, F_UI_MED, ox + 68, oy + 28 - line_h(F_UI_MED) / 2, D.title_buf, C_TEXT);
    if (D.blink) gfx_rect(s, ox + 69 + tw, oy + 19, 1.6f, 18, P_ACC);
  } else {
    float tw = gfx_text_w(F_UI_MED, D.title);
    if (tw > 340) tw = 340;
    if (hot == Z_TITLE) gfx_rrect(s, ox + 56, oy + 12, tw + 24, 32, 9, N_TINT_HOT);
    gfx_text_fit(s, F_UI_MED, ox + 68, oy + 28 - line_h(F_UI_MED) / 2, 340, D.title, C_TEXT);
  }
  for (int i = 0; i < 5; i++) {
    float mx = ox + menu_x(i);
    int open = D.popup == POP_M0 + i;
    if (open || hot == Z_MENU + i) gfx_rrect(s, mx - 10, oy + 12, gfx_text_w(F_UI, MENU_NAMES[i]) + 20, 32, 9, open ? P_TINT : N_TINT_HOT);
    gfx_text(s, F_UI, mx, oy + 28 - line_h(F_UI) / 2, MENU_NAMES[i], open ? P_ACC : C_TEXT);
  }
  float pw = present_w(), px = ox + OFF_W - 18 - pw;
  gfx_rrect(s, px, oy + 12, pw, 32, 16, hot == Z_PRESENT ? THEME(RGB(200, 82, 16), RGB(255, 170, 110)) : P_ACC);
  gfx_tri(s, px + 16, oy + 22, px + 16, oy + 34, px + 26, oy + 28, RGB(255, 255, 255));
  gfx_text(s, F_UI_MED, px + 34, oy + 28 - line_h(F_UI_MED) / 2, "Present", RGB(255, 255, 255));
  gfx_shadow(s, ox + pill_x, oy + OFF_TOOL_Y + 3, pill_w, OFF_TOOL_H, 22, 16, RGBA(30, 28, 60, 40));
  gfx_rrect(s, ox + pill_x - 1, oy + OFF_TOOL_Y - 1, pill_w + 2, OFF_TOOL_H + 2, 23, THEME(RGB(230, 228, 236), RGB(54, 56, 64)));
  gfx_rrect(s, ox + pill_x, oy + OFF_TOOL_Y, pill_w, OFF_TOOL_H, 22, N_PAGE);
  for (int i = 0; i < nseps; i++) gfx_rect(s, ox + seps[i], oy + OFF_TOOL_Y + 13, 1, OFF_TOOL_H - 26, THEME(RGB(226, 224, 230), RGB(66, 68, 76)));
  for (int i = 1; i < T_COUNT; i++) draw_tool(s, i, ox, oy, hot == i);
  char st[64];
  snprintf(st, sizeof st, "Slide %d of %d", D.cur + 1, D.ns);
  const char *saved = D.dirty ? "Saving" : "Saved";
  float sw = gfx_text_w(F_SMALL, saved), ww = gfx_text_w(F_SMALL, st);
  float bw = 28 + sw + 21 + ww + 14, bh = 30, bx = cx + SW * k - bw, by = cy + SH * k + 10;
  if (by + bh > oy + ch - 2) by = oy + ch - bh - 2;
  (void)bx;
  bx = ox + CANVAS_X + (OFF_W - 16 - CANVAS_X - bw) / 2;
  gfx_rrect(s, bx - 1, by - 1, bw + 2, bh + 2, 16, THEME(RGB(230, 228, 236), RGB(50, 52, 60)));
  gfx_rrect(s, bx, by, bw, bh, 15, N_HEAD);
  float sty = by + bh / 2 - line_h(F_SMALL) / 2;
  if (D.dirty) gfx_ring(s, bx + 16, by + bh / 2, 4, 1.6f, C_MUTED);
  else {
    gfx_line(s, bx + 12, by + bh / 2, bx + 15, by + bh / 2 + 3, 1.7f, P_ACC);
    gfx_line(s, bx + 15, by + bh / 2 + 3, bx + 20.5f, by + bh / 2 - 3.5f, 1.7f, P_ACC);
  }
  gfx_text(s, F_SMALL, bx + 28, sty, saved, C_MUTED);
  gfx_disc(s, bx + 28 + sw + 10, by + bh / 2, 1.5f, C_MUTED);
  gfx_text(s, F_SMALL, bx + 28 + sw + 21, sty, st, C_TEXT);
  if (D.popup) draw_popup(s, ox, oy, hot);
}

static void add_slide(int layout) {
  if (D.ns >= MAXSLIDES) return;
  push_undo();
  int at = D.cur + 1;
  memmove(&D.sl[at + 1], &D.sl[at], sizeof(Slide) * (size_t)(D.ns - at));
  memset(&D.sl[at], 0, sizeof(Slide));
  D.sl[at].bg = D.sl[D.cur].bg;
  D.ns++;
  apply_layout(&D.sl[at], layout);
  D.cur = at;
  D.sel = -1;
  D.editing = 0;
  float y = 8 + at * 92;
  float h = content_h() - 16 - BODY_Y;
  if (y - D.strip_scroll > h - 90) D.strip_scroll = y - h + 100;
  changed();
}

static void dup_slide(void) {
  if (D.ns >= MAXSLIDES) return;
  push_undo();
  int at = D.cur + 1;
  memmove(&D.sl[at + 1], &D.sl[at], sizeof(Slide) * (size_t)(D.ns - at));
  memset(&D.sl[at], 0, sizeof(Slide));
  Slide *src = &D.sl[D.cur];
  D.sl[at].bg = src->bg;
  for (int i = 0; i < src->n; i++) {
    Obj *o = obj_add(&D.sl[at]);
    if (!o) break;
    free(o->text);
    obj_copy(o, &src->o[i]);
  }
  D.ns++;
  D.cur = at;
  D.sel = -1;
  changed();
}

static void del_slide(void) {
  push_undo();
  slide_free(&D.sl[D.cur]);
  memmove(&D.sl[D.cur], &D.sl[D.cur + 1], sizeof(Slide) * (size_t)(D.ns - D.cur - 1));
  D.ns--;
  if (D.ns == 0) {
    memset(&D.sl[0], 0, sizeof(Slide));
    D.ns = 1;
  }
  if (D.cur >= D.ns) D.cur = D.ns - 1;
  D.sel = -1;
  D.editing = 0;
  changed();
}

static void move_slide(int d) {
  int to = D.cur + d;
  if (to < 0 || to >= D.ns) return;
  push_undo();
  Slide t = D.sl[D.cur];
  D.sl[D.cur] = D.sl[to];
  D.sl[to] = t;
  D.cur = to;
  changed();
}

static void insert_obj(int type) {
  push_undo();
  Slide *s = cur_slide();
  Obj *o = obj_add(s);
  if (!o) return;
  o->type = (unsigned char)type;
  o->size = 28;
  o->align = type == O_TEXT ? AL_LEFT : AL_CENTER;
  o->valign = type == O_TEXT ? VA_TOP : VA_MID;
  int k = s->n % 6;
  if (type == O_TEXT) o->x = 470 + k * 24, o->y = 330 + k * 24, o->w = 500, o->h = 120;
  else {
    o->x = 560 + k * 24, o->y = 255 + k * 24, o->w = 320, o->h = type == O_ELLIPSE ? 300 : 220;
    o->fill = 10;
  }
  D.sel = s->n - 1;
  D.editing = type == O_TEXT;
  D.caret = 0;
  if (D.editing) office_show_keyboard();
  changed();
}

static void del_obj(void) {
  Slide *s = cur_slide();
  if (D.sel < 0 || D.sel >= s->n) return;
  push_undo();
  obj_free(&s->o[D.sel]);
  memmove(&s->o[D.sel], &s->o[D.sel + 1], sizeof(Obj) * (size_t)(s->n - D.sel - 1));
  s->n--;
  D.sel = -1;
  D.editing = 0;
  changed();
}

static void dup_obj(int from_clip) {
  Slide *s = cur_slide();
  Obj *src = from_clip ? (D.has_clip ? &D.clip : NULL) : sel_obj();
  if (!src || s->n >= MAXOBJ) return;
  push_undo();
  Obj tmp;
  obj_copy(&tmp, src);
  tmp.x += 30, tmp.y += 30;
  tmp.ph = 0;
  Obj *o = obj_add(s);
  free(o->text);
  *o = tmp;
  D.sel = s->n - 1;
  D.editing = 0;
  if (from_clip) D.clip.x += 30, D.clip.y += 30;
  changed();
}

static void restack(int front) {
  Slide *s = cur_slide();
  if (D.sel < 0) return;
  push_undo();
  Obj o = s->o[D.sel];
  memmove(&s->o[D.sel], &s->o[D.sel + 1], sizeof(Obj) * (size_t)(s->n - D.sel - 1));
  if (front) {
    s->o[s->n - 1] = o;
    D.sel = s->n - 1;
  } else {
    memmove(&s->o[1], &s->o[0], sizeof(Obj) * (size_t)(s->n - 1));
    s->o[0] = o;
    D.sel = 0;
  }
  changed();
}

static void set_style(int which, int val) {
  Obj *o = sel_obj();
  if (!o) return;
  push_undo();
  switch (which) {
  case 0: o->bold = !o->bold; break;
  case 1: o->ital = !o->ital; break;
  case 2: o->under = !o->under; break;
  case 3: o->align = (unsigned char)val; break;
  case 4: o->bullets = !o->bullets; break;
  case 5: o->color = (unsigned char)val; break;
  case 6: o->fill = (unsigned char)val; break;
  case 7: {
    int i = 0;
    while (i < NSIZES && SIZES[i] < o->size - 0.1f) i++;
    if (val < 0) i = i > 0 ? i - 1 : 0;
    else {
      while (i < NSIZES && SIZES[i] <= o->size + 0.1f) i++;
      if (i >= NSIZES) i = NSIZES - 1;
    }
    o->size = SIZES[i];
    break;
  }
  }
  changed();
}

static void export_outline(void) {
  char dir[512], path[700], name[96];
  snprintf(dir, sizeof dir, "%s/Documents", user_home());
  office_mkdirs(dir);
  int k = 0;
  for (const char *t = D.title; *t && k < 80; t++) name[k++] = (isalnum((unsigned char)*t) || *t == '-' || *t == '_' || *t == ' ') ? *t : '_';
  name[k] = 0;
  if (!k) snprintf(name, sizeof name, "Untitled");
  snprintf(path, sizeof path, "%s/%s.txt", dir, name);
  FILE *f = fopen(path, "w");
  if (!f) {
    office_toast("Could not save the file");
    return;
  }
  for (int i = 0; i < D.ns; i++) {
    fprintf(f, "Slide %d\n", i + 1);
    for (int j = 0; j < D.sl[i].n; j++) {
      Obj *o = &D.sl[i].o[j];
      if (!o->text[0] || o->type == O_EMBED) continue;
      const char *t = o->text;
      while (*t) {
        const char *e = strchr(t, '\n');
        int l = e ? (int)(e - t) : (int)strlen(t);
        fprintf(f, "%s%.*s\n", o->bullets ? "  - " : "  ", l, t);
        t += l + (e ? 1 : 0);
      }
    }
    fputc('\n', f);
  }
  fclose(f);
  char m[200];
  snprintf(m, sizeof m, "Saved to Documents/%s.txt", name);
  office_toast(m);
}

static void begin_title_edit(void) {
  D.title_edit = 1;
  snprintf(D.title_buf, sizeof D.title_buf, "%s", D.title);
  office_show_keyboard();
}

static void commit_title(void) {
  if (!D.title_edit) return;
  D.title_edit = 0;
  char *t = D.title_buf;
  while (*t == ' ') t++;
  if (*t && strcmp(t, D.title)) {
    snprintf(D.title, sizeof D.title, "%s", t);
    save_deck();
    office_set_title();
  }
}

static struct {
  Surface cache;
  int ccur, cpend, cw, ch;
  uint32_t moved_at, start_at;
  float lmx, lmy;
  int bar_on;
} PR;

static float dlh(const Font *f) { return (float)(f->ascent + f->descent); }

static void dtext_c(Surface *s, const Font *f, float cx, float y, const char *t, uint32_t c) {
  gfx_text(s, f, cx - gfx_text_w(f, t) * SCALE / s->scale / 2, y, t, c);
}

static void pr_bar(float w, float h, float *bx, float *by, float *bw, float *bh) {
  *bw = 270, *bh = 64;
  *bx = (w - *bw) / 2, *by = h - *bh - 28;
}

static int pr_hit(float w, float h, float x, float y) {
  float bx, by, bw, bh;
  pr_bar(w, h, &bx, &by, &bw, &bh);
  if (x < bx || x >= bx + bw || y < by || y >= by + bh) return 0;
  float rx = x - bx;
  if (rx < 70) return 1;
  if (rx >= 200) return 2;
  return 4;
}

static int pr_bar_visible(uint32_t now) { return now - PR.moved_at < 2600 || D.pend; }

static void stop_present(void) {
  if (!D.present) return;
  D.present = 0;
  D.pend = 0;
  memset(&OV, 0, sizeof OV);
  surf_free(&PR.cache);
  PR.cw = 0;
}

static void pr_step(int d) {
  if (d > 0) {
    if (D.pend) stop_present();
    else if (D.cur + 1 < D.ns) D.cur++;
    else D.pend = 1;
  } else if (d < 0) {
    if (D.pend) D.pend = 0;
    else if (D.cur > 0) D.cur--;
  }
}

static void pr_icon(Surface *s, float cx, float cy, int kind, uint32_t c) {
  if (kind == 1 || kind == 2) {
    float d = kind == 1 ? -1.f : 1.f;
    gfx_line(s, cx - 5 * d, cy - 11, cx + 6 * d, cy, 3.4f, c);
    gfx_line(s, cx + 6 * d, cy, cx - 5 * d, cy + 11, 3.4f, c);
    gfx_disc(s, cx + 6 * d, cy, 1.7f, c);
  } else {
    gfx_line(s, cx - 9, cy - 9, cx + 9, cy + 9, 3.4f, c);
    gfx_line(s, cx + 9, cy - 9, cx - 9, cy + 9, 3.4f, c);
  }
}

static int pr_close_hit(float x, float y) { return (x - 44) * (x - 44) + (y - 44) * (y - 44) <= 30 * 30; }

static void pr_draw(Surface *s, float x, float y, float w, float h, float mx, float my) {
  uint32_t now = now_ms();
  if (fabsf(mx - PR.lmx) > 1 || fabsf(my - PR.lmy) > 1) PR.moved_at = now;
  PR.lmx = mx, PR.lmy = my;
  int iw = (int)w, ih = (int)h;
  if (!D.pend) {
    if (PR.cw != iw || PR.ch != ih || PR.ccur != D.cur || PR.cpend) {
      if (PR.cw != iw || PR.ch != ih) {
        surf_free(&PR.cache);
        surf_init(&PR.cache, iw, ih, 1);
      }
      PR.cw = iw, PR.ch = ih, PR.ccur = D.cur, PR.cpend = 0;
      surf_clear(&PR.cache, 0xff000000u);
      float k = w / SW;
      if (SH * k > h) k = h / SH;
      float sx = (w - SW * k) / 2, sy = (h - SH * k) / 2;
      gfx_clip(&PR.cache, sx, sy, SW * k, SH * k);
      render_slide(&PR.cache, cur_slide(), sx, sy, k, 1, -1, -1);
      gfx_noclip(&PR.cache);
    }
    int x0 = (int)x, y0 = (int)y;
    for (int r = 0; r < ih && y0 + r < s->h; r++) {
      int n = iw;
      if (x0 + n > s->w) n = s->w - x0;
      if (n > 0) memcpy(s->px + (size_t)(y0 + r) * s->stride + x0, PR.cache.px + (size_t)r * PR.cache.stride, (size_t)n * 4);
    }
  } else {
    gfx_rect(s, x, y, w, h, RGB(0, 0, 0));
    dtext_c(s, F_H1, x + w / 2, y + h / 2 - dlh(F_H1) - 10, "End of slideshow", RGB(232, 234, 240));
    dtext_c(s, F_UI, x + w / 2, y + h / 2 + 6, "Click or press any key to exit", RGB(140, 144, 152));
  }
  float pw = D.ns > 0 ? w * (D.pend ? 1.f : (D.cur + 1) / (float)D.ns) : 0;
  gfx_rect(s, x, y + h - 4, pw, 4, P_ACC);
  PR.bar_on = pr_bar_visible(now);
  {
    int xh = pr_close_hit(mx, my);
    float cx = x + 44, cy = y + 44;
    gfx_disc(s, cx, cy, 26, xh ? RGBA(232, 72, 60, 235) : RGBA(20, 20, 24, PR.bar_on || now - PR.start_at < 2600 ? 170 : 90));
    pr_icon(s, cx, cy, 3, RGBA(255, 255, 255, xh || PR.bar_on ? 255 : 170));
  }
  if (!PR.bar_on) return;
  float bx, by, bw, bh;
  pr_bar(w, h, &bx, &by, &bw, &bh);
  bx += x, by += y;
  int hv = pr_hit(w, h, mx, my);
  gfx_shadow(s, bx, by + 6, bw, bh, bh / 2, 18, RGBA(0, 0, 0, 120));
  gfx_rrect(s, bx, by, bw, bh, bh / 2, RGBA(26, 27, 32, 235));
  float cy = by + bh / 2;
  int can_prev = D.cur > 0 || D.pend;
  if (hv == 1 && can_prev) gfx_disc(s, bx + 38, cy, 24, RGBA(255, 255, 255, 34));
  pr_icon(s, bx + 36, cy, 1, can_prev ? RGB(240, 240, 244) : RGB(96, 98, 106));
  if (hv == 2) gfx_disc(s, bx + 234, cy, 24, RGBA(255, 255, 255, 34));
  pr_icon(s, bx + 236, cy, 2, RGB(240, 240, 244));
  char b[32];
  if (D.pend) snprintf(b, sizeof b, "End");
  else snprintf(b, sizeof b, "%d / %d", D.cur + 1, D.ns);
  dtext_c(s, F_UI_MED, bx + 135, cy - dlh(F_UI_MED) / 2, b, RGB(240, 240, 244));
}

static void pr_press(float x, float y, int button, int down) {
  if (!D.present || down) return;
  if (pr_close_hit(x, y)) {
    stop_present();
    return;
  }
  int z = PR.bar_on ? pr_hit(OV.w, OV.h, x, y) : 0;
  if (z == 1) pr_step(-1);
  else if (z == 2) pr_step(1);
  else if (z == 4) return;
  else if (button == 3) pr_step(-1);
  else pr_step(1);
}

static void pr_key(int code, int mods) {
  (void)mods;
  if (!D.present) return;
  if (code == KEY_ESC) stop_present();
  else if (D.pend && !(code == KEY_LEFT || code == KEY_BACKSPACE || code == KEY_PAGEUP || code == KEY_UP)) stop_present();
  else if (code == KEY_RIGHT || code == KEY_SPACE || code == KEY_ENTER || code == KEY_DOWN || code == KEY_PAGEDOWN || code == KEY_N) pr_step(1);
  else if (code == KEY_LEFT || code == KEY_BACKSPACE || code == KEY_UP || code == KEY_PAGEUP || code == KEY_P) pr_step(-1);
  else if (code == KEY_HOME) D.cur = 0, D.pend = 0;
  else if (code == KEY_END) D.cur = D.ns - 1, D.pend = 0;
}

static void pr_wheel(int steps) {
  if (D.present) pr_step(steps < 0 ? 1 : -1);
}

static void start_present(int from_start) {
  end_edit();
  D.popup = 0;
  if (from_start) D.cur = 0;
  D.present = 1;
  D.pend = 0;
  PR.start_at = PR.moved_at = now_ms();
  PR.cw = 0;
  OV.draw = pr_draw;
  OV.press = pr_press;
  OV.key = pr_key;
  OV.wheel = pr_wheel;
  OV.dirty = 1;
}

void slides_stop_present(void) { stop_present(); }

static void run_cmd(int c) {
  D.popup = 0;
  switch (c) {
  case C_NEW:
    new_deck();
    office_set_title();
    break;
  case C_COPYDOC: {
    char *s = serialize(), t[120];
    snprintf(t, sizeof t, "Copy of %.80s", D.title);
    new_deck();
    deserialize(s);
    snprintf(D.title, sizeof D.title, "%.95s", t);
    free(s);
    save_deck();
    office_set_title();
    office_toast("Copy created");
    break;
  }
  case C_RENAME: begin_title_edit(); break;
  case C_OUTLINE: export_outline(); break;
  case C_PPTX: export_pptx(); break;
  case C_DELETE: {
    char path[700];
    deck_path(D.id, path, sizeof path);
    unlink(path);
    D.dirty = 0;
    D.id[0] = 0;
    office_go_home();
    office_toast("Moved to trash");
    break;
  }
  case C_UNDO: undo_redo(0); break;
  case C_REDO: undo_redo(1); break;
  case C_COPY:
  case C_CUT: {
    Obj *o = sel_obj();
    if (!o) break;
    if (D.has_clip) obj_free(&D.clip);
    obj_copy(&D.clip, o);
    D.has_clip = 1;
    if (c == C_CUT) del_obj();
    else office_toast("Copied");
    break;
  }
  case C_PASTE: dup_obj(1); break;
  case C_DUP: dup_obj(0); break;
  case C_DEL: del_obj(); break;
  case C_ITEXT: insert_obj(O_TEXT); break;
  case C_IRECT: insert_obj(O_RECT); break;
  case C_IROUND: insert_obj(O_ROUND); break;
  case C_IELL: insert_obj(O_ELLIPSE); break;
  case C_NEWSLIDE: add_slide(1); break;
  case C_DUPSLIDE: dup_slide(); break;
  case C_DELSLIDE: del_slide(); break;
  case C_SUP: move_slide(-1); break;
  case C_SDOWN: move_slide(1); break;
  case C_BG: D.popup = POP_BG; break;
  case C_FRONT: restack(1); break;
  case C_BACK: restack(0); break;
  case C_HCENTER:
  case C_VCENTER: {
    Obj *o = sel_obj();
    if (!o) break;
    push_undo();
    if (c == C_HCENTER) o->x = (SW - o->w) / 2;
    else o->y = (SH - o->h) / 2;
    changed();
    break;
  }
  case C_PRESENT: start_present(1); break;
  case C_EDOC:
  case C_ESHEET:
  case C_ESLIDE:
    end_edit();
    if (D.dirty) save_deck();
    office_picker_open(c - C_EDOC, 2, D.id);
    break;
  }
}

static void tool_click(int t) {
  switch (t) {
  case T_UNDO: run_cmd(C_UNDO); break;
  case T_REDO: run_cmd(C_REDO); break;
  case T_SLIDE: D.popup = D.popup == POP_LAYOUT ? 0 : POP_LAYOUT; break;
  case T_TEXT: run_cmd(C_ITEXT); break;
  case T_RECT: run_cmd(C_IRECT); break;
  case T_EMBED: run_cmd(C_EDOC); break;
  case T_ELLIPSE: run_cmd(C_IELL); break;
  case T_SIZEM: set_style(7, -1); break;
  case T_SIZEP: set_style(7, 1); break;
  case T_BOLD: set_style(0, 0); break;
  case T_ITAL: set_style(1, 0); break;
  case T_UNDER: set_style(2, 0); break;
  case T_COLOR:
    if (sel_obj()) D.popup = D.popup == POP_COLOR ? 0 : POP_COLOR;
    break;
  case T_FILL:
    if (sel_obj()) D.popup = D.popup == POP_FILL ? 0 : POP_FILL;
    break;
  case T_ALEFT: set_style(3, AL_LEFT); break;
  case T_ACENTER: set_style(3, AL_CENTER); break;
  case T_ARIGHT: set_style(3, AL_RIGHT); break;
  case T_BULLET: set_style(4, 0); break;
  case T_FRONT: run_cmd(C_FRONT); break;
  case T_BACK: run_cmd(C_BACK); break;
  }
}

static int caret_at(const Obj *o, float ux, float uy) {
  TLine ln[128];
  int nl = layout_text(o, ln, 128);
  float lh = o->size * 1.22f, ty = text_top(o, nl);
  int li = (int)floorf((uy - ty) / lh);
  if (li < 0) li = 0;
  if (li >= nl) li = nl - 1;
  float cx = line_x(o, &ln[li]);
  int i = ln[li].a;
  for (; i < ln[li].b; i++) {
    float w = meas_w(o, o->text[i]);
    if (ux < cx + w / 2) break;
    cx += w;
  }
  if (i == ln[li].b && i > ln[li].a && o->text[i - 1] == ' ' && li + 1 < nl && ln[li + 1].a == i) i--;
  return i;
}

static void begin_edit(int caret) {
  Obj *o = sel_obj();
  if (!o) return;
  if (o->type == O_EMBED) {
    int ek = 0, sub;
    char id[40];
    if (office_embed_parse(o->text, &ek, id, sizeof id, &sub)) office_embed_open(ek, id, sub);
    return;
  }
  push_undo();
  D.editing = 1;
  D.caret = caret < 0 ? (int)strlen(o->text) : caret;
  D.blink = 1;
  D.blink_t = now_ms();
  office_show_keyboard();
}

static void end_edit(void) {
  if (!D.editing) return;
  D.editing = 0;
  Obj *o = sel_obj();
  if (o && o->type == O_TEXT && !o->text[0] && !o->ph) del_obj();
}

void slides_press(Panel *p, float x, float y, int button, int down) {
  (void)p;
  if (button != 1) return;
  int z = slides_zone(x, y);
  if (D.present) return;
  if (down) {
    D.press = z;
    if (D.popup && (z <= 0 || z == Z_AREA || z >= Z_THUMB)) {
      D.popup = 0;
      D.press = 0;
      return;
    }
    if (z == Z_AREA) {
      commit_title();
      float ux, uy;
      to_units(x, y, &ux, &uy);
      int hit = hit_obj(ux, uy);
      if (D.editing && hit == D.sel) {
        D.caret = caret_at(sel_obj(), ux, uy);
        return;
      }
      uint32_t now = now_ms();
      int dbl = hit >= 0 && hit == D.last_obj && now - D.last_click < 420;
      D.last_click = now, D.last_obj = hit;
      end_edit();
      if (hit >= 0 && hit >= cur_slide()->n) hit = -1;
      D.sel = hit;
      if (hit < 0) return;
      Obj *o = sel_obj();
      if (dbl && o->type == O_EMBED) {
        begin_edit(-1);
        return;
      }
      if (dbl || (o->ph && !o->text[0])) {
        begin_edit(caret_at(o, ux, uy));
        return;
      }
      D.drag = 1;
      D.moved = 0;
      D.gx0 = ux, D.gy0 = uy, D.ox0 = o->x, D.oy0 = o->y;
      push_undo();
      return;
    }
    if (z >= Z_HANDLE && z < Z_HANDLE + 8) {
      Obj *o = sel_obj();
      if (!o) return;
      float ux, uy;
      to_units(x, y, &ux, &uy);
      D.drag = 2;
      D.handle = z - Z_HANDLE;
      D.moved = 0;
      D.gx0 = ux, D.gy0 = uy, D.ox0 = o->x, D.oy0 = o->y, D.ow0 = o->w, D.oh0 = o->h;
      push_undo();
      return;
    }
    return;
  }
  int pz = D.press;
  D.press = 0;
  if (D.drag) {
    if (!D.moved && D.nundo) {
      free(D.undo[--D.nundo]);
    } else changed();
    D.drag = 0;
    D.snapx = D.snapy = 0;
    return;
  }
  if (!pz || z != pz) return;
  if (D.popup && z >= Z_POPUP && z < Z_THUMB) {
    int i = z - Z_POPUP;
    int pop = D.popup;
    if (pop <= POP_M4) run_cmd(MENUS[pop - POP_M0][i].cmd);
    else {
      D.popup = 0;
      if (pop == POP_LAYOUT) add_slide(i);
      else if (pop == POP_COLOR) set_style(5, i);
      else if (pop == POP_FILL) set_style(6, i);
      else {
        push_undo();
        cur_slide()->bg = (unsigned char)i;
        changed();
      }
    }
    return;
  }
  if (z != Z_TITLE) commit_title();
  if (z >= Z_MENU && z < Z_MENU + 5) {
    end_edit();
    int m = POP_M0 + z - Z_MENU;
    D.popup = D.popup == m ? 0 : m;
  } else if (z > 0 && z < T_COUNT) {
    if (z != T_COLOR && z != T_FILL && z != T_SLIDE) D.popup = 0;
    if (!(z >= T_SIZEM && z <= T_BULLET)) end_edit();
    tool_click(z);
  } else if (z >= Z_THUMB) {
    end_edit();
    D.popup = 0;
    D.cur = z - Z_THUMB;
    D.sel = -1;
  } else {
    D.popup = 0;
    if (z == Z_HOME) {
      end_edit();
      office_go_home();
    } else if (z == Z_TITLE) {
      end_edit();
      begin_title_edit();
    } else if (z == Z_PRESENT) start_present(0);
  }
}

void slides_scroll(float x, float y, int steps) {
  (void)y;
  if (D.present) return;
  if (x < CANVAS_X) {
    D.strip_scroll -= steps * 60;
    float h = content_h() - 16 - BODY_Y;
    float maxs = D.ns * 92 + 16 - h;
    if (D.strip_scroll > maxs) D.strip_scroll = maxs;
    if (D.strip_scroll < 0) D.strip_scroll = 0;
  } else {
    if (steps < 0 && D.cur + 1 < D.ns) D.cur++, D.sel = -1, D.editing = 0;
    else if (steps > 0 && D.cur > 0) D.cur--, D.sel = -1, D.editing = 0;
  }
}

static void text_insert(Obj *o, const char *s) {
  int l = (int)strlen(o->text), n = (int)strlen(s);
  if (l + n > 4000) return;
  char *t = malloc((size_t)(l + n + 1));
  memcpy(t, o->text, (size_t)D.caret);
  memcpy(t + D.caret, s, (size_t)n);
  memcpy(t + D.caret + n, o->text + D.caret, (size_t)(l - D.caret + 1));
  free(o->text);
  o->text = t;
  D.caret += n;
  changed();
}

static void caret_vert(Obj *o, int d) {
  TLine ln[128];
  int nl = layout_text(o, ln, 128);
  int li = nl - 1;
  for (int i = 0; i < nl; i++)
    if (D.caret >= ln[i].a && (D.caret < ln[i].b || i == nl - 1 || ln[i + 1].a > D.caret)) {
      li = i;
      break;
    }
  int to = li + d;
  if (to < 0 || to >= nl) return;
  float cx = line_x(o, &ln[li]);
  for (int j = ln[li].a; j < D.caret; j++) cx += meas_w(o, o->text[j]);
  float lh = o->size * 1.22f, ty = text_top(o, nl);
  D.caret = caret_at(o, cx, ty + to * lh + lh / 2);
}

void slides_key(Panel *p, int code, int mods) {
  (void)p;
  int ctrl = mods & MOD_CTRL, shift = mods & MOD_SHIFT;
  D.blink = 1;
  D.blink_t = now_ms();
  if (D.present) {
    pr_key(code, mods);
    return;
  }
  if (code == KEY_ESC && D.popup) {
    D.popup = 0;
    return;
  }
  if (D.title_edit) {
    if (code == KEY_ENTER || code == KEY_KPENTER || code == KEY_TAB) commit_title();
    else if (code == KEY_ESC) D.title_edit = 0;
    else if (code == KEY_BACKSPACE) {
      int l = (int)strlen(D.title_buf);
      if (l) D.title_buf[l - 1] = 0;
    } else if (!ctrl) {
      char b[8];
      int n = key_to_bytes(code, mods, b);
      int l = (int)strlen(D.title_buf);
      if (n == 1 && b[0] >= 32 && b[0] < 127 && l < 90) D.title_buf[l] = b[0], D.title_buf[l + 1] = 0;
    }
    return;
  }
  if (code == KEY_F5) {
    start_present(!shift);
    return;
  }
  Obj *o = sel_obj();
  if (D.editing && o) {
    if (ctrl) {
      if (code == KEY_B) set_style(0, 0);
      else if (code == KEY_I) set_style(1, 0);
      else if (code == KEY_U) set_style(2, 0);
      return;
    }
    int l = (int)strlen(o->text);
    switch (code) {
    case KEY_ESC: end_edit(); return;
    case KEY_ENTER:
    case KEY_KPENTER: text_insert(o, "\n"); return;
    case KEY_BACKSPACE:
      if (D.caret > 0) {
        memmove(o->text + D.caret - 1, o->text + D.caret, (size_t)(l - D.caret + 1));
        D.caret--;
        changed();
      }
      return;
    case KEY_DELETE:
      if (D.caret < l) {
        memmove(o->text + D.caret, o->text + D.caret + 1, (size_t)(l - D.caret));
        changed();
      }
      return;
    case KEY_LEFT:
      if (D.caret > 0) D.caret--;
      return;
    case KEY_RIGHT:
      if (D.caret < l) D.caret++;
      return;
    case KEY_UP: caret_vert(o, -1); return;
    case KEY_DOWN: caret_vert(o, 1); return;
    case KEY_HOME:
      while (D.caret > 0 && o->text[D.caret - 1] != '\n') D.caret--;
      return;
    case KEY_END:
      while (D.caret < l && o->text[D.caret] != '\n') D.caret++;
      return;
    case KEY_TAB: text_insert(o, "    "); return;
    }
    char b[8];
    int n = key_to_bytes(code, mods, b);
    if (n == 1 && b[0] >= 32 && b[0] < 127) {
      b[1] = 0;
      text_insert(o, b);
    }
    return;
  }
  if (ctrl) {
    int cmd = 0;
    switch (code) {
    case KEY_Z: cmd = shift ? C_REDO : C_UNDO; break;
    case KEY_Y: cmd = C_REDO; break;
    case KEY_C: cmd = C_COPY; break;
    case KEY_X: cmd = C_CUT; break;
    case KEY_V: cmd = C_PASTE; break;
    case KEY_D: cmd = C_DUP; break;
    case KEY_M: cmd = C_NEWSLIDE; break;
    case KEY_N: cmd = C_NEW; break;
    case KEY_B: set_style(0, 0); return;
    case KEY_I: set_style(1, 0); return;
    case KEY_U: set_style(2, 0); return;
    case KEY_S:
      save_deck();
      office_toast("Saved");
      return;
    }
    if (cmd) run_cmd(cmd);
    return;
  }
  if (o) {
    float step = shift ? 40 : 6;
    switch (code) {
    case KEY_DELETE:
    case KEY_BACKSPACE: del_obj(); return;
    case KEY_ESC: D.sel = -1; return;
    case KEY_LEFT:
    case KEY_RIGHT:
    case KEY_UP:
    case KEY_DOWN:
      push_undo();
      if (code == KEY_LEFT) o->x -= step;
      if (code == KEY_RIGHT) o->x += step;
      if (code == KEY_UP) o->y -= step;
      if (code == KEY_DOWN) o->y += step;
      changed();
      return;
    case KEY_ENTER:
    case KEY_KPENTER: begin_edit(-1); return;
    case KEY_TAB: {
      int n = cur_slide()->n;
      if (n) D.sel = (D.sel + (shift ? n - 1 : 1)) % n;
      return;
    }
    }
    char b[8];
    int n = key_to_bytes(code, mods, b);
    if (n == 1 && b[0] >= 32 && b[0] < 127) {
      begin_edit(-1);
      b[1] = 0;
      text_insert(o, b);
    }
    return;
  }
  switch (code) {
  case KEY_UP:
  case KEY_PAGEUP:
  case KEY_LEFT:
    if (D.cur > 0) D.cur--;
    return;
  case KEY_DOWN:
  case KEY_PAGEDOWN:
  case KEY_RIGHT:
    if (D.cur + 1 < D.ns) D.cur++;
    return;
  case KEY_TAB:
    if (cur_slide()->n) D.sel = 0;
    return;
  }
}

int slides_tick(Panel *p, uint32_t now) {
  int r = 0;
  if (D.present) {
    if (PR.bar_on != pr_bar_visible(now) || now - PR.start_at < 3400) OV.dirty = 1;
    if (!D.dirty) return 0;
  }
  int me = W.hover == (int)(p - P);
  if (D.drag && me) {
    Obj *o = sel_obj();
    if (o) {
      float ux, uy;
      to_units(W.hs, W.ht - BAR_H, &ux, &uy);
      float dx = ux - D.gx0, dy = uy - D.gy0;
      if (fabsf(dx) > 2 || fabsf(dy) > 2) D.moved = 1;
      if (D.moved) {
        if (D.drag == 1) {
          float nx = D.ox0 + dx, ny = D.oy0 + dy;
          D.snapx = fabsf(nx + o->w / 2 - SW / 2) < 10;
          D.snapy = fabsf(ny + o->h / 2 - SH / 2) < 10;
          if (D.snapx) nx = SW / 2 - o->w / 2;
          if (D.snapy) ny = SH / 2 - o->h / 2;
          o->x = nx, o->y = ny;
        } else {
          int hh = D.handle;
          float x0 = D.ox0, y0 = D.oy0, x1 = D.ox0 + D.ow0, y1 = D.oy0 + D.oh0;
          int left = hh == 0 || hh == 6 || hh == 7, right = hh == 2 || hh == 3 || hh == 4;
          int top = hh == 0 || hh == 1 || hh == 2, bot = hh == 4 || hh == 5 || hh == 6;
          if (left) x0 += dx;
          if (right) x1 += dx;
          if (top) y0 += dy;
          if (bot) y1 += dy;
          if (x1 - x0 < 30) {
            if (left) x0 = x1 - 30;
            else x1 = x0 + 30;
          }
          if (y1 - y0 < 30) {
            if (top) y0 = y1 - 30;
            else y1 = y0 + 30;
          }
          o->x = x0, o->y = y0, o->w = x1 - x0, o->h = y1 - y0;
        }
        r = 1;
      }
    }
  }
  if (D.dirty && now - D.dirty_at > 900 && !D.drag) {
    save_deck();
    r = 1;
  }
  if (now - D.blink_t > 530) {
    D.blink_t = now;
    D.blink = !D.blink;
    if (D.editing || D.title_edit) r = 1;
  }
  return r;
}

void slides_home_scan(void) {
  if (!D.loaded) {
    D.loaded = 1;
    D.confirm_del = -1;
    D.sel = -1;
    D.last_obj = -1;
    tool_layout();
  }
  scan_list();
}

void slides_home_reset(void) { D.confirm_del = -1; }

static float home_tpl_y(float top) { return top + 52; }

#define NEW_H 196

static float home_band_b(float top) { return top + 52 + NEW_H + 40; }

#define DCARD_W 240
#define DCARD_H 135
#define DCARD_STEP 214

static float card_x(int i) { return (OFF_W - (4 * DCARD_W + 3 * OFF_CARD_GAP)) * 0.5f + (i % 4) * (DCARD_W + OFF_CARD_GAP); }

static float card_y(int i, float top) { return home_band_b(top) + 64 + (i / 4) * DCARD_STEP; }

float slides_home_h(void) {
  int rows = D.nlist ? (D.nlist + 3) / 4 : 1;
  return 52 + NEW_H + 40 + 64 + rows * DCARD_STEP + 20;
}

static float new_x(void) { return (OFF_W - 4 * DCARD_W - 3 * OFF_CARD_GAP) * 0.5f; }

int slides_home_zone(float x, float y, float top) {
  float nx = new_x(), ny = home_tpl_y(top);
  if (x >= nx && x < nx + 284 && y >= ny && y < ny + NEW_H) return 6000;
  for (int i = 0; i < D.nlist; i++) {
    float cx = card_x(i), cy = card_y(i, top);
    if (x >= cx && x < cx + DCARD_W && y >= cy && y < cy + DCARD_H + 58) {
      if (x >= cx + DCARD_W - 40 && y < cy + 40) return 6400 + i;
      return 6100 + i;
    }
  }
  return 0;
}

void slides_home_draw(Surface *s, float ox, float oy, int hot, float top) {
  float lx = ox + new_x();
  gfx_text(s, F_UI_MED, lx, oy + top + 18, "Start something new", C_TEXT);
  float x = lx, y = oy + home_tpl_y(top), w = 284, h = NEW_H;
  int hv = hot == 6000;
  office_card(s, x, y, w, h, hv, P_ACC);
  float sx = x + 14, sy = y + 14, swd = w - 28, sht = swd * SH / SW;
  gfx_rrect(s, sx, sy, swd, sht, 4, THEME(RGB(248, 247, 250), RGB(44, 46, 54)));
  gfx_rrect(s, sx + swd * 0.2f, sy + sht * 0.38f, swd * 0.6f, 7, 3.5f, THEME(RGB(200, 200, 206), RGB(80, 82, 92)));
  gfx_rrect(s, sx + swd * 0.32f, sy + sht * 0.58f, swd * 0.36f, 5, 2.5f, THEME(RGB(220, 220, 226), RGB(66, 68, 78)));
  float cx = x + w - 30, cy = y + h - 24;
  gfx_disc(s, cx, cy, 17, P_TINT);
  gfx_rrect(s, cx - 7, cy - 1.2f, 14, 2.4f, 1.2f, P_ACC);
  gfx_rrect(s, cx - 1.2f, cy - 7, 2.4f, 14, 1.2f, P_ACC);
  gfx_text(s, F_UI_MED, x + 16, y + h - 24 - line_h(F_UI_MED) / 2, "Blank presentation", hv ? P_ACC : C_TEXT);
  float bb = oy + home_band_b(top);
  gfx_rect(s, lx, bb + 4, OFF_W - 2 * (lx - ox), 1, N_LINE);
  gfx_text(s, F_UI_MED, lx, bb + 24, "Recent", C_TEXT);
  if (!D.nlist) gfx_text(s, F_UI, lx, bb + 68, "No presentations yet. Start a blank one above.", C_MUTED);
  for (int i = 0; i < D.nlist; i++) {
    float x2 = ox + card_x(i), y2 = oy + card_y(i, top);
    if (y2 > oy + content_h() || y2 + DCARD_STEP < oy + OFF_HOME_HEAD) continue;
    int h2 = hot == 6100 + i || hot == 6400 + i;
    office_card(s, x2, y2, DCARD_W, DCARD_H + 58, h2, P_ACC);
    float cy0 = y2 > oy + OFF_HOME_HEAD ? y2 : oy + OFF_HOME_HEAD;
    gfx_clip(s, x2, cy0, DCARD_W, y2 + DCARD_H - cy0);
    gfx_rrect(s, x2, y2, DCARD_W, DCARD_H + 20, 12, bg_col(&D.list[i].first));
    render_slide(s, &D.list[i].first, x2, y2, DCARD_W / (float)SW, 1, -1, -1);
    gfx_clip(s, ox, oy + OFF_HOME_HEAD, OFF_W, content_h() - OFF_HOME_HEAD);
    gfx_rect(s, x2, y2 + DCARD_H, DCARD_W, 1, N_LINE);
    gfx_rrect(s, x2 + 14, y2 + DCARD_H + 12, 14, 14, 4, P_ACC);
    gfx_tri(s, x2 + 19, y2 + DCARD_H + 15.5f, x2 + 19, y2 + DCARD_H + 22.5f, x2 + 24.5f, y2 + DCARD_H + 19, RGB(255, 255, 255));
    gfx_text_fit(s, F_UI_MED, x2 + 36, y2 + DCARD_H + 9, DCARD_W - 50, D.list[i].title, C_TEXT);
    char d[48], m[80];
    office_fmt_date(D.list[i].mtime, d, sizeof d);
    snprintf(m, sizeof m, "%s  -  %d slide%s", d, D.list[i].nslides, D.list[i].nslides == 1 ? "" : "s");
    gfx_text(s, F_SMALL, x2 + 14, y2 + DCARD_H + 34, m, C_MUTED);
    if (D.confirm_del == i) {
      gfx_rrect(s, x2 + DCARD_W - 86, y2 + 8, 78, 28, 14, RGB(217, 48, 37));
      gfx_text_c(s, F_SMALL, x2 + DCARD_W - 47, y2 + 22 - line_h(F_SMALL) / 2, "Delete?", RGB(255, 255, 255));
    } else if (h2) office_trash(s, x2 + DCARD_W - 22, y2 + 22, hot == 6400 + i);
  }
}

int slides_home_press(int z) {
  if (z == 6000) {
    D.confirm_del = -1;
    new_deck();
    return 1;
  }
  if (z >= 6400 && z < 6400 + MAXDECKS) {
    int i = z - 6400;
    if (D.confirm_del == i) {
      char path[700];
      deck_path(D.list[i].id, path, sizeof path);
      unlink(path);
      if (!strcmp(D.list[i].id, D.id)) D.id[0] = 0;
      D.confirm_del = -1;
      scan_list();
      office_toast("Moved to trash");
      return 0;
    }
    D.confirm_del = i;
    return 0;
  }
  if (z >= 6100 && z < 6100 + MAXDECKS) {
    int i = z - 6100;
    if (D.confirm_del == i) {
      D.confirm_del = -1;
      return 0;
    }
    D.confirm_del = -1;
    open_deck(D.list[i].id);
    return 1;
  }
  D.confirm_del = -1;
  return 0;
}

int slides_new(void) {
  new_deck();
  return 1;
}

int slides_presenting(void) { return D.present; }

void slides_insert_embed(int kind, const char *id, int sub) {
  push_undo();
  end_edit();
  Slide *sl = cur_slide();
  Obj *o = obj_add(sl);
  if (!o) return;
  o->type = O_EMBED;
  o->size = 28;
  free(o->text);
  o->text = malloc(64);
  office_embed_ref(o->text, 64, kind, id, sub);
  if (kind == 2) o->w = 720, o->h = 405;
  else if (kind == 1) {
    float nw = 760, nh = 420;
    sheets_embed_size(id, &nw, &nh);
    o->w = 760, o->h = 760 * nh / nw;
    if (o->h > 640) o->w *= 640 / o->h, o->h = 640;
  }
  else o->w = 460, o->h = 600;
  o->x = (SW - o->w) / 2, o->y = (SH - o->h) / 2;
  D.sel = sl->n - 1;
  changed();
}

void slides_open(const char *id, int sub) {
  slides_home_scan();
  open_deck(id);
  if (sub >= 0 && sub < D.ns) D.cur = sub;
}

typedef struct {
  char id[40], title[96];
  long mtime;
  uint32_t at;
  int ok, ns, cap;
  Slide *sl;
} DeckSnap;

static DeckSnap DKS[4];
static int dks_next;

static DeckSnap *deck_snap(const char *id) {
  DeckSnap *d = NULL;
  for (int i = 0; i < 4; i++)
    if (!strcmp(DKS[i].id, id)) d = &DKS[i];
  uint32_t now = now_ms();
  if (d && now - d->at < 700) return d;
  char path[700];
  deck_path(id, path, sizeof path);
  struct stat st;
  long mt = stat(path, &st) ? -1 : (long)st.st_mtime;
  if (d && d->mtime == mt) {
    d->at = now;
    return d;
  }
  if (!d) {
    d = &DKS[dks_next];
    dks_next = (dks_next + 1) % 4;
  }
  for (int i = 0; i < d->ns; i++) slide_free(&d->sl[i]);
  d->ns = 0;
  snprintf(d->id, sizeof d->id, "%s", id);
  d->at = now, d->mtime = mt, d->ok = 0;
  snprintf(d->title, sizeof d->title, "Untitled presentation");
  char *body = mt < 0 ? NULL : office_read_file(path);
  if (body) {
    parse_deck(body, &d->sl, &d->ns, &d->cap, d->title, sizeof d->title, NULL);
    free(body);
    d->ok = d->ns > 0;
  }
  return d;
}

int slides_embed(Surface *s, const char *id, int sub, float x, float y, float w, float h, char *title, int tn) {
  const Slide *sl;
  if (D.id[0] && !strcmp(D.id, id) && D.ns) {
    snprintf(title, (size_t)tn, "%s", D.title);
    sl = &D.sl[sub < D.ns ? sub : D.ns - 1];
  } else {
    DeckSnap *d = deck_snap(id);
    if (!d->ok) return 0;
    snprintf(title, (size_t)tn, "%s", d->title);
    sl = &d->sl[sub < d->ns ? sub : d->ns - 1];
  }
  if (!s) return 1;
  float k = w / SW;
  if (SH * k > h) k = h / SH;
  float sx = x + (w - SW * k) / 2, sy = y + (h - SH * k) / 2;
  if (sx > x + 0.5f || sy > y + 0.5f) gfx_rect(s, x, y, w, h, THEME(RGB(236, 236, 240), RGB(28, 29, 34)));
  render_slide(s, sl, sx, sy, k, 1, -1, -1);
  return 1;
}

#define EMU_U (12192000.0 / SW)

static const char *const PNS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" "
                               "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
                               "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"";

static const char *const GRP0 = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/>"
                                "<a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>";

static long emu(float u) { return (long)(u * EMU_U + 0.5); }

static void px_fill(Buf *b, uint32_t c) { buf_printf(b, "<a:solidFill><a:srgbClr val=\"%06X\"/></a:solidFill>", (unsigned)(c & 0xffffff)); }

static void px_xfrm(Buf *b, const Obj *o) {
  buf_printf(b, "<a:xfrm><a:off x=\"%ld\" y=\"%ld\"/><a:ext cx=\"%ld\" cy=\"%ld\"/></a:xfrm>", emu(o->x), emu(o->y), emu(o->w), emu(o->h));
}

static void px_run_pr(Buf *b, const Obj *o, uint32_t col, int sz, int bold) {
  buf_printf(b, "<a:rPr lang=\"en-US\" sz=\"%d\"%s%s%s dirty=\"0\">", sz, bold ? " b=\"1\"" : "", o && o->ital ? " i=\"1\"" : "", o && o->under ? " u=\"sng\"" : "");
  px_fill(b, col);
  buf_printf(b, "<a:latin typeface=\"Arial\"/><a:cs typeface=\"Arial\"/></a:rPr>");
}

static void px_table(Buf *b, const Obj *o, const char *id, int nid) {
  int nc, nr;
  if (!sheets_embed_dims(id, &nc, &nr)) return;
  long cw = emu(o->w) / nc, rh = emu(o->h) / nr;
  int sz = (int)(o->h / nr * 0.6667f * 0.5f * 100);
  for (int c = 0; c < nc; c++) {
    int ml = 1;
    for (int r = 0; r < nr; r++) {
      int l = (int)strlen(sheets_embed_cell(id, r, c, NULL, NULL));
      if (l > ml) ml = l;
    }
    int fit = (int)((o->w / nc * 0.6667f - 9) / (ml * 0.56f) * 100);
    if (fit < sz) sz = fit;
  }
  if (sz > 2400) sz = 2400;
  if (sz < 800) sz = 800;
  buf_printf(b, "<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id=\"%d\" name=\"Table %d\"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp=\"1\"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>"
                "<p:xfrm><a:off x=\"%ld\" y=\"%ld\"/><a:ext cx=\"%ld\" cy=\"%ld\"/></p:xfrm><a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/table\"><a:tbl><a:tblPr firstRow=\"1\"/><a:tblGrid>",
             nid, nid, emu(o->x), emu(o->y), cw * nc, rh * nr);
  for (int c = 0; c < nc; c++) buf_printf(b, "<a:gridCol w=\"%ld\"/>", cw);
  buf_printf(b, "</a:tblGrid>");
  for (int r = 0; r < nr; r++) {
    buf_printf(b, "<a:tr h=\"%ld\">", rh);
    for (int c = 0; c < nc; c++) {
      int bold = 0, right = 0;
      const char *t = sheets_embed_cell(id, r, c, &bold, &right);
      buf_printf(b, "<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr algn=\"%s\"/>", right ? "r" : "l");
      if (t[0]) {
        buf_printf(b, "<a:r>");
        px_run_pr(b, NULL, RGB(32, 33, 36), sz, bold);
        buf_printf(b, "<a:t>");
        buf_esc(b, t, -1);
        buf_printf(b, "</a:t></a:r>");
      } else buf_printf(b, "<a:endParaRPr lang=\"en-US\" sz=\"%d\"/>", sz);
      buf_printf(b, "</a:p></a:txBody><a:tcPr marL=\"45720\" marR=\"45720\" marT=\"22860\" marB=\"22860\" anchor=\"ctr\">");
      static const char *const ln[4] = {"lnL", "lnR", "lnT", "lnB"};
      for (int k = 0; k < 4; k++)
        buf_printf(b, "<a:%s w=\"9525\"><a:solidFill><a:srgbClr val=\"BFC3C9\"/></a:solidFill></a:%s>", ln[k], ln[k]);
      buf_printf(b, "%s</a:tcPr></a:tc>", r == 0 ? "<a:solidFill><a:srgbClr val=\"F1F3F4\"/></a:solidFill>" : "<a:noFill/>");
    }
    buf_printf(b, "</a:tr>");
  }
  buf_printf(b, "</a:tbl></a:graphicData></a:graphic></p:graphicFrame>");
}

static void px_shape(Buf *b, const Slide *sl, const Obj *o, int nid) {
  static const char *const PRST[5] = {"rect", "rect", "roundRect", "ellipse", "rect"};
  static const char *const ALG[3] = {"l", "ctr", "r"};
  static const char *const ANC[3] = {"t", "ctr", "b"};
  char label[160];
  const char *text = o->text;
  int ek = -1, sub;
  char id[40];
  if (o->type == O_EMBED) {
    char t[96] = "";
    if (office_embed_parse(o->text, &ek, id, sizeof id, &sub)) {
      if (ek == 1 && sheets_embed_dims(id, &(int){0}, &(int){0})) {
        px_table(b, o, id, nid);
        return;
      }
      office_embed_title(ek, id, sub, t, sizeof t);
    }
    snprintf(label, sizeof label, "[%s: %s]", ek == 0 ? "Document" : ek == 2 ? "Slide" : "Spreadsheet", t[0] ? t : "missing");
    text = label;
  }
  int istext = o->type == O_TEXT;
  if (istext && !text[0]) return;
  buf_printf(b, "<p:sp><p:nvSpPr><p:cNvPr id=\"%d\" name=\"%s %d\"/><p:cNvSpPr%s/><p:nvPr/></p:nvSpPr><p:spPr>", nid, istext ? "TextBox" : "Shape", nid,
             istext ? " txBox=\"1\"" : "");
  px_xfrm(b, o);
  buf_printf(b, "<a:prstGeom prst=\"%s\"><a:avLst/></a:prstGeom>", PRST[o->type]);
  if (o->type == O_EMBED) px_fill(b, RGB(246, 246, 248));
  else if (o->fill) px_fill(b, PAL[o->fill]);
  else buf_printf(b, "<a:noFill/>");
  if (o->line) {
    buf_printf(b, "<a:ln w=\"%ld\">", emu(3));
    px_fill(b, PAL[o->line]);
    buf_printf(b, "</a:ln>");
  } else buf_printf(b, "<a:ln><a:noFill/></a:ln>");
  buf_printf(b, "</p:spPr>");
  if (text[0] || istext) {
    long ins = emu(PAD);
    buf_printf(b, "<p:txBody><a:bodyPr wrap=\"square\" lIns=\"%ld\" tIns=\"%ld\" rIns=\"%ld\" bIns=\"%ld\" anchor=\"%s\" rtlCol=\"0\"><a:noAutofit/></a:bodyPr><a:lstStyle/>",
               ins, ins, ins, ins, o->type == O_EMBED ? "ctr" : ANC[o->valign % 3]);
    int sz = (int)(o->size * 0.6667f * 100 + 0.5f);
    uint32_t col = o->type == O_EMBED ? RGB(95, 99, 104) : text_col(sl, o);
    const char *t = text;
    do {
      const char *e = strchr(t, '\n');
      int l = e ? (int)(e - t) : (int)strlen(t);
      buf_printf(b, "<a:p><a:pPr algn=\"%s\"", o->type == O_EMBED ? "ctr" : ALG[o->align % 3]);
      if (o->bullets && l) buf_printf(b, " marL=\"%ld\" indent=\"-%ld\"><a:buFont typeface=\"Arial\"/><a:buChar char=\"&#8226;\"/></a:pPr>", emu(o->size * 1.2f), emu(o->size * 1.2f));
      else buf_printf(b, "><a:buNone/></a:pPr>");
      if (l) {
        buf_printf(b, "<a:r>");
        px_run_pr(b, o, col, sz, o->bold);
        buf_printf(b, "<a:t>");
        buf_esc(b, t, l);
        buf_printf(b, "</a:t></a:r>");
      }
      buf_printf(b, "<a:endParaRPr lang=\"en-US\" sz=\"%d\" dirty=\"0\"/></a:p>", sz);
      t = e ? e + 1 : NULL;
    } while (t);
    buf_printf(b, "</p:txBody>");
  }
  buf_printf(b, "</p:sp>");
}

static void export_pptx(void) {
  char path[700], shown[200];
  end_edit();
  office_export_path(D.title, "pptx", path, sizeof path, shown, sizeof shown);
  ZipW *z = zw_open(path);
  if (!z) {
    office_toast("Could not save the file");
    return;
  }
  Buf b = {0};
  int ns = D.ns > 60 ? 60 : D.ns;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                 "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                 "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>"
                 "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>"
                 "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>"
                 "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>"
                 "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>");
  for (int i = 0; i < ns; i++)
    buf_printf(&b, "<Override PartName=\"/ppt/slides/slide%d.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>", i + 1);
  buf_printf(&b, "</Types>");
  zw_add(z, "[Content_Types].xml", b.s, b.n);
  zw_adds(z, "_rels/.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"ppt/presentation.xml\"/>"
          "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
          "</Relationships>");
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>");
  buf_esc(&b, D.title, -1);
  buf_printf(&b, "</dc:title><dc:creator>Oreon Office</dc:creator></cp:coreProperties>");
  zw_add(z, "docProps/core.xml", b.s, b.n);
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<p:presentation %s saveSubsetFonts=\"1\"><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>", PNS);
  for (int i = 0; i < ns; i++) buf_printf(&b, "<p:sldId id=\"%d\" r:id=\"rId%d\"/>", 256 + i, i + 3);
  buf_printf(&b, "</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>");
  zw_add(z, "ppt/presentation.xml", b.s, b.n);
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                 "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>"
                 "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme\" Target=\"theme/theme1.xml\"/>");
  for (int i = 0; i < ns; i++)
    buf_printf(&b, "<Relationship Id=\"rId%d\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide%d.xml\"/>", i + 3, i + 1);
  buf_printf(&b, "</Relationships>");
  zw_add(z, "ppt/_rels/presentation.xml.rels", b.s, b.n);
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<p:sldMaster %s><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>%s</p:spTree></p:cSld>"
                 "<p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>"
                 "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst>"
                 "<p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz=\"4400\"><a:latin typeface=\"+mj-lt\"/></a:defRPr></a:lvl1pPr></p:titleStyle>"
                 "<p:bodyStyle><a:lvl1pPr><a:defRPr sz=\"2800\"><a:latin typeface=\"+mn-lt\"/></a:defRPr></a:lvl1pPr></p:bodyStyle>"
                 "<p:otherStyle><a:lvl1pPr><a:defRPr sz=\"1800\"><a:latin typeface=\"+mn-lt\"/></a:defRPr></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>",
             PNS, GRP0);
  zw_add(z, "ppt/slideMasters/slideMaster1.xml", b.s, b.n);
  zw_adds(z, "ppt/slideMasters/_rels/slideMaster1.xml.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>"
          "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme\" Target=\"../theme/theme1.xml\"/>"
          "</Relationships>");
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<p:sldLayout %s type=\"blank\" preserve=\"1\"><p:cSld name=\"Blank\"><p:spTree>%s</p:spTree></p:cSld>"
                 "<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>",
             PNS, GRP0);
  zw_add(z, "ppt/slideLayouts/slideLayout1.xml", b.s, b.n);
  zw_adds(z, "ppt/slideLayouts/_rels/slideLayout1.xml.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/>"
          "</Relationships>");
  b.n = 0;
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<a:theme xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" name=\"Oreon\"><a:themeElements>"
                 "<a:clrScheme name=\"Oreon\"><a:dk1><a:srgbClr val=\"202124\"/></a:dk1><a:lt1><a:srgbClr val=\"FFFFFF\"/></a:lt1><a:dk2><a:srgbClr val=\"3C4043\"/></a:dk2>"
                 "<a:lt2><a:srgbClr val=\"F1F3F4\"/></a:lt2><a:accent1><a:srgbClr val=\"1A73E8\"/></a:accent1><a:accent2><a:srgbClr val=\"DE6018\"/></a:accent2>"
                 "<a:accent3><a:srgbClr val=\"188038\"/></a:accent3><a:accent4><a:srgbClr val=\"F9AB00\"/></a:accent4><a:accent5><a:srgbClr val=\"9334E6\"/></a:accent5>"
                 "<a:accent6><a:srgbClr val=\"D93025\"/></a:accent6><a:hlink><a:srgbClr val=\"1A73E8\"/></a:hlink><a:folHlink><a:srgbClr val=\"9334E6\"/></a:folHlink></a:clrScheme>"
                 "<a:fontScheme name=\"Oreon\"><a:majorFont><a:latin typeface=\"Arial\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont>"
                 "<a:minorFont><a:latin typeface=\"Arial\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>"
                 "<a:fmtScheme name=\"Oreon\"><a:fillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>"
                 "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>"
                 "<a:ln w=\"12700\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln><a:ln w=\"19050\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln></a:lnStyleLst>"
                 "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>"
                 "<a:bgFillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:bgFillStyleLst>"
                 "</a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>");
  zw_add(z, "ppt/theme/theme1.xml", b.s, b.n);
  for (int i = 0; i < ns; i++) {
    Slide *sl = &D.sl[i];
    b.n = 0;
    buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<p:sld %s><p:cSld>", PNS);
    buf_printf(&b, "<p:bg><p:bgPr>");
    px_fill(&b, bg_col(sl));
    buf_printf(&b, "<a:effectLst/></p:bgPr></p:bg><p:spTree>%s", GRP0);
    for (int j = 0; j < sl->n; j++) px_shape(&b, sl, &sl->o[j], j + 2);
    buf_printf(&b, "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>");
    char nm[64];
    snprintf(nm, sizeof nm, "ppt/slides/slide%d.xml", i + 1);
    zw_add(z, nm, b.s, b.n);
    snprintf(nm, sizeof nm, "ppt/slides/_rels/slide%d.xml.rels", i + 1);
    zw_adds(z, nm,
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>"
            "</Relationships>");
  }
  free(b.s);
  office_toast(zw_close(z) ? "Could not save the file" : shown);
}

static int pal_near(unsigned rgb) {
  int best = 1;
  long bd = 1L << 40;
  for (int i = 1; i < 16; i++) {
    long dr = (long)((PAL[i] >> 16) & 255) - (rgb >> 16 & 255), dg = (long)((PAL[i] >> 8) & 255) - (rgb >> 8 & 255), db = (long)(PAL[i] & 255) - (rgb & 255);
    long d = dr * dr * 3 + dg * dg * 4 + db * db * 2;
    if (d < bd) bd = d, best = i;
  }
  return best;
}

static unsigned scheme_rgb(const char *v) {
  static const struct {
    const char *n;
    unsigned c;
  } T[] = {{"dk1", 0x000000}, {"tx1", 0x000000}, {"lt1", 0xFFFFFF}, {"bg1", 0xFFFFFF}, {"dk2", 0x44546A}, {"tx2", 0x44546A},
           {"lt2", 0xE7E6E6}, {"bg2", 0xE7E6E6}, {"accent1", 0x4472C4}, {"accent2", 0xED7D31}, {"accent3", 0xA5A5A5},
           {"accent4", 0xFFC000}, {"accent5", 0x5B9BD5}, {"accent6", 0x70AD47}, {"hlink", 0x0563C1}, {"folHlink", 0x954F72}};
  for (unsigned i = 0; i < sizeof T / sizeof *T; i++)
    if (!strcmp(T[i].n, v)) return T[i].c;
  return 0x808080;
}

typedef struct {
  char type[24];
  int idx, has;
  double x, y, w, h;
  int sz;
} PhPos;

typedef struct {
  double ox, oy, sx, sy;
} GrpT;

static int rel_target(Zip *z, const char *part, const char *rid, const char *type_sub, char *out, int n) {
  char rp[300], v[300];
  const char *sl = strrchr(part, '/');
  int dl = sl ? (int)(sl - part) : 0;
  snprintf(rp, sizeof rp, "%.*s/_rels/%s.rels", dl, part, sl ? sl + 1 : part);
  size_t len;
  char *x = zip_read(z, rp, &len);
  if (!x) return 0;
  Xml X;
  xml_init(&X, x, len);
  int ok = 0;
  while (!ok && xml_next(&X) != X_EOF) {
    if (X.type != X_OPEN || !xml_is(&X, "Relationship")) continue;
    if (rid) {
      xml_attr(&X, "Id", v, sizeof v);
      if (strcmp(v, rid)) continue;
    } else {
      xml_attr(&X, "Type", v, sizeof v);
      if (!strstr(v, type_sub)) continue;
    }
    xml_attr(&X, "Target", v, sizeof v);
    if (v[0] == '/') snprintf(out, (size_t)n, "%s", v + 1);
    else {
      char base[300];
      snprintf(base, sizeof base, "%.*s", dl, part);
      const char *t = v;
      while (!strncmp(t, "../", 3)) {
        char *s2 = strrchr(base, '/');
        if (s2) *s2 = 0;
        else base[0] = 0;
        t += 3;
      }
      snprintf(out, (size_t)n, "%.180s%s%.110s", base, base[0] ? "/" : "", t);
    }
    ok = 1;
  }
  free(x);
  return ok;
}

static int ph_scan(Zip *z, const char *part, PhPos *ph, int max) {
  size_t n;
  char *x = zip_read(z, part, &n);
  if (!x) return 0;
  Xml X;
  xml_init(&X, x, n);
  int cnt = 0, in_sp = 0, in_sppr = 0, in_rpr = 0;
  char v[64];
  PhPos cur;
  while (xml_next(&X) != X_EOF) {
    if (X.type == X_OPEN) {
      if (xml_is(&X, "sp")) in_sp = 1, memset(&cur, 0, sizeof cur), cur.idx = -1;
      else if (in_sp && xml_is(&X, "ph")) {
        cur.has = 1;
        if (!xml_attr(&X, "type", cur.type, sizeof cur.type)) snprintf(cur.type, sizeof cur.type, "body");
        if (xml_attr(&X, "idx", v, sizeof v)) cur.idx = atoi(v);
      } else if (in_sp && xml_is(&X, "spPr")) in_sppr = 1;
      else if (in_sppr && xml_is(&X, "off")) {
        xml_attr(&X, "x", v, sizeof v), cur.x = atof(v);
        xml_attr(&X, "y", v, sizeof v), cur.y = atof(v);
      } else if (in_sppr && xml_is(&X, "ext")) {
        xml_attr(&X, "cx", v, sizeof v), cur.w = atof(v);
        xml_attr(&X, "cy", v, sizeof v), cur.h = atof(v);
      } else if (in_sp && (xml_is(&X, "defRPr") || xml_is(&X, "rPr")) && !cur.sz && xml_attr(&X, "sz", v, sizeof v)) cur.sz = atoi(v);
      else if (xml_is(&X, "rPr")) in_rpr = 1;
    } else if (X.type == X_CLOSE) {
      if (xml_is(&X, "spPr")) in_sppr = 0;
      else if (xml_is(&X, "rPr")) in_rpr = 0;
      else if (xml_is(&X, "sp")) {
        if (cur.has && cnt < max) ph[cnt++] = cur;
        in_sp = 0;
      }
    }
  }
  (void)in_rpr;
  free(x);
  return cnt;
}

static const PhPos *ph_find(const PhPos *ph, int n, const char *type, int idx) {
  for (int i = 0; i < n; i++)
    if (idx >= 0 && ph[i].idx == idx && ph[i].w > 0) return &ph[i];
  int title = !strcmp(type, "title") || !strcmp(type, "ctrTitle");
  for (int i = 0; i < n; i++) {
    int t2 = !strcmp(ph[i].type, "title") || !strcmp(ph[i].type, "ctrTitle");
    if ((title && t2) || !strcmp(ph[i].type, type)) return &ph[i];
  }
  if (!strcmp(type, "subTitle") || !strcmp(type, "obj"))
    for (int i = 0; i < n; i++)
      if (!strcmp(ph[i].type, "body")) return &ph[i];
  return NULL;
}

static void pptx_slide(Zip *z, const char *part, double k, double offx, double offy, Slide *sl) {
  char layout[300] = "", master[300] = "";
  PhPos lph[40], mph[40];
  int nl = 0, nm = 0;
  if (rel_target(z, part, NULL, "/slideLayout", layout, sizeof layout)) {
    nl = ph_scan(z, layout, lph, 40);
    if (rel_target(z, layout, NULL, "/slideMaster", master, sizeof master)) nm = ph_scan(z, master, mph, 40);
  }
  size_t n;
  char *x = zip_read(z, part, &n);
  if (!x) return;
  Xml X;
  xml_init(&X, x, n);
  char stack[48][16];
  int sp = 0;
  GrpT gs[16];
  int ng = 0;
  gs[0] = (GrpT){0, 0, 1, 1};
  char v[128];
  int in_shape = 0, in_t = 0, para_has = 0, any_bu = 0, bu_none = 0, first_run = 1, autofit = 100000;
  double sx = 0, sy = 0, sw = 0, sh = 0, gox = 0, goy = 0, gcx = 0, gcy = 0, gchx = 0, gchy = 0;
  int has_xfrm = 0, prst = O_TEXT, fill = 0, line = 0, txcol = 0, sz = 0, bold = 0, ital = 0, under = 0, algn = -1, anchor = -1, txbox = 0;
  char phtype[24] = "";
  int phidx = -1, isph = 0, is_tbl = 0;
  Buf text = {0};
  int bg = 0;
  while (xml_next(&X) != X_EOF) {
    if (X.type == X_OPEN) {
      const char *parent = sp > 0 ? stack[sp - 1] : "";
      const char *gp = sp > 1 ? stack[sp - 2] : "";
      if (xml_is(&X, "pic") || xml_is(&X, "cxnSp") || xml_is(&X, "AlternateContent") || xml_is(&X, "extLst")) {
        xml_skip(&X);
        continue;
      }
      if (xml_is(&X, "sp") || (xml_is(&X, "graphicFrame"))) {
        in_shape = 1, has_xfrm = 0, prst = O_TEXT, fill = line = txcol = sz = bold = ital = under = 0, algn = anchor = -1, txbox = 0;
        phtype[0] = 0, phidx = -1, isph = 0, any_bu = 0, bu_none = 0, first_run = 1, para_has = 0, autofit = 100000;
        is_tbl = xml_is(&X, "graphicFrame");
        text.n = 0;
        buf_put(&text, "", 0);
      } else if (xml_is(&X, "grpSp") && ng < 15) {
        ng++;
        gs[ng] = gs[ng - 1];
        gox = goy = gcx = gcy = gchx = gchy = 0;
      } else if (in_shape && xml_is(&X, "ph")) {
        isph = 1;
        if (!xml_attr(&X, "type", phtype, sizeof phtype)) snprintf(phtype, sizeof phtype, "body");
        if (xml_attr(&X, "idx", v, sizeof v)) phidx = atoi(v);
      } else if (in_shape && xml_is(&X, "cNvSpPr")) txbox = xml_attr(&X, "txBox", v, sizeof v) && (v[0] == '1' || v[0] == 't');
      else if (xml_is(&X, "off") && (!strcmp(parent, "xfrm"))) {
        xml_attr(&X, "x", v, sizeof v);
        double ox = atof(v);
        xml_attr(&X, "y", v, sizeof v);
        double oy = atof(v);
        if (in_shape) sx = ox, sy = oy, has_xfrm = 1;
        else if (!strcmp(gp, "grpSpPr")) gox = ox, goy = oy;
      } else if (xml_is(&X, "ext") && !strcmp(parent, "xfrm")) {
        xml_attr(&X, "cx", v, sizeof v);
        double cx = atof(v);
        xml_attr(&X, "cy", v, sizeof v);
        double cy = atof(v);
        if (in_shape) sw = cx, sh = cy;
        else if (!strcmp(gp, "grpSpPr")) gcx = cx, gcy = cy;
      } else if (xml_is(&X, "chOff") && !in_shape && ng > 0) {
        xml_attr(&X, "x", v, sizeof v), gchx = atof(v);
        xml_attr(&X, "y", v, sizeof v), gchy = atof(v);
      } else if (xml_is(&X, "chExt") && !in_shape && ng > 0) {
        xml_attr(&X, "cx", v, sizeof v);
        double cx = atof(v);
        xml_attr(&X, "cy", v, sizeof v);
        double cy = atof(v);
        GrpT *p = &gs[ng - 1], *g = &gs[ng];
        double kx = cx > 0 ? gcx / cx : 1, ky = cy > 0 ? gcy / cy : 1;
        g->sx = p->sx * kx, g->sy = p->sy * ky;
        g->ox = p->ox + p->sx * (gox - gchx * kx), g->oy = p->oy + p->sy * (goy - gchy * ky);
      } else if (in_shape && xml_is(&X, "prstGeom")) {
        xml_attr(&X, "prst", v, sizeof v);
        prst = !strcmp(v, "ellipse") ? O_ELLIPSE : (!strcmp(v, "roundRect") || !strcmp(v, "snipRoundRect")) ? O_ROUND : O_RECT;
      } else if (xml_is(&X, "srgbClr") || xml_is(&X, "schemeClr") || xml_is(&X, "sysClr")) {
        unsigned rgb;
        if (xml_is(&X, "srgbClr")) xml_attr(&X, "val", v, sizeof v), rgb = (unsigned)strtoul(v, NULL, 16);
        else if (xml_is(&X, "sysClr")) xml_attr(&X, "lastClr", v, sizeof v), rgb = (unsigned)strtoul(v, NULL, 16);
        else xml_attr(&X, "val", v, sizeof v), rgb = scheme_rgb(v);
        int pi = pal_near(rgb);
        if (!strcmp(parent, "solidFill")) {
          if (!strcmp(gp, "spPr") && in_shape) fill = pi;
          else if (!strcmp(gp, "ln") && in_shape) line = pi;
          else if ((!strcmp(gp, "rPr") || !strcmp(gp, "defRPr")) && in_shape && !txcol) txcol = pi;
          else if (!strcmp(gp, "bgPr")) bg = pi;
        }
      } else if (in_shape && xml_is(&X, "normAutofit") && xml_attr(&X, "fontScale", v, sizeof v)) autofit = atoi(v);
      else if (in_shape && xml_is(&X, "bodyPr") && xml_attr(&X, "anchor", v, sizeof v)) anchor = !strcmp(v, "ctr") ? VA_MID : !strcmp(v, "b") ? VA_BOT : VA_TOP;
      else if (in_shape && xml_is(&X, "pPr")) {
        if (algn < 0 && xml_attr(&X, "algn", v, sizeof v)) algn = !strcmp(v, "ctr") ? AL_CENTER : !strcmp(v, "r") ? AL_RIGHT : AL_LEFT;
      } else if (in_shape && (xml_is(&X, "buChar") || xml_is(&X, "buAutoNum"))) any_bu = 1;
      else if (in_shape && xml_is(&X, "buNone")) bu_none = 1;
      else if (in_shape && xml_is(&X, "p")) {
        if (para_has++) buf_put(&text, "\n", 1);
      } else if (in_shape && is_tbl && xml_is(&X, "tc") && strcmp(parent, "tr") == 0) {
        if (text.n && text.s[text.n - 1] != '\n') buf_put(&text, "  |  ", 5);
      } else if (in_shape && is_tbl && xml_is(&X, "tr")) {
        if (text.n) buf_put(&text, "\n", 1);
      } else if (in_shape && xml_is(&X, "rPr") && first_run) {
        first_run = 0;
        if (xml_attr(&X, "sz", v, sizeof v)) sz = atoi(v);
        if (xml_attr(&X, "b", v, sizeof v)) bold = v[0] == '1' || v[0] == 't';
        if (xml_attr(&X, "i", v, sizeof v)) ital = v[0] == '1' || v[0] == 't';
        if (xml_attr(&X, "u", v, sizeof v)) under = strcmp(v, "none") != 0;
      } else if (in_shape && xml_is(&X, "t")) in_t = !X.empty;
      else if (in_shape && xml_is(&X, "br")) buf_put(&text, "\n", 1);
      if (!X.empty && sp < 48) snprintf(stack[sp++], 16, "%.*s", X.llen < 15 ? X.llen : 15, X.lname);
      if (is_tbl && xml_is(&X, "tc")) para_has = 0;
    } else if (X.type == X_CLOSE) {
      if (sp > 0) sp--;
      if (xml_is(&X, "t")) in_t = 0;
      else if (xml_is(&X, "grpSp") && ng > 0) ng--;
      else if (in_shape && (xml_is(&X, "sp") || xml_is(&X, "graphicFrame"))) {
        in_shape = 0;
        double ex = sx, ey = sy, ew = sw, eh = sh;
        const PhPos *pp = NULL;
        if (isph) {
          pp = ph_find(lph, nl, phtype, phidx);
          const PhPos *mp = ph_find(mph, nm, phtype, phidx);
          if (!has_xfrm) {
            if (!pp || pp->w <= 0) pp = mp;
            if (pp) ex = pp->x, ey = pp->y, ew = pp->w, eh = pp->h, has_xfrm = 1;
          }
          if (!sz) sz = pp && pp->sz ? pp->sz : mp && mp->sz ? mp->sz : 0;
        }
        int is_title = isph && (!strcmp(phtype, "title") || !strcmp(phtype, "ctrTitle"));
        if (!sz) sz = is_title ? 4400 : isph ? 2800 : 1800;
        if (!has_xfrm || ew <= 0 || eh <= 0) continue;
        if (!text.s || !text.s[0]) {
          if (txbox || isph || is_tbl || (!fill && !line)) continue;
        }
        GrpT *g = &gs[ng];
        Obj *o = obj_add(sl);
        if (!o) continue;
        o->type = (unsigned char)(txbox || isph || is_tbl || (prst == O_RECT && !fill && !line) ? O_TEXT : prst);
        o->x = (float)((g->ox + ex * g->sx) * k + offx), o->y = (float)((g->oy + ey * g->sy) * k + offy);
        o->w = (float)(ew * g->sx * k), o->h = (float)(eh * g->sy * k);
        float fs = (float)(sz / 100.0 * 1.5 * autofit / 100000.0 * (k * EMU_U));
        o->size = fs < 8 ? 8 : fs > 200 ? 200 : fs;
        o->bold = (unsigned char)(bold || is_title), o->ital = (unsigned char)ital, o->under = (unsigned char)under;
        o->align = (unsigned char)(is_tbl ? AL_LEFT : algn >= 0 ? algn : (o->type == O_TEXT ? (!strcmp(phtype, "ctrTitle") || !strcmp(phtype, "subTitle") ? AL_CENTER : AL_LEFT) : AL_CENTER));
        o->valign = (unsigned char)(anchor >= 0 ? anchor : o->type == O_TEXT ? (is_title ? VA_MID : VA_TOP) : VA_MID);
        o->fill = (unsigned char)(o->type == O_TEXT && !txbox && !isph ? 0 : fill);
        if (o->type != O_TEXT) o->fill = (unsigned char)fill;
        o->line = (unsigned char)line;
        o->color = (unsigned char)txcol;
        o->bullets = (unsigned char)((any_bu || (isph && !strcmp(phtype, "body") && !is_title && phidx >= 1)) && !bu_none);
        free(o->text);
        o->text = strdup(text.s ? text.s : "");
      }
    } else if (X.type == X_TEXT && in_t && in_shape) {
      char *t = malloc((size_t)X.tlen * 3 + 8);
      int l = xml_text(&X, t, X.tlen * 3 + 8);
      buf_put(&text, t, (size_t)l);
      free(t);
    }
  }
  sl->bg = (unsigned char)(bg == 1 ? 0 : bg);
  free(text.s);
  free(x);
}

int slides_import(const char *path) {
  Zip *z = zip_open(path);
  size_t n;
  char *x = z ? zip_read(z, "ppt/presentation.xml", &n) : NULL;
  if (!x) {
    zip_close(z);
    return 0;
  }
  double cx = 12192000, cy = 6858000;
  char rids[MAXSLIDES][24];
  int nr = 0;
  char v[64];
  Xml X;
  xml_init(&X, x, n);
  while (xml_next(&X) != X_EOF) {
    if (X.type != X_OPEN) continue;
    if (xml_is(&X, "sldId") && nr < MAXSLIDES) nr += xml_attr(&X, "r:id", rids[nr], sizeof rids[0]) && rids[nr][0];
    else if (xml_is(&X, "sldSz")) {
      if (xml_attr(&X, "cx", v, sizeof v)) cx = atof(v);
      if (xml_attr(&X, "cy", v, sizeof v)) cy = atof(v);
    }
  }
  free(x);
  if (cx <= 0 || cy <= 0) cx = 12192000, cy = 6858000;
  double k = SW / cx;
  if (SH / cy < k) k = SH / cy;
  double offx = (SW - cx * k) / 2, offy = (SH - cy * k) / 2;
  slides_home_scan();
  new_deck();
  deck_clear();
  office_title_from_path(path, D.title, sizeof D.title);
  for (int i = 0; i < nr && D.ns < MAXSLIDES; i++) {
    char part[300];
    if (!rel_target(z, "ppt/presentation.xml", rids[i], NULL, part, sizeof part)) continue;
    Slide *sl = &D.sl[D.ns++];
    memset(sl, 0, sizeof *sl);
    pptx_slide(z, part, k, offx, offy, sl);
  }
  zip_close(z);
  if (!D.ns) {
    memset(&D.sl[0], 0, sizeof(Slide));
    D.ns = 1;
  }
  D.cur = 0;
  reset_view();
  save_deck();
  office_set_title();
  return 1;
}
