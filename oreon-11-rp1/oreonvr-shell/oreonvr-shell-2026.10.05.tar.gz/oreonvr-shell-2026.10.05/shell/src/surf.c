#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <glob.h>
#include <linux/input.h>
#include <math.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "store.h"

#define NW 1240
#define NH 820
#define TS 56
#define TBH 64
#define BBH 32
#define MAXT 32
#define MAXH 2000
#define MAXB 40
#define RAD 22
#define DOCKH 320
#define DOCK_HEAD 40
#define MAXSC 12
#define WIN_W0 1240
#define WIN_H0 836
#define WIN_SZ "1240,836"

#define K_FRAME THEME(RGB(255, 255, 255), RGB(40, 43, 50))
#define K_TAB_HOT THEME(RGB(244, 245, 247), RGB(50, 53, 60))
#define K_BAR THEME(RGB(255, 255, 255), RGB(40, 43, 50))
#define K_OMNI THEME(RGB(240, 241, 243), RGB(56, 59, 67))
#define K_OMNI_HOT THEME(RGB(232, 234, 237), RGB(64, 67, 76))
#define K_TEXT THEME(RGB(32, 33, 36), RGB(232, 234, 237))
#define K_MUTED THEME(RGB(95, 99, 104), RGB(154, 160, 166))
#define K_ICON THEME(RGB(68, 71, 76), RGB(206, 210, 216))
#define K_DIM THEME(RGB(180, 184, 190), RGB(92, 96, 104))
#define K_LINE THEME(RGB(218, 222, 228), RGB(62, 66, 74))
#define K_HOVER THEME(RGBA(32, 33, 36, 22), RGBA(255, 255, 255, 26))
#define K_PRESS THEME(RGBA(32, 33, 36, 40), RGBA(255, 255, 255, 44))
#define K_ACC THEME(RGB(11, 87, 208), RGB(138, 180, 248))
#define K_ACC_SOFT THEME(RGB(211, 227, 253), RGB(40, 60, 96))
#define K_CARD THEME(RGB(255, 255, 255), RGB(41, 44, 51))
#define K_PAGE THEME(RGB(248, 248, 249), RGB(32, 34, 39))
#define K_WARN THEME(RGB(197, 34, 31), RGB(242, 139, 130))

enum { E_OFF, E_START, E_READY, E_MISSING, E_FAIL };
enum { N_WEB, N_NEWTAB, N_HISTORY, N_ABOUT, N_PDF };
enum { R_NONE, R_CREATE, R_ATTACH, R_HIST, R_FOCUS, R_CTX, R_VERSION, R_WIN, R_INFO, R_EVAL };
enum {
  Z_TAB = 100, Z_TABX = 200, Z_NEWTAB = 300, Z_WINX, Z_DRAG, Z_BACK = 310, Z_FWD, Z_RELOAD, Z_HOMEB, Z_OMNI = 320, Z_STAR, Z_MENU,
  Z_ZOOMB, Z_BM = 400, Z_SUG = 500, Z_MI = 600, Z_PAGE = 700, Z_FAKEBOX = 710, Z_TILE = 720, Z_CTX = 800, Z_DLG_OK = 900,
  Z_DLG_NO, Z_DLG_IN, Z_RETRY = 950, Z_BLOCK = 990, Z_HROW = 1000, Z_HCLEAR = 3000, Z_HSEARCH, Z_SC_EDIT = 4100, Z_SC_ADD = 4120, Z_SE_NAME, Z_SE_URL, Z_SE_DONE,
  Z_SE_CANCEL, Z_SE_REMOVE, Z_REC = 4140, Z_DOCK = 4200, Z_DOCKX, Z_DOCK_DT, Z_DOCK_CON, Z_CON_CLEAR, Z_CON_IN, Z_DOCK_BODY,
  Z_PDF_ZOUT = 4300, Z_PDF_ZIN, Z_PDF_FIT, Z_PDF_DL, Z_PDF_BODY
};
enum { M_NEWTAB, M_REOPEN, M_HISTORY, M_BBAR, M_ZOOM_OUT, M_ZOOM_RESET, M_ZOOM_IN, M_DEVTOOLS, M_CONSOLE, M_CLEAR, M_ABOUT, M_COUNT };
enum { C_OPEN_LINK, C_OPEN_IMG, C_SEARCH, C_BACK, C_FWD, C_RELOAD, C_SOURCE, C_INSPECT, C_PIN, C_UNPIN, C_DUP, C_CLOSETAB, C_CLOSEOTHERS };

typedef struct {
  char lvl;
  char text[220];
} Con;

typedef struct {
  uint32_t *px;
  int w, h, want;
  NetReq *job;
} PdfPage;

typedef struct {
  char url[1024], path[700], name[160], title[160];
  int state, n, rendering, dl, cur, fit;
  float pw, ph, zoom, scroll;
  NetReq *fetch, *info;
  PdfPage pg[400];
} Pdf;

typedef struct {
  char tid[40], sid[48], url[1024], title[200];
  int native, loading, back_id, fwd_id, attached, zoom, crashed, pinned, wdx, wdy, bad, ldw, ldh, ncon, devtools;
  uint32_t bad_t;
  Con *con;
  Pdf *pdf;
  uint32_t load_t0;
  uint32_t *fb;
  int fw, fh;
  char *pend;
  int pend_sid;
} Tab;

typedef struct {
  char url[1024], title[160];
  long t;
  int n;
} Hist;

typedef struct {
  char url[1024], title[120];
} Mark;

typedef struct {
  int id, kind, zoom;
  char tid[40];
} Pend;

typedef struct {
  int native, activate, after, pinned, devtools;
} Want;

typedef struct {
  char name[60], url[600];
} Short;

static struct {
  int st, fd, port, fport, nextid, have_ver, cal, dx, dy, bad, ldw, ldh;
  uint32_t bad_t;
  pid_t pid;
  uint32_t t0;
  char bin[760], err[240], ver[64], ua[300], dir[600], prof[700], wsp[200];
  Buf rx, msg;
  Pend pend[160];
} E;

static Tab *TB[MAXT];
static int ntab, act = -1;
static Hist H[MAXH];
static int nh;
static Mark BM[MAXB];
static int nbm;
static Want WANT[8];
static int nwant;
static Short SCL[MAXSC];
static int nsc;
static Tab *DT;
static char dt_for[40];
static char closed[10][1024];
static int nclosed;

static struct {
  int panel, omni, sel_all, cur, sug_sel, nsug, menu, ctx, nctx, bbar, hscroll, press, mbtn, mdown, mover, dlg, dlg_type, dlg_focus,
      hfocus, zoom_pop, dock, kfocus, sedit, se_focus, ctx_tab, con_scroll;
  int ctx_items[16], ctx_args[16];
  float newtab_x;
  char se_name[60], se_url[600], con_in[600], con_last[600];
  float mx, my, ctx_x, ctx_y, sent_x, sent_y, last_cx, last_cy;
  uint32_t toast_t, blink_t, click_t, zoom_t, moved_t;
  int blink, clicks;
  char text[1024], toast[160], ctx_link[1024], ctx_img[1024], ctx_sel[200], dlg_msg[600], dlg_in[400], hq[96];
  char sug[8][1024], sug_title[8][200];
  int sug_kind[8];
  float content_h;
} S;

static const float ZOOMS[] = {0.5f, 0.67f, 0.75f, 0.8f, 0.9f, 1.f, 1.1f, 1.25f, 1.5f, 1.75f, 2.f};
#define ZOOM_DEF 5
#define NZOOM 11

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static uint32_t mixc(uint32_t a, uint32_t b, float t) {
  int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
  return RGB((int)(ar + (br - ar) * t), (int)(ag + (bg - ag) * t), (int)(ab + (bb - ab) * t));
}

static void toast(const char *m) {
  snprintf(S.toast, sizeof S.toast, "%.159s", m);
  S.toast_t = now_ms();
}

static void dirty(void) {
  if (S.panel >= 0 && S.panel < MAXP && P[S.panel].used) P[S.panel].dirty = 1;
}

static int page_y(void) { return TS + TBH + (S.bbar ? BBH : 0); }
static int page_h(void) { return NH - page_y() - (S.dock ? DOCKH : 0); }
static int dock_y(void) { return NH - DOCKH; }
static int dt_h(void) { return DOCKH - DOCK_HEAD - 8; }

static Tab *cur(void) { return act >= 0 && act < ntab ? TB[act] : NULL; }

static const char *js(const char *s) {
  static char ring[4][2600];
  static int k;
  char *o = ring[k = (k + 1) & 3];
  int n = 0;
  o[n++] = '"';
  for (; *s && n < 2590; s++) {
    unsigned char c = (unsigned char)*s;
    if (c == '"' || c == '\\') o[n++] = '\\', o[n++] = (char)c;
    else if (c < 0x20) n += snprintf(o + n, 8, "\\u%04x", c);
    else o[n++] = (char)c;
  }
  o[n++] = '"';
  o[n] = 0;
  return o;
}

static size_t b64dec(const char *s, unsigned char *out) {
  static signed char T[256];
  static int init;
  if (!init) {
    memset(T, -1, sizeof T);
    const char *a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (int i = 0; i < 64; i++) T[(unsigned char)a[i]] = (signed char)i;
    init = 1;
  }
  size_t n = 0;
  unsigned v = 0;
  int bits = 0;
  for (; *s; s++) {
    int d = T[(unsigned char)*s];
    if (d < 0) continue;
    v = v << 6 | (unsigned)d, bits += 6;
    if (bits >= 8) bits -= 8, out[n++] = (unsigned char)(v >> bits);
  }
  return n;
}

static void url_host(const char *u, char *h, int n) {
  const char *p = strstr(u, "://");
  p = p ? p + 3 : u;
  const char *at = strchr(p, '@'), *sl = strpbrk(p, "/?#");
  if (at && (!sl || at < sl)) p = at + 1;
  int l = 0;
  while (p[l] && p[l] != '/' && p[l] != ':' && p[l] != '?' && p[l] != '#' && l < n - 1) l++;
  memcpy(h, p, (size_t)l);
  h[l] = 0;
}

static int is_web(const char *u) { return !strncmp(u, "http://", 7) || !strncmp(u, "https://", 8); }

static void pretty_url(const char *u, char *o, int n) {
  const char *p = u;
  if (!strncmp(p, "https://", 8)) p += 8;
  if (!strncmp(p, "www.", 4) && strchr(p + 4, '.')) p += 4;
  snprintf(o, (size_t)n, "%s", p);
  int l = (int)strlen(o);
  if (l > 1 && strchr(o, '/') == o + l - 1) o[l - 1] = 0;
}

static void urlenc(const char *s, char *o, int n) {
  int k = 0;
  for (; *s && k < n - 4; s++) {
    unsigned char c = (unsigned char)*s;
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o[k++] = (char)c;
    else if (c == ' ') o[k++] = '+';
    else k += snprintf(o + k, 4, "%%%02X", c);
  }
  o[k] = 0;
}

static void search_url(const char *q, char *o, int n) {
  char e[900];
  urlenc(q, e, sizeof e);
  snprintf(o, (size_t)n, "https://www.google.com/search?q=%s", e);
}

static int looks_url(const char *t) {
  if (!*t || strchr(t, ' ')) return 0;
  if (strstr(t, "://") || !strncmp(t, "about:", 6) || !strncmp(t, "data:", 5) || !strncmp(t, "view-source:", 12) ||
      !strncmp(t, "chrome:", 7) || !strncmp(t, "surf:", 5) || !strncmp(t, "file:", 5))
    return 1;
  if (!strncmp(t, "localhost", 9)) return 1;
  const char *d = strchr(t, '.');
  if (!d || d == t || !d[1]) return 0;
  char h[300];
  url_host(t, h, sizeof h);
  const char *ld = strrchr(h, '.');
  if (!ld || strlen(ld + 1) < 2) return 0;
  for (const char *c = ld + 1; *c; c++)
    if (!isalpha((unsigned char)*c) && !isdigit((unsigned char)*c)) return 0;
  return 1;
}

static void fixup(const char *t, char *o, int n) {
  while (*t == ' ') t++;
  if (!looks_url(t)) {
    search_url(t, o, n);
    return;
  }
  if (strstr(t, "://") || !strncmp(t, "about:", 6) || !strncmp(t, "data:", 5) || !strncmp(t, "view-source:", 12) ||
      !strncmp(t, "chrome:", 7) || !strncmp(t, "surf:", 5) || !strncmp(t, "file:", 5))
    snprintf(o, (size_t)n, "%s", t);
  else if (!strncmp(t, "localhost", 9)) snprintf(o, (size_t)n, "http://%s", t);
  else snprintf(o, (size_t)n, "https://%s", t);
}

static void favicon_url(const char *u, char *o, int n) {
  char h[300];
  url_host(u, h, sizeof h);
  snprintf(o, (size_t)n, "https://www.google.com/s2/favicons?domain=%s&sz=32", h);
}

static void data_path(char *o, int n, const char *f) { snprintf(o, (size_t)n, "%s/%s", E.dir, f); }

static void clean_field(char *s) {
  for (; *s; s++)
    if (*s == '\t' || *s == '\n' || *s == '\r') *s = ' ';
}

static void save_hist(void) {
  char p[700];
  data_path(p, sizeof p, "history.tsv");
  FILE *f = fopen(p, "w");
  if (!f) return;
  for (int i = nh - 1; i >= 0; i--) fprintf(f, "%ld\t%d\t%s\t%s\n", H[i].t, H[i].n, H[i].url, H[i].title);
  fclose(f);
}

static void save_marks(void) {
  char p[700];
  data_path(p, sizeof p, "bookmarks.tsv");
  FILE *f = fopen(p, "w");
  if (!f) return;
  for (int i = 0; i < nbm; i++) fprintf(f, "%s\t%s\n", BM[i].url, BM[i].title);
  fclose(f);
}

static void save_prefs(void) {
  char p[700];
  data_path(p, sizeof p, "prefs");
  FILE *f = fopen(p, "w");
  if (!f) return;
  fprintf(f, "bookmarks_bar=%d\n", S.bbar);
  fclose(f);
}

static Hist *hist_find(const char *u) {
  for (int i = 0; i < nh; i++)
    if (!strcmp(H[i].url, u)) return &H[i];
  return NULL;
}

static void hist_add(const char *u, const char *title) {
  if (!is_web(u)) return;
  Hist *h = hist_find(u);
  Hist tmp = {0};
  if (h) {
    tmp = *h;
    memmove(h, h + 1, sizeof(Hist) * (size_t)(nh - 1 - (h - H)));
    nh--;
  } else snprintf(tmp.url, sizeof tmp.url, "%s", u);
  if (title && *title) snprintf(tmp.title, sizeof tmp.title, "%s", title);
  clean_field(tmp.title);
  tmp.t = (long)time(NULL), tmp.n++;
  if (nh == MAXH) nh--;
  memmove(&H[1], &H[0], sizeof(Hist) * (size_t)nh);
  H[0] = tmp;
  nh++;
  save_hist();
}

static void hist_title(const char *u, const char *title) {
  Hist *h = hist_find(u);
  if (!h || !title || !*title || !strcmp(h->title, title)) return;
  snprintf(h->title, sizeof h->title, "%s", title);
  clean_field(h->title);
  save_hist();
}

static void load_sc(void);

static void load_data(void) {
  char p[700], line[2000];
  nh = nbm = 0;
  data_path(p, sizeof p, "history.tsv");
  FILE *f = fopen(p, "r");
  if (f) {
    while (fgets(line, sizeof line, f)) {
      line[strcspn(line, "\n")] = 0;
      char *a = strtok(line, "\t"), *b = strtok(NULL, "\t"), *c = strtok(NULL, "\t"), *d = strtok(NULL, "");
      if (!a || !b || !c) continue;
      if (nh == MAXH) memmove(&H[0], &H[1], sizeof(Hist) * (MAXH - 1)), nh--;
      memmove(&H[1], &H[0], sizeof(Hist) * (size_t)nh);
      memset(&H[0], 0, sizeof H[0]);
      H[0].t = atol(a), H[0].n = atoi(b);
      snprintf(H[0].url, sizeof H[0].url, "%s", c);
      snprintf(H[0].title, sizeof H[0].title, "%s", d ? d : "");
      nh++;
    }
    fclose(f);
  }
  data_path(p, sizeof p, "bookmarks.tsv");
  f = fopen(p, "r");
  if (f) {
    while (nbm < MAXB && fgets(line, sizeof line, f)) {
      line[strcspn(line, "\n")] = 0;
      char *tab = strchr(line, '\t');
      if (tab) *tab++ = 0;
      if (!line[0]) continue;
      snprintf(BM[nbm].url, sizeof BM[nbm].url, "%.1023s", line);
      snprintf(BM[nbm].title, sizeof BM[nbm].title, "%.119s", tab ? tab : line);
      nbm++;
    }
    fclose(f);
  }
  S.bbar = 0;
  load_sc();
  data_path(p, sizeof p, "prefs");
  f = fopen(p, "r");
  if (f) {
    while (fgets(line, sizeof line, f))
      if (!strncmp(line, "bookmarks_bar=", 14)) S.bbar = atoi(line + 14) != 0;
    fclose(f);
  }
}

static int mark_idx(const char *u) {
  for (int i = 0; i < nbm; i++)
    if (!strcmp(BM[i].url, u)) return i;
  return -1;
}

static void toggle_mark(void) {
  Tab *t = cur();
  if (!t || t->native || !t->url[0]) return;
  int i = mark_idx(t->url);
  if (i >= 0) {
    memmove(&BM[i], &BM[i + 1], sizeof(Mark) * (size_t)(nbm - i - 1));
    nbm--;
    toast("Bookmark removed");
  } else {
    if (nbm == MAXB) nbm--;
    snprintf(BM[nbm].url, sizeof BM[nbm].url, "%s", t->url);
    snprintf(BM[nbm].title, sizeof BM[nbm].title, "%.119s", t->title[0] ? t->title : t->url);
    clean_field(BM[nbm].title);
    nbm++;
    toast("Bookmarked");
  }
  save_marks();
}

static void find_bin(void) {
  E.bin[0] = 0;
  const char *e = getenv("OREONVR_CHROMIUM");
  if (e && *e) {
    if (strchr(e, '/')) {
      if (!access(e, X_OK)) snprintf(E.bin, sizeof E.bin, "%s", e);
      return;
    }
  }
  const char *names[] = {e && *e ? e : "chromium", "chromium", "chromium-browser", "google-chrome-stable", "google-chrome", "chrome"};
  const char *path = getenv("PATH");
  if (!path || !*path) path = "/usr/local/bin:/usr/bin:/bin";
  for (int k = 0; k < 6 && !E.bin[0]; k++) {
    char pp[2048];
    snprintf(pp, sizeof pp, "%s", path);
    for (char *sv = NULL, *d = strtok_r(pp, ":", &sv); d; d = strtok_r(NULL, ":", &sv)) {
      char c[700];
      snprintf(c, sizeof c, "%s/%s", d, names[k]);
      if (!access(c, X_OK)) {
        snprintf(E.bin, sizeof E.bin, "%s", c);
        break;
      }
    }
  }
  if (E.bin[0] || (e && *e)) return;
  if (!access("/var/lib/flatpak/app/org.chromium.Chromium", F_OK) && !access("/usr/libexec/oreonvr-chromium", X_OK)) {
    snprintf(E.bin, sizeof E.bin, "/usr/libexec/oreonvr-chromium");
    return;
  }
  const char *fixed[] = {"/usr/lib/chromium/chromium", "/usr/lib/chromium-browser/chromium-browser", "/usr/lib64/chromium-browser/chromium-browser",
                         "/snap/bin/chromium", "/opt/google/chrome/chrome", "/opt/chromium/chrome"};
  for (int k = 0; k < 6; k++)
    if (!access(fixed[k], X_OK)) {
      snprintf(E.bin, sizeof E.bin, "%s", fixed[k]);
      return;
    }
  glob_t g;
  if (!glob("/opt/pw-browsers/chromium-*/chrome-linux/chrome", 0, NULL, &g)) {
    if (g.gl_pathc) snprintf(E.bin, sizeof E.bin, "%s", g.gl_pathv[g.gl_pathc - 1]);
    globfree(&g);
  }
}

static void engine_stop(void) {
  if (E.fd >= 0) close(E.fd);
  E.fd = -1;
  if (E.pid > 0) {
    kill(E.pid, SIGTERM);
    int done = 0;
    for (int i = 0; i < 60 && !done; i++) {
      if (waitpid(E.pid, NULL, WNOHANG) == E.pid) done = 1;
      else usleep(20000);
    }
    if (!done) kill(E.pid, SIGKILL), waitpid(E.pid, NULL, 0);
  }
  E.pid = 0;
  free(E.rx.s), free(E.msg.s);
  memset(&E.rx, 0, sizeof E.rx), memset(&E.msg, 0, sizeof E.msg);
  memset(E.pend, 0, sizeof E.pend);
}

static void fail(const char *m) {
  snprintf(E.err, sizeof E.err, "%s", m);
  engine_stop();
  E.st = E_FAIL;
  dirty();
}

static void engine_start(void) {
  find_bin();
  if (!E.bin[0]) {
    E.st = E_MISSING;
    return;
  }
  char port[800];
  snprintf(port, sizeof port, "%s/DevToolsActivePort", E.prof);
  unlink(port);
  office_mkdirs(E.prof);
  char *av[64], ud[760];
  static char portarg[64], origin[96];
  int n = 0, fp = 0;
  int sk = socket(AF_INET, SOCK_STREAM, 0);
  if (sk >= 0) {
    struct sockaddr_in a = {0};
    socklen_t al = sizeof a;
    a.sin_family = AF_INET, a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (!bind(sk, (struct sockaddr *)&a, sizeof a) && !getsockname(sk, (struct sockaddr *)&a, &al)) fp = ntohs(a.sin_port);
    close(sk);
  }
  E.fport = fp;
  snprintf(portarg, sizeof portarg, "--remote-debugging-port=%d", fp);
  snprintf(origin, sizeof origin, "--remote-allow-origins=http://127.0.0.1:%d", fp);
  snprintf(ud, sizeof ud, "--user-data-dir=%s", E.prof);
  av[n++] = E.bin;
  av[n++] = "--headless=new";
  av[n++] = portarg;
  if (fp) av[n++] = origin;
  av[n++] = ud;
  av[n++] = "--no-first-run";
  av[n++] = "--no-default-browser-check";
  av[n++] = "--disable-gpu";
  av[n++] = "--hide-crash-restore-bubble";
  av[n++] = "--force-color-profile=srgb";
  av[n++] = "--window-size=" WIN_SZ;
  av[n++] = "--password-store=basic";
  av[n++] = "--disable-dev-shm-usage";
  av[n++] = "--disable-features=Translate,MediaRouter";
  if (geteuid() == 0) av[n++] = "--no-sandbox";
  char px[600];
  const char *pe = getenv("https_proxy");
  if (!pe || !*pe) pe = getenv("HTTPS_PROXY");
  if (pe && *pe && !getenv("OREONVR_SURF_NOPROXY")) {
    snprintf(px, sizeof px, "--proxy-server=%s", pe);
    av[n++] = px;
  }
  static char extra[1200];
  const char *fl = getenv("OREONVR_SURF_FLAGS");
  snprintf(extra, sizeof extra, "%s", fl ? fl : "");
  for (char *sv = NULL, *t = strtok_r(extra, " ", &sv); t && n < 60; t = strtok_r(NULL, " ", &sv)) av[n++] = t;
  av[n++] = "about:blank";
  av[n] = NULL;
  char logp[700];
  data_path(logp, sizeof logp, "chromium.log");
  pid_t pid = fork();
  if (pid < 0) {
    fail("Could not start Chromium");
    return;
  }
  if (pid == 0) {
    setsid();
    prctl(PR_SET_PDEATHSIG, SIGTERM);
    int nul = open("/dev/null", O_RDWR), lg = open(logp, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    dup2(nul, 0);
    dup2(lg >= 0 ? lg : nul, 1);
    dup2(lg >= 0 ? lg : nul, 2);
    for (int fd = 3; fd < 256; fd++) close(fd);
    execv(av[0], av);
    _exit(127);
  }
  E.pid = pid;
  E.st = E_START;
  E.t0 = now_ms();
  E.err[0] = 0;
}

static int ws_write(const void *d, size_t n) {
  const char *p = d;
  while (n) {
    ssize_t w = write(E.fd, p, n);
    if (w > 0) {
      p += w, n -= (size_t)w;
      continue;
    }
    if (w < 0 && (errno == EAGAIN || errno == EINTR)) {
      struct pollfd pf = {E.fd, POLLOUT, 0};
      if (poll(&pf, 1, 500) <= 0) return 0;
      continue;
    }
    return 0;
  }
  return 1;
}

static int ws_frame(int op, const char *s, size_t n) {
  if (E.fd < 0) return 0;
  unsigned char h[14];
  int hl = 0;
  h[hl++] = (unsigned char)(0x80 | op);
  if (n < 126) h[hl++] = (unsigned char)(0x80 | n);
  else if (n < 65536) h[hl++] = 0x80 | 126, h[hl++] = (unsigned char)(n >> 8), h[hl++] = (unsigned char)n;
  else {
    h[hl++] = 0x80 | 127;
    for (int i = 7; i >= 0; i--) h[hl++] = (unsigned char)((uint64_t)n >> (8 * i));
  }
  uint32_t r = (uint32_t)rand() ^ now_ms() * 2654435761u;
  unsigned char m[4] = {(unsigned char)r, (unsigned char)(r >> 8), (unsigned char)(r >> 16), (unsigned char)(r >> 24)};
  memcpy(h + hl, m, 4);
  hl += 4;
  unsigned char *b = malloc((size_t)hl + n);
  if (!b) return 0;
  memcpy(b, h, (size_t)hl);
  for (size_t i = 0; i < n; i++) b[hl + i] = (unsigned char)(s[i] ^ m[i & 3]);
  int ok = ws_write(b, (size_t)hl + n);
  free(b);
  if (!ok) fail("Lost connection to Chromium");
  return ok;
}

static int cdp(const char *sid, int kind, const char *tid, const char *method, const char *params) {
  if (E.st != E_READY) return 0;
  int id = ++E.nextid;
  Buf b = {0};
  buf_printf(&b, "{\"id\":%d,\"method\":\"%s\"", id, method);
  if (sid && *sid) buf_printf(&b, ",\"sessionId\":\"%s\"", sid);
  buf_printf(&b, ",\"params\":%s}", params && *params ? params : "{}");
  if (kind) {
    Pend *pd = &E.pend[id % 160];
    memset(pd, 0, sizeof *pd);
    pd->id = id, pd->kind = kind;
    snprintf(pd->tid, sizeof pd->tid, "%s", tid ? tid : "");
  }
  ws_frame(1, b.s, b.n);
  free(b.s);
  return id;
}

static int ws_connect(void) {
  int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
  if (fd < 0) return 0;
  struct sockaddr_in a = {0};
  a.sin_family = AF_INET, a.sin_port = htons((uint16_t)E.port);
  a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if (connect(fd, (struct sockaddr *)&a, sizeof a)) {
    close(fd);
    return 0;
  }
  char req[600];
  int n = snprintf(req, sizeof req,
                   "GET %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                   "Sec-WebSocket-Key: c3VyZi1vcmVvbnZyLWtleQ==\r\nSec-WebSocket-Version: 13\r\n\r\n",
                   E.wsp, E.port);
  if (write(fd, req, (size_t)n) != n) {
    close(fd);
    return 0;
  }
  char resp[2048];
  int got = 0;
  uint32_t t0 = now_ms();
  while (got < (int)sizeof resp - 1 && now_ms() - t0 < 4000) {
    struct pollfd pf = {fd, POLLIN, 0};
    if (poll(&pf, 1, 200) <= 0) continue;
    ssize_t r = read(fd, resp + got, 1);
    if (r <= 0) break;
    got++;
    resp[got] = 0;
    if (got >= 4 && !memcmp(resp + got - 4, "\r\n\r\n", 4)) break;
  }
  if (!strstr(resp, " 101")) {
    close(fd);
    return 0;
  }
  fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
  E.fd = fd;
  return 1;
}

static Tab *tab_by_tid(const char *tid, int *idx) {
  for (int i = 0; i < ntab; i++)
    if (!strcmp(TB[i]->tid, tid)) {
      if (idx) *idx = i;
      return TB[i];
    }
  return NULL;
}

static Tab *tab_by_sid(const char *sid) {
  for (int i = 0; i < ntab; i++)
    if (TB[i]->sid[0] && !strcmp(TB[i]->sid, sid)) return TB[i];
  if (DT && DT->sid[0] && !strcmp(DT->sid, sid)) return DT;
  return NULL;
}

static Tab *any_tab(const char *tid) {
  if (DT && !strcmp(DT->tid, tid)) return DT;
  return tab_by_tid(tid, NULL);
}

static int want_h(Tab *t) { return t == DT ? dt_h() : page_h(); }

static int npinned(void) {
  int n = 0;
  for (int i = 0; i < ntab; i++) n += TB[i]->pinned;
  return n;
}

static void set_metrics(Tab *t) {
  if (!t->attached) return;
  float z = ZOOMS[t->zoom];
  char p[200];
  snprintf(p, sizeof p, "{\"width\":%d,\"height\":%d,\"deviceScaleFactor\":%.3f,\"mobile\":false}", (int)(NW / z + 0.5f), (int)(want_h(t) / z + 0.5f), z);
  cdp(t->sid, 0, NULL, "Emulation.setDeviceMetricsOverride", p);
}

static void screencast(Tab *t, int on) {
  if (!t || !t->attached) return;
  if (!on) {
    cdp(t->sid, 0, NULL, "Page.stopScreencast", NULL);
    return;
  }
  char p[200];
  snprintf(p, sizeof p, "{\"format\":\"jpeg\",\"quality\":82,\"maxWidth\":%d,\"maxHeight\":%d,\"everyNthFrame\":1}", NW, want_h(t));
  cdp(t->sid, 0, NULL, "Page.startScreencast", p);
}

static void ask_history(Tab *t) {
  if (t && t->attached) cdp(t->sid, R_HIST, t->tid, "Page.getNavigationHistory", NULL);
}

static void set_title(void) {
  if (S.panel < 0 || !P[S.panel].used) return;
  Tab *t = cur();
  const char *tt = !t ? "Surf" : t->native == N_HISTORY ? "History" : t->native == N_ABOUT ? "About Surf" : t->native == N_PDF && t->pdf ? t->pdf->name : t->native ? "New Tab" : t->title[0] ? t->title : t->url;
  snprintf(P[S.panel].title, sizeof P[S.panel].title, "%.63s", tt);
}

static void fit_window(Tab *t);
static void open_devtools(void);
static void close_devtools(void);

static void activate(int i) {
  if (i < 0 || i >= ntab) return;
  Tab *old = cur();
  if (old && old != TB[i]) screencast(old, 0);
  act = i;
  fit_window(TB[i]);
  screencast(TB[i], 1);
  if (S.dock == 1 && strcmp(dt_for, TB[i]->tid)) close_devtools(), open_devtools();
  if (!S.omni || old != TB[i]) S.omni = 0;
  S.menu = S.ctx = 0;
  set_title();
  dirty();
}

static void close_omni(void) {
  S.omni = 0, S.nsug = 0;
}

static void free_pdf(Pdf *f) {
  if (!f) return;
  net_drop(f->fetch), net_drop(f->info);
  for (int i = 0; i < 400; i++) free(f->pg[i].px), net_drop(f->pg[i].job);
  free(f);
}

static void free_tab(Tab *t) {
  free(t->fb);
  free(t->pend);
  free(t->con);
  free_pdf(t->pdf);
  free(t);
}

static void save_pinned(void) {
  char p[700];
  data_path(p, sizeof p, "pinned.tsv");
  FILE *f = fopen(p, "w");
  if (!f) return;
  for (int i = 0; i < ntab; i++)
    if (TB[i]->pinned && !TB[i]->native && TB[i]->url[0]) fprintf(f, "%s\n", TB[i]->url);
  fclose(f);
}

static void remove_tab(int i, int user) {
  if (i < 0 || i >= ntab) return;
  Tab *t = TB[i];
  if (user && t->url[0] && !t->native) {
    if (nclosed == 10) memmove(closed[0], closed[1], sizeof closed[0] * 9), nclosed--;
    snprintf(closed[nclosed++], sizeof closed[0], "%s", t->url);
  }
  int was_act = i == act, was_pin = t->pinned;
  memmove(&TB[i], &TB[i + 1], sizeof(Tab *) * (size_t)(ntab - i - 1));
  ntab--;
  free_tab(t);
  if (was_pin) save_pinned();
  if (i < act || (was_act && act >= ntab)) act--;
  if (ntab && act < 0) act = 0;
  if (was_act && ntab) {
    act = -1;
    activate(i < ntab ? i : ntab - 1);
  }
  set_title();
  dirty();
}

static void new_tab_x(const char *url, int native, int activate_it, int after, int pinned, int devtools) {
  if (nwant >= 8) return;
  Want *w = &WANT[nwant++];
  memset(w, 0, sizeof *w);
  w->native = native, w->activate = activate_it, w->after = after, w->pinned = pinned, w->devtools = devtools;
  char p[1400];
  snprintf(p, sizeof p, "{\"url\":%s%s}", js(url && *url ? url : "about:blank"), devtools ? ",\"newWindow\":true" : "");
  if (!cdp(NULL, R_CREATE, NULL, "Target.createTarget", p)) nwant--;
}

static void new_tab(const char *url, int native, int activate_it, int after) { new_tab_x(url, native, activate_it, after, 0, 0); }

static void open_devtools(void) {
  Tab *t = cur();
  if (E.st != E_READY || DT || !t || t->native || !t->tid[0]) return;
  char u[400];
  snprintf(u, sizeof u, "http://127.0.0.1:%d/devtools/inspector.html?ws=127.0.0.1:%d/devtools/page/%s", E.port, E.port, t->tid);
  snprintf(dt_for, sizeof dt_for, "%s", t->tid);
  new_tab_x(u, N_WEB, 0, -1, 0, 1);
}

static void close_devtools(void) {
  dt_for[0] = 0;
  if (!DT) return;
  char p[120];
  snprintf(p, sizeof p, "{\"targetId\":%s}", js(DT->tid));
  cdp(NULL, 0, NULL, "Target.closeTarget", p);
  free_tab(DT);
  DT = NULL;
}

static void close_tab(int i) {
  if (i < 0 || i >= ntab) return;
  char p[120];
  snprintf(p, sizeof p, "{\"targetId\":%s}", js(TB[i]->tid));
  cdp(NULL, 0, NULL, "Target.closeTarget", p);
  remove_tab(i, 1);
  if (!ntab && S.panel >= 0 && P[S.panel].used) panel_close(S.panel);
}

static void navigate(const char *url) {
  Tab *t = cur();
  close_omni();
  if (!t) {
    new_tab(url, N_WEB, 1, -1);
    return;
  }
  if (!strcmp(url, "surf://history")) {
    t->native = N_HISTORY;
    S.hscroll = 0;
    if (strcmp(t->url, "about:blank")) {
      char p[100];
      snprintf(p, sizeof p, "{\"url\":\"about:blank\"}");
      cdp(t->sid, 0, NULL, "Page.navigate", p);
    }
    set_title();
    dirty();
    return;
  }
  if (!strcmp(url, "surf://about") || !strcmp(url, "surf://settings/help")) {
    t->native = N_ABOUT;
    set_title();
    dirty();
    return;
  }
  if (!strcmp(url, "surf://newtab") || !strcmp(url, "about:newtab")) url = "about:blank";
  char p[2400];
  snprintf(p, sizeof p, "{\"url\":%s}", js(url));
  cdp(t->sid, 0, NULL, "Page.navigate", p);
  snprintf(t->url, sizeof t->url, "%s", url);
  t->native = strcmp(url, "about:blank") ? N_WEB : N_NEWTAB;
  if (!t->native) t->loading = 1, t->load_t0 = now_ms();
  set_title();
  dirty();
}

static void go_hist(int dir) {
  Tab *t = cur();
  if (!t) return;
  int id = dir < 0 ? t->back_id : t->fwd_id;
  if (t->native == N_PDF && t->pdf && t->pdf->dl && dir < 0) {
    t->native = N_WEB;
    free_pdf(t->pdf);
    t->pdf = NULL;
    char p[120];
    snprintf(p, sizeof p, "{\"targetId\":%s}", js(t->tid));
    cdp(NULL, R_INFO, t->tid, "Target.getTargetInfo", p);
    dirty();
    return;
  }
  if (id < 0) return;
  char p[60];
  snprintf(p, sizeof p, "{\"entryId\":%d}", id);
  cdp(t->sid, 0, NULL, "Page.navigateToHistoryEntry", p);
  if (t->native == N_HISTORY || t->native == N_ABOUT || t->native == N_PDF) t->native = N_WEB;
}

static void reload(int hard) {
  Tab *t = cur();
  if (!t || t->native) return;
  if (t->loading) {
    cdp(t->sid, 0, NULL, "Page.stopLoading", NULL);
    t->loading = 0;
    return;
  }
  cdp(t->sid, 0, NULL, "Page.reload", hard ? "{\"ignoreCache\":true}" : "{}");
  t->loading = 1, t->load_t0 = now_ms();
}

static void zoom(int d) {
  Tab *t = cur();
  if (!t) return;
  int z = d == 0 ? ZOOM_DEF : t->zoom + d;
  if (z < 0) z = 0;
  if (z >= NZOOM) z = NZOOM - 1;
  t->zoom = z;
  set_metrics(t);
  S.zoom_pop = 1, S.zoom_t = now_ms();
  dirty();
}

static void fit_window(Tab *t) {
  if (!t || E.cal != 2 || !t->attached) return;
  char p[120];
  snprintf(p, sizeof p, "{\"targetId\":%s}", js(t->tid));
  cdp(NULL, R_WIN, t->tid, "Browser.getWindowForTarget", p);
}

static void relayout(void) {
  Tab *t = cur();
  if (t) fit_window(t);
  for (int i = 0; i < ntab; i++) set_metrics(TB[i]);
  if (t) screencast(t, 0), screencast(t, 1);
}

static void setup_session(Tab *t) {
  t->attached = 1;
  cdp(t->sid, 0, NULL, "Page.enable", NULL);
  if (t->devtools) {
    t->wdx = E.dx, t->wdy = E.dy;
    fit_window(t);
    set_metrics(t);
    screencast(t, 1);
    return;
  }
  cdp(t->sid, 0, NULL, "Runtime.enable", NULL);
  cdp(t->sid, 0, NULL, "Emulation.setFocusEmulationEnabled", "{\"enabled\":true}");
  cdp(t->sid, 0, NULL, "Emulation.setEmulatedMedia", g_dark ? "{\"features\":[{\"name\":\"prefers-color-scheme\",\"value\":\"dark\"}]}" : "{\"features\":[{\"name\":\"prefers-color-scheme\",\"value\":\"light\"}]}");
  if (E.ua[0]) {
    char p[400];
    snprintf(p, sizeof p, "{\"userAgent\":%s}", js(E.ua));
    cdp(t->sid, 0, NULL, "Emulation.setUserAgentOverride", p);
  }
  if (!E.cal) E.cal = 1;
  t->wdx = E.dx, t->wdy = E.dy;
  fit_window(t);
  if (E.cal == 2) set_metrics(t);
  ask_history(t);
  if (t == cur()) screencast(t, 1);
}

static void on_target(J *ti) {
  if (strcmp(jstr(ti, "type", ""), "page")) return;
  const char *tid = jstr(ti, "targetId", "");
  if (!*tid || tab_by_tid(tid, NULL) || ntab >= MAXT) return;
  Tab *t = calloc(1, sizeof *t);
  snprintf(t->tid, sizeof t->tid, "%s", tid);
  snprintf(t->url, sizeof t->url, "%s", jstr(ti, "url", ""));
  snprintf(t->title, sizeof t->title, "%s", jstr(ti, "title", ""));
  t->zoom = ZOOM_DEF, t->back_id = t->fwd_id = -1;
  const char *op = jstr(ti, "openerId", "");
  int at = ntab, activate_it = 0;
  if (!*op && nwant && WANT[0].devtools) {
    memmove(&WANT[0], &WANT[1], sizeof(Want) * (size_t)(nwant - 1));
    nwant--;
    t->devtools = 1;
    if (DT || S.dock != 1) {
      char p[120];
      snprintf(p, sizeof p, "{\"targetId\":%s}", js(tid));
      cdp(NULL, 0, NULL, "Target.closeTarget", p);
      free(t);
      return;
    }
    DT = t;
    char p[120];
    snprintf(p, sizeof p, "{\"targetId\":%s,\"flatten\":true}", js(tid));
    cdp(NULL, R_ATTACH, tid, "Target.attachToTarget", p);
    return;
  }
  if (*op) {
    int oi;
    if (tab_by_tid(op, &oi)) at = oi + 1;
    activate_it = 1;
  } else if (nwant) {
    Want w = WANT[0];
    memmove(&WANT[0], &WANT[1], sizeof(Want) * (size_t)(nwant - 1));
    nwant--;
    t->native = w.native;
    activate_it = w.activate;
    t->pinned = w.pinned;
    if (w.after >= 0 && w.after < ntab) at = w.after + 1;
    if (t->pinned) at = npinned();
  } else activate_it = act < 0;
  if (!t->pinned && at < npinned()) at = npinned();
  if (!t->native && (!t->url[0] || !strcmp(t->url, "about:blank"))) t->native = N_NEWTAB;
  t->con = calloc(300, sizeof(Con));
  if (!t->native) t->loading = 1, t->load_t0 = now_ms();
  memmove(&TB[at + 1], &TB[at], sizeof(Tab *) * (size_t)(ntab - at));
  TB[at] = t;
  ntab++;
  if (act >= at) act++;
  char p[120];
  snprintf(p, sizeof p, "{\"targetId\":%s,\"flatten\":true}", js(tid));
  cdp(NULL, R_ATTACH, tid, "Target.attachToTarget", p);
  if (activate_it) activate(at);
  if (t->pinned) save_pinned();
  dirty();
}

static void on_info(J *ti) {
  Tab *t = tab_by_tid(jstr(ti, "targetId", ""), NULL);
  if (!t || t->native == N_PDF || t->native == N_ABOUT) return;
  const char *u = jstr(ti, "url", ""), *title = jstr(ti, "title", "");
  if (strcmp(t->url, u)) {
    snprintf(t->url, sizeof t->url, "%s", u);
    if (!strcmp(u, "about:blank") || !*u) {
      if (t->native == N_WEB) t->native = N_NEWTAB;
    } else t->native = N_WEB;
  }
  if (strcmp(t->title, title)) snprintf(t->title, sizeof t->title, "%s", title), hist_title(t->url, title);
  if (t == cur()) set_title();
  dirty();
}

static void show_frame(Tab *t) {
  if (!t->pend) return;
  size_t n = strlen(t->pend);
  unsigned char *bin = malloc(n * 3 / 4 + 4);
  size_t bn = b64dec(t->pend, bin);
  int w = 0, h = 0;
  uint32_t *px = jpeg_decode(bin, bn, &w, &h);
  free(bin);
  if (px) {
    free(t->fb);
    t->fb = px, t->fw = w, t->fh = h;
    if (t == cur() || t == DT) dirty();
  }
  char p[60];
  snprintf(p, sizeof p, "{\"sessionId\":%d}", t->pend_sid);
  cdp(t->sid, 0, NULL, "Page.screencastFrameAck", p);
  free(t->pend);
  t->pend = NULL;
}

static void open_ctx(J *v) {
  const char *s = jval(v, "");
  J *o = json_parse(s, strlen(s));
  snprintf(S.ctx_link, sizeof S.ctx_link, "%s", jstr(o, "h", ""));
  snprintf(S.ctx_img, sizeof S.ctx_img, "%s", jstr(o, "i", ""));
  snprintf(S.ctx_sel, sizeof S.ctx_sel, "%s", jstr(o, "s", ""));
  json_free(o);
  int n = 0;
  if (S.ctx_link[0]) S.ctx_items[n++] = C_OPEN_LINK;
  if (S.ctx_img[0]) S.ctx_items[n++] = C_OPEN_IMG;
  if (S.ctx_sel[0]) S.ctx_items[n++] = C_SEARCH;
  S.ctx_items[n++] = C_BACK, S.ctx_items[n++] = C_FWD, S.ctx_items[n++] = C_RELOAD, S.ctx_items[n++] = C_SOURCE, S.ctx_items[n++] = C_INSPECT;
  S.ctx_tab = -1;
  S.nctx = n, S.ctx = 1;
  dirty();
}

static void con_add(Tab *t, char lvl, const char *txt) {
  if (!t || !t->con) return;
  if (t->ncon == 300) memmove(&t->con[0], &t->con[1], sizeof(Con) * 299), t->ncon--;
  Con *c = &t->con[t->ncon++];
  c->lvl = lvl;
  snprintf(c->text, sizeof c->text, "%s", txt);
  clean_field(c->text);
  if (t == cur() && S.dock == 2) dirty();
}

static void remote_str(J *o, char *b, int n) {
  const char *ty = jstr(o, "type", "undefined");
  J *v = jget(o, "value");
  if (!strcmp(ty, "string")) snprintf(b, (size_t)n, "%s", jval(v, ""));
  else if (!strcmp(ty, "undefined")) snprintf(b, (size_t)n, "undefined");
  else if (!strcmp(ty, "boolean")) snprintf(b, (size_t)n, "%s", jnumv(v, 0) ? "true" : "false");
  else if (!strcmp(ty, "object") && !strcmp(jstr(o, "subtype", ""), "null")) snprintf(b, (size_t)n, "null");
  else if (jget(o, "description")) snprintf(b, (size_t)n, "%s", jstr(o, "description", ""));
  else if (v && jtype(v) == J_NUM) snprintf(b, (size_t)n, "%g", jnumv(v, 0));
  else snprintf(b, (size_t)n, "%s", ty);
}

static void open_pdf(Tab *t, const char *url, int dl);

static void on_result(int id, J *res) {
  Pend *pd = &E.pend[id % 160];
  if (pd->id != id) return;
  int kind = pd->kind;
  Tab *t = pd->tid[0] ? any_tab(pd->tid) : NULL;
  pd->id = 0;
  if (kind == R_VERSION) {
    const char *ua = jstr(res, "userAgent", "");
    char *h = strstr(ua, "HeadlessChrome");
    if (h) snprintf(E.ua, sizeof E.ua, "%.*s%s", (int)(h - ua), ua, h + 8);
    else snprintf(E.ua, sizeof E.ua, "%s", ua);
    const char *pr = jstr(res, "product", "");
    const char *sl = strchr(pr, '/');
    snprintf(E.ver, sizeof E.ver, "%s", sl ? sl + 1 : pr);
  } else if (kind == R_ATTACH && t) {
    snprintf(t->sid, sizeof t->sid, "%s", jstr(res, "sessionId", ""));
    if (t->sid[0]) setup_session(t);
  } else if (kind == R_HIST && t) {
    int ci = (int)jnum(res, "currentIndex", 0);
    J *en = jget(res, "entries");
    t->back_id = ci > 0 ? (int)jnum(jat(en, ci - 1), "id", -1) : -1;
    t->fwd_id = ci + 1 < jlen(en) ? (int)jnum(jat(en, ci + 1), "id", -1) : -1;
    dirty();
  } else if (kind == R_FOCUS) {
    if (jnumv(jget(jget(res, "result"), "value"), 0)) office_show_keyboard();
  } else if (kind == R_WIN && t) {
    char p[200];
    snprintf(p, sizeof p, "{\"windowId\":%d,\"bounds\":{\"width\":%d,\"height\":%d}}", (int)jnum(res, "windowId", 0), NW + t->wdx, want_h(t) + t->wdy);
    cdp(NULL, 0, NULL, "Browser.setWindowBounds", p);
    set_metrics(t);
    if (t == cur() || t == DT) screencast(t, 0), screencast(t, 1);
  } else if (kind == R_EVAL && t) {
    J *ex = jget(res, "exceptionDetails"), *o = jget(res, "result");
    char b[220];
    if (ex) snprintf(b, sizeof b, "Uncaught %s", jstr(jget(ex, "exception"), "description", jstr(ex, "text", "error")));
    else remote_str(o, b, sizeof b);
    con_add(t, ex ? 'e' : 'r', b);
  } else if (kind == R_INFO) {
    on_info(jget(res, "targetInfo"));
  } else if (kind == R_CTX) {
    open_ctx(jget(jget(res, "result"), "value"));
  }
}

static void on_event(const char *m, J *pa, const char *sid) {
  Tab *t = sid && *sid ? tab_by_sid(sid) : NULL;
  if (!strcmp(m, "Target.targetCreated")) on_target(jget(pa, "targetInfo"));
  else if (!strcmp(m, "Target.targetInfoChanged")) on_info(jget(pa, "targetInfo"));
  else if (!strcmp(m, "Target.targetDestroyed") || !strcmp(m, "Target.targetCrashed")) {
    int i;
    if (DT && !strcmp(DT->tid, jstr(pa, "targetId", ""))) {
      free_tab(DT);
      DT = NULL;
      dt_for[0] = 0;
      dirty();
      return;
    }
    Tab *x = tab_by_tid(jstr(pa, "targetId", ""), &i);
    if (x && !strcmp(m, "Target.targetCrashed")) {
      x->crashed = 1, x->loading = 0;
      dirty();
    } else if (x) {
      remove_tab(i, 0);
      if (!ntab) new_tab(NULL, N_NEWTAB, 1, -1);
    }
  } else if (!t) return;
  else if (t == DT && strcmp(m, "Page.screencastFrame")) return;
  else if (!strcmp(m, "Runtime.consoleAPICalled")) {
    const char *ty = jstr(pa, "type", "log");
    J *args = jget(pa, "args");
    char b[220] = "";
    int k = 0;
    for (int i = 0; i < jlen(args) && k < 200; i++) {
      char a[220];
      remote_str(jat(args, i), a, sizeof a);
      k += snprintf(b + k, sizeof b - (size_t)k, "%s%s", i ? " " : "", a);
    }
    con_add(t, !strcmp(ty, "error") || !strcmp(ty, "assert") ? 'e' : !strcmp(ty, "warning") ? 'w' : !strcmp(ty, "info") ? 'i' : 'l', b);
  } else if (!strcmp(m, "Runtime.exceptionThrown")) {
    J *ex = jget(pa, "exceptionDetails");
    char b[220];
    snprintf(b, sizeof b, "Uncaught %s", jstr(jget(ex, "exception"), "description", jstr(ex, "text", "error")));
    con_add(t, 'e', b);
  } else if (!strcmp(m, "Page.screencastFrame")) {
    free(t->pend);
    const char *d = jstr(pa, "data", "");
    t->pend = strdup(d);
    t->pend_sid = (int)jnum(pa, "sessionId", 0);
    J *md = jget(pa, "metadata");
    int dw = (int)(jnum(md, "deviceWidth", 0) + 0.5), dh = (int)(jnum(md, "deviceHeight", 0) + 0.5);
    if (E.cal == 1) {
      E.dx = WIN_W0 - dw, E.dy = WIN_H0 - dh;
      if (dw <= 0 || dh <= 0 || E.dx < 0 || E.dy < 0 || E.dx > 400 || E.dy > 400) E.dx = 0, E.dy = 139;
      E.cal = 2;
      for (int i = 0; i < ntab; i++) TB[i]->wdx = E.dx, TB[i]->wdy = E.dy;
      fit_window(cur());
    } else if (E.cal == 2 && (t == cur() || t == DT) && t->zoom == ZOOM_DEF && dw > 0 && dh > 0) {
      if (dw != NW || dh != want_h(t)) {
        if (!t->bad || dw != t->ldw || dh != t->ldh) t->bad_t = now_ms();
        t->bad = 1, t->ldw = dw, t->ldh = dh;
      } else t->bad = 0;
    }
    if (t != cur() && t != DT) show_frame(t);
  } else if (!strcmp(m, "Page.frameStartedLoading")) {
    if (!strcmp(jstr(pa, "frameId", ""), t->tid)) t->loading = 1, t->load_t0 = now_ms(), t->crashed = 0, dirty();
  } else if (!strcmp(m, "Page.frameStoppedLoading")) {
    if (!strcmp(jstr(pa, "frameId", ""), t->tid)) t->loading = 0, dirty();
  } else if (!strcmp(m, "Page.loadEventFired")) {
    t->loading = 0;
    char p[120];
    snprintf(p, sizeof p, "{\"targetId\":%s}", js(t->tid));
    cdp(NULL, R_INFO, t->tid, "Target.getTargetInfo", p);
    dirty();
  } else if (!strcmp(m, "Page.frameNavigated")) {
    J *f = jget(pa, "frame");
    if (!jget(f, "parentId")) {
      const char *u = jstr(f, "url", "");
      snprintf(t->url, sizeof t->url, "%s%s", u, jstr(f, "urlFragment", ""));
      set_metrics(t);
      if (t->ncon) con_add(t, 'n', t->url);
      if (!strcmp(jstr(f, "mimeType", ""), "application/pdf")) {
        open_pdf(t, t->url, 0);
        hist_add(t->url, t->pdf ? t->pdf->name : "");
        ask_history(t);
        return;
      }
      if (t->native == N_PDF) free_pdf(t->pdf), t->pdf = NULL;
      if (strcmp(u, "about:blank")) t->native = N_WEB, hist_add(t->url, t->title);
      else if (t->native == N_WEB) t->native = N_NEWTAB;
      ask_history(t);
      if (t == cur()) set_title();
      dirty();
    }
  } else if (!strcmp(m, "Page.navigatedWithinDocument")) {
    if (!strcmp(jstr(pa, "frameId", ""), t->tid)) {
      snprintf(t->url, sizeof t->url, "%s", jstr(pa, "url", t->url));
      hist_add(t->url, t->title);
      ask_history(t);
      dirty();
    }
  } else if (!strcmp(m, "Page.javascriptDialogOpening")) {
    const char *ty = jstr(pa, "type", "alert");
    S.dlg = 1;
    S.dlg_type = !strcmp(ty, "alert") ? 0 : !strcmp(ty, "prompt") ? 2 : 1;
    snprintf(S.dlg_msg, sizeof S.dlg_msg, "%s", !strcmp(ty, "beforeunload") ? "Leave site? Changes you made may not be saved." : jstr(pa, "message", ""));
    snprintf(S.dlg_in, sizeof S.dlg_in, "%s", jstr(pa, "defaultPrompt", ""));
    S.dlg_focus = S.dlg_type == 2;
    if (t != cur()) {
      for (int i = 0; i < ntab; i++)
        if (TB[i] == t) activate(i);
    }
    dirty();
  } else if (!strcmp(m, "Page.javascriptDialogClosed")) {
    if (t == cur()) S.dlg = 0, dirty();
  }
}

static int ends_pdf(const char *s) {
  size_t l = strlen(s);
  const char *q = strpbrk(s, "?#");
  if (q) l = (size_t)(q - s);
  return l > 4 && !strncasecmp(s + l - 4, ".pdf", 4);
}

static void on_browser_event(const char *m, J *pa) {
  if (!strcmp(m, "Browser.downloadWillBegin") && (ends_pdf(jstr(pa, "suggestedFilename", "")) || ends_pdf(jstr(pa, "url", "")))) {
    char p[200];
    snprintf(p, sizeof p, "{\"guid\":%s}", js(jstr(pa, "guid", "")));
    cdp(NULL, 0, NULL, "Browser.cancelDownload", p);
    Tab *t = tab_by_tid(jstr(pa, "frameId", ""), NULL);
    if (!t) t = cur();
    if (t) open_pdf(t, jstr(pa, "url", ""), 1), hist_add(t->url, t->pdf ? t->pdf->name : "");
    return;
  }
  if (!strcmp(m, "Browser.downloadWillBegin")) {
    char b[200];
    snprintf(b, sizeof b, "Downloading %.150s", jstr(pa, "suggestedFilename", "file"));
    toast(b);
  } else if (!strcmp(m, "Browser.downloadProgress") && !strcmp(jstr(pa, "state", ""), "completed")) {
    toast("Download complete - saved to Downloads");
  }
}

static void on_message(const char *s, size_t n) {
  J *j = json_parse(s, n);
  if (!j) return;
  J *id = jget(j, "id");
  if (id) on_result((int)jnumv(id, 0), jget(j, "result"));
  else {
    const char *m = jstr(j, "method", "");
    if (!strncmp(m, "Browser.", 8)) on_browser_event(m, jget(j, "params"));
    else on_event(m, jget(j, "params"), jstr(j, "sessionId", ""));
  }
  json_free(j);
}

static int ws_pump(void) {
  if (E.fd < 0) return 0;
  char tmp[65536];
  int got = 0;
  for (;;) {
    ssize_t r = read(E.fd, tmp, sizeof tmp);
    if (r > 0) {
      buf_put(&E.rx, tmp, (size_t)r);
      got = 1;
      continue;
    }
    if (r < 0 && (errno == EAGAIN || errno == EINTR)) break;
    fail("Chromium closed the connection");
    return 1;
  }
  size_t off = 0;
  while (E.rx.n - off >= 2) {
    unsigned char *b = (unsigned char *)E.rx.s + off;
    int op = b[0] & 15, fin = b[0] & 0x80;
    uint64_t len = b[1] & 127;
    size_t hl = 2;
    if (len == 126) {
      if (E.rx.n - off < 4) break;
      len = (uint64_t)b[2] << 8 | b[3], hl = 4;
    } else if (len == 127) {
      if (E.rx.n - off < 10) break;
      len = 0;
      for (int i = 0; i < 8; i++) len = len << 8 | b[2 + i];
      hl = 10;
    }
    if (b[1] & 0x80) hl += 4;
    if (E.rx.n - off < hl + len) break;
    const char *pl = (const char *)b + hl;
    if (op == 0 || op == 1 || op == 2) {
      buf_put(&E.msg, pl, (size_t)len);
      if (fin) {
        on_message(E.msg.s, E.msg.n);
        if (E.st != E_READY) return 1;
        E.msg.n = 0;
      }
    } else if (op == 9) ws_frame(10, pl, (size_t)len);
    else if (op == 8) {
      fail("Chromium closed the connection");
      return 1;
    }
    off += hl + (size_t)len;
  }
  if (off) {
    memmove(E.rx.s, E.rx.s + off, E.rx.n - off);
    E.rx.n -= off;
  }
  return got;
}

static char *probe_port(int port) {
  int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
  if (fd < 0) return NULL;
  struct sockaddr_in a = {0};
  a.sin_family = AF_INET, a.sin_port = htons((uint16_t)port), a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if (connect(fd, (struct sockaddr *)&a, sizeof a)) {
    close(fd);
    return NULL;
  }
  char req[120], buf[4096];
  int n = snprintf(req, sizeof req, "GET /json/version HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nConnection: close\r\n\r\n", port), got = 0;
  if (write(fd, req, (size_t)n) != n) {
    close(fd);
    return NULL;
  }
  uint32_t t0 = now_ms();
  while (got < (int)sizeof buf - 1 && now_ms() - t0 < 1500) {
    struct pollfd pf = {fd, POLLIN, 0};
    if (poll(&pf, 1, 100) <= 0) continue;
    ssize_t r = read(fd, buf + got, sizeof buf - 1 - (size_t)got);
    if (r <= 0) break;
    got += (int)r;
  }
  close(fd);
  buf[got] = 0;
  char *w = strstr(buf, "/devtools/browser/");
  if (!w) return NULL;
  char *e = strchr(w, '"');
  if (e) *e = 0;
  char *out = malloc(300);
  snprintf(out, 300, "%d\n%.250s", port, w);
  return out;
}

static int engine_tick(void) {
  if (E.st == E_START) {
    int st;
    if (waitpid(E.pid, &st, WNOHANG) == E.pid) {
      E.pid = 0;
      char m[200];
      snprintf(m, sizeof m, "Chromium exited during startup (status %d)", WIFEXITED(st) ? WEXITSTATUS(st) : 128 + WTERMSIG(st));
      fail(m);
      return 1;
    }
    char path[800];
    snprintf(path, sizeof path, "%s/DevToolsActivePort", E.prof);
    char *c = office_read_file(path);
    if (!c && E.fport) c = probe_port(E.fport);
    if (c) {
      char ws[200] = "";
      int port = 0;
      if (sscanf(c, "%d %199s", &port, ws) == 2 && port > 0) {
        E.port = port;
        snprintf(E.wsp, sizeof E.wsp, "%s", ws);
        if (ws_connect()) {
          E.st = E_READY, E.cal = 0;
          E.nextid = 0;
          cdp(NULL, R_VERSION, NULL, "Browser.getVersion", NULL);
          char dl[800], p[900];
          snprintf(dl, sizeof dl, "%s/Downloads", user_home());
          office_mkdirs(dl);
          snprintf(p, sizeof p, "{\"behavior\":\"allow\",\"downloadPath\":%s,\"eventsEnabled\":true}", js(dl));
          cdp(NULL, 0, NULL, "Browser.setDownloadBehavior", p);
          cdp(NULL, 0, NULL, "Target.setDiscoverTargets", "{\"discover\":true}");
          char pp[700], line[1100];
          data_path(pp, sizeof pp, "pinned.tsv");
          FILE *pf = fopen(pp, "r");
          while (pf && fgets(line, sizeof line, pf)) {
            line[strcspn(line, "\n")] = 0;
            if (line[0]) new_tab_x(line, N_WEB, 0, -1, 1, 0);
          }
          if (pf) fclose(pf);
        }
      }
      free(c);
    }
    if (E.st == E_START && now_ms() - E.t0 > 90000) fail("Chromium did not respond in time");
    return 1;
  }
  if (E.st != E_READY) return 0;
  int ch = ws_pump();
  if (E.st != E_READY) return 1;
  Tab *t = cur();
  if (t && t->pend) show_frame(t), ch = 1;
  if (DT && DT->pend) show_frame(DT), ch = 1;
  Tab *fx[2] = {t, DT};
  for (int k = 0; k < 2; k++) {
    Tab *x = fx[k];
    if (!x || !x->bad || now_ms() - x->bad_t < 350) continue;
    x->wdx += NW - x->ldw, x->wdy += want_h(x) - x->ldh;
    if (x->wdx < 0 || x->wdx > 600) x->wdx = 0;
    if (x->wdy < 0 || x->wdy > 600) x->wdy = 139;
    x->bad = 0;
    fit_window(x);
  }
  if (E.pid > 0 && waitpid(E.pid, NULL, WNOHANG) == E.pid) {
    E.pid = 0;
    fail("Chromium quit unexpectedly");
    return 1;
  }
  return ch;
}

static void restart_engine(void) {
  engine_stop();
  if (DT) free_tab(DT), DT = NULL;
  for (int i = 0; i < ntab; i++) free_tab(TB[i]);
  ntab = 0, act = -1, nwant = 0;
  S.ctx = 0;
  engine_start();
}

static int mods_cdp(int m) { return (m & MOD_ALT ? 1 : 0) | (m & MOD_CTRL ? 2 : 0) | (m & MOD_SHIFT ? 8 : 0); }

static Tab *in_dt(float y) { return S.dock == 1 && DT && DT->attached && y >= dock_y() + DOCK_HEAD ? DT : NULL; }

static void page_mouse(const char *type, float x, float y, const char *btn, int buttons, int clicks, int mods) {
  Tab *t = in_dt(y);
  float oy = t ? dock_y() + DOCK_HEAD : page_y();
  if (!t) t = cur();
  if (!t || !t->attached || t->native) return;
  float z = ZOOMS[t->zoom];
  char p[300];
  snprintf(p, sizeof p, "{\"type\":\"%s\",\"x\":%.1f,\"y\":%.1f,\"button\":\"%s\",\"buttons\":%d,\"clickCount\":%d,\"modifiers\":%d}", type, x / z,
           (y - oy) / z, btn, buttons, clicks, mods_cdp(mods));
  cdp(t->sid, 0, NULL, "Input.dispatchMouseEvent", p);
}

typedef struct {
  int code, vk;
  const char *key, *name;
} KeyDef;

static const KeyDef KEYS[] = {
    {KEY_ENTER, 13, "Enter", "Enter"},         {KEY_KPENTER, 13, "Enter", "NumpadEnter"}, {KEY_BACKSPACE, 8, "Backspace", "Backspace"},
    {KEY_TAB, 9, "Tab", "Tab"},                {KEY_ESC, 27, "Escape", "Escape"},         {KEY_DELETE, 46, "Delete", "Delete"},
    {KEY_LEFT, 37, "ArrowLeft", "ArrowLeft"},  {KEY_UP, 38, "ArrowUp", "ArrowUp"},        {KEY_RIGHT, 39, "ArrowRight", "ArrowRight"},
    {KEY_DOWN, 40, "ArrowDown", "ArrowDown"},  {KEY_HOME, 36, "Home", "Home"},            {KEY_END, 35, "End", "End"},
    {KEY_PAGEUP, 33, "PageUp", "PageUp"},      {KEY_PAGEDOWN, 34, "PageDown", "PageDown"}, {KEY_INSERT, 45, "Insert", "Insert"},
    {KEY_F1, 112, "F1", "F1"},                 {KEY_F2, 113, "F2", "F2"},                 {KEY_F3, 114, "F3", "F3"},
    {KEY_F4, 115, "F4", "F4"},                 {KEY_F6, 117, "F6", "F6"},                 {KEY_F7, 118, "F7", "F7"},
    {KEY_F8, 119, "F8", "F8"},                 {KEY_F9, 120, "F9", "F9"},                 {KEY_F10, 121, "F10", "F10"},
    {KEY_F11, 122, "F11", "F11"},              {KEY_F12, 123, "F12", "F12"},
};

static void punct_code(char c, const char **name, int *vk) {
  static const char *ch = "-=[]\\;'`,./ ";
  static const char *nm[] = {"Minus", "Equal", "BracketLeft", "BracketRight", "Backslash", "Semicolon", "Quote", "Backquote", "Comma", "Period", "Slash", "Space"};
  static const int vks[] = {189, 187, 219, 221, 220, 186, 222, 192, 188, 190, 191, 32};
  const char *f = strchr(ch, c);
  if (f) *name = nm[f - ch], *vk = vks[f - ch];
}

static void page_key(int code, int mods) {
  Tab *t = S.kfocus == 1 && S.dock == 1 && DT && DT->attached ? DT : cur();
  if (!t || !t->attached || t->native) return;
  int m = mods_cdp(mods);
  char p[600], keyj[40], codej[40];
  for (size_t i = 0; i < sizeof KEYS / sizeof KEYS[0]; i++)
    if (KEYS[i].code == code) {
      const char *txt = KEYS[i].vk == 13 ? ",\"text\":\"\\r\",\"unmodifiedText\":\"\\r\"" : "";
      snprintf(p, sizeof p, "{\"type\":\"%s\",\"key\":\"%s\",\"code\":\"%s\",\"windowsVirtualKeyCode\":%d,\"nativeVirtualKeyCode\":%d,\"modifiers\":%d%s}",
               *txt && !(mods & (MOD_CTRL | MOD_ALT)) ? "keyDown" : "rawKeyDown", KEYS[i].key, KEYS[i].name, KEYS[i].vk, KEYS[i].vk, m, txt);
      cdp(t->sid, 0, NULL, "Input.dispatchKeyEvent", p);
      snprintf(p, sizeof p, "{\"type\":\"keyUp\",\"key\":\"%s\",\"code\":\"%s\",\"windowsVirtualKeyCode\":%d,\"nativeVirtualKeyCode\":%d,\"modifiers\":%d}", KEYS[i].key,
               KEYS[i].name, KEYS[i].vk, KEYS[i].vk, m);
      cdp(t->sid, 0, NULL, "Input.dispatchKeyEvent", p);
      return;
    }
  char b[8];
  int n = key_to_bytes(code, mods & ~(MOD_CTRL | MOD_ALT), b);
  if (n != 1 || (unsigned char)b[0] < 32 || b[0] == 127) return;
  char c = b[0];
  const char *name = "";
  int vk = 0;
  char nb[16];
  if (isalpha((unsigned char)c)) snprintf(nb, sizeof nb, "Key%c", toupper((unsigned char)c)), name = nb, vk = toupper((unsigned char)c);
  else if (isdigit((unsigned char)c)) snprintf(nb, sizeof nb, "Digit%c", c), name = nb, vk = c;
  else {
    char base[8];
    int bn = key_to_bytes(code, 0, base);
    punct_code(bn == 1 ? base[0] : c, &name, &vk);
    if (isdigit((unsigned char)base[0])) snprintf(nb, sizeof nb, "Digit%c", base[0]), name = nb, vk = base[0];
  }
  char cs[2] = {c, 0};
  snprintf(keyj, sizeof keyj, "%s", js(cs));
  snprintf(codej, sizeof codej, "%s", js(name));
  if (mods & (MOD_CTRL | MOD_ALT))
    snprintf(p, sizeof p, "{\"type\":\"rawKeyDown\",\"key\":%s,\"code\":%s,\"windowsVirtualKeyCode\":%d,\"nativeVirtualKeyCode\":%d,\"modifiers\":%d}", keyj, codej, vk, vk, m);
  else
    snprintf(p, sizeof p, "{\"type\":\"keyDown\",\"key\":%s,\"code\":%s,\"windowsVirtualKeyCode\":%d,\"nativeVirtualKeyCode\":%d,\"text\":%s,\"unmodifiedText\":%s,\"modifiers\":%d}",
             keyj, codej, vk, vk, keyj, keyj, m);
  cdp(t->sid, 0, NULL, "Input.dispatchKeyEvent", p);
  snprintf(p, sizeof p, "{\"type\":\"keyUp\",\"key\":%s,\"code\":%s,\"windowsVirtualKeyCode\":%d,\"nativeVirtualKeyCode\":%d,\"modifiers\":%d}", keyj, codej, vk, vk, m);
  cdp(t->sid, 0, NULL, "Input.dispatchKeyEvent", p);
}

static void build_sugs(void) {
  S.nsug = 0;
  const char *q = S.text;
  while (*q == ' ') q++;
  if (!*q) return;
  char u[1024];
  if (looks_url(q)) {
    fixup(q, u, sizeof u);
    snprintf(S.sug[0], sizeof S.sug[0], "%s", u);
    snprintf(S.sug_title[0], sizeof S.sug_title[0], "%.199s", q);
    S.sug_kind[0] = 1;
    S.nsug = 1;
  }
  search_url(q, u, sizeof u);
  snprintf(S.sug[S.nsug], sizeof S.sug[0], "%s", u);
  snprintf(S.sug_title[S.nsug], sizeof S.sug_title[0], "%.199s", q);
  S.sug_kind[S.nsug++] = 0;
  char lq[200];
  int k = 0;
  for (; q[k] && k < 199; k++) lq[k] = (char)tolower((unsigned char)q[k]);
  lq[k] = 0;
  int pick[MAXH], np = 0;
  for (int i = 0; i < nh && np < MAXH; i++) {
    char lu[600], lt[160];
    int a = 0;
    for (; H[i].url[a] && a < 599; a++) lu[a] = (char)tolower((unsigned char)H[i].url[a]);
    lu[a] = 0;
    for (a = 0; H[i].title[a] && a < 159; a++) lt[a] = (char)tolower((unsigned char)H[i].title[a]);
    lt[a] = 0;
    if (strstr(lu, lq) || strstr(lt, lq)) pick[np++] = i;
  }
  for (int a = 0; a < np; a++)
    for (int b = a + 1; b < np; b++)
      if (H[pick[b]].n > H[pick[a]].n) {
        int x = pick[a];
        pick[a] = pick[b], pick[b] = x;
      }
  for (int a = 0; a < np && S.nsug < 7; a++) {
    if (!strcmp(H[pick[a]].url, S.sug[0])) continue;
    snprintf(S.sug[S.nsug], sizeof S.sug[0], "%s", H[pick[a]].url);
    snprintf(S.sug_title[S.nsug], sizeof S.sug_title[0], "%s", H[pick[a]].title[0] ? H[pick[a]].title : H[pick[a]].url);
    S.sug_kind[S.nsug++] = 2;
  }
  if (S.sug_sel >= S.nsug) S.sug_sel = 0;
}

static void focus_omni(void) {
  Tab *t = cur();
  S.omni = 1, S.sel_all = 1, S.sug_sel = 0, S.nsug = 0, S.menu = 0, S.ctx = 0;
  if (t && !t->native) snprintf(S.text, sizeof S.text, "%s", t->url);
  else S.text[0] = 0;
  S.cur = (int)strlen(S.text);
  S.blink = 1, S.blink_t = now_ms();
  office_show_keyboard();
  dirty();
}

static void omni_go(void) {
  char u[1024];
  if (S.nsug && S.sug_sel < S.nsug) snprintf(u, sizeof u, "%s", S.sug[S.sug_sel]);
  else if (S.text[0]) fixup(S.text, u, sizeof u);
  else return;
  if (!strncmp(S.text, "surf://", 7)) snprintf(u, sizeof u, "%s", S.text);
  navigate(u);
}

static void omni_insert(const char *s) {
  if (S.sel_all) S.text[0] = 0, S.cur = 0, S.sel_all = 0;
  int l = (int)strlen(S.text), n = (int)strlen(s);
  if (l + n >= (int)sizeof S.text - 1) return;
  memmove(S.text + S.cur + n, S.text + S.cur, (size_t)(l - S.cur + 1));
  memcpy(S.text + S.cur, s, (size_t)n);
  S.cur += n;
  S.sug_sel = 0;
  build_sugs();
}

static void omni_key(int code, int mods) {
  int l = (int)strlen(S.text), ctrl = mods & MOD_CTRL;
  S.blink = 1, S.blink_t = now_ms();
  if (code == KEY_ESC) {
    if (S.nsug) S.nsug = 0;
    else close_omni();
  } else if (code == KEY_ENTER || code == KEY_KPENTER) omni_go();
  else if (code == KEY_UP && S.nsug) S.sug_sel = (S.sug_sel + S.nsug - 1) % S.nsug;
  else if (code == KEY_DOWN && S.nsug) S.sug_sel = (S.sug_sel + 1) % S.nsug;
  else if (code == KEY_BACKSPACE) {
    if (S.sel_all) S.text[0] = 0, S.cur = 0, S.sel_all = 0;
    else if (S.cur > 0) {
      int k = 1;
      if (ctrl)
        while (S.cur - k > 0 && S.text[S.cur - k - 1] != ' ' && S.text[S.cur - k - 1] != '/' && S.text[S.cur - k - 1] != '.') k++;
      memmove(S.text + S.cur - k, S.text + S.cur, (size_t)(l - S.cur + 1));
      S.cur -= k;
    }
    build_sugs();
  } else if (code == KEY_DELETE) {
    if (S.sel_all) S.text[0] = 0, S.cur = 0, S.sel_all = 0;
    else if (S.cur < l) memmove(S.text + S.cur, S.text + S.cur + 1, (size_t)(l - S.cur));
    build_sugs();
  } else if (code == KEY_LEFT) S.cur = S.sel_all ? 0 : S.cur > 0 ? S.cur - 1 : 0, S.sel_all = 0;
  else if (code == KEY_RIGHT) S.cur = S.sel_all ? l : S.cur < l ? S.cur + 1 : l, S.sel_all = 0;
  else if (code == KEY_HOME) S.cur = 0, S.sel_all = 0;
  else if (code == KEY_END) S.cur = l, S.sel_all = 0;
  else if (ctrl && code == KEY_A) S.sel_all = 1;
  else if (!ctrl && !(mods & MOD_ALT)) {
    char b[8];
    int n = key_to_bytes(code, mods, b);
    if (n == 1 && (unsigned char)b[0] >= 32 && b[0] != 127) {
      b[1] = 0;
      omni_insert(b);
    }
  }
}

static void pdf_name(const char *url, char *o, int n) {
  const char *q = strpbrk(url, "?#"), *e = q ? q : url + strlen(url), *b = e;
  while (b > url && b[-1] != '/') b--;
  int k = 0;
  for (const char *c = b; c < e && k < n - 1; c++) {
    if (*c == '%' && c + 2 < e && isxdigit((unsigned char)c[1]) && isxdigit((unsigned char)c[2])) {
      char hx[3] = {c[1], c[2], 0};
      o[k++] = (char)strtol(hx, NULL, 16);
      c += 2;
    } else o[k++] = *c;
  }
  o[k] = 0;
  if (!k) snprintf(o, (size_t)n, "document.pdf");
}

static void open_pdf(Tab *t, const char *url, int dl) {
  free_pdf(t->pdf);
  Pdf *f = calloc(1, sizeof *f);
  t->pdf = f;
  t->native = N_PDF, t->loading = 0;
  snprintf(f->url, sizeof f->url, "%s", url);
  snprintf(t->url, sizeof t->url, "%s", url);
  pdf_name(url, f->name, sizeof f->name);
  snprintf(t->title, sizeof t->title, "%s", f->name);
  f->dl = dl, f->fit = 1, f->zoom = 1;
  char dir[700];
  data_path(dir, sizeof dir, "pdf");
  office_mkdirs(dir);
  snprintf(f->path, sizeof f->path, "%.600s/%.20s.pdf", dir, t->tid);
  if (!strncmp(url, "file://", 7)) {
    snprintf(f->path, sizeof f->path, "%s", url + 7);
    char *a[] = {"pdfinfo", f->path, NULL};
    f->info = net_proc("pdfinfo", a, 0);
    f->state = 1;
  } else f->fetch = net_http(url, NULL, 0);
  set_title();
  dirty();
}

static float pdf_scale(Pdf *f) {
  if (f->fit && f->pw > 0) f->zoom = (NW - 220) / (f->pw * 4 / 3.f);
  if (f->zoom < 0.25f) f->zoom = 0.25f;
  if (f->zoom > 4) f->zoom = 4;
  return f->pw * 4 / 3.f * f->zoom;
}

#define PDF_BAR 52
#define PDF_GAP 14

static uint32_t *read_ppm(const char *path, int *w, int *h) {
  FILE *fp = fopen(path, "rb");
  if (!fp) return NULL;
  int mx = 0;
  if (fscanf(fp, "P6 %d %d %d", w, h, &mx) != 3 || *w <= 0 || *h <= 0 || *w > 8000 || *h > 12000 || mx != 255) {
    fclose(fp);
    return NULL;
  }
  fgetc(fp);
  size_t n = (size_t)*w * (size_t)*h;
  unsigned char *raw = malloc(n * 3);
  uint32_t *px = malloc(n * 4);
  if (!raw || !px || fread(raw, 3, n, fp) != n) {
    free(raw), free(px), fclose(fp);
    return NULL;
  }
  fclose(fp);
  for (size_t i = 0; i < n; i++) px[i] = 0xff000000u | (uint32_t)raw[i * 3] << 16 | (uint32_t)raw[i * 3 + 1] << 8 | raw[i * 3 + 2];
  free(raw);
  return px;
}

static int pdf_tick(Tab *t) {
  Pdf *f = t->pdf;
  if (!f) return 0;
  int ch = 0;
  if (f->state == 0 && f->fetch && (f->fetch->state == NET_OK || f->fetch->state == NET_FAIL)) {
    if (f->fetch->state == NET_OK && f->fetch->out.n > 4 && !memcmp(f->fetch->out.s, "%PDF", 4)) {
      FILE *fp = fopen(f->path, "wb");
      if (fp) fwrite(f->fetch->out.s, 1, f->fetch->out.n, fp), fclose(fp);
      char *a[] = {"pdfinfo", f->path, NULL};
      f->info = net_proc("pdfinfo", a, 0);
      f->state = 1;
    } else f->state = -1;
    net_drop(f->fetch);
    f->fetch = NULL;
    ch = 1;
  }
  if (f->state == 1 && f->info && (f->info->state == NET_OK || f->info->state == NET_FAIL)) {
    const char *o = f->info->out.s ? f->info->out.s : "";
    const char *pg = strstr(o, "Pages:"), *sz = strstr(o, "Page size:"), *ti = strstr(o, "Title:");
    f->n = pg ? atoi(pg + 6) : 0;
    if (sz) sscanf(sz + 10, " %f x %f", &f->pw, &f->ph);
    if (ti) {
      char b[160];
      sscanf(ti + 6, " %159[^\n]", b);
      if (b[0]) snprintf(f->title, sizeof f->title, "%s", b);
    }
    if (f->n > 400) f->n = 400;
    f->state = f->n > 0 && f->pw > 0 ? 2 : -1;
    net_drop(f->info);
    f->info = NULL;
    ch = 1;
  }
  if (f->state != 2) return ch;
  float dw = pdf_scale(f), dh = dw * f->ph / f->pw, vh = page_h() - PDF_BAR;
  int rw = (int)(dw * 1.5f);
  if (rw > 1900) rw = 1900;
  int first = (int)((f->scroll - PDF_GAP) / (dh + PDF_GAP)), last = (int)((f->scroll + vh) / (dh + PDF_GAP));
  if (first < 0) first = 0;
  if (last >= f->n) last = f->n - 1;
  f->cur = first;
  for (int i = 0; i < f->n; i++) {
    PdfPage *g = &f->pg[i];
    if (g->job && (g->job->state == NET_OK || g->job->state == NET_FAIL)) {
      char out[760];
      snprintf(out, sizeof out, "%s-%d.ppm", f->path, i + 1);
      int w, h;
      uint32_t *px = g->job->state == NET_OK ? read_ppm(out, &w, &h) : NULL;
      unlink(out);
      if (px) free(g->px), g->px = px, g->w = w, g->h = h;
      net_drop(g->job);
      g->job = NULL;
      f->rendering--;
      ch = 1;
    }
    if ((i < first - 3 || i > last + 3) && g->px && !g->job) free(g->px), g->px = NULL;
  }
  for (int i = first; i <= last + 1 && i < f->n && f->rendering < 2; i++) {
    if (f->pg[i].job || (f->pg[i].px && abs(f->pg[i].w - rw) < 8)) continue;
    char fp1[16], wb[16], pre[740];
    snprintf(fp1, sizeof fp1, "%d", i + 1);
    snprintf(wb, sizeof wb, "%d", rw);
    snprintf(pre, sizeof pre, "%s-%d", f->path, i + 1);
    char *a[] = {"pdftoppm", "-f", fp1, "-l", fp1, "-scale-to-x", wb, "-scale-to-y", "-1", "-ppm", "-singlefile", f->path, pre, NULL};
    f->pg[i].job = net_proc("pdfpage", a, 0);
    if (f->pg[i].job) f->rendering++;
  }
  return ch;
}

static void pdf_scroll_by(Pdf *f, float d) {
  if (!f || f->state != 2) return;
  float dw = pdf_scale(f), dh = dw * f->ph / f->pw, total = f->n * (dh + PDF_GAP) + PDF_GAP, mx = total - (page_h() - PDF_BAR);
  f->scroll += d;
  if (f->scroll > mx) f->scroll = mx;
  if (f->scroll < 0) f->scroll = 0;
}

static void pdf_zoom(Pdf *f, int d) {
  if (!f || f->state != 2) return;
  float old = pdf_scale(f), rel = f->scroll / (old * f->ph / f->pw + PDF_GAP);
  static const float Z[] = {0.25f, 0.33f, 0.5f, 0.67f, 0.75f, 0.9f, 1, 1.1f, 1.25f, 1.5f, 1.75f, 2, 2.5f, 3, 4};
  if (d == 0) f->fit = 1;
  else {
    int k = 0;
    while (k < 14 && Z[k] < f->zoom - 0.01f) k++;
    k += d > 0 ? (Z[k] > f->zoom + 0.01f ? 0 : 1) : -1;
    if (k < 0) k = 0;
    if (k > 14) k = 14;
    f->fit = 0, f->zoom = Z[k];
  }
  float nw = pdf_scale(f);
  f->scroll = rel * (nw * f->ph / f->pw + PDF_GAP);
  pdf_scroll_by(f, 0);
}

static void pdf_save(Pdf *f) {
  if (!f || f->state != 2) return;
  char dst[900];
  snprintf(dst, sizeof dst, "%s/Downloads", user_home());
  office_mkdirs(dst);
  snprintf(dst, sizeof dst, "%s/Downloads/%s", user_home(), f->name);
  FILE *a = fopen(f->path, "rb"), *b = a ? fopen(dst, "wb") : NULL;
  char buf[65536];
  size_t n;
  while (a && b && (n = fread(buf, 1, sizeof buf, a)) > 0) fwrite(buf, 1, n, b);
  if (a) fclose(a);
  if (b) fclose(b);
  char m[260];
  snprintf(m, sizeof m, b ? "Saved %.200s to Downloads" : "Could not save %.200s", f->name);
  toast(m);
}

static Surface *SF;
static float OX, OY;
static int HOT;
static struct {
  float x, y, w, h;
  int z;
} HR[600];
static int nhr;

static void hit(int z, float x, float y, float w, float h) {
  if (nhr < 600 && w > 0 && h > 0) HR[nhr].x = x, HR[nhr].y = y, HR[nhr].w = w, HR[nhr].h = h, HR[nhr++].z = z;
}

static void rc(float x, float y, float w, float h, uint32_t c) { gfx_rect(SF, OX + x, OY + y, w, h, c); }
static void rr(float x, float y, float w, float h, float r, uint32_t c) { gfx_rrect(SF, OX + x, OY + y, w, h, r, c); }
static void dsc(float x, float y, float r, uint32_t c) { gfx_disc(SF, OX + x, OY + y, r, c); }
static void ring(float x, float y, float r, float th, uint32_t c) { gfx_ring(SF, OX + x, OY + y, r, th, c); }
static void ln(float x0, float y0, float x1, float y1, float th, uint32_t c) { gfx_line(SF, OX + x0, OY + y0, OX + x1, OY + y1, th, c); }
static void tri(float x0, float y0, float x1, float y1, float x2, float y2, uint32_t c) { gfx_tri(SF, OX + x0, OY + y0, OX + x1, OY + y1, OX + x2, OY + y2, c); }
static void tx(const Font *f, float x, float y, const char *t, uint32_t c) { gfx_text(SF, f, OX + x, OY + y, t, c); }
static void tf(const Font *f, float x, float y, float w, const char *t, uint32_t c) { gfx_text_fit(SF, f, OX + x, OY + y, w, t, c); }
static void tcn(const Font *f, float cx, float y, const char *t, uint32_t c) { gfx_text_c(SF, f, OX + cx, OY + y, t, c); }
static void clip(float x, float y, float w, float h) { gfx_clip(SF, OX + x, OY + y, w, h); }

static void page_bg(float y0, float h, uint32_t c) {
  if (y0 + h < NH - 1) {
    rc(0, y0, NW, h, c);
    return;
  }
  rr(0, y0 + h - 2 * RAD, NW, 2 * RAD, RAD, c);
  rc(0, y0, NW, h - RAD, c);
}

static void arc(float cx, float cy, float r, float a0, float a1, float th, uint32_t c) {
  int n = (int)(fabsf(a1 - a0) / 0.22f) + 2;
  float px = cx + cosf(a0) * r, py = cy + sinf(a0) * r;
  for (int i = 1; i <= n; i++) {
    float a = a0 + (a1 - a0) * i / n, x = cx + cosf(a) * r, y = cy + sinf(a) * r;
    ln(px, py, x, y, th, c);
    px = x, py = y;
  }
}

static void ic_x(float cx, float cy, float r, float th, uint32_t c) {
  ln(cx - r, cy - r, cx + r, cy + r, th, c);
  ln(cx + r, cy - r, cx - r, cy + r, th, c);
}

static void ic_arrow(float cx, float cy, int dir, uint32_t c) {
  float d = (float)dir;
  ln(cx - 7 * d, cy, cx + 7 * d, cy, 1.9f, c);
  ln(cx - 7 * d, cy, cx - 1 * d, cy - 6, 1.9f, c);
  ln(cx - 7 * d, cy, cx - 1 * d, cy + 6, 1.9f, c);
}

static void ic_reload(float cx, float cy, uint32_t c) {
  arc(cx, cy, 7, -1.2f, 4.1f, 1.9f, c);
  float a = -1.2f, ex = cx + cosf(a) * 7, ey = cy + sinf(a) * 7;
  tri(ex + 4.6f, ey - 0.2f, ex - 1.4f, ey - 4.2f, ex - 0.6f, ey + 3.6f, c);
}

static void ic_home(float cx, float cy, uint32_t c) {
  ln(cx - 8, cy - 0.5f, cx, cy - 8, 1.8f, c);
  ln(cx, cy - 8, cx + 8, cy - 0.5f, 1.8f, c);
  ln(cx - 5.5f, cy - 2.5f, cx - 5.5f, cy + 7, 1.8f, c);
  ln(cx + 5.5f, cy - 2.5f, cx + 5.5f, cy + 7, 1.8f, c);
  ln(cx - 5.5f, cy + 7, cx + 5.5f, cy + 7, 1.8f, c);
}

static void ic_star(float cx, float cy, float r, int filled, uint32_t c) {
  float px[10], py[10];
  for (int i = 0; i < 10; i++) {
    float a = -PI_F / 2 + i * PI_F / 5, rr2 = i & 1 ? r * 0.45f : r;
    px[i] = cx + cosf(a) * rr2, py[i] = cy + sinf(a) * rr2;
  }
  if (filled)
    for (int i = 0; i < 10; i++) tri(cx, cy, px[i], py[i], px[(i + 1) % 10], py[(i + 1) % 10], c);
  else
    for (int i = 0; i < 10; i++) ln(px[i], py[i], px[(i + 1) % 10], py[(i + 1) % 10], 1.6f, c);
}

static void ic_lock(float cx, float cy, uint32_t c) {
  rr(cx - 5.5f, cy - 1.5f, 11, 8.5f, 2, c);
  arc(cx, cy - 2.5f, 3.6f, PI_F, 2 * PI_F, 1.7f, c);
  ln(cx - 3.6f, cy - 2.5f, cx - 3.6f, cy - 1, 1.7f, c);
  ln(cx + 3.6f, cy - 2.5f, cx + 3.6f, cy - 1, 1.7f, c);
}

static void ic_info(float cx, float cy, uint32_t c) {
  ring(cx, cy, 7.5f, 1.5f, c);
  dsc(cx, cy - 3.6f, 1.1f, c);
  ln(cx, cy - 1, cx, cy + 4, 1.6f, c);
}

static void ic_search(float cx, float cy, uint32_t c) {
  ring(cx - 1.5f, cy - 1.5f, 5.5f, 1.8f, c);
  ln(cx + 2.5f, cy + 2.5f, cx + 7, cy + 7, 2, c);
}

static void ic_globe(float cx, float cy, uint32_t c) {
  ring(cx, cy, 7.5f, 1.4f, c);
  ln(cx - 7.5f, cy, cx + 7.5f, cy, 1.2f, c);
  arc(cx + 5.5f, cy, 8.8f, PI_F - 0.95f, PI_F + 0.95f, 1.2f, c);
  arc(cx - 5.5f, cy, 8.8f, -0.95f, 0.95f, 1.2f, c);
}

static void ic_clock(float cx, float cy, uint32_t c) {
  ring(cx, cy, 7.5f, 1.5f, c);
  ln(cx, cy, cx, cy - 4.5f, 1.6f, c);
  ln(cx, cy, cx + 3.5f, cy + 2, 1.6f, c);
}

static void ic_dots(float cx, float cy, uint32_t c) {
  for (int i = -1; i <= 1; i++) dsc(cx + i * 6.5f, cy, 2.1f, c);
}

static void logo_wave(float cx, float cy, float r, float yb, float amp, float ph, uint32_t c) {
  float step = r > 20 ? 0.5f : 1.f / SCALE;
  for (float dx = -r + 0.5f; dx < r - 0.4f; dx += step) {
    float hh = sqrtf(r * r - dx * dx) - 0.6f, wy = yb - amp * sinf(dx / r * 2.6f + ph);
    float top = wy < cy - hh ? cy - hh : wy, bot = cy + hh;
    if (top < bot) rc(cx + dx, top, step + 0.3f, bot - top, c);
  }
}

static void surf_logo(float cx, float cy, float r) {
  uint32_t a = RGB(46, 134, 255), b = RGB(0, 214, 214);
  for (int i = 0; i < 14; i++) {
    float t = i / 13.f;
    dsc(cx - r * 0.1f * t, cy - r * 0.1f * t, r * (1 - t * 0.5f), mixc(a, b, t));
  }
  dsc(cx + r * 0.38f, cy - r * 0.42f, r * 0.17f, RGBA(255, 255, 255, 235));
  logo_wave(cx, cy, r, cy + r * 0.12f, r * 0.2f, 0.6f, RGBA(255, 255, 255, 110));
  logo_wave(cx, cy, r, cy + r * 0.34f, r * 0.2f, 3.2f, RGB(255, 255, 255));
  logo_wave(cx, cy, r, cy + r * 0.62f, r * 0.17f, 1.4f, RGB(18, 96, 214));
}

static void favicon(const char *url, float x, float y, float sz, int native) {
  if (native == N_HISTORY) {
    ic_clock(x + sz / 2, y + sz / 2, K_ICON);
    return;
  }
  if (native == N_PDF) {
    rr(x + sz * 0.12f, y, sz * 0.76f, sz, sz * 0.14f, RGB(234, 67, 53));
    rc(x + sz * 0.28f, y + sz * 0.38f, sz * 0.44f, sz * 0.09f, RGB(255, 255, 255));
    rc(x + sz * 0.28f, y + sz * 0.58f, sz * 0.44f, sz * 0.09f, RGB(255, 255, 255));
    return;
  }
  if (native || !is_web(url)) {
    surf_logo(x + sz / 2, y + sz / 2, sz / 2);
    return;
  }
  char fu[400];
  favicon_url(url, fu, sizeof fu);
  Img *im = img_get(fu, 64, 0);
  if (im && im->state == IMG_READY) {
    gfx_blit_premul(SF, im->px, im->w, im->h, OX + x, OY + y, sz, sz);
    return;
  }
  ic_globe(x + sz / 2, y + sz / 2, K_MUTED);
}

static void spinner(float cx, float cy, float r, uint32_t c) {
  float a = (now_ms() % 900) / 900.f * 2 * PI_F;
  arc(cx, cy, r, a, a + 4.2f, 2, c);
}

static void round_btn(int z, float cx, float cy, int enabled) {
  if (!enabled) return;
  if (HOT == z) dsc(cx, cy, 22, S.press == z ? K_PRESS : K_HOVER);
  hit(z, cx - 23, cy - 23, 46, 46);
}

static float TXP[MAXT], TWP[MAXT];
static int TVIS[MAXT];

static void layout_tabs(void) {
  float x0 = 14, avail = NW - x0 - 70 - 64, fixed = 0;
  int nn = 0;
  for (int i = 0; i < ntab; i++) {
    if (TB[i]->pinned) fixed += 58;
    else nn++;
  }
  float tw = nn ? (avail - fixed) / nn - 6 : 0;
  if (tw > 240) tw = 240;
  if (tw < 64) tw = 64;
  float x = x0;
  for (int i = 0; i < ntab; i++) {
    Tab *t = TB[i];
    TVIS[i] = 1;
    if (t->pinned) TXP[i] = x, TWP[i] = 52, x += 58;
    else TXP[i] = x, TWP[i] = tw, x += tw + 6;
    if (TXP[i] + TWP[i] > NW - 110) TVIS[i] = 0;
  }
  S.newtab_x = (x > NW - 110 ? NW - 110 : x) + 22;
}

static void draw_tabs(void) {
  rr(0, 0, NW, TS + RAD, RAD, K_FRAME);
  hit(Z_DRAG, 0, 0, NW, TS);
  layout_tabs();
  float ty = 10, th = TS - 16;
  for (int i = 0; i < ntab; i++) {
    Tab *t = TB[i];
    if (!TVIS[i]) continue;
    float x = TXP[i], w = TWP[i], cy = ty + th / 2;
    int a = i == act, hv = HOT == Z_TAB + i || HOT == Z_TABX + i;
    uint32_t bg = a ? K_OMNI : hv ? K_TAB_HOT : 0;
    if (bg) rr(x, ty, w, th, th / 2, bg);
    hit(Z_TAB + i, x, ty, w, th);
    if (t->pinned) {
      if (t->loading && !t->native) spinner(x + w / 2, cy, 7, K_ACC);
      else favicon(t->url, x + w / 2 - 9, cy - 9, 18, t->native);
      continue;
    }
    if (t->loading && !t->native) spinner(x + 26, cy, 7, K_ACC);
    else favicon(t->url, x + 17, cy - 9, 18, t->native);
    const char *title = t->native == N_HISTORY ? "History" : t->native == N_ABOUT ? "About Surf" : t->native == N_PDF && t->pdf ? t->pdf->name : t->native ? "New Tab" : t->title[0] ? t->title : t->url;
    if (t->crashed) title = "Aw, snap!";
    int showx = a || hv || w > 130;
    clip(x, 0, w - (showx ? 40 : 12), TS);
    tf(F_UI, x + 46, cy - line_h(F_UI) / 2, w - 46 - (showx ? 40 : 12), title, a ? K_TEXT : K_MUTED);
    gfx_clip(SF, OX, OY, NW, NH);
    if (showx) {
      float bx = x + w - 24;
      dsc(bx, cy, 12, HOT == Z_TABX + i ? K_PRESS : a || hv ? THEME(RGB(218, 220, 224), RGB(80, 84, 94)) : 0);
      ic_x(bx, cy, 4, 1.7f, K_ICON);
      hit(Z_TABX + i, bx - 14, cy - 14, 28, 28);
    }
  }
  float nx = S.newtab_x, ny = ty + th / 2;
  if (HOT == Z_NEWTAB) dsc(nx, ny, 18, K_HOVER);
  ln(nx - 7, ny, nx + 7, ny, 2, K_ICON);
  ln(nx, ny - 7, nx, ny + 7, 2, K_ICON);
  hit(Z_NEWTAB, nx - 20, ny - 20, 40, 40);
  float wx = NW - 34, wy = ty + th / 2;
  if (HOT == Z_WINX) dsc(wx, wy, 19, C_CLOSE_HOT);
  ic_x(wx, wy, 6, 1.8f, HOT == Z_WINX ? RGB(255, 255, 255) : K_ICON);
  hit(Z_WINX, wx - 21, wy - 21, 42, 42);
}

static void draw_omni_text(float x, float y, float w) {
  Tab *t = cur();
  float ty = y - line_h(F_UI) / 2;
  if (S.omni) {
    float tw = gfx_text_w(F_UI, S.text);
    char pre[1024];
    snprintf(pre, sizeof pre, "%.*s", S.cur, S.text);
    float cxp = gfx_text_w(F_UI, pre), shift = 0;
    if (cxp > w - 4) shift = cxp - (w - 4);
    clip(x - 2, y - 14, w + 4, 28);
    if (S.sel_all && S.text[0]) rc(x - shift, y - 10, tw, 20, K_ACC_SOFT);
    if (!S.text[0]) tx(F_UI, x, ty, "Search or enter website", K_MUTED);
    tx(F_UI, x - shift, ty, S.text, K_TEXT);
    if (S.blink && !S.sel_all) rc(x - shift + cxp, y - 10, 1.5f, 20, K_ACC);
    gfx_clip(SF, OX, OY, NW, NH);
    return;
  }
  if (!t || t->native) {
    tx(F_UI, x, ty, "Search or enter website", K_MUTED);
    return;
  }
  char pu[1024], host[300];
  pretty_url(t->url, pu, sizeof pu);
  url_host(t->url, host, sizeof host);
  clip(x, y - 14, w, 28);
  char *h = strstr(pu, host[0] && !strncmp(host, "www.", 4) && !strstr(pu, host) ? host + 4 : host);
  if (h && host[0]) {
    char a[1024];
    snprintf(a, sizeof a, "%.*s", (int)(h - pu), pu);
    float xx = x + gfx_text_w(F_UI, a);
    tx(F_UI, x, ty, a, K_MUTED);
    const char *hh = !strncmp(host, "www.", 4) && strncmp(h, "www.", 4) ? host + 4 : host;
    int hl = (int)strlen(hh);
    char hb[300];
    snprintf(hb, sizeof hb, "%.*s", hl, h);
    tx(F_UI, xx, ty, hb, K_TEXT);
    tx(F_UI, xx + gfx_text_w(F_UI, hb), ty, h + strlen(hb), K_MUTED);
  } else tx(F_UI, x, ty, pu, K_TEXT);
  gfx_clip(SF, OX, OY, NW, NH);
}

static void draw_toolbar(void) {
  Tab *t = cur();
  rc(0, TS, NW, TBH, K_BAR);
  float cy = TS + TBH / 2;
  int web = t && !t->native;
  int bk = t && (t->back_id >= 0 || (t->native == N_PDF && t->pdf && t->pdf->dl));
  round_btn(Z_BACK, 36, cy, bk);
  ic_arrow(36, cy, 1, bk ? K_ICON : K_DIM);
  round_btn(Z_FWD, 86, cy, t && t->fwd_id >= 0);
  ic_arrow(86, cy, -1, t && t->fwd_id >= 0 ? K_ICON : K_DIM);
  round_btn(Z_RELOAD, 136, cy, web);
  if (web && t->loading) ic_x(136, cy, 6, 1.9f, K_ICON);
  else ic_reload(136, cy, web ? K_ICON : K_DIM);
  round_btn(Z_HOMEB, 186, cy, 1);
  ic_home(186, cy, K_ICON);
  float ox = 220, ow = NW - ox - 76, oh = 46, oy = cy - oh / 2;
  if (S.omni) {
    rr(ox - 2, oy - 2, ow + 4, oh + 4, oh / 2 + 2, K_ACC);
    rr(ox, oy, ow, oh, oh / 2, K_CARD);
  } else rr(ox, oy, ow, oh, oh / 2, HOT == Z_OMNI || HOT == Z_STAR ? K_OMNI_HOT : K_OMNI);
  hit(Z_OMNI, ox, oy, ow, oh);
  float ix = ox + 22;
  if (S.omni) ic_search(ix, cy, K_MUTED);
  else if (!web) ic_search(ix, cy, K_MUTED);
  else if (!strncmp(t->url, "https://", 8)) {
    if (HOT == Z_OMNI) dsc(ix, cy, 13, K_HOVER);
    ic_lock(ix, cy, K_ICON);
  } else if (!strncmp(t->url, "http://", 7)) {
    rr(ix - 12, cy - 12, 98, 24, 12, THEME(RGB(252, 232, 230), RGB(80, 40, 40)));
    ic_info(ix, cy, K_WARN);
    tx(F_SMALL, ix + 12, cy - line_h(F_SMALL) / 2, "Not secure", K_WARN);
    ix += 84;
  } else ic_info(ix, cy, K_ICON);
  float tx0 = ix + 20, tw = ow - (tx0 - ox) - 50;
  if (web && t->zoom != ZOOM_DEF && !S.omni) {
    char zb[16];
    snprintf(zb, sizeof zb, "%d%%", (int)(ZOOMS[t->zoom] * 100 + 0.5f));
    float zw = gfx_text_w(F_SMALL, zb) + 18, zx = ox + ow - 44 - zw;
    rr(zx, cy - 12, zw, 24, 12, HOT == Z_ZOOMB ? K_ACC_SOFT : K_OMNI_HOT);
    tcn(F_SMALL, zx + zw / 2, cy - line_h(F_SMALL) / 2, zb, K_TEXT);
    hit(Z_ZOOMB, zx, cy - 12, zw, 24);
    tw -= zw + 6;
  }
  draw_omni_text(tx0, cy, tw);
  if (web && !S.omni) {
    float sx = ox + ow - 22;
    if (HOT == Z_STAR) dsc(sx, cy, 14, K_HOVER);
    int m = mark_idx(t->url) >= 0;
    ic_star(sx, cy, 8, m, m ? K_ACC : K_ICON);
    hit(Z_STAR, sx - 15, cy - 15, 30, 30);
  }
  round_btn(Z_MENU, NW - 38, cy, 1);
  if (S.menu) dsc(NW - 38, cy, 22, K_PRESS);
  ic_dots(NW - 38, cy, K_ICON);
  if (web && t->loading) {
    float e = (now_ms() - t->load_t0) / 1000.f, pr = 1 - expf(-e * 1.3f);
    pr = 0.08f + pr * 0.84f;
    rc(0, TS + TBH - 2, NW * pr, 2, K_ACC);
  }
}

static void draw_bbar(void) {
  float y = TS + TBH;
  rc(0, y, NW, BBH, K_BAR);
  float x = 10;
  if (!nbm) tx(F_SMALL, 16, y + BBH / 2 - line_h(F_SMALL) / 2, "For quick access, bookmark pages with the star in the address bar", K_MUTED);
  for (int i = 0; i < nbm; i++) {
    float w = gfx_text_w(F_SMALL, BM[i].title) + 38;
    if (w > 170) w = 170;
    if (x + w > NW - 10) break;
    if (HOT == Z_BM + i) rr(x, y + 3, w, BBH - 6, 13, K_HOVER);
    favicon(BM[i].url, x + 9, y + BBH / 2 - 7, 14, N_WEB);
    tf(F_SMALL, x + 29, y + BBH / 2 - line_h(F_SMALL) / 2, w - 36, BM[i].title, K_TEXT);
    hit(Z_BM + i, x, y + 3, w, BBH - 6);
    x += w + 4;
  }
}

static const Short DEF_SHORTS[8] = {
    {"Google", "https://www.google.com/"},     {"YouTube", "https://www.youtube.com/"}, {"Wikipedia", "https://www.wikipedia.org/"},
    {"GitHub", "https://github.com/"},         {"Reddit", "https://www.reddit.com/"},   {"Flathub", "https://flathub.org/"},
    {"Maps", "https://maps.google.com/"},      {"News", "https://news.ycombinator.com/"},
};

int surf_shortcuts(char (*names)[60], char (*urls)[600], int max) {
  char dir[600], p[700], line[800];
  const char *d = getenv("OREONVR_SURF_DIR");
  if (d && *d) snprintf(dir, sizeof dir, "%s", d);
  else snprintf(dir, sizeof dir, "%s/.local/share/oreonvr/surf", user_home());
  snprintf(p, sizeof p, "%s/shortcuts.tsv", dir);
  memset(names, 0, sizeof names[0] * (size_t)max);
  memset(urls, 0, sizeof urls[0] * (size_t)max);
  int n = 0;
  FILE *f = fopen(p, "r");
  if (!f) {
    for (int i = 0; i < 8 && n < max; i++, n++) {
      snprintf(names[n], 60, "%.59s", DEF_SHORTS[i].name);
      snprintf(urls[n], 600, "%.599s", DEF_SHORTS[i].url);
    }
    return n;
  }
  while (n < max && fgets(line, sizeof line, f)) {
    line[strcspn(line, "\n")] = 0;
    char *tb = strchr(line, '\t');
    if (!tb) continue;
    *tb++ = 0;
    snprintf(names[n], 60, "%.59s", line);
    snprintf(urls[n], 600, "%.599s", tb);
    n++;
  }
  fclose(f);
  return n;
}

static char pend_url[1024];

void surf_open_url(const char *url) {
  snprintf(pend_url, sizeof pend_url, "%s", url);
  panel_open_app("surf");
}

static void save_sc(void) {
  char p[700];
  data_path(p, sizeof p, "shortcuts.tsv");
  FILE *f = fopen(p, "w");
  if (!f) return;
  for (int i = 0; i < nsc; i++) fprintf(f, "%s\t%s\n", SCL[i].name, SCL[i].url);
  fclose(f);
}

static void load_sc(void) {
  char p[700], line[800];
  data_path(p, sizeof p, "shortcuts.tsv");
  FILE *f = fopen(p, "r");
  nsc = 0;
  if (!f) {
    for (int i = 0; i < 8; i++) SCL[nsc++] = DEF_SHORTS[i];
    return;
  }
  while (nsc < MAXSC && fgets(line, sizeof line, f)) {
    line[strcspn(line, "\n")] = 0;
    char *tb = strchr(line, '\t');
    if (!tb) continue;
    *tb++ = 0;
    snprintf(SCL[nsc].name, sizeof SCL[nsc].name, "%.59s", line);
    snprintf(SCL[nsc].url, sizeof SCL[nsc].url, "%.599s", tb);
    nsc++;
  }
  fclose(f);
}

static int shortcut(int i, char *name, int nn, char *url, int un) {
  if (i < 0 || i >= nsc) return 0;
  snprintf(name, (size_t)nn, "%s", SCL[i].name);
  snprintf(url, (size_t)un, "%s", SCL[i].url);
  return 1;
}

static uint32_t host_tint(const char *u) {
  static const uint32_t P[6] = {RGB(214, 228, 252), RGB(252, 222, 214), RGB(214, 240, 222), RGB(236, 222, 252), RGB(252, 238, 206), RGB(208, 236, 240)};
  char h[300];
  url_host(u, h, sizeof h);
  unsigned k = 5;
  for (char *c = h; *c; c++) k = k * 33 + (unsigned char)*c;
  return g_dark ? mixc(P[k % 6], RGB(40, 43, 50), 0.72f) : P[k % 6];
}

static int recent(int *out, int cap) {
  int n = 0;
  for (int i = 0; i < nh && n < cap; i++) {
    char a[300], b[300];
    url_host(H[i].url, a, sizeof a);
    int dup = 0;
    for (int k = 0; k < n; k++) {
      url_host(H[out[k]].url, b, sizeof b);
      if (!strcmp(a, b)) dup = 1;
    }
    if (!dup) out[n++] = i;
  }
  return n;
}

static void draw_ntp(float y0, float h) {
  page_bg(y0, h, K_PAGE);
  float x0 = 64, y = y0 + 36;
  tx(F_UI_MED, x0, y, "Popular", K_TEXT);
  y += 40;
  float tw = 112, th = 100, gap = 14;
  int per = (int)((NW - 2 * x0 + gap) / (tw + gap));
  for (int i = 0; i <= nsc && i < MAXSC; i++) {
    float x = x0 + (i % per) * (tw + gap), yy = y + (i / per) * (th + gap);
    if (i == nsc) {
      rr(x, yy, tw, th, 18, HOT == Z_SC_ADD ? K_OMNI_HOT : K_OMNI);
      dsc(x + tw / 2, yy + 36, 18, K_CARD);
      ln(x + tw / 2 - 7, yy + 36, x + tw / 2 + 7, yy + 36, 2, K_ICON);
      ln(x + tw / 2, yy + 29, x + tw / 2, yy + 43, 2, K_ICON);
      tcn(F_SMALL, x + tw / 2, yy + 68, "Add shortcut", K_MUTED);
      hit(Z_SC_ADD, x, yy, tw, th);
      break;
    }
    int hv = HOT == Z_TILE + i || HOT == Z_SC_EDIT + i;
    gfx_shadow(SF, OX + x, OY + yy + 2, tw, th, 18, 8, RGBA(0, 0, 0, g_dark ? 50 : 16));
    rr(x, yy, tw, th, 18, hv ? K_OMNI_HOT : K_CARD);
    favicon(SCL[i].url, x + tw / 2 - 16, yy + 18, 32, N_WEB);
    clip(x + 6, yy + 56, tw - 12, 34);
    if (gfx_text_w(F_SMALL, SCL[i].name) > tw - 12) tf(F_SMALL, x + 6, yy + 66, tw - 12, SCL[i].name, K_TEXT);
    else tcn(F_SMALL, x + tw / 2, yy + 66, SCL[i].name, K_TEXT);
    gfx_clip(SF, OX, OY, NW, NH);
    hit(Z_TILE + i, x, yy, tw, th);
    if (hv) {
      dsc(x + tw - 16, yy + 16, 12, HOT == Z_SC_EDIT + i ? K_PRESS : K_OMNI);
      for (int k = -1; k <= 1; k++) dsc(x + tw - 16 + k * 4.5f, yy + 16, 1.5f, K_ICON);
      hit(Z_SC_EDIT + i, x + tw - 30, yy + 2, 28, 28);
    }
  }
  y += ((nsc) / per + 1) * (th + gap) + 22;
  int rec[3], nr = recent(rec, 3);
  if (!nr) return;
  tx(F_UI_MED, x0, y, "Jump back in", K_TEXT);
  y += 40;
  float cw = (NW - 2 * x0 - 2 * 20) / 3, ch = 150;
  if (y + ch + 60 > y0 + h) ch = y0 + h - y - 64;
  if (ch < 60) return;
  for (int k = 0; k < nr; k++) {
    Hist *e = &H[rec[k]];
    float x = x0 + k * (cw + 20);
    int hv = HOT == Z_REC + k;
    rr(x, y, cw, ch, 20, host_tint(e->url));
    if (hv) rr(x, y, cw, ch, 20, K_HOVER);
    dsc(x + cw / 2, y + ch / 2, 34, K_CARD);
    favicon(e->url, x + cw / 2 - 18, y + ch / 2 - 18, 36, N_WEB);
    char host[300];
    url_host(e->url, host, sizeof host);
    tf(F_UI_MED, x + 4, y + ch + 10, cw - 8, e->title[0] ? e->title : host, K_TEXT);
    tf(F_SMALL, x + 4, y + ch + 34, cw - 8, host, K_MUTED);
    hit(Z_REC + k, x, y, cw, ch + 52);
  }
}

static void draw_about(float y0, float h) {
  page_bg(y0, h, K_PAGE);
  tcn(F_H1, NW / 2.f, y0 + h / 2 - line_h(F_H1) / 2, "Version 0.1.0", K_TEXT);
}

static int hist_rows(int *idx, int cap) {
  int n = 0;
  for (int i = 0; i < nh && n < cap; i++) {
    if (S.hq[0]) {
      char a[1400], q[96];
      snprintf(a, sizeof a, "%.1023s %.159s", H[i].url, H[i].title);
      for (char *c = a; *c; c++) *c = (char)tolower((unsigned char)*c);
      snprintf(q, sizeof q, "%s", S.hq);
      for (char *c = q; *c; c++) *c = (char)tolower((unsigned char)*c);
      if (!strstr(a, q)) continue;
    }
    idx[n++] = i;
  }
  return n;
}

static void draw_history(float y0, float h) {
  page_bg(y0, h, THEME(RGB(248, 249, 250), RGB(32, 33, 38)));
  float cw = 760, cx = (NW - cw) / 2;
  clip(0, y0, NW, h);
  float y = y0 + 24 - S.hscroll;
  tx(F_H1, cx, y, "History", K_TEXT);
  float sw = 300, sx = cx + cw - sw - 150;
  rr(sx, y + 2, sw, 36, 18, S.hfocus ? K_CARD : K_OMNI);
  ic_search(sx + 20, y + 20, K_MUTED);
  tx(F_UI, sx + 38, y + 20 - line_h(F_UI) / 2, S.hq[0] ? S.hq : "Search history", S.hq[0] ? K_TEXT : K_MUTED);
  if (S.hfocus && S.blink) rc(sx + 38 + gfx_text_w(F_UI, S.hq), y + 10, 1.5f, 20, K_ACC);
  hit(Z_HSEARCH, sx, y + 2, sw, 36);
  float bx = cx + cw - 138;
  rr(bx, y + 2, 138, 36, 18, HOT == Z_HCLEAR ? K_ACC_SOFT : K_CARD);
  tcn(F_SMALL, bx + 69, y + 20 - line_h(F_SMALL) / 2, "Clear browsing data", K_ACC);
  hit(Z_HCLEAR, bx, y + 2, 138, 36);
  y += 64;
  static int idx[MAXH];
  int n = hist_rows(idx, MAXH);
  if (!n) {
    tcn(F_UI, NW / 2.f, y + 40, S.hq[0] ? "No search results found" : "Your browsing history will appear here", K_MUTED);
  }
  char lastday[40] = "";
  int open = 0;
  for (int k = 0; k < n; k++) {
    Hist *e = &H[idx[k]];
    time_t tt = (time_t)e->t;
    struct tm tmv;
    localtime_r(&tt, &tmv);
    char day[40], tm[16];
    strftime(day, sizeof day, "%A, %B %d, %Y", &tmv);
    strftime(tm, sizeof tm, "%H:%M", &tmv);
    if (strcmp(day, lastday)) {
      if (open) y += 16;
      snprintf(lastday, sizeof lastday, "%s", day);
      tx(F_UI_MED, cx + 4, y, day, K_TEXT);
      y += 32;
      open = 1;
    }
    if (y > y0 - 50 && y < y0 + h + 10) {
      rc(cx, y, cw, 44, K_CARD);
      if (HOT == Z_HROW + k) rc(cx, y, cw, 44, K_HOVER);
      tx(F_SMALL, cx + 16, y + 22 - line_h(F_SMALL) / 2, tm, K_MUTED);
      favicon(e->url, cx + 72, y + 14, 16, N_WEB);
      char host[300];
      url_host(e->url, host, sizeof host);
      float tw2 = gfx_text_w(F_UI, e->title[0] ? e->title : host);
      if (tw2 > cw - 330) tw2 = cw - 330;
      tf(F_UI, cx + 100, y + 22 - line_h(F_UI) / 2, cw - 330, e->title[0] ? e->title : host, K_TEXT);
      tf(F_SMALL, cx + 112 + tw2, y + 22 - line_h(F_SMALL) / 2, cw - 120 - tw2 - 16, host, K_MUTED);
      if (k < MAXH && Z_HROW + k < Z_HCLEAR && y + 44 > y0) hit(Z_HROW + k, cx, y < y0 ? y0 : y, cw, y < y0 ? 44 - (y0 - y) : 44);
    }
    y += 44;
  }
  S.content_h = y + S.hscroll - y0 + 40;
  gfx_clip(SF, OX, OY, NW, NH);
}

static void draw_status_page(float y0, float h) {
  page_bg(y0, h, K_PAGE);
  float cx = NW / 2.f, cy = y0 + h * 0.36f;
  if (E.st == E_START || E.st == E_OFF) {
    surf_logo(cx, cy, 40);
    spinner(cx, cy + 82, 12, K_ACC);
    tcn(F_UI, cx, cy + 112, "Starting Chromium...", K_MUTED);
    return;
  }
  surf_logo(cx, cy - 20, 36);
  const char *head = E.st == E_MISSING ? "Chromium is needed to browse" : "Surf couldn't start the browser engine";
  tcn(F_H1, cx, cy + 36, head, K_TEXT);
  if (E.st == E_MISSING) {
    tcn(F_UI, cx, cy + 86, "Surf uses Chromium under the hood. Install it from the Store (org.chromium.Chromium),", K_MUTED);
    tcn(F_UI, cx, cy + 110, "or run:  flatpak install flathub org.chromium.Chromium", K_MUTED);
    tcn(F_UI, cx, cy + 134, "or point OREONVR_CHROMIUM at a Chrome or Chromium binary.", K_MUTED);
  } else {
    tcn(F_UI, cx, cy + 86, E.err, K_MUTED);
    char l[800];
    snprintf(l, sizeof l, "Engine: %s", E.bin);
    tcn(F_SMALL, cx, cy + 112, l, K_MUTED);
  }
  float bw = 140, bx = cx - bw / 2, by = cy + 168;
  rr(bx, by, bw, 40, 20, HOT == Z_RETRY ? mixc(K_ACC, RGB(0, 0, 0), 0.12f) : K_ACC);
  tcn(F_UI_MED, cx, by + 20 - line_h(F_UI_MED) / 2, "Try again", g_dark ? RGB(20, 24, 32) : RGB(255, 255, 255));
  hit(Z_RETRY, bx, by, bw, 40);
}

static void draw_crashed(float y0, float h) {
  page_bg(y0, h, K_PAGE);
  float cx = NW / 2.f, cy = y0 + h * 0.38f;
  ring(cx, cy - 20, 30, 3, K_MUTED);
  dsc(cx - 10, cy - 26, 3, K_MUTED);
  dsc(cx + 10, cy - 26, 3, K_MUTED);
  arc(cx, cy - 2, 12, PI_F + 0.4f, 2 * PI_F - 0.4f, 2.4f, K_MUTED);
  tcn(F_H1, cx, cy + 30, "Aw, snap!", K_TEXT);
  tcn(F_UI, cx, cy + 74, "Something went wrong while displaying this page. Press reload to try again.", K_MUTED);
}

static void draw_pdf(Tab *t, float y0, float h);

static void draw_page(void) {
  float y0 = (float)page_y(), h = (float)page_h();
  Tab *t = cur();
  if (E.st != E_READY) {
    draw_status_page(y0, h);
    hit(Z_PAGE, 0, y0, NW, h);
    return;
  }
  hit(Z_PAGE, 0, y0, NW, h);
  if (!t) {
    page_bg(y0, h, K_PAGE);
    return;
  }
  if (t->native == N_NEWTAB) draw_ntp(y0, h);
  else if (t->native == N_HISTORY) draw_history(y0, h);
  else if (t->native == N_ABOUT) draw_about(y0, h);
  else if (t->native == N_PDF) draw_pdf(t, y0, h);
  else if (t->crashed) draw_crashed(y0, h);
  else if (t->fb) {
    page_bg(y0, h, RGB(255, 255, 255));
    float w = (float)t->fw, hh = (float)t->fh;
    if (w > NW - 0.5f && w < NW + 0.5f) w = NW;
    if (hh > h - 0.5f && hh < h + 0.5f) hh = h;
    float cr = S.dock ? 0 : RAD;
    clip(0, y0, NW, h - cr);
    gfx_blit_premul(SF, t->fb, t->fw, t->fh, OX, OY + y0, w, hh);
    for (int k = 0; k < (int)cr; k++) {
      float dy = cr - k - 0.5f, inset = cr - sqrtf(cr * cr - dy * dy) + 0.5f;
      clip(inset, y0 + h - cr + k, NW - 2 * inset, 1);
      gfx_blit_premul(SF, t->fb, t->fw, t->fh, OX, OY + y0, w, hh);
    }
    gfx_clip(SF, OX, OY, NW, NH);
  } else page_bg(y0, h, RGB(255, 255, 255));
  if (!t->native && t->loading && now_ms() - t->load_t0 > 250) {
    char host[300], b[360];
    url_host(t->url, host, sizeof host);
    snprintf(b, sizeof b, "Waiting for %s...", host[0] ? host : "page");
    float w = gfx_text_w(F_SMALL, b) + 20;
    rr(6, y0 + h - 30, w, 24, 6, THEME(RGB(242, 242, 242), RGB(50, 52, 58)));
    tx(F_SMALL, 16, y0 + h - 18 - line_h(F_SMALL) / 2, b, K_TEXT);
  }
}

static void draw_pdf(Tab *t, float y0, float h) {
  Pdf *f = t->pdf;
  uint32_t body = THEME(RGB(82, 86, 89), RGB(38, 40, 44)), bar = RGB(50, 54, 57), fg = RGB(241, 243, 244);
  page_bg(y0, h, body);
  hit(Z_PDF_BODY, 0, y0, NW, h);
  float vy = y0 + PDF_BAR, vh = h - PDF_BAR;
  if (f && f->state == 2) {
    float dw = pdf_scale(f), dh = dw * f->ph / f->pw, px = (NW - dw) / 2;
    clip(0, vy, NW, vh - RAD);
    for (int i = 0; i < f->n; i++) {
      float py = vy + PDF_GAP + i * (dh + PDF_GAP) - f->scroll;
      if (py > vy + vh || py + dh < vy) continue;
      gfx_shadow(SF, OX + px, OY + py + 2, dw, dh, 2, 8, RGBA(0, 0, 0, 90));
      rc(px, py, dw, dh, RGB(255, 255, 255));
      if (f->pg[i].px) gfx_blit_premul(SF, f->pg[i].px, f->pg[i].w, f->pg[i].h, OX + px, OY + py, dw, dh);
      else spinner(px + dw / 2, py + dh / 2, 14, RGB(150, 150, 150));
    }
    gfx_clip(SF, OX, OY, NW, NH);
    float total = f->n * (dh + PDF_GAP) + PDF_GAP;
    if (total > vh) {
      float th = vh * vh / total, ty = vy + (vh - th) * f->scroll / (total - vh);
      rr(NW - 12, ty + 4, 6, th - 8, 3, RGBA(255, 255, 255, 110));
    }
  } else if (f && f->state == -1) {
    tcn(F_H1, NW / 2.f, vy + vh * 0.35f, "Couldn't open this PDF", fg);
    tcn(F_UI, NW / 2.f, vy + vh * 0.35f + 48, "The file could not be downloaded or read. Surf's viewer uses poppler (pdfinfo, pdftoppm).", RGB(200, 204, 208));
  } else {
    spinner(NW / 2.f, vy + vh * 0.4f, 16, fg);
    tcn(F_UI, NW / 2.f, vy + vh * 0.4f + 34, "Loading PDF...", fg);
  }
  rc(0, y0, NW, PDF_BAR, bar);
  float cy = y0 + PDF_BAR / 2;
  rr(18, cy - 12, 20, 24, 3, RGB(234, 67, 53));
  tcn(F_SMALL, 28, cy - line_h(F_SMALL) / 2, "PDF", RGB(255, 255, 255));
  tf(F_UI_MED, 50, cy - line_h(F_UI_MED) / 2, 360, f && f->title[0] ? f->title : f ? f->name : "", fg);
  if (!f || f->state != 2) return;
  char pb[40];
  snprintf(pb, sizeof pb, "%d  /  %d", f->cur + 1, f->n);
  float pw = gfx_text_w(F_UI, pb) + 32;
  rr(NW / 2.f - pw / 2, cy - 16, pw, 32, 16, RGB(32, 33, 36));
  tcn(F_UI, NW / 2.f, cy - line_h(F_UI) / 2, pb, fg);
  float bx = NW - 300;
  const int Z[] = {Z_PDF_ZOUT, Z_PDF_ZIN, Z_PDF_FIT, Z_PDF_DL};
  float X[] = {bx, bx + 110, bx + 170, bx + 230};
  for (int k = 0; k < 4; k++) {
    if (HOT == Z[k]) dsc(X[k], cy, 20, RGBA(255, 255, 255, 40));
    hit(Z[k], X[k] - 21, cy - 21, 42, 42);
  }
  ln(bx - 7, cy, bx + 7, cy, 2, fg);
  char zb[16];
  snprintf(zb, sizeof zb, "%d%%", (int)(f->zoom * 100 + 0.5f));
  tcn(F_UI, bx + 55, cy - line_h(F_UI) / 2, zb, fg);
  ln(bx + 103, cy, bx + 117, cy, 2, fg);
  ln(bx + 110, cy - 7, bx + 110, cy + 7, 2, fg);
  rr(bx + 160, cy - 10, 20, 20, 3, f->fit ? RGB(138, 180, 248) : fg);
  rr(bx + 162, cy - 8, 16, 16, 2, bar);
  ln(bx + 164, cy, bx + 176, cy, 1.6f, f->fit ? RGB(138, 180, 248) : fg);
  ln(bx + 230, cy - 9, bx + 230, cy + 4, 2, fg);
  ln(bx + 230, cy + 4, bx + 224, cy - 2, 2, fg);
  ln(bx + 230, cy + 4, bx + 236, cy - 2, 2, fg);
  ln(bx + 222, cy + 10, bx + 238, cy + 10, 2, fg);
}

static void draw_dock(void) {
  if (!S.dock) return;
  float y = (float)dock_y();
  rc(0, y, NW, DOCKH - RAD, K_BAR);
  rr(0, NH - 2 * RAD, NW, 2 * RAD, RAD, K_BAR);
  rc(0, y, NW, 1, K_LINE);
  hit(Z_DOCK_BODY, 0, y, NW, DOCKH);
  const char *lab[2] = {"Developer tools", "Console"};
  float x = 14;
  for (int k = 0; k < 2; k++) {
    float w = gfx_text_w(F_UI, lab[k]) + 32;
    int z = k ? Z_DOCK_CON : Z_DOCK_DT, on = S.dock == k + 1;
    rr(x, y + 6, w, DOCK_HEAD - 12, (DOCK_HEAD - 12) / 2.f, on ? K_ACC_SOFT : HOT == z ? K_TAB_HOT : 0);
    tcn(F_UI, x + w / 2, y + DOCK_HEAD / 2.f - line_h(F_UI) / 2, lab[k], on ? K_ACC : K_MUTED);
    hit(z, x, y + 6, w, DOCK_HEAD - 12);
    x += w + 8;
  }
  float cx = NW - 30, cy = y + DOCK_HEAD / 2.f;
  if (HOT == Z_DOCKX) dsc(cx, cy, 16, K_HOVER);
  ic_x(cx, cy, 5, 1.7f, K_ICON);
  hit(Z_DOCKX, cx - 18, cy - 18, 36, 36);
  float by = y + DOCK_HEAD, bh = DOCKH - DOCK_HEAD;
  Tab *t = cur();
  if (S.dock == 1) {
    if (DT && DT->fb) {
      clip(0, by, NW, bh - RAD);
      gfx_blit_premul(SF, DT->fb, DT->fw, DT->fh, OX, OY + by, (float)DT->fw, (float)DT->fh);
      clip(RAD, by, NW - 2 * RAD, bh);
      gfx_blit_premul(SF, DT->fb, DT->fw, DT->fh, OX, OY + by, (float)DT->fw, (float)DT->fh);
      gfx_clip(SF, OX, OY, NW, NH);
      if (S.kfocus == 1) rc(0, by, NW, 2, K_ACC);
    } else if (!t || t->native) tcn(F_UI, NW / 2.f, by + bh / 2 - 10, "Open a web page to inspect it with the developer tools", K_MUTED);
    else {
      spinner(NW / 2.f, by + bh / 2 - 20, 12, K_ACC);
      tcn(F_UI, NW / 2.f, by + bh / 2 + 6, "Loading Chromium developer tools...", K_MUTED);
    }
    return;
  }
  float cbx = x + 8, cw = gfx_text_w(F_SMALL, "Clear") + 26;
  rr(cbx, y + 9, cw, DOCK_HEAD - 18, (DOCK_HEAD - 18) / 2.f, HOT == Z_CON_CLEAR ? K_OMNI_HOT : K_OMNI);
  tcn(F_SMALL, cbx + cw / 2, cy - line_h(F_SMALL) / 2, "Clear", K_TEXT);
  hit(Z_CON_CLEAR, cbx, y + 9, cw, DOCK_HEAD - 18);
  float ih = 40, iy = NH - ih - 10, lh = line_h(F_MONO) + 8;
  rc(0, by, NW, 1, K_LINE);
  clip(0, by + 1, NW, iy - by - 4);
  float ry = iy - 6;
  int n = t && t->con ? t->ncon : 0;
  for (int i = n - 1 - S.con_scroll; i >= 0 && ry > by; i--) {
    Con *c = &t->con[i];
    ry -= lh;
    uint32_t bg = 0, fgc = K_TEXT;
    const char *pre = "  ";
    if (c->lvl == 'e') bg = THEME(RGB(253, 236, 236), RGB(74, 36, 36)), fgc = THEME(RGB(197, 34, 31), RGB(255, 138, 128)), pre = "x ";
    else if (c->lvl == 'w') bg = THEME(RGB(254, 247, 224), RGB(70, 58, 24)), fgc = THEME(RGB(142, 92, 0), RGB(253, 214, 99)), pre = "! ";
    else if (c->lvl == 'i') fgc = K_ACC, pre = "> ";
    else if (c->lvl == 'r') fgc = K_MUTED, pre = "< ";
    else if (c->lvl == 'n') fgc = K_MUTED, pre = "~ ";
    if (bg) rc(0, ry, NW, lh, bg);
    rc(0, ry + lh - 1, NW, 1, K_LINE);
    char b[260];
    snprintf(b, sizeof b, "%s%s%s", pre, c->lvl == 'n' ? "Navigated to " : "", c->text);
    tf(F_MONO, 16, ry + 4, NW - 32, b, fgc);
  }
  if (!n) tcn(F_UI, NW / 2.f, by + 40, t && !t->native ? "Console messages from this page will appear here" : "Open a web page to use the console", K_MUTED);
  gfx_clip(SF, OX, OY, NW, NH);
  rr(10, iy, NW - 20, ih, ih / 2, S.kfocus == 2 ? K_CARD : K_OMNI);
  if (S.kfocus == 2) rr(10, iy + ih - 2, NW - 20, 2, 1, K_ACC);
  tx(F_MONO, 26, iy + ih / 2 - line_h(F_MONO) / 2, ">", K_ACC);
  tx(F_MONO, 46, iy + ih / 2 - line_h(F_MONO) / 2, S.con_in[0] || S.kfocus == 2 ? S.con_in : "Run JavaScript in this page", S.con_in[0] ? K_TEXT : K_MUTED);
  if (S.kfocus == 2 && S.blink) rc(46 + gfx_text_w(F_MONO, S.con_in), iy + 10, 1.5f, ih - 20, K_ACC);
  hit(Z_CON_IN, 10, iy, NW - 20, ih);
}

static void draw_sedit(void) {
  if (!S.sedit) return;
  hit(Z_BLOCK, 0, 0, NW, NH);
  rc(0, 0, NW, NH, RGBA(0, 0, 0, 60));
  float w = 520, h = 330, x = (NW - w) / 2, y = (NH - h) / 2;
  gfx_shadow(SF, OX + x, OY + y + 6, w, h, 24, 24, RGBA(0, 0, 0, 90));
  rr(x, y, w, h, 24, K_CARD);
  tx(F_H1, x + 32, y + 26, S.sedit > 0 ? "Edit shortcut" : "Add shortcut", K_TEXT);
  const char *lab[2] = {"Name", "URL"};
  char *val[2] = {S.se_name, S.se_url};
  for (int k = 0; k < 2; k++) {
    float fy = y + 88 + k * 84;
    tx(F_SMALL, x + 32, fy, lab[k], K_MUTED);
    rr(x + 32, fy + 22, w - 64, 46, 12, K_OMNI);
    if (S.se_focus == k) rr(x + 32, fy + 66, w - 64, 2, 1, K_ACC);
    tf(F_UI, x + 48, fy + 45 - line_h(F_UI) / 2, w - 96, val[k], K_TEXT);
    if (S.se_focus == k && S.blink) rc(x + 48 + gfx_text_w(F_UI, val[k]), fy + 33, 1.5f, 24, K_ACC);
    hit(k ? Z_SE_URL : Z_SE_NAME, x + 32, fy + 22, w - 64, 46);
  }
  float by = y + h - 68;
  float bx = x + w - 32 - 110;
  rr(bx, by, 110, 44, 22, HOT == Z_SE_DONE ? mixc(K_ACC, RGB(0, 0, 0), 0.12f) : K_ACC);
  tcn(F_UI_MED, bx + 55, by + 22 - line_h(F_UI_MED) / 2, "Done", g_dark ? RGB(20, 24, 32) : RGB(255, 255, 255));
  hit(Z_SE_DONE, bx, by, 110, 44);
  bx -= 122;
  rr(bx, by, 110, 44, 22, HOT == Z_SE_CANCEL ? K_OMNI_HOT : K_OMNI);
  tcn(F_UI_MED, bx + 55, by + 22 - line_h(F_UI_MED) / 2, "Cancel", K_TEXT);
  hit(Z_SE_CANCEL, bx, by, 110, 44);
  if (S.sedit > 0) {
    rr(x + 32, by, 110, 44, 22, HOT == Z_SE_REMOVE ? THEME(RGB(252, 232, 230), RGB(80, 40, 40)) : 0);
    tcn(F_UI_MED, x + 87, by + 22 - line_h(F_UI_MED) / 2, "Remove", K_WARN);
    hit(Z_SE_REMOVE, x + 32, by, 110, 44);
  }
}

static void draw_sugs(void) {
  if (!S.omni || !S.nsug) return;
  float ox = 220, ow = NW - ox - 76, y = TS + TBH / 2.f - 23;
  float rh = 46, hh = 46 + S.nsug * rh + 12;
  gfx_shadow(SF, OX + ox, OY + y + 4, ow, hh, 18, 16, RGBA(0, 0, 0, g_dark ? 110 : 50));
  rr(ox, y, ow, hh, 18, K_CARD);
  draw_omni_text(ox + 46, y + 23, ow - 90);
  ic_search(ox + 24, y + 23, K_MUTED);
  rc(ox + 16, y + 46, ow - 32, 1, K_LINE);
  hit(Z_BLOCK, ox, y, ow, 46);
  for (int i = 0; i < S.nsug; i++) {
    float ry = y + 52 + i * rh;
    if (i == S.sug_sel) rc(ox, ry, ow, rh, K_OMNI_HOT);
    else if (HOT == Z_SUG + i) rc(ox, ry, ow, rh, K_HOVER);
    float cy = ry + rh / 2;
    if (S.sug_kind[i] == 0) ic_search(ox + 22, cy, K_MUTED);
    else if (S.sug_kind[i] == 1) ic_globe(ox + 22, cy, K_MUTED);
    else favicon(S.sug[i], ox + 14, cy - 8, 16, N_WEB);
    float x = ox + 46;
    if (S.sug_kind[i] == 0) {
      float w = gfx_text_w(F_UI, S.sug_title[i]);
      if (w > ow - 280) w = ow - 280;
      tf(F_UI, x, cy - line_h(F_UI) / 2, ow - 280, S.sug_title[i], K_TEXT);
      tx(F_UI, x + w, cy - line_h(F_UI) / 2, " - Search", K_MUTED);
    } else if (S.sug_kind[i] == 1) {
      char pu[1024];
      pretty_url(S.sug[i], pu, sizeof pu);
      tf(F_UI, x, cy - line_h(F_UI) / 2, ow - 80, pu, K_ACC);
    } else {
      float w = gfx_text_w(F_UI, S.sug_title[i]);
      if (w > ow * 0.55f) w = ow * 0.55f;
      tf(F_UI, x, cy - line_h(F_UI) / 2, ow * 0.55f, S.sug_title[i], K_TEXT);
      char pu[1024];
      pretty_url(S.sug[i], pu, sizeof pu);
      tx(F_UI, x + w, cy - line_h(F_UI) / 2, " - ", K_MUTED);
      tf(F_UI, x + w + gfx_text_w(F_UI, " - "), cy - line_h(F_UI) / 2, ow - (x - ox) - w - 40, pu, K_ACC);
    }
    hit(Z_SUG + i, ox, ry, ow, rh);
  }
}

static const char *MENU_LABEL[M_COUNT] = {"New tab", "Reopen closed tab", "History", "Show bookmarks bar", "", "", "",
                                          "Developer tools", "JavaScript console", "Clear browsing data", "About Surf"};
static const char *MENU_KEYS[M_COUNT] = {"Ctrl+T", "Ctrl+Shift+T", "Ctrl+H", "Ctrl+Shift+B", "", "", "", "Ctrl+Shift+I", "Ctrl+Shift+J", "", ""};

static void draw_menu(void) {
  if (!S.menu) return;
  float w = 360, x = NW - w - 12, y = TS + TBH - 6, rh = 44;
  float h = 12 + (M_COUNT - 2) * rh + 4 * 9 + 12;
  hit(Z_BLOCK, 0, 0, NW, NH);
  gfx_shadow(SF, OX + x, OY + y + 4, w, h, 10, 18, RGBA(0, 0, 0, g_dark ? 120 : 56));
  rr(x, y, w, h, 18, K_CARD);
  float cy = y + 12;
  for (int i = 0; i < M_COUNT; i++) {
    if (i == M_ZOOM_IN || i == M_ZOOM_RESET) continue;
    if (i == M_HISTORY + 1 || i == M_ZOOM_OUT || i == M_DEVTOOLS || i == M_CLEAR) rc(x, cy + 4, w, 1, K_LINE), cy += 9;
    if (i == M_ZOOM_OUT) {
      Tab *t = cur();
      tx(F_UI, x + 20, cy + rh / 2 - line_h(F_UI) / 2, "Zoom", K_TEXT);
      float bx = x + w - 156;
      for (int k = 0; k < 3; k++) {
        int z = Z_MI + M_ZOOM_OUT + k;
        float bxx = k == 0 ? bx : k == 1 ? bx + 38 : bx + 106;
        float bw = k == 1 ? 64 : 34;
        if (HOT == z) rr(bxx, cy + 2, bw, rh - 4, 8, K_HOVER);
        hit(z, bxx, cy + 2, bw, rh - 4);
      }
      ln(bx + 11, cy + rh / 2, bx + 23, cy + rh / 2, 1.7f, K_ICON);
      char zb[16];
      snprintf(zb, sizeof zb, "%d%%", t ? (int)(ZOOMS[t->zoom] * 100 + 0.5f) : 100);
      tcn(F_UI, bx + 70, cy + rh / 2 - line_h(F_UI) / 2, zb, K_TEXT);
      ln(bx + 117, cy + rh / 2, bx + 129, cy + rh / 2, 1.7f, K_ICON);
      ln(bx + 123, cy + rh / 2 - 6, bx + 123, cy + rh / 2 + 6, 1.7f, K_ICON);
      cy += rh;
      continue;
    }
    int z = Z_MI + i;
    int disabled = i == M_REOPEN && !nclosed;
    if (HOT == z && !disabled) rc(x, cy, w, rh, K_HOVER);
    tx(F_UI, x + 20, cy + rh / 2 - line_h(F_UI) / 2, MENU_LABEL[i], disabled ? K_DIM : K_TEXT);
    if ((i == M_BBAR && S.bbar) || (i == M_DEVTOOLS && S.dock == 1) || (i == M_CONSOLE && S.dock == 2)) {
      ln(x + w - 34, cy + rh / 2, x + w - 29, cy + rh / 2 + 5, 2, K_ACC);
      ln(x + w - 29, cy + rh / 2 + 5, x + w - 20, cy + rh / 2 - 5, 2, K_ACC);
    } else if (MENU_KEYS[i][0]) {
      float kw = gfx_text_w(F_SMALL, MENU_KEYS[i]);
      tx(F_SMALL, x + w - 20 - kw, cy + rh / 2 - line_h(F_SMALL) / 2, MENU_KEYS[i], K_MUTED);
    }
    hit(z, x, cy, w, rh);
    cy += rh;
  }
}

static const char *CTX_LABEL[] = {"Open link in new tab", "Open image in new tab", "Search Google for selection", "Back", "Forward", "Reload", "View page source", "Inspect",
                                   "Pin", "Unpin", "Duplicate", "Close tab", "Close other tabs"};

static void draw_ctx(void) {
  if (!S.ctx) return;
  float w = 300, rh = 42, h = S.nctx * rh + 16 + 9;
  float x = S.ctx_x, y = S.ctx_y;
  if (x + w > NW - 8) x = NW - 8 - w;
  if (y + h > NH - 8) y = NH - 8 - h;
  hit(Z_BLOCK, 0, 0, NW, NH);
  gfx_shadow(SF, OX + x, OY + y + 3, w, h, 8, 14, RGBA(0, 0, 0, g_dark ? 120 : 56));
  rr(x, y, w, h, 16, K_CARD);
  float cy = y + 8;
  Tab *t = cur();
  for (int i = 0; i < S.nctx; i++) {
    int it = S.ctx_items[i];
    if ((it == C_BACK || it == C_DUP) && i) rc(x, cy + 4, w, 1, K_LINE), cy += 9;
    int dis = (it == C_BACK && (!t || t->back_id < 0)) || (it == C_FWD && (!t || t->fwd_id < 0));
    if (HOT == Z_CTX + i && !dis) rc(x, cy, w, rh, K_HOVER);
    if (it == C_SEARCH) {
      char b[260];
      snprintf(b, sizeof b, "Search Google for \"%.40s%s\"", S.ctx_sel, strlen(S.ctx_sel) > 40 ? "..." : "");
      tf(F_UI, x + 18, cy + rh / 2 - line_h(F_UI) / 2, w - 30, b, K_TEXT);
    } else tx(F_UI, x + 18, cy + rh / 2 - line_h(F_UI) / 2, CTX_LABEL[it], dis ? K_DIM : K_TEXT);
    hit(Z_CTX + i, x, cy, w, rh);
    cy += rh;
  }
}

static void draw_dialog(void) {
  if (!S.dlg) return;
  Tab *t = cur();
  hit(Z_BLOCK, 0, 0, NW, NH);
  rc(0, page_y(), NW, page_h(), RGBA(0, 0, 0, 40));
  float w = 460, x = (NW - w) / 2, y = page_y() + 8;
  char host[300], head[360];
  url_host(t ? t->url : "", host, sizeof host);
  snprintf(head, sizeof head, "%s says", host[0] ? host : "This page");
  float h = 150 + (S.dlg_type == 2 ? 50 : 0);
  gfx_shadow(SF, OX + x, OY + y + 6, w, h, 10, 20, RGBA(0, 0, 0, 70));
  rr(x, y, w, h, 10, K_CARD);
  tx(F_UI_MED, x + 24, y + 22, head, K_TEXT);
  tf(F_UI, x + 24, y + 56, w - 48, S.dlg_msg, K_TEXT);
  float by = y + h - 56;
  if (S.dlg_type == 2) {
    rr(x + 24, by - 50, w - 48, 36, 6, K_ACC);
    rr(x + 25.5f, by - 48.5f, w - 51, 33, 5, K_CARD);
    tx(F_UI, x + 36, by - 32 - line_h(F_UI) / 2, S.dlg_in, K_TEXT);
    if (S.blink) rc(x + 36 + gfx_text_w(F_UI, S.dlg_in), by - 42, 1.5f, 20, K_ACC);
  }
  float bx = x + w - 24 - 90;
  rr(bx, by, 90, 36, 18, HOT == Z_DLG_OK ? mixc(K_ACC, RGB(0, 0, 0), 0.12f) : K_ACC);
  tcn(F_UI_MED, bx + 45, by + 18 - line_h(F_UI_MED) / 2, "OK", g_dark ? RGB(20, 24, 32) : RGB(255, 255, 255));
  hit(Z_DLG_OK, bx, by, 90, 36);
  if (S.dlg_type) {
    bx -= 100;
    rr(bx, by, 90, 36, 18, HOT == Z_DLG_NO ? K_ACC_SOFT : K_CARD);
    tcn(F_UI_MED, bx + 45, by + 18 - line_h(F_UI_MED) / 2, "Cancel", K_ACC);
    hit(Z_DLG_NO, bx, by, 90, 36);
  }
}

static void draw_toast(void) {
  if (!S.toast[0]) return;
  float w = gfx_text_w(F_UI, S.toast) + 40, x = (NW - w) / 2, y = NH - 64;
  rr(x, y, w, 40, 8, THEME(RGB(48, 49, 52), RGB(232, 234, 237)));
  tcn(F_UI, NW / 2.f, y + 20 - line_h(F_UI) / 2, S.toast, THEME(RGB(255, 255, 255), RGB(32, 33, 36)));
}

static void draw_zoom_pop(void) {
  if (!S.zoom_pop) return;
  Tab *t = cur();
  if (!t) return;
  char b[40];
  snprintf(b, sizeof b, "Zoom: %d%%", (int)(ZOOMS[t->zoom] * 100 + 0.5f));
  float w = 150, x = NW - w - 70, y = TS + TBH - 2;
  gfx_shadow(SF, OX + x, OY + y + 3, w, 44, 8, 12, RGBA(0, 0, 0, 50));
  rr(x, y, w, 44, 8, K_CARD);
  tcn(F_UI, x + w / 2, y + 22 - line_h(F_UI) / 2, b, K_TEXT);
}

static void surf_draw(Panel *p, Surface *s, float ox, float oy) {
  SF = s, OX = ox, OY = oy, S.panel = (int)(p - P);
  HOT = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  img_frame();
  nhr = 0;
  rr(0, 0, NW, NH, RAD, K_BAR);
  draw_page();
  draw_tabs();
  draw_toolbar();
  if (S.bbar) draw_bbar();
  rc(0, page_y() - 1, NW, 1, K_LINE);
  draw_dock();
  draw_sugs();
  draw_menu();
  draw_ctx();
  draw_sedit();
  draw_dialog();
  draw_zoom_pop();
  draw_toast();
}

static int surf_zone(Panel *p, float x, float y) {
  (void)p;
  S.mx = x, S.my = y, S.mover = 1;
  for (int i = nhr - 1; i >= 0; i--)
    if (x >= HR[i].x && x < HR[i].x + HR[i].w && y >= HR[i].y && y < HR[i].y + HR[i].h) return HR[i].z;
  return 0;
}

static void move_tab(int from, int to) {
  if (from < 0 || from >= ntab) return;
  if (to < 0) to = 0;
  if (to >= ntab) to = ntab - 1;
  Tab *a = cur(), *t = TB[from];
  memmove(&TB[from], &TB[from + 1], sizeof(Tab *) * (size_t)(ntab - from - 1));
  memmove(&TB[to + 1], &TB[to], sizeof(Tab *) * (size_t)(ntab - 1 - to));
  TB[to] = t;
  for (int i = 0; i < ntab; i++)
    if (TB[i] == a) act = i;
}

static void pin_tab(int i, int on) {
  if (i < 0 || i >= ntab) return;
  Tab *t = TB[i];
  t->pinned = on;
  int np = npinned();
  move_tab(i, on ? np - 1 : np);
  save_pinned();
  dirty();
}

static void open_tab_ctx(int i, float x, float y) {
  Tab *t = TB[i];
  int n = 0;
  S.ctx_items[n++] = t->pinned ? C_UNPIN : C_PIN;
  S.ctx_items[n++] = C_DUP, S.ctx_items[n++] = C_CLOSETAB, S.ctx_items[n++] = C_CLOSEOTHERS;
  S.nctx = n, S.ctx = 1, S.ctx_tab = i, S.ctx_x = x, S.ctx_y = y;
  S.menu = 0;
  dirty();
}

static void sedit_open(int i) {
  S.sedit = i < 0 ? -1 : i + 1, S.se_focus = 0, S.blink = 1, S.blink_t = now_ms();
  if (i >= 0) {
    snprintf(S.se_name, sizeof S.se_name, "%s", SCL[i].name);
    snprintf(S.se_url, sizeof S.se_url, "%s", SCL[i].url);
  } else S.se_name[0] = S.se_url[0] = 0;
  office_show_keyboard();
}

static void sedit_done(int remove) {
  int i = S.sedit - 1;
  if (remove && i >= 0 && i < nsc) {
    memmove(&SCL[i], &SCL[i + 1], sizeof(Short) * (size_t)(nsc - i - 1));
    nsc--;
  } else if (!remove && S.se_url[0]) {
    char u[1024];
    fixup(S.se_url, u, sizeof u);
    if (i < 0) {
      if (nsc >= MAXSC) return;
      i = nsc++;
    }
    snprintf(SCL[i].url, sizeof SCL[i].url, "%.599s", u);
    if (S.se_name[0]) snprintf(SCL[i].name, sizeof SCL[i].name, "%s", S.se_name);
    else {
      char h[300];
      url_host(u, h, sizeof h);
      snprintf(SCL[i].name, sizeof SCL[i].name, "%.59s", !strncmp(h, "www.", 4) ? h + 4 : h);
    }
    clean_field(SCL[i].name);
  } else if (!remove) return;
  S.sedit = 0;
  save_sc();
  dirty();
}

static void set_dock(int d) {
  if (S.dock == d) d = 0;
  int was = S.dock;
  S.dock = d;
  if (d != 1) close_devtools();
  S.kfocus = d == 2 ? 2 : d == 1 ? 1 : 0;
  if (!was != !d) relayout();
  if (d == 1) open_devtools();
  if (d == 2) office_show_keyboard();
  dirty();
}

static void con_eval(void) {
  Tab *t = cur();
  if (!S.con_in[0]) return;
  if (!t || t->native || !t->attached) {
    toast("Open a web page to run JavaScript");
    return;
  }
  con_add(t, 'i', S.con_in);
  char p[1400];
  snprintf(p, sizeof p, "{\"expression\":%s,\"replMode\":true,\"includeCommandLineAPI\":true,\"userGesture\":true}", js(S.con_in));
  cdp(t->sid, R_EVAL, t->tid, "Runtime.evaluate", p);
  snprintf(S.con_last, sizeof S.con_last, "%s", S.con_in);
  S.con_in[0] = 0, S.con_scroll = 0;
}

static int line_edit(char *b, int cap, int code, int mods) {
  int l = (int)strlen(b);
  char c[8];
  if (code == KEY_BACKSPACE) {
    if (l) b[l - 1] = 0;
    return 1;
  }
  if ((mods & (MOD_CTRL | MOD_ALT)) || key_to_bytes(code, mods, c) != 1 || (unsigned char)c[0] < 32 || c[0] == 127) return 0;
  if (l < cap - 1) b[l] = c[0], b[l + 1] = 0;
  return 1;
}

static void open_url_new(const char *u) {
  Tab *t = cur();
  new_tab(u, N_WEB, 1, t ? act : -1);
}

static void dialog_close(int accept) {
  Tab *t = cur();
  char p[600];
  snprintf(p, sizeof p, "{\"accept\":%s,\"promptText\":%s}", accept ? "true" : "false", js(S.dlg_in));
  if (t) cdp(t->sid, 0, NULL, "Page.handleJavaScriptDialog", p);
  S.dlg = 0;
}

static void clear_data(void) {
  nh = 0;
  save_hist();
  cdp(NULL, 0, NULL, "Storage.clearDataForOrigin", "{\"origin\":\"*\",\"storageTypes\":\"all\"}");
  Tab *t = cur();
  if (t && t->attached) {
    cdp(t->sid, 0, NULL, "Network.clearBrowserCache", NULL);
    cdp(t->sid, 0, NULL, "Network.clearBrowserCookies", NULL);
  }
  toast("Browsing data cleared");
}

static void menu_action(int i) {
  S.menu = 0;
  Tab *t = cur();
  switch (i) {
  case M_NEWTAB: new_tab(NULL, N_NEWTAB, 1, -1); break;
  case M_DEVTOOLS: set_dock(1); break;
  case M_CONSOLE: set_dock(2); break;
  case M_REOPEN:
    if (nclosed) new_tab(closed[--nclosed], N_WEB, 1, -1);
    break;
  case M_HISTORY:
    if (t && t->native) navigate("surf://history");
    else new_tab(NULL, N_HISTORY, 1, act);
    S.hscroll = 0;
    break;
  case M_BBAR:
    S.bbar = !S.bbar;
    save_prefs();
    relayout();
    break;
  case M_ZOOM_OUT: zoom(-1), S.menu = 1; break;
  case M_ZOOM_RESET: zoom(0), S.menu = 1; break;
  case M_ZOOM_IN: zoom(1), S.menu = 1; break;
  case M_CLEAR: clear_data(); break;
  case M_ABOUT:
    if (t && (t->native == N_NEWTAB || t->native == N_ABOUT)) navigate("surf://about");
    else new_tab(NULL, N_ABOUT, 1, act);
    break;
  }
}

static void ctx_action(int it, int arg) {
  S.ctx = 0;
  char u[1024];
  int ti = S.ctx_tab;
  switch (it) {
  case C_INSPECT:
    if (S.dock != 1) set_dock(1);
    break;
  case C_PIN: pin_tab(ti, 1); break;
  case C_UNPIN: pin_tab(ti, 0); break;
  case C_DUP:
    if (ti >= 0 && ti < ntab) new_tab_x(TB[ti]->native ? NULL : TB[ti]->url, TB[ti]->native == N_HISTORY ? N_HISTORY : TB[ti]->native ? N_NEWTAB : N_WEB, 1, ti, 0, 0);
    break;
  case C_CLOSETAB: close_tab(ti); break;
  case C_CLOSEOTHERS:
    for (int i = ntab - 1; i >= 0; i--)
      if (i != ti && !TB[i]->pinned) {
        if (i < ti) ti--;
        close_tab(i);
      }
    break;
  case C_OPEN_LINK: open_url_new(S.ctx_link); break;
  case C_OPEN_IMG: open_url_new(S.ctx_img); break;
  case C_SEARCH:
    search_url(S.ctx_sel, u, sizeof u);
    open_url_new(u);
    break;
  case C_BACK: go_hist(-1); break;
  case C_FWD: go_hist(1); break;
  case C_RELOAD: reload(0); break;
  case C_SOURCE: {
    Tab *t = cur();
    if (t && !t->native) {
      snprintf(u, sizeof u, "view-source:%.1000s", t->url);
      open_url_new(u);
    }
    break;
  }
  }
}

static void action(Panel *p, int z) {
  if (z >= Z_TABX && z < Z_TABX + MAXT) close_tab(z - Z_TABX);
  else if (z >= Z_TAB && z < Z_TAB + MAXT) close_omni(), activate(z - Z_TAB);
  else if (z == Z_NEWTAB) new_tab(NULL, N_NEWTAB, 1, -1);
  else if (z == Z_WINX) panel_close((int)(p - P));
  else if (z == Z_BACK) go_hist(-1);
  else if (z == Z_FWD) go_hist(1);
  else if (z == Z_RELOAD) reload(input_mods() & MOD_SHIFT);
  else if (z == Z_HOMEB) navigate("about:blank");
  else if (z == Z_OMNI) {
    if (!S.omni) focus_omni();
  } else if (z == Z_STAR) toggle_mark();
  else if (z == Z_MENU) S.menu = !S.menu, close_omni();
  else if (z == Z_ZOOMB) zoom(0);
  else if (z >= Z_BM && z < Z_BM + MAXB) navigate(BM[z - Z_BM].url);
  else if (z >= Z_SUG && z < Z_SUG + 8) S.sug_sel = z - Z_SUG, omni_go();
  else if (z >= Z_MI && z < Z_MI + M_COUNT) menu_action(z - Z_MI);
  else if (z >= Z_CTX && z < Z_CTX + 16) ctx_action(S.ctx_items[z - Z_CTX], S.ctx_args[z - Z_CTX]);
  else if (z >= Z_SC_EDIT && z < Z_SC_EDIT + MAXSC) sedit_open(z - Z_SC_EDIT);
  else if (z == Z_SC_ADD) sedit_open(-1);
  else if (z == Z_SE_NAME || z == Z_SE_URL) S.se_focus = z == Z_SE_URL;
  else if (z == Z_SE_DONE) sedit_done(0);
  else if (z == Z_SE_CANCEL) S.sedit = 0;
  else if (z == Z_SE_REMOVE) sedit_done(1);
  else if (z >= Z_REC && z < Z_REC + 3) {
    int rec[3], nr = recent(rec, 3);
    if (z - Z_REC < nr) navigate(H[rec[z - Z_REC]].url);
  } else if (z == Z_DOCKX) set_dock(S.dock);
  else if (z == Z_DOCK_DT) {
    if (S.dock != 1) set_dock(1);
  } else if (z == Z_DOCK_CON) {
    if (S.dock != 2) set_dock(2);
  } else if (z == Z_CON_CLEAR) {
    Tab *t = cur();
    if (t) t->ncon = 0;
  } else if (z == Z_CON_IN) S.kfocus = 2, office_show_keyboard();
  else if (z >= Z_PDF_ZOUT && z <= Z_PDF_DL) {
    Tab *t = cur();
    Pdf *f = t ? t->pdf : NULL;
    if (z == Z_PDF_ZOUT) pdf_zoom(f, -1);
    else if (z == Z_PDF_ZIN) pdf_zoom(f, 1);
    else if (z == Z_PDF_FIT) pdf_zoom(f, 0);
    else pdf_save(f);
  }
  else if (z == Z_DLG_OK) dialog_close(1);
  else if (z == Z_DLG_NO) dialog_close(0);
  else if (z == Z_FAKEBOX) focus_omni();
  else if (z >= Z_TILE && z < Z_TILE + 8) {
    char name[160], url[600];
    if (shortcut(z - Z_TILE, name, sizeof name, url, sizeof url)) navigate(url);
  } else if (z == Z_RETRY) restart_engine();
  else if (z == Z_HCLEAR) clear_data();
  else if (z == Z_HSEARCH) S.hfocus = 1, office_show_keyboard();
  else if (z >= Z_HROW && z < Z_HCLEAR) {
    static int idx[MAXH];
    int n = hist_rows(idx, MAXH), k = z - Z_HROW;
    if (k < n) navigate(H[idx[k]].url);
  }
}

static int on_web_page(int z) {
  Tab *t = cur();
  if (z == Z_DOCK_BODY && S.dock == 1 && DT && DT->attached && S.my >= dock_y() + DOCK_HEAD) return 1;
  return z == Z_PAGE && E.st == E_READY && t && !t->native && !t->crashed;
}

static void surf_press(Panel *p, float x, float y, int button, int down) {
  S.panel = (int)(p - P);
  int z = surf_zone(p, x, y);
  p->dirty = 1;
  const char *bn = button == 1 ? "left" : button == 3 ? "right" : "middle";
  int bm = button == 1 ? 1 : button == 3 ? 2 : 4;
  if (down) {
    S.press = z;
    if (z == Z_DRAG && button == 1) {
      input_begin_drag(S.panel);
      return;
    }
    if (S.menu && z != Z_BLOCK && !(z >= Z_MI && z < Z_MI + M_COUNT) && z != Z_MENU) S.menu = 0;
    if (S.ctx && !(z >= Z_CTX && z < Z_CTX + 16)) S.ctx = 0;
    if (S.dock && (z == Z_DOCK_BODY || z == Z_PAGE)) S.kfocus = z == Z_PAGE ? 0 : S.dock == 1 ? 1 : S.kfocus;
    if (S.omni && z != Z_OMNI && z != Z_BLOCK && !(z >= Z_SUG && z < Z_SUG + 8)) close_omni();
    if (z != Z_HSEARCH) S.hfocus = 0;
    if (on_web_page(z) && !S.dlg) {
      uint32_t now = now_ms();
      if (now - S.click_t < 450 && fabsf(x - S.last_cx) < 6 && fabsf(y - S.last_cy) < 6) S.clicks++;
      else S.clicks = 1;
      S.click_t = now, S.last_cx = x, S.last_cy = y;
      S.mdown |= bm;
      page_mouse("mousePressed", x, y, bn, S.mdown, S.clicks, input_mods());
    }
    return;
  }
  int pz = S.press;
  S.press = 0;
  if (S.mdown & bm) {
    S.mdown &= ~bm;
    page_mouse("mouseReleased", x, y, bn, S.mdown, S.clicks, input_mods());
    Tab *t = cur();
    if (in_dt(y)) return;
    if (button == 1 && t)
      cdp(t->sid, R_FOCUS, t->tid, "Runtime.evaluate",
          "{\"expression\":\"(()=>{const e=document.activeElement;return !!e&&(e.isContentEditable||/^(INPUT|TEXTAREA)$/.test(e.tagName))})()\",\"returnByValue\":true}");
    if (button == 3 && t) {
      float zf = ZOOMS[t->zoom];
      char ex[700], p2[1200];
      snprintf(ex, sizeof ex,
               "(()=>{const e=document.elementFromPoint(%.0f,%.0f);const a=e&&e.closest('a[href]');const i=e&&e.closest('img');"
               "return JSON.stringify({h:a?a.href:'',i:i?i.src:'',s:String(getSelection()).trim().slice(0,180)})})()",
               x / zf, (y - page_y()) / zf);
      snprintf(p2, sizeof p2, "{\"expression\":%s,\"returnByValue\":true}", js(ex));
      S.ctx_x = x, S.ctx_y = y;
      cdp(t->sid, R_CTX, t->tid, "Runtime.evaluate", p2);
    }
    return;
  }
  if (button == 3 && z >= Z_TAB && z < Z_TAB + MAXT && z == pz) {
    open_tab_ctx(z - Z_TAB, x, y);
    return;
  }
  if (button == 2 && z >= Z_TAB && z < Z_TAB + MAXT && z == pz) {
    close_tab(z - Z_TAB);
    return;
  }
  if (button == 2 && z >= Z_BM && z < Z_BM + MAXB && z == pz) {
    new_tab(BM[z - Z_BM].url, N_WEB, 0, act);
    return;
  }
  if (button != 1) return;
  if (z && z == pz) action(p, z);
}

static void surf_scroll(Panel *p, float x, float y, int steps) {
  S.panel = (int)(p - P);
  int z = surf_zone(p, x, y);
  Tab *t = cur();
  if (S.menu || S.ctx || S.dlg || S.sedit) return;
  if (S.dock == 2 && y >= dock_y()) {
    int n = t ? t->ncon : 0;
    S.con_scroll += steps * 3;
    if (S.con_scroll > n - 1) S.con_scroll = n > 0 ? n - 1 : 0;
    if (S.con_scroll < 0) S.con_scroll = 0;
    p->dirty = 1;
    return;
  }
  if (S.dock == 1 && y >= dock_y() + DOCK_HEAD && DT && DT->attached) {
    char pp[200];
    snprintf(pp, sizeof pp, "{\"type\":\"mouseWheel\",\"x\":%.1f,\"y\":%.1f,\"deltaX\":0,\"deltaY\":%d,\"modifiers\":0}", x, y - dock_y() - DOCK_HEAD, -steps * 110);
    cdp(DT->sid, 0, NULL, "Input.dispatchMouseEvent", pp);
    return;
  }
  if (S.dock && y >= dock_y()) return;
  if (t && t->native == N_PDF && y >= page_y()) {
    if (input_mods() & MOD_CTRL) pdf_zoom(t->pdf, steps > 0 ? 1 : -1);
    else pdf_scroll_by(t->pdf, -steps * 90.f);
    p->dirty = 1;
    return;
  }
  if (t && t->native == N_HISTORY && z != Z_DRAG) {
    S.hscroll -= steps * 80;
    float mx = S.content_h - page_h();
    if (S.hscroll > mx) S.hscroll = (int)mx;
    if (S.hscroll < 0) S.hscroll = 0;
    p->dirty = 1;
    return;
  }
  if (z >= Z_TAB && z < Z_TABX + MAXT && ntab > 1) {
    activate((act + (steps > 0 ? ntab - 1 : 1)) % ntab);
    return;
  }
  if (!t || t->native || E.st != E_READY || y < page_y()) return;
  if (input_mods() & MOD_CTRL) {
    zoom(steps > 0 ? 1 : -1);
    return;
  }
  float zf = ZOOMS[t->zoom];
  char pp[200];
  snprintf(pp, sizeof pp, "{\"type\":\"mouseWheel\",\"x\":%.1f,\"y\":%.1f,\"deltaX\":0,\"deltaY\":%d,\"modifiers\":%d}", x / zf, (y - page_y()) / zf, -steps * 110,
           mods_cdp(input_mods()));
  cdp(t->sid, 0, NULL, "Input.dispatchMouseEvent", pp);
}

static void surf_key(Panel *p, int code, int mods) {
  S.panel = (int)(p - P);
  int ctrl = mods & MOD_CTRL, alt = mods & MOD_ALT, shift = mods & MOD_SHIFT;
  p->dirty = 1;
  Tab *t = cur();
  if (S.dlg) {
    S.blink = 1, S.blink_t = now_ms();
    if (code == KEY_ENTER || code == KEY_KPENTER) dialog_close(1);
    else if (code == KEY_ESC) dialog_close(0);
    else if (S.dlg_type == 2) {
      int l = (int)strlen(S.dlg_in);
      char b[8];
      if (code == KEY_BACKSPACE && l) S.dlg_in[l - 1] = 0;
      else if (!ctrl && !alt && key_to_bytes(code, mods, b) == 1 && (unsigned char)b[0] >= 32 && b[0] != 127 && l < 380) S.dlg_in[l] = b[0], S.dlg_in[l + 1] = 0;
    }
    return;
  }
  if (S.menu || S.ctx) {
    if (code == KEY_ESC) S.menu = S.ctx = 0;
    return;
  }
  if (S.sedit) {
    S.blink = 1, S.blink_t = now_ms();
    if (code == KEY_ESC) S.sedit = 0;
    else if (code == KEY_ENTER || code == KEY_KPENTER) sedit_done(0);
    else if (code == KEY_TAB) S.se_focus = !S.se_focus;
    else if (S.se_focus) line_edit(S.se_url, sizeof S.se_url, code, mods);
    else line_edit(S.se_name, sizeof S.se_name, code, mods);
    return;
  }
  if ((ctrl && shift && code == KEY_I) || code == KEY_F12) {
    set_dock(1);
    return;
  }
  if (ctrl && shift && code == KEY_J) {
    set_dock(2);
    return;
  }
  if (S.dock == 2 && S.kfocus == 2 && !S.omni) {
    S.blink = 1, S.blink_t = now_ms();
    if (code == KEY_ENTER || code == KEY_KPENTER) con_eval();
    else if (code == KEY_UP) snprintf(S.con_in, sizeof S.con_in, "%s", S.con_last);
    else if (code == KEY_ESC) S.kfocus = 0;
    else if (ctrl && code == KEY_L) {
      if (t) t->ncon = 0;
    } else line_edit(S.con_in, sizeof S.con_in, code, mods);
    return;
  }
  if (ctrl && code == KEY_T && shift) {
    menu_action(M_REOPEN);
    return;
  }
  if (ctrl && code == KEY_T) {
    new_tab(NULL, N_NEWTAB, 1, -1);
    return;
  }
  if (ctrl && (code == KEY_W || code == KEY_F4)) {
    close_tab(act);
    return;
  }
  if ((ctrl && code == KEY_L) || (alt && code == KEY_D) || code == KEY_F6) {
    focus_omni();
    return;
  }
  if (ctrl && code == KEY_TAB && ntab > 1) {
    activate((act + (shift ? ntab - 1 : 1)) % ntab);
    return;
  }
  if (ctrl && (code == KEY_PAGEDOWN || code == KEY_PAGEUP) && ntab > 1) {
    activate((act + (code == KEY_PAGEUP ? ntab - 1 : 1)) % ntab);
    return;
  }
  if (ctrl && code >= KEY_1 && code <= KEY_9) {
    int i = code == KEY_9 ? ntab - 1 : code - KEY_1;
    if (i < ntab) activate(i);
    return;
  }
  if (ctrl && code == KEY_H) {
    menu_action(M_HISTORY);
    return;
  }
  if (ctrl && shift && code == KEY_B) {
    menu_action(M_BBAR);
    return;
  }
  if (S.omni) {
    omni_key(code, mods);
    return;
  }
  if (S.hfocus && t && t->native == N_HISTORY) {
    int l = (int)strlen(S.hq);
    char b[8];
    S.blink = 1, S.blink_t = now_ms();
    if (code == KEY_ESC) S.hfocus = 0;
    else if (code == KEY_BACKSPACE && l) S.hq[l - 1] = 0;
    else if (!ctrl && !alt && key_to_bytes(code, mods, b) == 1 && (unsigned char)b[0] >= 32 && b[0] != 127 && l < 90) S.hq[l] = b[0], S.hq[l + 1] = 0;
    S.hscroll = 0;
    return;
  }
  if ((alt && code == KEY_LEFT) || (t && t->native && code == KEY_BACKSPACE)) {
    go_hist(-1);
    return;
  }
  if (alt && code == KEY_RIGHT) {
    go_hist(1);
    return;
  }
  if (alt && code == KEY_HOME) {
    navigate("about:blank");
    return;
  }
  if (code == KEY_F5 || (ctrl && code == KEY_R)) {
    if (t && t->loading) t->loading = 0;
    reload(shift || ctrl ? (code == KEY_F5 && ctrl) || (code == KEY_R && shift) : 0);
    return;
  }
  if (ctrl && code == KEY_D) {
    toggle_mark();
    return;
  }
  if (ctrl && t && t->native == N_PDF && (code == KEY_EQUAL || code == KEY_MINUS || code == KEY_0)) {
    pdf_zoom(t->pdf, code == KEY_EQUAL ? 1 : code == KEY_MINUS ? -1 : 0);
    return;
  }
  if (ctrl && (code == KEY_EQUAL || code == KEY_KPPLUS)) {
    zoom(1);
    return;
  }
  if (ctrl && (code == KEY_MINUS || code == KEY_KPMINUS)) {
    zoom(-1);
    return;
  }
  if (ctrl && code == KEY_0) {
    zoom(0);
    return;
  }
  if (t && t->loading && code == KEY_ESC) {
    reload(0);
    return;
  }
  if (t && t->native == N_PDF) {
    Pdf *f = t->pdf;
    float vh = page_h() - PDF_BAR;
    if (code == KEY_DOWN) pdf_scroll_by(f, 60);
    else if (code == KEY_UP) pdf_scroll_by(f, -60);
    else if (code == KEY_PAGEDOWN || code == KEY_SPACE) pdf_scroll_by(f, vh - 40);
    else if (code == KEY_PAGEUP) pdf_scroll_by(f, -(vh - 40));
    else if (code == KEY_HOME) pdf_scroll_by(f, -1e9f);
    else if (code == KEY_END) pdf_scroll_by(f, 1e9f);
    else if (ctrl && code == KEY_S) pdf_save(f);
    return;
  }
  if (t && t->native) {
    char b[8];
    if (t->native == N_NEWTAB && !ctrl && !alt && key_to_bytes(code, mods, b) == 1 && (unsigned char)b[0] > 32 && b[0] != 127) {
      focus_omni();
      S.sel_all = 0;
      b[1] = 0;
      omni_insert(b);
    } else if (t->native == N_HISTORY) {
      if (code == KEY_DOWN) S.hscroll += 60;
      else if (code == KEY_UP) S.hscroll -= 60;
      if (S.hscroll < 0) S.hscroll = 0;
    }
    return;
  }
  page_key(code, mods);
}

static int surf_tick(Panel *p, uint32_t now) {
  S.panel = (int)(p - P);
  int ch = 0;
  if (E.st == E_OFF) engine_start(), ch = 1;
  if (engine_tick()) ch = 1;
  if (pend_url[0] && E.st == E_READY && ntab > 0) {
    Tab *t = cur();
    if (!strcmp(pend_url, "surf:search")) {
      if (!t || t->native != N_NEWTAB) new_tab(NULL, N_NEWTAB, 1, -1);
      focus_omni();
    } else if (t && t->native == N_NEWTAB) navigate(pend_url);
    else new_tab(pend_url, N_WEB, 1, -1);
    pend_url[0] = 0;
    ch = 1;
  }
  if (net_poll()) ch = 1;
  if (img_pending()) ch = 1;
  Tab *t = cur();
  if (W.hover != S.panel) S.mover = 0;
  for (int i = 0; i < ntab; i++)
    if (TB[i]->pdf && pdf_tick(TB[i])) ch = 1;
  if (t && t->pdf && t->pdf->rendering) ch = 1;
  int over_dt = in_dt(S.my) != NULL, over_page = S.my >= page_y() && S.my < page_y() + page_h() && t && !t->native;
  if (S.mover && E.st == E_READY && (over_dt || over_page) && !S.menu && !S.ctx && !S.dlg && !S.sedit && (S.mx != S.sent_x || S.my != S.sent_y) &&
      now - S.moved_t >= 16) {
    S.sent_x = S.mx, S.sent_y = S.my, S.moved_t = now;
    page_mouse("mouseMoved", S.mx, S.my, S.mdown & 1 ? "left" : "none", S.mdown, 0, input_mods());
  }
  if (t && t->loading) ch = 1;
  if (E.st == E_START) ch = 1;
  for (int i = 0; i < ntab; i++)
    if (TB[i]->loading) ch = 1;
  if (S.dock == 1 && !DT && t && !t->native && t->tid[0] && !nwant) open_devtools();
  if ((S.omni || S.dlg || S.hfocus || S.sedit || (S.dock == 2 && S.kfocus == 2)) && now - S.blink_t > 530) S.blink = !S.blink, S.blink_t = now, ch = 1;
  if (S.toast[0] && now - S.toast_t > 3200) S.toast[0] = 0, ch = 1;
  if (S.zoom_pop && now - S.zoom_t > 1600) S.zoom_pop = 0, ch = 1;
  return ch;
}

static void surf_open(Panel *p) {
  memset(&S, 0, sizeof S);
  S.panel = (int)(p - P);
  p->nobar = 1;
  const char *d = getenv("OREONVR_SURF_DIR");
  if (d && *d) snprintf(E.dir, sizeof E.dir, "%s", d);
  else snprintf(E.dir, sizeof E.dir, "%s/.local/share/oreonvr/surf", user_home());
  snprintf(E.prof, sizeof E.prof, "%s/profile", E.dir);
  office_mkdirs(E.dir);
  E.fd = -1;
  E.st = E_OFF;
  load_data();
  snprintf(p->title, sizeof p->title, "Surf");
  engine_start();
}

static void surf_close(Panel *p) {
  (void)p;
  if (E.st == E_READY) cdp(NULL, 0, NULL, "Browser.close", NULL);
  engine_stop();
  for (int i = 0; i < ntab; i++) free_tab(TB[i]);
  if (DT) free_tab(DT), DT = NULL;
  ntab = 0, act = -1, nwant = 0;
  E.st = E_OFF;
  S.panel = -1;
}

App surf_app = {"surf", "Surf", IC_SURF, NW, NH, surf_open, surf_draw, NULL, surf_scroll, surf_key, surf_zone, surf_tick, surf_close, surf_press};
