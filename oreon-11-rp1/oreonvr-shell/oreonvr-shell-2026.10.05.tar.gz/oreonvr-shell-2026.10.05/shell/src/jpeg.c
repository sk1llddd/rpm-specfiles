#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "store.h"

typedef struct {
  unsigned char bits, code;
} Vlc;

typedef struct {
  int cid, ssx, ssy, w, h, stride, qt, actab, dctab, dcpred;
  unsigned char *px;
} Comp;

typedef struct {
  const unsigned char *p;
  int size, err, w, h, mbw, mbh, ssxmax, ssymax, ncomp, rst;
  uint32_t buf;
  int bits;
  Comp c[3];
  unsigned char q[4][64];
  Vlc vlc[4][65536];
  int blk[64];
} Jd;

static Jd *JD;

static const unsigned char ZZ[64] = {0,  1,  8,  16, 9,  2,  3,  10, 17, 24, 32, 25, 18, 11, 4,  5,  12, 19, 26, 33, 40, 48,
                                     41, 34, 27, 20, 13, 6,  7,  14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23,
                                     30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63};

#define W1 2841
#define W2 2676
#define W3 2408
#define W5 1609
#define W6 1108
#define W7 565

static unsigned char clip8(int x) { return x < 0 ? 0 : x > 255 ? 255 : (unsigned char)x; }

static void row_idct(int *b) {
  int x0, x1, x2, x3, x4, x5, x6, x7, x8;
  if (!((x1 = b[4] * 2048) | (x2 = b[6]) | (x3 = b[2]) | (x4 = b[1]) | (x5 = b[7]) | (x6 = b[5]) | (x7 = b[3]))) {
    b[0] = b[1] = b[2] = b[3] = b[4] = b[5] = b[6] = b[7] = b[0] * 8;
    return;
  }
  x0 = b[0] * 2048 + 128;
  x8 = W7 * (x4 + x5);
  x4 = x8 + (W1 - W7) * x4;
  x5 = x8 - (W1 + W7) * x5;
  x8 = W3 * (x6 + x7);
  x6 = x8 - (W3 - W5) * x6;
  x7 = x8 - (W3 + W5) * x7;
  x8 = x0 + x1;
  x0 -= x1;
  x1 = W6 * (x3 + x2);
  x2 = x1 - (W2 + W6) * x2;
  x3 = x1 + (W2 - W6) * x3;
  x1 = x4 + x6;
  x4 -= x6;
  x6 = x5 + x7;
  x5 -= x7;
  x7 = x8 + x3;
  x8 -= x3;
  x3 = x0 + x2;
  x0 -= x2;
  x2 = (181 * (x4 + x5) + 128) >> 8;
  x4 = (181 * (x4 - x5) + 128) >> 8;
  b[0] = (x7 + x1) >> 8;
  b[1] = (x3 + x2) >> 8;
  b[2] = (x0 + x4) >> 8;
  b[3] = (x8 + x6) >> 8;
  b[4] = (x8 - x6) >> 8;
  b[5] = (x0 - x4) >> 8;
  b[6] = (x3 - x2) >> 8;
  b[7] = (x7 - x1) >> 8;
}

static void col_idct(const int *b, unsigned char *o, int st) {
  int x0, x1, x2, x3, x4, x5, x6, x7, x8;
  if (!((x1 = b[32] * 256) | (x2 = b[48]) | (x3 = b[16]) | (x4 = b[8]) | (x5 = b[56]) | (x6 = b[40]) | (x7 = b[24]))) {
    unsigned char v = clip8(((b[0] + 32) >> 6) + 128);
    for (int i = 0; i < 8; i++, o += st) *o = v;
    return;
  }
  x0 = b[0] * 256 + 8192;
  x8 = W7 * (x4 + x5) + 4;
  x4 = (x8 + (W1 - W7) * x4) >> 3;
  x5 = (x8 - (W1 + W7) * x5) >> 3;
  x8 = W3 * (x6 + x7) + 4;
  x6 = (x8 - (W3 - W5) * x6) >> 3;
  x7 = (x8 - (W3 + W5) * x7) >> 3;
  x8 = x0 + x1;
  x0 -= x1;
  x1 = W6 * (x3 + x2) + 4;
  x2 = (x1 - (W2 + W6) * x2) >> 3;
  x3 = (x1 + (W2 - W6) * x3) >> 3;
  x1 = x4 + x6;
  x4 -= x6;
  x6 = x5 + x7;
  x5 -= x7;
  x7 = x8 + x3;
  x8 -= x3;
  x3 = x0 + x2;
  x0 -= x2;
  x2 = (181 * (x4 + x5) + 128) >> 8;
  x4 = (181 * (x4 - x5) + 128) >> 8;
  o[0] = clip8(((x7 + x1) >> 14) + 128);
  o[st] = clip8(((x3 + x2) >> 14) + 128);
  o[2 * st] = clip8(((x0 + x4) >> 14) + 128);
  o[3 * st] = clip8(((x8 + x6) >> 14) + 128);
  o[4 * st] = clip8(((x8 - x6) >> 14) + 128);
  o[5 * st] = clip8(((x0 - x4) >> 14) + 128);
  o[6 * st] = clip8(((x3 - x2) >> 14) + 128);
  o[7 * st] = clip8(((x7 - x1) >> 14) + 128);
}

static void skip(int n) {
  JD->p += n, JD->size -= n;
  if (JD->size < 0) JD->err = 1;
}

static int be16(const unsigned char *p) { return p[0] << 8 | p[1]; }

static int show(int n) {
  if (!n) return 0;
  while (JD->bits < n) {
    if (JD->size <= 0) {
      JD->buf = JD->buf << 8 | 0xFF, JD->bits += 8;
      continue;
    }
    unsigned char b = *JD->p++;
    JD->size--;
    JD->bits += 8;
    JD->buf = JD->buf << 8 | b;
    if (b == 0xFF) {
      if (!JD->size) {
        JD->err = 1;
        continue;
      }
      unsigned char m = *JD->p++;
      JD->size--;
      if (m == 0xD9) JD->size = 0;
      else if (m && m != 0xFF) {
        if ((m & 0xF8) != 0xD0) JD->err = 1;
        else JD->buf = JD->buf << 8 | m, JD->bits += 8;
      }
    }
  }
  return (int)((JD->buf >> (JD->bits - n)) & ((1u << n) - 1));
}

static void drop(int n) {
  if (JD->bits < n) show(n);
  JD->bits -= n;
}

static int get(int n) {
  int r = show(n);
  drop(n);
  return r;
}

static int vlc(Vlc *t, unsigned char *code) {
  int v = show(16), n = t[v].bits;
  if (!n) {
    JD->err = 1;
    return 0;
  }
  drop(n);
  v = t[v].code;
  if (code) *code = (unsigned char)v;
  n = v & 15;
  if (!n) return 0;
  v = get(n);
  if (v < (1 << (n - 1))) v += (-1 * (1 << n)) + 1;
  return v;
}

static void block(Comp *c, unsigned char *out) {
  unsigned char code = 0;
  int coef = 0;
  memset(JD->blk, 0, sizeof JD->blk);
  c->dcpred += vlc(JD->vlc[c->dctab], NULL);
  JD->blk[0] = c->dcpred * JD->q[c->qt][0];
  do {
    int v = vlc(JD->vlc[c->actab], &code);
    if (!code) break;
    if (!(code & 15) && code != 0xF0) {
      JD->err = 1;
      return;
    }
    coef += (code >> 4) + 1;
    if (coef > 63) {
      JD->err = 1;
      return;
    }
    JD->blk[ZZ[coef]] = v * JD->q[c->qt][coef];
  } while (coef < 63);
  for (int i = 0; i < 64; i += 8) row_idct(&JD->blk[i]);
  for (int i = 0; i < 8; i++) col_idct(&JD->blk[i], out + i, c->stride);
}

static void sof(int len) {
  const unsigned char *p = JD->p;
  if (len < 9 || p[0] != 8) {
    JD->err = 1;
    return;
  }
  JD->h = be16(p + 1), JD->w = be16(p + 3), JD->ncomp = p[5];
  if (!JD->w || !JD->h || (JD->ncomp != 1 && JD->ncomp != 3) || len < 6 + 3 * JD->ncomp) {
    JD->err = 1;
    return;
  }
  JD->ssxmax = JD->ssymax = 1;
  for (int i = 0; i < JD->ncomp; i++) {
    Comp *c = &JD->c[i];
    const unsigned char *q = p + 6 + 3 * i;
    c->cid = q[0], c->ssx = q[1] >> 4, c->ssy = q[1] & 15, c->qt = q[2] & 3;
    if (!c->ssx || !c->ssy) {
      JD->err = 1;
      return;
    }
    if (c->ssx > JD->ssxmax) JD->ssxmax = c->ssx;
    if (c->ssy > JD->ssymax) JD->ssymax = c->ssy;
  }
  if (JD->ncomp == 1) JD->c[0].ssx = JD->c[0].ssy = JD->ssxmax = JD->ssymax = 1;
  int mx = JD->ssxmax * 8, my = JD->ssymax * 8;
  JD->mbw = (JD->w + mx - 1) / mx, JD->mbh = (JD->h + my - 1) / my;
  for (int i = 0; i < JD->ncomp; i++) {
    Comp *c = &JD->c[i];
    c->w = (JD->w * c->ssx + JD->ssxmax - 1) / JD->ssxmax;
    c->h = (JD->h * c->ssy + JD->ssymax - 1) / JD->ssymax;
    c->stride = JD->mbw * c->ssx * 8;
    c->px = malloc((size_t)c->stride * (size_t)(JD->mbh * c->ssy * 8));
    if (!c->px) JD->err = 1;
  }
}

static void dht(int len) {
  const unsigned char *p = JD->p;
  while (len >= 17) {
    int i = p[0];
    if (i & 0xEC) {
      JD->err = 1;
      return;
    }
    i = (i | i >> 3) & 3;
    const unsigned char *cnt = p + 1;
    p += 17, len -= 17;
    Vlc *v = JD->vlc[i];
    int remain = 65536, spread = 65536;
    for (int cl = 1; cl <= 16; cl++) {
      spread >>= 1;
      int n = cnt[cl - 1];
      if (!n) continue;
      if (len < n) {
        JD->err = 1;
        return;
      }
      remain -= n << (16 - cl);
      if (remain < 0) {
        JD->err = 1;
        return;
      }
      for (int k = 0; k < n; k++)
        for (int s = spread; s; s--) v->bits = (unsigned char)cl, v->code = p[k], v++;
      p += n, len -= n;
    }
    while (remain--) v->bits = 0, v++;
  }
}

static void dqt(int len) {
  const unsigned char *p = JD->p;
  while (len >= 65) {
    if (p[0] & 0xFC) {
      JD->err = 1;
      return;
    }
    memcpy(JD->q[p[0]], p + 1, 64);
    p += 65, len -= 65;
  }
}

static void sos(int len) {
  const unsigned char *p = JD->p;
  if (len < 4 + 2 * JD->ncomp || p[0] != JD->ncomp || !JD->c[0].px) {
    JD->err = 1;
    return;
  }
  for (int i = 0; i < JD->ncomp; i++) {
    Comp *c = &JD->c[i];
    const unsigned char *q = p + 1 + 2 * i;
    if (q[0] != c->cid || (q[1] & 0xEE)) {
      JD->err = 1;
      return;
    }
    c->dctab = q[1] >> 4, c->actab = (q[1] & 1) | 2, c->dcpred = 0;
  }
  const unsigned char *t = p + 1 + 2 * JD->ncomp;
  if (t[0] || t[1] != 63 || t[2]) {
    JD->err = 1;
    return;
  }
  skip(len);
  JD->buf = 0, JD->bits = 0;
  int mbx = 0, mby = 0, rc = JD->rst, next = 0;
  for (;;) {
    for (int i = 0; i < JD->ncomp; i++) {
      Comp *c = &JD->c[i];
      for (int sy = 0; sy < c->ssy; sy++)
        for (int sx = 0; sx < c->ssx; sx++) {
          block(c, &c->px[((mby * c->ssy + sy) * c->stride + mbx * c->ssx + sx) * 8]);
          if (JD->err) return;
        }
    }
    if (++mbx >= JD->mbw) {
      mbx = 0;
      if (++mby >= JD->mbh) break;
    }
    if (JD->rst && !--rc) {
      JD->bits &= 0xF8;
      int m = get(16);
      if ((m & 0xFFF8) != 0xFFD0 || (m & 7) != next) {
        JD->err = 1;
        return;
      }
      next = (next + 1) & 7, rc = JD->rst;
      for (int i = 0; i < JD->ncomp; i++) JD->c[i].dcpred = 0;
    }
  }
}

uint32_t *jpeg_decode(const unsigned char *data, size_t n, int *ow, int *oh) {
  if (!JD) JD = malloc(sizeof *JD);
  if (!JD || n < 4 || data[0] != 0xFF || data[1] != 0xD8) return NULL;
  memset(JD, 0, offsetof(Jd, vlc));
  JD->p = data + 2, JD->size = (int)n - 2;
  int scanned = 0;
  while (!JD->err && !scanned) {
    if (JD->size < 4 || JD->p[0] != 0xFF) {
      JD->err = 1;
      break;
    }
    int m = JD->p[1];
    if (m == 0xFF) {
      skip(1);
      continue;
    }
    skip(2);
    if (m == 0xD8 || (m >= 0xD0 && m <= 0xD7) || m == 0x01) continue;
    if (m == 0xD9) break;
    int len = be16(JD->p);
    if (len < 2 || len > JD->size) {
      JD->err = 1;
      break;
    }
    skip(2);
    len -= 2;
    switch (m) {
    case 0xC0:
    case 0xC1: sof(len); break;
    case 0xC4: dht(len); break;
    case 0xDB: dqt(len); break;
    case 0xDD: JD->rst = len >= 2 ? be16(JD->p) : 0; break;
    case 0xDA:
      sos(len);
      scanned = 1;
      continue;
    default:
      if (m >= 0xC2 && m <= 0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC) JD->err = 1;
      break;
    }
    if (!JD->err) skip(len);
  }
  uint32_t *out = NULL;
  if (!JD->err && scanned) {
    out = malloc((size_t)JD->w * (size_t)JD->h * 4);
    if (out) {
      Comp *y = &JD->c[0], *cb = &JD->c[1], *cr = &JD->c[2];
      for (int r = 0; r < JD->h; r++) {
        const unsigned char *yr = y->px + (size_t)(r * y->ssy / JD->ssymax) * (size_t)y->stride;
        uint32_t *o = out + (size_t)r * (size_t)JD->w;
        if (JD->ncomp == 1) {
          for (int x = 0; x < JD->w; x++) {
            unsigned v = yr[x];
            o[x] = 0xff000000u | v << 16 | v << 8 | v;
          }
          continue;
        }
        const unsigned char *br = cb->px + (size_t)(r * cb->ssy / JD->ssymax) * (size_t)cb->stride;
        const unsigned char *rr = cr->px + (size_t)(r * cr->ssy / JD->ssymax) * (size_t)cr->stride;
        int fy = y->ssx, fb = cb->ssx, fr = cr->ssx, mx = JD->ssxmax;
        for (int x = 0; x < JD->w; x++) {
          int Y = yr[x * fy / mx], U = br[x * fb / mx] - 128, V = rr[x * fr / mx] - 128;
          int R = Y + ((91881 * V + 32768) >> 16);
          int G = Y - ((22554 * U + 46802 * V - 32768) >> 16);
          int B = Y + ((116130 * U + 32768) >> 16);
          o[x] = 0xff000000u | (uint32_t)clip8(R) << 16 | (uint32_t)clip8(G) << 8 | clip8(B);
        }
      }
      *ow = JD->w, *oh = JD->h;
    }
  }
  for (int i = 0; i < 3; i++) free(JD->c[i].px), JD->c[i].px = NULL;
  return out;
}
