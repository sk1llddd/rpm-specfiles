#include <ctype.h>
#include <dirent.h>
#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "office.h"

#define MAXR 500
#define MAXC 40
#define ROW_H 28
#define CH_H 28
#define RH_W 48
#define DEF_CW 104
#define FBAR_Y 124
#define FBAR_H 36
#define GRID_X 16
#define GRID_Y 172
#define GRID_BOT 52
#define MAXUNDO 60
#define MAXSHEETS 256
#define NSTPL 6
#define MAXPV 48

enum { V_EMPTY, V_NUM, V_STR, V_BOOL, V_ERR };
enum { FM_GEN, FM_NUM, FM_CUR, FM_PCT };
enum { AL_AUTO, AL_LEFT, AL_CENTER, AL_RIGHT };

enum {
  T_UNDO = 1, T_REDO, T_CUR, T_PCT, T_DECM, T_DECP, T_GEN, T_BOLD, T_ITAL, T_STRIKE, T_COLOR, T_FILL, T_ALEFT,
  T_ACENTER, T_ARIGHT, T_SUM, T_SORTA, T_SORTD, T_COUNT
};

enum {
  Z_MENU = 40, Z_TITLE = 50, Z_HOME = 51, Z_FBAR = 52, Z_NAME = 53, Z_GRID = 60, Z_COLH = 61, Z_ROWH = 62,
  Z_CORNER = 63, Z_RESIZE = 64, Z_HANDLE = 65, Z_POPUP = 100
};

enum {
  C_NONE, C_NEW, C_COPYDOC, C_RENAME, C_CSV, C_XLSX, C_DELETE, C_UNDO, C_REDO, C_CUT, C_COPY, C_PASTE, C_PASTEV, C_SELALL,
  C_CLEARV, C_ROWA, C_ROWB, C_COLL, C_COLR, C_BOLD, C_ITAL, C_STRIKE, C_FGEN, C_FNUM, C_FCUR, C_FPCT, C_ALEFT,
  C_ACENTER, C_ARIGHT, C_CLEARF, C_SORTA, C_SORTD, C_DELROW, C_DELCOL, C_SUM
};

typedef struct {
  unsigned char t;
  double n;
  char s[120];
} Val;

typedef struct {
  char *src;
  unsigned char bold, ital, strike, align, color, fill, fmt, dec;
  Val v;
  unsigned gen;
  unsigned char busy;
} Cell;

typedef struct {
  const char *label, *key;
  int cmd;
} Item;

typedef struct {
  char id[40];
  char title[96];
  long mtime;
  unsigned char pv[MAXPV][4];
  int npv;
} SheetInfo;

static const Item M_FILE[] = {{"New spreadsheet", "", C_NEW}, {"Make a copy", "", C_COPYDOC}, {"Rename", "", C_RENAME},
                              {NULL, NULL, 0}, {"Download as CSV (.csv)", "", C_CSV},
                              {"Download as Excel (.xlsx)", "", C_XLSX}, {NULL, NULL, 0},
                              {"Move to trash", "", C_DELETE}};
static const Item M_EDIT[] = {{"Undo", "Ctrl+Z", C_UNDO}, {"Redo", "Ctrl+Y", C_REDO}, {NULL, NULL, 0},
                              {"Cut", "Ctrl+X", C_CUT}, {"Copy", "Ctrl+C", C_COPY}, {"Paste", "Ctrl+V", C_PASTE},
                              {"Paste values only", "Ctrl+Shift+V", C_PASTEV}, {NULL, NULL, 0},
                              {"Select all", "Ctrl+A", C_SELALL}, {"Delete values", "Del", C_CLEARV}};
static const Item M_INSERT[] = {{"Row above", "", C_ROWA}, {"Row below", "", C_ROWB}, {NULL, NULL, 0},
                                {"Column left", "", C_COLL}, {"Column right", "", C_COLR}, {NULL, NULL, 0},
                                {"Sum of selection", "Alt+=", C_SUM}};
static const Item M_FORMAT[] = {{"Bold", "Ctrl+B", C_BOLD}, {"Italic", "Ctrl+I", C_ITAL},
                                {"Strikethrough", "Alt+Shift+5", C_STRIKE}, {NULL, NULL, 0},
                                {"Automatic", "", C_FGEN}, {"Number  1,000.12", "", C_FNUM},
                                {"Currency  $1,000.12", "", C_FCUR}, {"Percent  10.12%", "", C_FPCT},
                                {NULL, NULL, 0}, {"Align left", "", C_ALEFT}, {"Center", "", C_ACENTER},
                                {"Align right", "", C_ARIGHT}, {NULL, NULL, 0}, {"Clear formatting", "Ctrl+\\", C_CLEARF}};
static const Item M_DATA[] = {{"Sort A to Z", "", C_SORTA}, {"Sort Z to A", "", C_SORTD}, {NULL, NULL, 0},
                              {"Delete row", "", C_DELROW}, {"Delete column", "", C_DELCOL}};
static const char *MENU_NAMES[5] = {"File", "Edit", "Insert", "Format", "Data"};
static const Item *MENUS[5] = {M_FILE, M_EDIT, M_INSERT, M_FORMAT, M_DATA};
static const int MENU_LEN[5] = {8, 10, 7, 14, 5};

enum { POP_NONE, POP_M0, POP_M1, POP_M2, POP_M3, POP_M4, POP_COLOR, POP_FILL };

static const uint32_t FILL_L[8] = {0, RGB(241, 243, 244), RGB(252, 228, 226), RGB(254, 236, 214), RGB(255, 245, 200),
                                   RGB(220, 242, 228), RGB(220, 234, 252), RGB(236, 226, 252)};
static const uint32_t FILL_D[8] = {0, RGB(56, 58, 66), RGB(92, 44, 44), RGB(96, 64, 32), RGB(92, 82, 30),
                                   RGB(34, 78, 54), RGB(34, 60, 98), RGB(68, 50, 102)};

static Cell *G[MAXR][MAXC];
static int CW[MAXC];
static unsigned GEN = 1;

static struct {
  char id[40], title[96];
  int ac, ar, bc, br;
  float sx, sy;
  int editing, emode, elen, ecur;
  char ebuf[512];
  int ref_a, ref_b, ref_c0, ref_r0;
  int popup;
  int dirty;
  uint32_t dirty_at;
  char *undo[MAXUNDO], *redo[MAXUNDO];
  int nundo, nredo;
  int press, dragsel, dragref, resize_col, filling;
  int fill_c, fill_r;
  float resize_x0;
  int resize_w0;
  uint32_t last_click;
  int last_cc, last_cr;
  int title_edit;
  char title_buf[96];
  int blink;
  uint32_t blink_t;
  struct {
    int w, h, c0, r0, cut;
    Cell *cells;
    char **srcs;
  } clip;
  SheetInfo list[MAXSHEETS];
  int nlist, confirm_del;
  int loaded;
} S;

static float line_h(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static float content_h(void) { return OFF_H - BAR_H; }

static Cell *cell_mk(int c, int r) {
  if (c < 0 || r < 0 || c >= MAXC || r >= MAXR) return NULL;
  if (!G[r][c]) {
    G[r][c] = calloc(1, sizeof(Cell));
    G[r][c]->dec = 255;
  }
  return G[r][c];
}

static void cell_free(int c, int r) {
  Cell *x = G[r][c];
  if (!x) return;
  free(x->src);
  free(x);
  G[r][c] = NULL;
}

static int cell_blank_style(Cell *x) {
  return !x->bold && !x->ital && !x->strike && !x->align && !x->color && !x->fill && !x->fmt && x->dec == 255;
}

static void cell_set_src(int c, int r, const char *src) {
  Cell *x = cell_mk(c, r);
  if (!x) return;
  free(x->src);
  x->src = (src && *src) ? strdup(src) : NULL;
  if (!x->src && cell_blank_style(x)) cell_free(c, r);
  GEN++;
}

static void sheet_clear(void) {
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++) cell_free(c, r);
  for (int c = 0; c < MAXC; c++) CW[c] = DEF_CW;
  GEN++;
}

static void col_name(int c, char *out) {
  if (c < 26) out[0] = (char)('A' + c), out[1] = 0;
  else out[0] = (char)('A' + c / 26 - 1), out[1] = (char)('A' + c % 26), out[2] = 0;
}

static void ref_name(int c, int r, char *out) {
  col_name(c, out);
  sprintf(out + strlen(out), "%d", r + 1);
}

static Val verr(const char *e) {
  Val v = {V_ERR, 0, ""};
  snprintf(v.s, sizeof v.s, "%s", e);
  return v;
}

static Val vnum(double n) {
  Val v = {V_NUM, n, ""};
  if (isnan(n) || isinf(n)) return verr("#NUM!");
  return v;
}

static Val vstr(const char *s) {
  Val v = {V_STR, 0, ""};
  snprintf(v.s, sizeof v.s, "%s", s);
  return v;
}

static Val vbool(int b) {
  Val v = {V_BOOL, b ? 1 : 0, ""};
  return v;
}

static int parse_number(const char *s, double *out, int *fmt) {
  while (*s == ' ') s++;
  char buf[64];
  int k = 0, cur = 0, pct = 0, neg = 0;
  if (*s == '-') neg = 1, s++;
  if (*s == '$') cur = 1, s++;
  if (!*s) return 0;
  for (; *s && k < 60; s++) {
    if (*s == ',') continue;
    if (*s == '%' && !s[1]) {
      pct = 1;
      break;
    }
    if (*s == ' ' && !s[1]) break;
    buf[k++] = *s;
  }
  buf[k] = 0;
  if (!k) return 0;
  char *e;
  double v = strtod(buf, &e);
  if (*e || !(isdigit((unsigned char)buf[0]) || buf[0] == '.')) return 0;
  if (pct) v /= 100;
  if (neg) v = -v;
  *out = v;
  if (fmt) *fmt = cur ? FM_CUR : pct ? FM_PCT : FM_GEN;
  return 1;
}

static Val cell_val(int c, int r);

typedef struct {
  const char *s;
  int i;
} Ps;

static void skip(Ps *p) {
  while (p->s[p->i] == ' ') p->i++;
}

static int parse_ref(Ps *p, int *c, int *r, int *ac, int *ar) {
  int i = p->i;
  const char *s = p->s;
  int a1 = 0, a2 = 0;
  if (s[i] == '$') a1 = 1, i++;
  int col = 0, nl = 0;
  while (isalpha((unsigned char)s[i]) && nl < 3) col = col * 26 + (toupper((unsigned char)s[i]) - 'A' + 1), i++, nl++;
  if (!nl || nl > 2) return 0;
  if (s[i] == '$') a2 = 1, i++;
  if (!isdigit((unsigned char)s[i])) return 0;
  int row = 0;
  while (isdigit((unsigned char)s[i])) row = row * 10 + (s[i] - '0'), i++;
  if (isalnum((unsigned char)s[i]) || s[i] == '(' || s[i] == '_') return 0;
  *c = col - 1, *r = row - 1;
  if (ac) *ac = a1;
  if (ar) *ar = a2;
  p->i = i;
  return 1;
}

static double num_of(Val v, int *err) {
  if (v.t == V_NUM || v.t == V_BOOL) return v.n;
  if (v.t == V_EMPTY) return 0;
  if (v.t == V_STR) {
    double d;
    if (parse_number(v.s, &d, NULL)) return d;
  }
  *err = 1;
  return 0;
}

static void str_of(Val v, char *out, int n) {
  if (v.t == V_NUM) {
    snprintf(out, (size_t)n, "%.10g", v.n);
  } else if (v.t == V_BOOL) snprintf(out, (size_t)n, "%s", v.n ? "TRUE" : "FALSE");
  else if (v.t == V_STR || v.t == V_ERR) snprintf(out, (size_t)n, "%s", v.s);
  else out[0] = 0;
}

static Val p_expr(Ps *p);

static void cat(char *dst, size_t cap, const char *src) {
  size_t l = strlen(dst), m = strlen(src);
  if (l + m >= cap) m = cap - l - 1;
  memcpy(dst + l, src, m);
  dst[l + m] = 0;
}

typedef struct {
  int isr, c0, r0, c1, r1;
  Val v;
} Arg;

static int parse_args(Ps *p, Arg *a, int max) {
  int n = 0;
  skip(p);
  if (p->s[p->i] == ')') {
    p->i++;
    return 0;
  }
  for (;;) {
    if (n >= max) return -1;
    skip(p);
    int save = p->i, c0, r0;
    Arg *x = &a[n];
    memset(x, 0, sizeof *x);
    if (parse_ref(p, &c0, &r0, NULL, NULL)) {
      skip(p);
      if (p->s[p->i] == ':') {
        p->i++;
        skip(p);
        int c1, r1;
        if (!parse_ref(p, &c1, &r1, NULL, NULL)) return -1;
        x->isr = 1;
        x->c0 = c0 < c1 ? c0 : c1, x->c1 = c0 < c1 ? c1 : c0;
        x->r0 = r0 < r1 ? r0 : r1, x->r1 = r0 < r1 ? r1 : r0;
      } else if (p->s[p->i] == ',' || p->s[p->i] == ')') {
        x->isr = 1;
        x->c0 = x->c1 = c0, x->r0 = x->r1 = r0;
      } else {
        p->i = save;
        x->v = p_expr(p);
      }
    } else {
      x->v = p_expr(p);
    }
    n++;
    skip(p);
    if (p->s[p->i] == ',') {
      p->i++;
      continue;
    }
    if (p->s[p->i] == ')') {
      p->i++;
      return n;
    }
    return -1;
  }
}

typedef struct {
  double sum, prod, mn, mx;
  int cnt, cnta, err;
  char errs[16];
  double vals[2048];
  int nv;
} Agg;

static void agg_val(Agg *g, Val v, int from_range) {
  if (v.t == V_ERR) {
    if (!g->err) snprintf(g->errs, sizeof g->errs, "%.15s", v.s);
    g->err = 1;
    return;
  }
  if (v.t != V_EMPTY) g->cnta++;
  double d;
  if (v.t == V_NUM || (!from_range && v.t == V_BOOL)) d = v.n;
  else if (!from_range && v.t == V_STR && parse_number(v.s, &d, NULL)) {
  } else return;
  g->sum += d;
  g->prod *= d;
  if (!g->cnt || d < g->mn) g->mn = d;
  if (!g->cnt || d > g->mx) g->mx = d;
  if (g->nv < 2048) g->vals[g->nv++] = d;
  g->cnt++;
}

static void agg_args(Agg *g, Arg *a, int n) {
  memset(g, 0, sizeof *g);
  g->prod = 1;
  for (int i = 0; i < n; i++) {
    if (a[i].isr) {
      for (int r = a[i].r0; r <= a[i].r1 && r < MAXR; r++)
        for (int c = a[i].c0; c <= a[i].c1 && c < MAXC; c++) agg_val(g, cell_val(c, r), 1);
    } else agg_val(g, a[i].v, 0);
  }
}

static Val arg_val(Arg *a) {
  if (a->isr) {
    if (a->c0 == a->c1 && a->r0 == a->r1) return cell_val(a->c0, a->r0);
    return verr("#VALUE!");
  }
  return a->v;
}

static int dcmp(const void *a, const void *b) {
  double x = *(const double *)a, y = *(const double *)b;
  return x < y ? -1 : x > y;
}

static int crit_match(Val v, Val crit) {
  char cs[128];
  str_of(crit, cs, sizeof cs);
  const char *q = cs;
  int op = 0;
  if (!strncmp(q, "<>", 2)) op = 1, q += 2;
  else if (!strncmp(q, ">=", 2)) op = 2, q += 2;
  else if (!strncmp(q, "<=", 2)) op = 3, q += 2;
  else if (*q == '>') op = 4, q++;
  else if (*q == '<') op = 5, q++;
  else if (*q == '=') op = 0, q++;
  double cn;
  int cnum = parse_number(q, &cn, NULL);
  if (cnum && (v.t == V_NUM || v.t == V_BOOL)) {
    double d = v.n;
    switch (op) {
    case 0: return d == cn;
    case 1: return d != cn;
    case 2: return d >= cn;
    case 3: return d <= cn;
    case 4: return d > cn;
    case 5: return d < cn;
    }
  }
  char vs[128];
  str_of(v, vs, sizeof vs);
  int eq = !strcasecmp(vs, q);
  if (op == 0) return eq;
  if (op == 1) return !eq;
  return 0;
}

static double round_to(double x, int d, int mode) {
  double m = pow(10, d);
  double y = x * m;
  if (mode == 0) y = y < 0 ? -floor(-y + 0.5) : floor(y + 0.5);
  else if (mode == 1) y = y < 0 ? -ceil(-y - 1e-9) : ceil(y - 1e-9);
  else y = y < 0 ? -floor(-y + 1e-9) : floor(y + 1e-9);
  return y / m;
}

static Val call_fn(const char *name, Arg *a, int n) {
  Agg g;
  int err = 0;
#define NEED(k) \
  if (n < (k)) return verr("#N/A")
#define NUMARG(i) num_of(arg_val(&a[i]), &err)
  if (!strcmp(name, "SUM") || !strcmp(name, "AVERAGE") || !strcmp(name, "MIN") || !strcmp(name, "MAX") ||
      !strcmp(name, "COUNT") || !strcmp(name, "COUNTA") || !strcmp(name, "PRODUCT") || !strcmp(name, "MEDIAN")) {
    agg_args(&g, a, n);
    if (g.err && strcmp(name, "COUNT") && strcmp(name, "COUNTA")) return verr(g.errs);
    if (!strcmp(name, "SUM")) return vnum(g.sum);
    if (!strcmp(name, "AVERAGE")) return g.cnt ? vnum(g.sum / g.cnt) : verr("#DIV/0!");
    if (!strcmp(name, "MIN")) return vnum(g.cnt ? g.mn : 0);
    if (!strcmp(name, "MAX")) return vnum(g.cnt ? g.mx : 0);
    if (!strcmp(name, "COUNT")) return vnum(g.cnt);
    if (!strcmp(name, "COUNTA")) return vnum(g.cnta);
    if (!strcmp(name, "PRODUCT")) return vnum(g.cnt ? g.prod : 0);
    if (!g.nv) return verr("#NUM!");
    qsort(g.vals, (size_t)g.nv, sizeof(double), dcmp);
    return vnum(g.nv % 2 ? g.vals[g.nv / 2] : (g.vals[g.nv / 2 - 1] + g.vals[g.nv / 2]) / 2);
  }
  if (!strcmp(name, "IF")) {
    NEED(2);
    Val c = arg_val(&a[0]);
    if (c.t == V_ERR) return c;
    double t = num_of(c, &err);
    if (err) return verr("#VALUE!");
    if (t != 0) return arg_val(&a[1]);
    return n > 2 ? arg_val(&a[2]) : vbool(0);
  }
  if (!strcmp(name, "IFERROR")) {
    NEED(2);
    Val v = arg_val(&a[0]);
    return v.t == V_ERR ? arg_val(&a[1]) : v;
  }
  if (!strcmp(name, "AND") || !strcmp(name, "OR")) {
    int any = 0, all = 1;
    for (int i = 0; i < n; i++) {
      if (a[i].isr) {
        for (int r = a[i].r0; r <= a[i].r1; r++)
          for (int c = a[i].c0; c <= a[i].c1; c++) {
            Val v = cell_val(c, r);
            if (v.t == V_ERR) return v;
            if (v.t == V_NUM || v.t == V_BOOL) {
              if (v.n != 0) any = 1;
              else all = 0;
            }
          }
      } else {
        Val v = a[i].v;
        if (v.t == V_ERR) return v;
        double d = num_of(v, &err);
        if (err) return verr("#VALUE!");
        if (d != 0) any = 1;
        else all = 0;
      }
    }
    return vbool(name[0] == 'A' ? all : any);
  }
  if (!strcmp(name, "NOT")) {
    NEED(1);
    double d = NUMARG(0);
    return err ? verr("#VALUE!") : vbool(d == 0);
  }
  if (!strcmp(name, "TRUE")) return vbool(1);
  if (!strcmp(name, "FALSE")) return vbool(0);
  if (!strcmp(name, "PI")) return vnum(M_PI);
  if (!strcmp(name, "ROUND") || !strcmp(name, "ROUNDUP") || !strcmp(name, "ROUNDDOWN")) {
    NEED(1);
    double x = NUMARG(0), d = n > 1 ? NUMARG(1) : 0;
    if (err) return verr("#VALUE!");
    return vnum(round_to(x, (int)d, name[5] == 'U' ? 1 : name[5] == 'D' ? 2 : 0));
  }
  if (!strcmp(name, "ABS") || !strcmp(name, "SQRT") || !strcmp(name, "INT") || !strcmp(name, "LN") ||
      !strcmp(name, "EXP")) {
    NEED(1);
    double x = NUMARG(0);
    if (err) return verr("#VALUE!");
    if (!strcmp(name, "ABS")) return vnum(fabs(x));
    if (!strcmp(name, "INT")) return vnum(floor(x));
    if (!strcmp(name, "EXP")) return vnum(exp(x));
    if (x < 0 || (name[0] == 'L' && x == 0)) return verr("#NUM!");
    return vnum(name[0] == 'S' ? sqrt(x) : log(x));
  }
  if (!strcmp(name, "POWER") || !strcmp(name, "MOD")) {
    NEED(2);
    double x = NUMARG(0), y = NUMARG(1);
    if (err) return verr("#VALUE!");
    if (name[0] == 'P') return vnum(pow(x, y));
    if (y == 0) return verr("#DIV/0!");
    return vnum(x - y * floor(x / y));
  }
  if (!strcmp(name, "LEN") || !strcmp(name, "UPPER") || !strcmp(name, "LOWER") || !strcmp(name, "TRIM")) {
    NEED(1);
    Val v = arg_val(&a[0]);
    if (v.t == V_ERR) return v;
    char b[120];
    str_of(v, b, sizeof b);
    if (name[0] == 'L' && name[1] == 'E') return vnum((double)strlen(b));
    if (name[0] == 'T') {
      char o[120];
      int k = 0, sp = 0;
      for (char *q = b; *q; q++) {
        if (*q == ' ') {
          sp = k > 0;
          continue;
        }
        if (sp && k < 118) o[k++] = ' ';
        sp = 0;
        if (k < 118) o[k++] = *q;
      }
      o[k] = 0;
      return vstr(o);
    }
    for (char *q = b; *q; q++) *q = (char)(name[0] == 'U' ? toupper((unsigned char)*q) : tolower((unsigned char)*q));
    return vstr(b);
  }
  if (!strcmp(name, "LEFT") || !strcmp(name, "RIGHT")) {
    NEED(1);
    Val v = arg_val(&a[0]);
    if (v.t == V_ERR) return v;
    char b[120];
    str_of(v, b, sizeof b);
    int k = n > 1 ? (int)NUMARG(1) : 1, l = (int)strlen(b);
    if (k < 0) return verr("#VALUE!");
    if (k > l) k = l;
    if (name[0] == 'L') b[k] = 0;
    else memmove(b, b + l - k, (size_t)k + 1);
    return vstr(b);
  }
  if (!strcmp(name, "CONCAT") || !strcmp(name, "CONCATENATE")) {
    char o[120] = "";
    for (int i = 0; i < n; i++) {
      if (a[i].isr) {
        for (int r = a[i].r0; r <= a[i].r1; r++)
          for (int c = a[i].c0; c <= a[i].c1; c++) {
            Val v = cell_val(c, r);
            if (v.t == V_ERR) return v;
            char b[120];
            str_of(v, b, sizeof b);
            cat(o, sizeof o, b);
          }
      } else {
        if (a[i].v.t == V_ERR) return a[i].v;
        char b[120];
        str_of(a[i].v, b, sizeof b);
        cat(o, sizeof o, b);
      }
    }
    return vstr(o);
  }
  if (!strcmp(name, "SUMIF") || !strcmp(name, "COUNTIF") || !strcmp(name, "AVERAGEIF")) {
    NEED(2);
    if (!a[0].isr) return verr("#VALUE!");
    Val crit = arg_val(&a[1]);
    Arg *sr = (n > 2 && a[2].isr && name[0] != 'C') ? &a[2] : &a[0];
    double sum = 0;
    int cnt = 0;
    for (int r = a[0].r0; r <= a[0].r1; r++)
      for (int c = a[0].c0; c <= a[0].c1; c++) {
        if (!crit_match(cell_val(c, r), crit)) continue;
        cnt++;
        Val v = cell_val(sr->c0 + (c - a[0].c0), sr->r0 + (r - a[0].r0));
        if (v.t == V_NUM) sum += v.n;
      }
    if (name[0] == 'C') return vnum(cnt);
    if (name[0] == 'A') return cnt ? vnum(sum / cnt) : verr("#DIV/0!");
    return vnum(sum);
  }
  if (!strcmp(name, "VLOOKUP")) {
    NEED(3);
    Val key = arg_val(&a[0]);
    if (key.t == V_ERR) return key;
    if (!a[1].isr) return verr("#VALUE!");
    int col = (int)NUMARG(2);
    int exact = n > 3 ? NUMARG(3) == 0 : 0;
    if (err || col < 1 || a[1].c0 + col - 1 > a[1].c1) return verr("#REF!");
    int best = -1;
    for (int r = a[1].r0; r <= a[1].r1; r++) {
      Val v = cell_val(a[1].c0, r);
      if (key.t == V_NUM && v.t == V_NUM) {
        if (v.n == key.n) {
          best = r;
          break;
        }
        if (!exact && v.n < key.n) best = r;
        else if (!exact && v.n > key.n) break;
      } else {
        char x[120], y[120];
        str_of(v, x, sizeof x);
        str_of(key, y, sizeof y);
        if (!strcasecmp(x, y)) {
          best = r;
          break;
        }
      }
    }
    if (best < 0) return verr("#N/A");
    return cell_val(a[1].c0 + col - 1, best);
  }
  return verr("#NAME?");
#undef NEED
#undef NUMARG
}

static Val p_primary(Ps *p) {
  skip(p);
  const char *s = p->s;
  char ch = s[p->i];
  if (ch == '(') {
    p->i++;
    Val v = p_expr(p);
    skip(p);
    if (s[p->i] != ')') return verr("#ERROR!");
    p->i++;
    return v;
  }
  if (ch == '"') {
    char b[120];
    int k = 0;
    p->i++;
    while (s[p->i] && !(s[p->i] == '"' && s[p->i + 1] != '"')) {
      if (s[p->i] == '"') p->i++;
      if (k < 118) b[k++] = s[p->i];
      p->i++;
    }
    if (s[p->i] != '"') return verr("#ERROR!");
    p->i++;
    b[k] = 0;
    return vstr(b);
  }
  if (isdigit((unsigned char)ch) || ch == '.') {
    char *e;
    double d = strtod(s + p->i, &e);
    p->i = (int)(e - s);
    return vnum(d);
  }
  int c, r;
  int save = p->i;
  if (parse_ref(p, &c, &r, NULL, NULL)) {
    skip(p);
    if (s[p->i] == ':') return verr("#VALUE!");
    if (c >= MAXC || r >= MAXR) return verr("#REF!");
    Val v = cell_val(c, r);
    return v;
  }
  p->i = save;
  if (isalpha((unsigned char)ch)) {
    char name[24];
    int k = 0;
    while ((isalnum((unsigned char)s[p->i]) || s[p->i] == '.') && k < 23) name[k++] = (char)toupper((unsigned char)s[p->i++]);
    name[k] = 0;
    skip(p);
    if (s[p->i] == '(') {
      p->i++;
      Arg args[32];
      int n = parse_args(p, args, 32);
      if (n < 0) return verr("#ERROR!");
      return call_fn(name, args, n);
    }
    if (!strcmp(name, "TRUE")) return vbool(1);
    if (!strcmp(name, "FALSE")) return vbool(0);
    if (!strncmp(name, "#REF", 4)) {
      while (s[p->i] == '!') p->i++;
      return verr("#REF!");
    }
    return verr("#NAME?");
  }
  if (ch == '#') {
    while (s[p->i] && s[p->i] != ' ' && s[p->i] != ')' && s[p->i] != ',') p->i++;
    return verr("#REF!");
  }
  return verr("#ERROR!");
}

static Val p_postfix(Ps *p) {
  Val v = p_primary(p);
  skip(p);
  while (p->s[p->i] == '%') {
    p->i++;
    if (v.t == V_ERR) return v;
    int err = 0;
    double d = num_of(v, &err);
    if (err) return verr("#VALUE!");
    v = vnum(d / 100);
    skip(p);
  }
  return v;
}

static Val p_unary(Ps *p) {
  skip(p);
  char ch = p->s[p->i];
  if (ch == '-' || ch == '+') {
    p->i++;
    Val v = p_unary(p);
    if (v.t == V_ERR) return v;
    int err = 0;
    double d = num_of(v, &err);
    if (err) return verr("#VALUE!");
    return vnum(ch == '-' ? -d : d);
  }
  return p_postfix(p);
}

static Val binop(Val a, Val b, char op) {
  if (a.t == V_ERR) return a;
  if (b.t == V_ERR) return b;
  int err = 0;
  double x = num_of(a, &err), y = num_of(b, &err);
  if (err) return verr("#VALUE!");
  switch (op) {
  case '+': return vnum(x + y);
  case '-': return vnum(x - y);
  case '*': return vnum(x * y);
  case '/': return y == 0 ? verr("#DIV/0!") : vnum(x / y);
  case '^': return vnum(pow(x, y));
  }
  return verr("#ERROR!");
}

static Val p_pow(Ps *p) {
  Val v = p_unary(p);
  for (;;) {
    skip(p);
    if (p->s[p->i] != '^') return v;
    p->i++;
    v = binop(v, p_unary(p), '^');
  }
}

static Val p_mul(Ps *p) {
  Val v = p_pow(p);
  for (;;) {
    skip(p);
    char op = p->s[p->i];
    if (op != '*' && op != '/') return v;
    p->i++;
    v = binop(v, p_pow(p), op);
  }
}

static Val p_add(Ps *p) {
  Val v = p_mul(p);
  for (;;) {
    skip(p);
    char op = p->s[p->i];
    if (op != '+' && op != '-') return v;
    p->i++;
    v = binop(v, p_mul(p), op);
  }
}

static Val p_concat(Ps *p) {
  Val v = p_add(p);
  for (;;) {
    skip(p);
    if (p->s[p->i] != '&') return v;
    p->i++;
    Val b = p_add(p);
    if (v.t == V_ERR) continue;
    if (b.t == V_ERR) {
      v = b;
      continue;
    }
    char x[120], y[120];
    str_of(v, x, sizeof x);
    str_of(b, y, sizeof y);
    cat(x, sizeof x, y);
    v = vstr(x);
  }
}

static int val_cmp(Val a, Val b) {
  if ((a.t == V_NUM || a.t == V_BOOL || a.t == V_EMPTY) && (b.t == V_NUM || b.t == V_BOOL || b.t == V_EMPTY)) {
    double x = a.t == V_EMPTY ? 0 : a.n, y = b.t == V_EMPTY ? 0 : b.n;
    return x < y ? -1 : x > y;
  }
  char x[120], y[120];
  str_of(a, x, sizeof x);
  str_of(b, y, sizeof y);
  if ((a.t == V_NUM) != (b.t == V_NUM) && a.t != V_EMPTY && b.t != V_EMPTY) return a.t == V_NUM ? -1 : 1;
  return strcasecmp(x, y);
}

static Val p_expr(Ps *p) {
  Val v = p_concat(p);
  for (;;) {
    skip(p);
    const char *s = p->s + p->i;
    int op = 0, l = 1;
    if (!strncmp(s, "<>", 2)) op = 1, l = 2;
    else if (!strncmp(s, ">=", 2)) op = 2, l = 2;
    else if (!strncmp(s, "<=", 2)) op = 3, l = 2;
    else if (*s == '>') op = 4;
    else if (*s == '<') op = 5;
    else if (*s == '=') op = 6;
    if (!op) return v;
    p->i += l;
    Val b = p_concat(p);
    if (v.t == V_ERR) continue;
    if (b.t == V_ERR) {
      v = b;
      continue;
    }
    int c = val_cmp(v, b);
    int r = op == 1 ? c != 0 : op == 2 ? c >= 0 : op == 3 ? c <= 0 : op == 4 ? c > 0 : op == 5 ? c < 0 : c == 0;
    v = vbool(r);
  }
}

static Val eval_src(const char *src) {
  if (!src || !*src) return (Val){V_EMPTY, 0, ""};
  if (src[0] == '=') {
    Ps p = {src + 1, 0};
    Val v = p_expr(&p);
    skip(&p);
    if (p.s[p.i] && v.t != V_ERR) return verr("#ERROR!");
    return v;
  }
  double d;
  if (parse_number(src, &d, NULL)) return vnum(d);
  if (!strcasecmp(src, "TRUE")) return vbool(1);
  if (!strcasecmp(src, "FALSE")) return vbool(0);
  return vstr(src);
}

static Val cell_val(int c, int r) {
  if (c < 0 || r < 0 || c >= MAXC || r >= MAXR) return verr("#REF!");
  Cell *x = G[r][c];
  if (!x || !x->src) return (Val){V_EMPTY, 0, ""};
  if (x->gen == GEN) return x->v;
  if (x->busy) return verr("#CIRC!");
  x->busy = 1;
  Val v = eval_src(x->src);
  x->busy = 0;
  x->v = v;
  x->gen = GEN;
  return v;
}

static void group3(double v, int dec, char *out, int n) {
  char b[64];
  snprintf(b, sizeof b, "%.*f", dec, fabs(v));
  char *dot = strchr(b, '.');
  int il = dot ? (int)(dot - b) : (int)strlen(b);
  char o[96];
  int k = 0;
  if (v < 0 && strtod(b, NULL) != 0) o[k++] = '-';
  for (int i = 0; i < il; i++) {
    if (i && (il - i) % 3 == 0) o[k++] = ',';
    o[k++] = b[i];
  }
  if (dot) {
    int l = (int)strlen(dot);
    memcpy(o + k, dot, (size_t)l);
    k += l;
  }
  o[k] = 0;
  snprintf(out, (size_t)n, "%s", o);
}

static void fmt_val(Cell *x, Val v, char *out, int n) {
  if (v.t == V_EMPTY) {
    out[0] = 0;
    return;
  }
  if (v.t != V_NUM) {
    str_of(v, out, n);
    return;
  }
  int fm = x ? x->fmt : FM_GEN, dec = x && x->dec != 255 ? x->dec : -1;
  if (fm == FM_NUM) group3(v.n, dec < 0 ? 2 : dec, out, n);
  else if (fm == FM_CUR) {
    char b[96];
    group3(v.n, dec < 0 ? 2 : dec, b, sizeof b);
    if (b[0] == '-') snprintf(out, (size_t)n, "-$%s", b + 1);
    else snprintf(out, (size_t)n, "$%s", b);
  } else if (fm == FM_PCT) {
    snprintf(out, (size_t)n, "%.*f%%", dec < 0 ? 0 : dec, v.n * 100);
  } else if (dec >= 0) {
    snprintf(out, (size_t)n, "%.*f", dec, v.n);
  } else {
    double a = fabs(v.n);
    if (a != 0 && (a >= 1e15 || a < 1e-9)) snprintf(out, (size_t)n, "%.6g", v.n);
    else snprintf(out, (size_t)n, "%.10g", v.n);
  }
}

static int shift_formula(const char *src, char *out, int cap, int mode, int a, int b) {
  int k = 0, instr = 0;
  const char *s = src;
  for (int i = 0; s[i] && k < cap - 8;) {
    char ch = s[i];
    if (ch == '"') instr = !instr;
    int start_ok = !instr && i > 0 && !(isalnum((unsigned char)s[i - 1]) || s[i - 1] == '_' || s[i - 1] == '.');
    if (start_ok && (ch == '$' || isalpha((unsigned char)ch))) {
      Ps p = {s, i};
      int c, r, ac, ar;
      if (parse_ref(&p, &c, &r, &ac, &ar)) {
        int bad = 0;
        if (mode == 0) {
          if (!ac) c += a;
          if (!ar) r += b;
        } else if (mode == 1) {
          if (r >= a) r += b;
        } else if (mode == 2) {
          if (c >= a) c += b;
        } else if (mode == 3) {
          if (r >= a && r < a + b) bad = 1;
          else if (r >= a + b) r -= b;
        } else if (mode == 4) {
          if (c >= a && c < a + b) bad = 1;
          else if (c >= a + b) c -= b;
        }
        if (bad || c < 0 || r < 0 || c >= MAXC || r >= MAXR) {
          k += snprintf(out + k, (size_t)(cap - k), "#REF!");
        } else {
          char cn[4];
          col_name(c, cn);
          k += snprintf(out + k, (size_t)(cap - k), "%s%s%s%d", ac ? "$" : "", cn, ar ? "$" : "", r + 1);
        }
        i = p.i;
        continue;
      }
    }
    out[k++] = ch;
    i++;
  }
  out[k] = 0;
  return k;
}

static void shift_all(int mode, int a, int b) {
  char buf[1024];
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++) {
      Cell *x = G[r][c];
      if (!x || !x->src || x->src[0] != '=') continue;
      shift_formula(x->src, buf, sizeof buf, mode, a, b);
      free(x->src);
      x->src = strdup(buf);
    }
  GEN++;
}

static void sheets_dir(char *out, size_t n) { office_dirs(out, n, "Sheets", "OREONVR_SHEETS_DIR"); }

static void sheet_path(const char *id, char *out, size_t n) {
  char d[512];
  sheets_dir(d, sizeof d);
  snprintf(out, n, "%s/%s.osheet", d, id);
}

static char *serialize(void) {
  size_t cap = 4096, k = 0;
  char *s = malloc(cap);
#define PUT(...)                                                    \
  do {                                                              \
    int need = snprintf(NULL, 0, __VA_ARGS__);                      \
    while (k + (size_t)need + 1 >= cap) cap *= 2, s = realloc(s, cap); \
    k += (size_t)sprintf(s + k, __VA_ARGS__);                       \
  } while (0)
  PUT("SHEET1\ntitle\t%s\n", S.title);
  for (int c = 0; c < MAXC; c++)
    if (CW[c] != DEF_CW) PUT("w\t%d\t%d\n", c, CW[c]);
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++) {
      Cell *x = G[r][c];
      if (!x) continue;
      PUT("c\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n", c, r, x->bold, x->ital, x->strike, x->align, x->color,
          x->fill, x->fmt, x->dec, x->src ? x->src : "");
    }
#undef PUT
  return s;
}

static void deserialize(const char *src) {
  sheet_clear();
  S.title[0] = 0;
  const char *s = src;
  while (s && *s) {
    const char *e = strchr(s, '\n');
    int len = e ? (int)(e - s) : (int)strlen(s);
    char line[1200];
    snprintf(line, sizeof line, "%.*s", len, s);
    if (!strncmp(line, "title\t", 6)) snprintf(S.title, sizeof S.title, "%.95s", line + 6);
    else if (line[0] == 'w' && line[1] == '\t') {
      int c, w;
      if (sscanf(line + 2, "%d %d", &c, &w) == 2 && c >= 0 && c < MAXC && w >= 30 && w <= 600) CW[c] = w;
    } else if (line[0] == 'c' && line[1] == '\t') {
      int v[12], k = 0;
      char *q = line + 2;
      while (k < 12) {
        char *t;
        long x = strtol(q, &t, 10);
        if (t == q || *t != '\t') break;
        v[k++] = (int)x;
        q = t + 1;
      }
      if (k == 10 && v[0] >= 0 && v[0] < MAXC && v[1] >= 0 && v[1] < MAXR) {
        Cell *x = cell_mk(v[0], v[1]);
        x->bold = (unsigned char)v[2], x->ital = (unsigned char)v[3], x->strike = (unsigned char)v[4];
        x->align = (unsigned char)(v[5] & 3), x->color = (unsigned char)(v[6] & 7), x->fill = (unsigned char)(v[7] & 7);
        x->fmt = (unsigned char)(v[8] & 3), x->dec = (unsigned char)v[9];
        free(x->src);
        x->src = *q ? strdup(q) : NULL;
      }
    }
    s += len + (e ? 1 : 0);
  }
  if (!S.title[0]) snprintf(S.title, sizeof S.title, "Untitled spreadsheet");
  GEN++;
}

static void scan_list(void) {
  S.nlist = 0;
  char d[512];
  sheets_dir(d, sizeof d);
  DIR *dir = opendir(d);
  if (!dir) return;
  struct dirent *e;
  while ((e = readdir(dir)) && S.nlist < MAXSHEETS) {
    size_t l = strlen(e->d_name);
    if (l < 8 || strcmp(e->d_name + l - 7, ".osheet")) continue;
    SheetInfo *si = &S.list[S.nlist];
    snprintf(si->id, sizeof si->id, "%.*s", (int)(l - 7), e->d_name);
    char path[700];
    sheet_path(si->id, path, sizeof path);
    struct stat st;
    si->mtime = stat(path, &st) ? 0 : (long)st.st_mtime;
    snprintf(si->title, sizeof si->title, "Untitled spreadsheet");
    si->npv = 0;
    char *body = office_read_file(path);
    if (body) {
      char *q = body;
      while (*q) {
        char *nl = strchr(q, '\n');
        int len = nl ? (int)(nl - q) : (int)strlen(q);
        if (!strncmp(q, "title\t", 6)) snprintf(si->title, sizeof si->title, "%.*s", len - 6 > 95 ? 95 : len - 6, q + 6);
        else if (q[0] == 'c' && q[1] == '\t' && si->npv < MAXPV) {
          int v[10];
          char *t = q + 2;
          int k = 0;
          while (k < 10) {
            char *u;
            long x = strtol(t, &u, 10);
            if (u == t) break;
            v[k++] = (int)x;
            t = u + 1;
          }
          if (k == 10 && v[0] < 6 && v[1] < 16 && t < q + len) {
            double dd;
            int isnum = *t == '=' || parse_number(t, &dd, NULL);
            si->pv[si->npv][0] = (unsigned char)v[0], si->pv[si->npv][1] = (unsigned char)v[1];
            si->pv[si->npv][2] = (unsigned char)(v[2] | (isnum << 1));
            si->pv[si->npv][3] = (unsigned char)v[7];
            si->npv++;
          }
        }
        q += len + (nl ? 1 : 0);
      }
      free(body);
    }
    S.nlist++;
  }
  closedir(dir);
  for (int i = 1; i < S.nlist; i++)
    for (int j = i; j > 0 && S.list[j].mtime > S.list[j - 1].mtime; j--) {
      SheetInfo t = S.list[j];
      S.list[j] = S.list[j - 1];
      S.list[j - 1] = t;
    }
}

static void save_sheet(void) {
  if (!S.id[0]) return;
  char d[512], path[700], tmp[720];
  sheets_dir(d, sizeof d);
  office_mkdirs(d);
  sheet_path(S.id, path, sizeof path);
  snprintf(tmp, sizeof tmp, "%s.tmp", path);
  char *s = serialize();
  FILE *f = fopen(tmp, "w");
  if (f) {
    fputs(s, f);
    fclose(f);
    rename(tmp, path);
  }
  free(s);
  S.dirty = 0;
}

void sheets_save_now(void) {
  if (S.editing) {
    S.editing = 0;
  }
  if (S.dirty) save_sheet();
}

static void clear_history(void) {
  for (int i = 0; i < S.nundo; i++) free(S.undo[i]);
  for (int i = 0; i < S.nredo; i++) free(S.redo[i]);
  S.nundo = S.nredo = 0;
}

static void export_xlsx(void);

static void reset_view(void) {
  S.ac = S.ar = S.bc = S.br = 0;
  S.sx = S.sy = 0;
  S.editing = 0;
  S.popup = 0;
  S.title_edit = 0;
  clear_history();
}

static void open_sheet(const char *idp) {
  char id[40];
  snprintf(id, sizeof id, "%s", idp);
  if (S.dirty) save_sheet();
  char path[700];
  sheet_path(id, path, sizeof path);
  char *body = office_read_file(path);
  snprintf(S.id, sizeof S.id, "%s", id);
  deserialize(body ? body : "");
  free(body);
  reset_view();
}

static void new_sheet(const char *title) {
  if (S.dirty) save_sheet();
  static int seq;
  snprintf(S.id, sizeof S.id, "sheet%ld%03d", (long)time(NULL), (seq++ + rand()) % 1000);
  sheet_clear();
  snprintf(S.title, sizeof S.title, "%s", title);
  reset_view();
  save_sheet();
}

static void changed(void) {
  S.dirty = 1;
  S.dirty_at = now_ms();
  GEN++;
}

static void push_undo(void) {
  if (S.nundo == MAXUNDO) {
    free(S.undo[0]);
    memmove(S.undo, S.undo + 1, sizeof(char *) * (MAXUNDO - 1));
    S.nundo--;
  }
  S.undo[S.nundo++] = serialize();
  for (int i = 0; i < S.nredo; i++) free(S.redo[i]);
  S.nredo = 0;
}

static void undo_redo(int redo) {
  char **from = redo ? S.redo : S.undo, **to = redo ? S.undo : S.redo;
  int *nf = redo ? &S.nredo : &S.nundo, *nt = redo ? &S.nundo : &S.nredo;
  if (!*nf) return;
  if (*nt == MAXUNDO) {
    free(to[0]);
    memmove(to, to + 1, sizeof(char *) * (MAXUNDO - 1));
    (*nt)--;
  }
  to[(*nt)++] = serialize();
  char *s = from[--(*nf)];
  char title[96];
  snprintf(title, sizeof title, "%s", S.title);
  deserialize(s);
  snprintf(S.title, sizeof S.title, "%s", title);
  free(s);
  changed();
}

typedef struct {
  const char *ref, *src;
  int st;
} TCell;

enum { TB = 1, TI = 2, TCUR = 4, TPCT = 8, TNUM = 16, TCEN = 32, TRIGHT = 64 };
#define TFILL(n) ((n) << 8)
#define TCOL(n) ((n) << 12)

typedef struct {
  const char *name, *title;
  const TCell *cells;
  int n;
  const int *widths;
} STpl;

static const TCell TP_BUDGET[] = {
    {"A1", "Monthly budget", TB}, {"A2", "Plan your month at a glance.", TI | TCOL(2)},
    {"A4", "Income", TB | TFILL(5)}, {"B4", "Amount", TB | TFILL(5) | TRIGHT}, {"C4", "", TFILL(5)},
    {"A5", "Salary", 0}, {"B5", "4200", TCUR}, {"A6", "Freelance", 0}, {"B6", "650", TCUR},
    {"A7", "Total income", TB}, {"B7", "=SUM(B5:B6)", TB | TCUR},
    {"A9", "Expenses", TB | TFILL(6)}, {"B9", "Amount", TB | TFILL(6) | TRIGHT}, {"C9", "% of income", TB | TFILL(6) | TRIGHT},
    {"A10", "Rent", 0}, {"B10", "1450", TCUR}, {"C10", "=B10/$B$7", TPCT},
    {"A11", "Groceries", 0}, {"B11", "520", TCUR}, {"C11", "=B11/$B$7", TPCT},
    {"A12", "Utilities", 0}, {"B12", "180", TCUR}, {"C12", "=B12/$B$7", TPCT},
    {"A13", "Transport", 0}, {"B13", "240", TCUR}, {"C13", "=B13/$B$7", TPCT},
    {"A14", "Dining out", 0}, {"B14", "210", TCUR}, {"C14", "=B14/$B$7", TPCT},
    {"A15", "Subscriptions", 0}, {"B15", "45", TCUR}, {"C15", "=B15/$B$7", TPCT},
    {"A16", "Savings", 0}, {"B16", "600", TCUR}, {"C16", "=B16/$B$7", TPCT},
    {"A17", "Total expenses", TB}, {"B17", "=SUM(B10:B16)", TB | TCUR}, {"C17", "=B17/$B$7", TB | TPCT},
    {"A19", "Left over", TB | TFILL(4)}, {"B19", "=B7-B17", TB | TCUR | TFILL(4)}, {"C19", "", TFILL(4)},
};
static const int W_BUDGET[] = {170, 120, 120, 0};

static const TCell TP_INVOICE[] = {
    {"A1", "INVOICE", TB | TCOL(6)}, {"D1", "Invoice #1042", TRIGHT},
    {"A2", "Bright Studio Ltd.", 0}, {"D2", "Date: May 14", TRIGHT},
    {"A3", "42 Market Street, Springfield", TCOL(2)}, {"D3", "Due: June 13", TRIGHT},
    {"A5", "Bill to", TB}, {"A6", "Harper & Co.", 0}, {"A7", "18 Lake Road, Riverton", TCOL(2)},
    {"A9", "Description", TB | TFILL(1)}, {"B9", "Qty", TB | TFILL(1) | TRIGHT}, {"C9", "Unit price", TB | TFILL(1) | TRIGHT},
    {"D9", "Amount", TB | TFILL(1) | TRIGHT},
    {"A10", "Website design", 0}, {"B10", "1", 0}, {"C10", "2400", TCUR}, {"D10", "=B10*C10", TCUR},
    {"A11", "Logo refresh", 0}, {"B11", "1", 0}, {"C11", "650", TCUR}, {"D11", "=B11*C11", TCUR},
    {"A12", "Photography (hours)", 0}, {"B12", "6", 0}, {"C12", "85", TCUR}, {"D12", "=B12*C12", TCUR},
    {"A13", "Hosting (months)", 0}, {"B13", "12", 0}, {"C13", "15", TCUR}, {"D13", "=B13*C13", TCUR},
    {"C15", "Subtotal", TRIGHT}, {"D15", "=SUM(D10:D13)", TCUR},
    {"C16", "Tax (8%)", TRIGHT}, {"D16", "=ROUND(D15*0.08,2)", TCUR},
    {"C17", "Total due", TB | TRIGHT}, {"D17", "=D15+D16", TB | TCUR | TFILL(6)},
    {"A19", "Thank you for your business.", TI | TCOL(2)},
};
static const int W_INVOICE[] = {210, 80, 120, 130, 0};

static const TCell TP_EXPENSES[] = {
    {"A1", "Expense tracker", TB},
    {"A3", "Date", TB | TFILL(3)}, {"B3", "Description", TB | TFILL(3)}, {"C3", "Category", TB | TFILL(3)},
    {"D3", "Amount", TB | TFILL(3) | TRIGHT},
    {"A4", "Jun 1", 0}, {"B4", "Coffee beans", 0}, {"C4", "Groceries", 0}, {"D4", "14.5", TCUR},
    {"A5", "Jun 2", 0}, {"B5", "Train ticket", 0}, {"C5", "Travel", 0}, {"D5", "32", TCUR},
    {"A6", "Jun 4", 0}, {"B6", "Weekly shop", 0}, {"C6", "Groceries", 0}, {"D6", "86.2", TCUR},
    {"A7", "Jun 5", 0}, {"B7", "Cinema", 0}, {"C7", "Fun", 0}, {"D7", "24", TCUR},
    {"A8", "Jun 8", 0}, {"B8", "Phone bill", 0}, {"C8", "Bills", 0}, {"D8", "45", TCUR},
    {"A9", "Jun 9", 0}, {"B9", "Taxi home", 0}, {"C9", "Travel", 0}, {"D9", "18.75", TCUR},
    {"A10", "Jun 12", 0}, {"B10", "Dinner with friends", 0}, {"C10", "Fun", 0}, {"D10", "58", TCUR},
    {"C12", "Total", TB | TRIGHT}, {"D12", "=SUM(D4:D10)", TB | TCUR},
    {"F3", "Category", TB | TFILL(5)}, {"G3", "Spent", TB | TFILL(5) | TRIGHT},
    {"F4", "Groceries", 0}, {"G4", "=SUMIF(C4:C10,F4,D4:D10)", TCUR},
    {"F5", "Travel", 0}, {"G5", "=SUMIF(C4:C10,F5,D4:D10)", TCUR},
    {"F6", "Fun", 0}, {"G6", "=SUMIF(C4:C10,F6,D4:D10)", TCUR},
    {"F7", "Bills", 0}, {"G7", "=SUMIF(C4:C10,F7,D4:D10)", TCUR},
};
static const int W_EXPENSES[] = {80, 170, 110, 100, 30, 110, 100, 0};

static const TCell TP_GRADES[] = {
    {"A1", "Grade book", TB}, {"A2", "Biology, Period 3", TI | TCOL(2)},
    {"A4", "Student", TB | TFILL(7)}, {"B4", "Test 1", TB | TFILL(7) | TRIGHT}, {"C4", "Test 2", TB | TFILL(7) | TRIGHT},
    {"D4", "Test 3", TB | TFILL(7) | TRIGHT}, {"E4", "Average", TB | TFILL(7) | TRIGHT}, {"F4", "Grade", TB | TFILL(7) | TCEN},
    {"A5", "Ava Thompson", 0}, {"B5", "92", 0}, {"C5", "88", 0}, {"D5", "95", 0},
    {"A6", "Liam Carter", 0}, {"B6", "78", 0}, {"C6", "84", 0}, {"D6", "80", 0},
    {"A7", "Mia Rodriguez", 0}, {"B7", "85", 0}, {"C7", "91", 0}, {"D7", "89", 0},
    {"A8", "Noah Kim", 0}, {"B8", "67", 0}, {"C8", "72", 0}, {"D8", "70", 0},
    {"A9", "Zoe Patel", 0}, {"B9", "98", 0}, {"C9", "95", 0}, {"D9", "99", 0},
    {"A11", "Class average", TB}, {"B11", "=AVERAGE(B5:B9)", TB}, {"C11", "=AVERAGE(C5:C9)", TB}, {"D11", "=AVERAGE(D5:D9)", TB},
    {"E11", "=AVERAGE(E5:E9)", TB},
};
static const int W_GRADES[] = {160, 80, 80, 80, 90, 80, 0};

static const TCell TP_SALES[] = {
    {"A1", "Sales report", TB}, {"A2", "First half of the year", TI | TCOL(2)},
    {"A4", "Month", TB | TFILL(6)}, {"B4", "Units sold", TB | TFILL(6) | TRIGHT}, {"C4", "Price", TB | TFILL(6) | TRIGHT},
    {"D4", "Revenue", TB | TFILL(6) | TRIGHT}, {"E4", "Growth", TB | TFILL(6) | TRIGHT},
    {"A5", "January", 0}, {"B5", "320", 0}, {"C5", "24", TCUR}, {"D5", "=B5*C5", TCUR},
    {"A6", "February", 0}, {"B6", "355", 0}, {"C6", "24", TCUR}, {"D6", "=B6*C6", TCUR}, {"E6", "=D6/D5-1", TPCT},
    {"A7", "March", 0}, {"B7", "410", 0}, {"C7", "24", TCUR}, {"D7", "=B7*C7", TCUR}, {"E7", "=D7/D6-1", TPCT},
    {"A8", "April", 0}, {"B8", "390", 0}, {"C8", "26", TCUR}, {"D8", "=B8*C8", TCUR}, {"E8", "=D8/D7-1", TPCT},
    {"A9", "May", 0}, {"B9", "465", 0}, {"C9", "26", TCUR}, {"D9", "=B9*C9", TCUR}, {"E9", "=D9/D8-1", TPCT},
    {"A10", "June", 0}, {"B10", "512", 0}, {"C10", "26", TCUR}, {"D10", "=B10*C10", TCUR}, {"E10", "=D10/D9-1", TPCT},
    {"A12", "Total", TB}, {"B12", "=SUM(B5:B10)", TB}, {"D12", "=SUM(D5:D10)", TB | TCUR},
    {"A13", "Best month", 0}, {"D13", "=MAX(D5:D10)", TCUR},
    {"A14", "Average month", 0}, {"D14", "=AVERAGE(D5:D10)", TCUR},
};
static const int W_SALES[] = {140, 100, 90, 120, 90, 0};

static const STpl STPLS[NSTPL] = {
    {"Blank spreadsheet", "Untitled spreadsheet", NULL, 0, NULL},
    {"Monthly budget", "Monthly budget", TP_BUDGET, sizeof TP_BUDGET / sizeof *TP_BUDGET, W_BUDGET},
    {"Invoice", "Invoice", TP_INVOICE, sizeof TP_INVOICE / sizeof *TP_INVOICE, W_INVOICE},
    {"Expense tracker", "Expense tracker", TP_EXPENSES, sizeof TP_EXPENSES / sizeof *TP_EXPENSES, W_EXPENSES},
    {"Grade book", "Grade book", TP_GRADES, sizeof TP_GRADES / sizeof *TP_GRADES, W_GRADES},
    {"Sales report", "Sales report", TP_SALES, sizeof TP_SALES / sizeof *TP_SALES, W_SALES},
};

static int ref_parse_str(const char *s, int *c, int *r) {
  Ps p = {s, 0};
  return parse_ref(&p, c, r, NULL, NULL);
}

int sheets_new_from_template(int t) {
  const STpl *tp = &STPLS[t];
  new_sheet(tp->title);
  if (tp->widths)
    for (int i = 0; tp->widths[i]; i++) CW[i] = tp->widths[i];
  for (int i = 0; i < tp->n; i++) {
    int c, r;
    if (!ref_parse_str(tp->cells[i].ref, &c, &r)) continue;
    Cell *x = cell_mk(c, r);
    int st = tp->cells[i].st;
    x->bold = (st & TB) != 0, x->ital = (st & TI) != 0;
    x->fmt = (st & TCUR) ? FM_CUR : (st & TPCT) ? FM_PCT : (st & TNUM) ? FM_NUM : FM_GEN;
    x->align = (st & TCEN) ? AL_CENTER : (st & TRIGHT) ? AL_RIGHT : AL_AUTO;
    x->fill = (unsigned char)((st >> 8) & 7), x->color = (unsigned char)((st >> 12) & 7);
    if (tp->cells[i].src[0]) x->src = strdup(tp->cells[i].src);
  }
  if (t == 4) {
    for (int r = 4; r <= 8; r++) {
      char b[160];
      snprintf(b, sizeof b, "=AVERAGE(B%d:D%d)", r + 1, r + 1);
      Cell *x = cell_mk(4, r);
      x->src = strdup(b);
      x->fmt = FM_NUM, x->dec = 1;
      snprintf(b, sizeof b, "=IF(E%d>=90,\"A\",IF(E%d>=80,\"B\",IF(E%d>=70,\"C\",\"D\")))", r + 1, r + 1, r + 1);
      x = cell_mk(5, r);
      x->src = strdup(b);
      x->align = AL_CENTER, x->bold = 1;
    }
    Cell *x = cell_mk(4, 10);
    x->fmt = FM_NUM, x->dec = 1;
    for (int c = 1; c <= 3; c++) cell_mk(c, 10)->fmt = FM_NUM, cell_mk(c, 10)->dec = 1;
  }
  GEN++;
  save_sheet();
  return 1;
}

static float col_x(int c) {
  float x = GRID_X + RH_W - S.sx;
  for (int i = 0; i < c; i++) x += CW[i];
  return x;
}

static float row_y(int r) { return GRID_Y + CH_H + r * ROW_H - S.sy; }

static float grid_r(void) { return OFF_W - GRID_X; }

static float grid_b(void) { return content_h() - GRID_BOT; }

static void sel_rect(int *c0, int *r0, int *c1, int *r1) {
  *c0 = S.ac < S.bc ? S.ac : S.bc, *c1 = S.ac < S.bc ? S.bc : S.ac;
  *r0 = S.ar < S.br ? S.ar : S.br, *r1 = S.ar < S.br ? S.br : S.ar;
}

static void ensure_visible(void) {
  float x0 = col_x(S.ac), x1 = x0 + CW[S.ac], y0 = row_y(S.ar), y1 = y0 + ROW_H;
  float left = GRID_X + RH_W, right = grid_r(), top = GRID_Y + CH_H, bot = grid_b();
  if (x0 < left) S.sx -= left - x0;
  if (x1 > right) S.sx += x1 - right;
  if (y0 < top) S.sy -= top - y0;
  if (y1 > bot) S.sy += y1 - bot;
  if (S.sx < 0) S.sx = 0;
  if (S.sy < 0) S.sy = 0;
}

static int hit_cell(float x, float y, int *c, int *r) {
  if (x < GRID_X + RH_W || y < GRID_Y + CH_H || x >= grid_r() || y >= grid_b()) return 0;
  float cx = GRID_X + RH_W - S.sx;
  int cc = 0;
  while (cc < MAXC - 1 && x >= cx + CW[cc]) cx += CW[cc], cc++;
  int rr = (int)floorf((y - (GRID_Y + CH_H) + S.sy) / ROW_H);
  if (rr < 0) rr = 0;
  if (rr >= MAXR) rr = MAXR - 1;
  *c = cc, *r = rr;
  return 1;
}

static int hit_col(float x) {
  float cx = GRID_X + RH_W - S.sx;
  for (int c = 0; c < MAXC; c++) {
    if (x >= cx && x < cx + CW[c]) return c;
    cx += CW[c];
  }
  return MAXC - 1;
}

static int resize_hit(float x) {
  float cx = GRID_X + RH_W - S.sx;
  for (int c = 0; c < MAXC; c++) {
    cx += CW[c];
    if (fabsf(x - cx) <= 5 && cx > GRID_X + RH_W + 4 && cx < grid_r()) return c;
  }
  return -1;
}

typedef struct {
  int id;
  float x, w;
} Tool;

static Tool tools[T_COUNT];
static float seps[10];
static int nseps;
static float pill_x, pill_w;

static void tool_layout(void) {
  static const int order[] = {T_UNDO, T_REDO, 0, T_CUR, T_PCT, T_DECM, T_DECP, T_GEN, 0, T_BOLD, T_ITAL, T_STRIKE,
                              T_COLOR, T_FILL, 0, T_ALEFT, T_ACENTER, T_ARIGHT, 0, T_SUM, T_SORTA, T_SORTD};
  float x = 0;
  nseps = 0;
  for (unsigned i = 0; i < sizeof order / sizeof *order; i++) {
    if (!order[i]) {
      seps[nseps++] = x + 5;
      x += 12;
      continue;
    }
    float w = order[i] == T_GEN ? 44 : 34;
    tools[order[i]] = (Tool){order[i], x, w};
    x += w + 3;
  }
  float off = (OFF_W - x) * 0.5f;
  for (int i = 1; i < T_COUNT; i++) tools[i].x += off;
  for (int i = 0; i < nseps; i++) seps[i] += off;
  pill_x = off - 10, pill_w = x + 20 - 3;
}

static float menu_x(int i) {
  float total = 0;
  for (int k = 0; k < 5; k++) total += gfx_text_w(F_UI, MENU_NAMES[k]) + 22;
  float x = OFF_W - 18 - total + 11;
  for (int k = 0; k < i; k++) x += gfx_text_w(F_UI, MENU_NAMES[k]) + 22;
  return x;
}

static void popup_rect(float *x, float *y, float *w, float *h) {
  if (S.popup >= POP_M0 && S.popup <= POP_M4) {
    int m = S.popup - POP_M0;
    *x = menu_x(m) - 10, *y = OFF_HEAD - 4, *w = 290;
    if (*x > OFF_W - 302) *x = OFF_W - 302;
    float hh = 8;
    for (int i = 0; i < MENU_LEN[m]; i++) hh += MENUS[m][i].label ? 34 : 9;
    *h = hh;
  } else {
    int t = S.popup == POP_COLOR ? T_COLOR : T_FILL;
    *x = tools[t].x - 8, *y = OFF_TOOL_Y + OFF_TOOL_H + 2, *w = 212, *h = 108;
  }
}

static int popup_zone(float x, float y) {
  float px, py, pw, ph;
  popup_rect(&px, &py, &pw, &ph);
  if (x < px || x >= px + pw || y < py || y >= py + ph) return -1;
  if (S.popup <= POP_M4) {
    int m = S.popup - POP_M0;
    float yy = py + 4;
    for (int i = 0; i < MENU_LEN[m]; i++) {
      float hh = MENUS[m][i].label ? 34 : 9;
      if (y >= yy && y < yy + hh) return MENUS[m][i].label ? Z_POPUP + i : 0;
      yy += hh;
    }
    return 0;
  }
  for (int i = 0; i < 8; i++) {
    float cx = px + 14 + (i % 4) * 48, cy = py + 40 + (i / 4) * 32;
    if (x >= cx - 2 && x < cx + 40 && y >= cy - 2 && y < cy + 28) return Z_POPUP + i;
  }
  return 0;
}

int sheets_zone(float x, float y) {
  if (S.popup) {
    int z = popup_zone(x, y);
    if (z >= 0) return z;
  }
  if (y < OFF_HEAD) {
    if (x >= 10 && x < 50 && y >= 8 && y < 48) return Z_HOME;
    if (x >= 56 && x < 56 + 420 && y >= 10 && y < 46) return Z_TITLE;
    for (int i = 0; i < 5; i++) {
      float mx = menu_x(i);
      if (x >= mx - 10 && x < mx + gfx_text_w(F_UI, MENU_NAMES[i]) + 10 && y >= 12 && y < 44) return Z_MENU + i;
    }
    return 0;
  }
  if (y >= OFF_TOOL_Y && y < OFF_TOOL_Y + OFF_TOOL_H && x >= pill_x && x < pill_x + pill_w) {
    for (int i = 1; i < T_COUNT; i++)
      if (x >= tools[i].x && x < tools[i].x + tools[i].w && y >= OFF_TOOL_Y + 5 && y < OFF_TOOL_Y + OFF_TOOL_H - 5) return i;
    return 0;
  }
  if (y >= FBAR_Y && y < FBAR_Y + FBAR_H && x >= GRID_X && x < grid_r()) return x < GRID_X + 96 ? Z_NAME : Z_FBAR;
  if (x >= GRID_X && x < grid_r() && y >= GRID_Y && y < grid_b()) {
    if (y < GRID_Y + CH_H) {
      if (x < GRID_X + RH_W) return Z_CORNER;
      if (resize_hit(x) >= 0) return Z_RESIZE;
      return Z_COLH;
    }
    if (x < GRID_X + RH_W) return Z_ROWH;
    int c0, r0, c1, r1;
    sel_rect(&c0, &r0, &c1, &r1);
    float hx = col_x(c1) + CW[c1], hy = row_y(r1) + ROW_H;
    if (!S.editing && fabsf(x - hx) <= 6 && fabsf(y - hy) <= 6) return Z_HANDLE;
    return Z_GRID;
  }
  return 0;
}

static uint32_t fill_col(int i) { return i ? (g_dark ? FILL_D[i] : FILL_L[i]) : 0; }

static void draw_text_clip(Surface *s, const Font *f, float x, float y, const char *t, uint32_t c, float maxx) {
  float cx = x;
  for (const char *q = t; *q; q++) {
    float w = doc_char_w(f, *q);
    if (cx + w > maxx) break;
    char ch[2] = {*q, 0};
    if (*q != ' ') gfx_text(s, f, cx, y, ch, c);
    cx += w;
  }
}

static float text_w(const Font *f, const char *t) {
  float w = 0;
  for (; *t; t++) w += doc_char_w(f, *t);
  return w;
}

static void draw_grid(Panel *p, Surface *s, float ox, float oy, int hot) {
  (void)p;
  float gx = ox + GRID_X, gy = oy + GRID_Y, gw = grid_r() - GRID_X, gh = grid_b() - GRID_Y;
  gfx_shadow(s, gx, gy + 4, gw, gh, 12, 18, RGBA(30, 28, 60, 30));
  gfx_rrect(s, gx - 1, gy - 1, gw + 2, gh + 2, 13, THEME(RGB(226, 224, 230), RGB(52, 54, 62)));
  gfx_rrect(s, gx, gy, gw, gh, 12, N_PAGE);
  float bx = gx + RH_W, by = gy + CH_H;
  uint32_t line = THEME(RGB(234, 233, 236), RGB(48, 50, 58)), ink = THEME(RGB(32, 33, 36), RGB(230, 232, 236));
  gfx_clip(s, bx, by, gw - RH_W, gh - CH_H);
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  int rs = (int)(S.sy / ROW_H), re = rs + (int)((gh - CH_H) / ROW_H) + 2;
  if (re > MAXR) re = MAXR;
  int cs = 0;
  while (cs < MAXC - 1 && col_x(cs + 1) <= ox * 0 + GRID_X + RH_W) cs++;
  int ce = cs;
  while (ce < MAXC && col_x(ce) < grid_r()) ce++;
  for (int r = rs; r < re; r++)
    for (int c = cs; c < ce; c++) {
      Cell *x = G[r][c];
      if (x && x->fill) gfx_rect(s, ox + col_x(c), oy + row_y(r), CW[c], ROW_H, fill_col(x->fill));
    }
  for (int r = rs; r <= re; r++) gfx_rect(s, bx, oy + row_y(r) - 0.5f, gw - RH_W, 1, line);
  for (int c = cs; c <= ce && c <= MAXC; c++) gfx_rect(s, ox + col_x(c) - 0.5f, by, 1, gh - CH_H, line);
  if (c0 != c1 || r0 != r1) {
    float x0 = ox + col_x(c0), y0 = oy + row_y(r0), x1 = ox + col_x(c1) + CW[c1], y1 = oy + row_y(r1) + ROW_H;
    gfx_rect(s, x0, y0, x1 - x0, y1 - y0, S_SEL);
  }
  for (int r = rs; r < re; r++) {
    float y = oy + row_y(r);
    for (int c = cs; c < ce; c++) {
      Cell *x = G[r][c];
      if (!x || !x->src) continue;
      if (S.editing && c == S.ac && r == S.ar) continue;
      Val v = cell_val(c, r);
      char t[160];
      fmt_val(x, v, t, sizeof t);
      if (!t[0]) continue;
      const Font *f = doc_font(0, x->bold, x->ital);
      int al = x->align;
      if (al == AL_AUTO) al = v.t == V_NUM ? AL_RIGHT : (v.t == V_BOOL || v.t == V_ERR) ? AL_CENTER : AL_LEFT;
      float cx = ox + col_x(c), cw = CW[c], tw = text_w(f, t);
      float maxx = cx + cw - 4;
      if (al == AL_LEFT && tw > cw - 12) {
        int k = c + 1;
        while (k < MAXC && (!G[r][k] || !G[r][k]->src) && maxx < ox + grid_r()) {
          maxx += CW[k];
          k++;
          if (maxx - cx > tw + 14) break;
        }
      }
      float tx = al == AL_RIGHT ? cx + cw - 7 - tw : al == AL_CENTER ? cx + (cw - tw) / 2 : cx + 7;
      if (v.t == V_NUM && tw > cw - 10 && al != AL_LEFT) {
        strcpy(t, "###");
        tw = text_w(f, t);
        tx = cx + cw - 7 - tw;
      }
      if (tx < cx + 3) tx = cx + 3;
      uint32_t col = x->color ? OFF_COLORS[x->color] : ink;
      if (g_dark && x->color == 1) col = ink;
      if (v.t == V_ERR) col = RGB(217, 48, 37);
      float ty = y + (ROW_H - line_h(f)) / 2;
      draw_text_clip(s, f, tx, ty, t, col, al == AL_LEFT ? maxx : cx + cw - 2);
      if (x->strike) gfx_rect(s, tx, ty + (float)f->ascent / SCALE * 0.66f, (tw < maxx - tx ? tw : maxx - tx), 1.2f, col);
    }
  }
  if (S.filling) {
    int fc0 = c0 < S.fill_c ? c0 : S.fill_c, fc1 = c1 > S.fill_c ? c1 : S.fill_c;
    int fr0 = r0 < S.fill_r ? r0 : S.fill_r, fr1 = r1 > S.fill_r ? r1 : S.fill_r;
    if (S.filling == 1) fc0 = c0, fc1 = c1;
    else fr0 = r0, fr1 = r1;
    float x0 = ox + col_x(fc0), y0 = oy + row_y(fr0), x1 = ox + col_x(fc1) + CW[fc1], y1 = oy + row_y(fr1) + ROW_H;
    for (float xx = x0; xx < x1; xx += 8) gfx_rect(s, xx, y0 - 1, 4, 1.5f, S_ACC), gfx_rect(s, xx, y1 - 1, 4, 1.5f, S_ACC);
    for (float yy = y0; yy < y1; yy += 8) gfx_rect(s, x0 - 1, yy, 1.5f, 4, S_ACC), gfx_rect(s, x1 - 1, yy, 1.5f, 4, S_ACC);
  }
  {
    float x0 = ox + col_x(c0), y0 = oy + row_y(r0), x1 = ox + col_x(c1) + CW[c1], y1 = oy + row_y(r1) + ROW_H;
    gfx_rect(s, x0 - 1, y0 - 1, x1 - x0 + 2, 2, S_ACC);
    gfx_rect(s, x0 - 1, y1 - 1, x1 - x0 + 2, 2, S_ACC);
    gfx_rect(s, x0 - 1, y0 - 1, 2, y1 - y0 + 2, S_ACC);
    gfx_rect(s, x1 - 1, y0 - 1, 2, y1 - y0 + 2, S_ACC);
    float ax = ox + col_x(S.ac), ay = oy + row_y(S.ar);
    if (c0 != c1 || r0 != r1) {
      gfx_rect(s, ax + 1, ay + 1, CW[S.ac] - 2, ROW_H - 2, N_PAGE);
      Cell *x = G[S.ar][S.ac];
      if (x && x->fill) gfx_rect(s, ax + 1, ay + 1, CW[S.ac] - 2, ROW_H - 2, fill_col(x->fill));
      if (x && x->src && !S.editing) {
        Val v = cell_val(S.ac, S.ar);
        char t[160];
        fmt_val(x, v, t, sizeof t);
        const Font *f = doc_font(0, x->bold, x->ital);
        int al = x->align;
        if (al == AL_AUTO) al = v.t == V_NUM ? AL_RIGHT : (v.t == V_BOOL || v.t == V_ERR) ? AL_CENTER : AL_LEFT;
        float tw = text_w(f, t), cw = CW[S.ac];
        float tx = al == AL_RIGHT ? ax + cw - 7 - tw : al == AL_CENTER ? ax + (cw - tw) / 2 : ax + 7;
        if (tx < ax + 3) tx = ax + 3;
        uint32_t col = x->color && !(g_dark && x->color == 1) ? OFF_COLORS[x->color] : ink;
        draw_text_clip(s, f, tx, ay + (ROW_H - line_h(f)) / 2, t, v.t == V_ERR ? RGB(217, 48, 37) : col, ax + cw - 2);
      }
      gfx_rect(s, ax - 1, ay - 1, CW[S.ac] + 2, 2, S_ACC);
      gfx_rect(s, ax - 1, ay + ROW_H - 1, CW[S.ac] + 2, 2, S_ACC);
      gfx_rect(s, ax - 1, ay - 1, 2, ROW_H + 2, S_ACC);
      gfx_rect(s, ax + CW[S.ac] - 1, ay - 1, 2, ROW_H + 2, S_ACC);
    }
    if (!S.editing) {
      gfx_rect(s, x1 - 4, y1 - 4, 8, 8, N_PAGE);
      gfx_rect(s, x1 - 3, y1 - 3, 6, 6, S_ACC);
      if (hot == Z_HANDLE) gfx_ring(s, x1, y1, 6, 1.4f, S_ACC);
    }
  }
  if (S.editing) {
    Cell *x = G[S.ar][S.ac];
    const Font *f = doc_font(0, x && x->bold, x && x->ital);
    float ax = ox + col_x(S.ac), ay = oy + row_y(S.ar);
    float tw = text_w(f, S.ebuf), w = CW[S.ac];
    if (tw + 16 > w) w = tw + 16;
    gfx_shadow(s, ax, ay + 2, w, ROW_H, 4, 8, RGBA(0, 0, 0, 40));
    gfx_rect(s, ax - 1, ay - 1, w + 2, ROW_H + 2, S_ACC);
    gfx_rect(s, ax + 1, ay + 1, w - 2, ROW_H - 2, N_PAGE);
    float ty = ay + (ROW_H - line_h(f)) / 2;
    float cx = ax + 7;
    for (int i = 0; i < S.elen; i++) {
      char ch[2] = {S.ebuf[i], 0};
      if (S.ebuf[i] != ' ') gfx_text(s, f, cx, ty, ch, ink);
      cx += doc_char_w(f, S.ebuf[i]);
    }
    if (S.blink) {
      float kx = ax + 7;
      for (int i = 0; i < S.ecur; i++) kx += doc_char_w(f, S.ebuf[i]);
      gfx_rect(s, kx, ay + 5, 1.6f, ROW_H - 10, S_ACC);
    }
  }
  gfx_noclip(s);
  uint32_t hbg = THEME(RGB(248, 247, 245), RGB(30, 32, 38)), htx = THEME(RGB(110, 112, 120), RGB(150, 154, 164));
  gfx_clip(s, gx, gy, gw, CH_H);
  gfx_rrect(s, gx, gy, gw, CH_H + 12, 12, hbg);
  gfx_clip(s, bx, gy, gw - RH_W, CH_H);
  for (int c = cs; c < ce; c++) {
    float x = ox + col_x(c);
    int on = c >= c0 && c <= c1;
    if (on) gfx_rect(s, x, gy, CW[c], CH_H, S_TINT);
    if (on) gfx_rect(s, x, gy + CH_H - 2, CW[c], 2, S_ACC);
    char n[4];
    col_name(c, n);
    gfx_text_c(s, F_SMALL, x + CW[c] / 2, gy + (CH_H - line_h(F_SMALL)) / 2, n, on ? S_ACC : htx);
    gfx_rect(s, x + CW[c] - 0.5f, gy + 6, 1, CH_H - 12, line);
  }
  if (hot == Z_RESIZE || S.resize_col >= 0) {
    int rc = S.resize_col >= 0 ? S.resize_col : resize_hit(W.hs);
    if (rc >= 0) gfx_rect(s, ox + col_x(rc) + CW[rc] - 1.5f, gy + 3, 3, CH_H - 6, S_ACC);
  }
  gfx_noclip(s);
  gfx_clip(s, gx, by, RH_W, gh - CH_H);
  gfx_rect(s, gx, by, RH_W, gh - CH_H, hbg);
  for (int r = rs; r < re; r++) {
    float y = oy + row_y(r);
    int on = r >= r0 && r <= r1;
    if (on) gfx_rect(s, gx, y, RH_W, ROW_H, S_TINT);
    if (on) gfx_rect(s, gx + RH_W - 2, y, 2, ROW_H, S_ACC);
    char n[16];
    snprintf(n, sizeof n, "%d", r + 1);
    gfx_text_c(s, F_SMALL, gx + RH_W / 2, y + (ROW_H - line_h(F_SMALL)) / 2, n, on ? S_ACC : htx);
    gfx_rect(s, gx + 6, y + ROW_H - 0.5f, RH_W - 12, 1, line);
  }
  gfx_noclip(s);
  gfx_rect(s, gx, by - 0.5f, gw, 1, line);
  gfx_rect(s, bx - 0.5f, gy, 1, gh, line);
  if (hot == Z_CORNER) gfx_rrect(s, gx + 4, gy + 4, RH_W - 8, CH_H - 8, 6, N_TINT_HOT);
  gfx_tri(s, bx - 6, by - 14, bx - 6, by - 6, bx - 14, by - 6, htx);
}

static void icon_lines(Surface *s, float cx, float cy, int align, uint32_t c) {
  float ws[4] = {16, 11, 16, 11};
  for (int i = 0; i < 4; i++) {
    float w = ws[i], x0 = align == AL_LEFT ? cx - 8 : align == AL_CENTER ? cx - w / 2 : cx + 8 - w;
    gfx_rect(s, x0, cy - 7 + i * 4.6f, w, 1.8f, c);
  }
}

static int active_flag(int t) {
  Cell *x = G[S.ar][S.ac];
  if (!x) return 0;
  switch (t) {
  case T_BOLD: return x->bold;
  case T_ITAL: return x->ital;
  case T_STRIKE: return x->strike;
  case T_CUR: return x->fmt == FM_CUR;
  case T_PCT: return x->fmt == FM_PCT;
  case T_ALEFT: return x->align == AL_LEFT;
  case T_ACENTER: return x->align == AL_CENTER;
  case T_ARIGHT: return x->align == AL_RIGHT;
  }
  return 0;
}

static void draw_tool(Surface *s, int id, float ox, float oy, int hot) {
  Tool *t = &tools[id];
  float x = ox + t->x, y = oy + OFF_TOOL_Y + 5, h = OFF_TOOL_H - 10, cx = x + t->w / 2, cy = y + h / 2;
  int active = active_flag(id) || (id == T_COLOR && S.popup == POP_COLOR) || (id == T_FILL && S.popup == POP_FILL);
  uint32_t ic = active ? S_ACC : N_ICON;
  if (active) gfx_rrect(s, x, y, t->w, h, 9, S_TINT);
  else if (hot) gfx_rrect(s, x, y, t->w, h, 9, N_TINT_HOT);
  const Font *df = doc_font(0, 0, 0), *bf = doc_font(0, 1, 0), *itf = doc_font(0, 0, 1);
  float ty = y + (h - line_h(df)) / 2;
  switch (id) {
  case T_UNDO:
  case T_REDO: {
    float d = id == T_UNDO ? 1.f : -1.f, r = 6.f, acx = cx + d * 1.f, acy = cy + 3.f;
    for (int i = 0; i < 10; i++) {
      float a0 = PI_F + PI_F * i / 10.f, a1 = PI_F + PI_F * (i + 1) / 10.f;
      gfx_line(s, acx + cosf(a0) * r * d, acy + sinf(a0) * r, acx + cosf(a1) * r * d, acy + sinf(a1) * r, 1.7f, ic);
    }
    float hx = acx - d * r, hy = acy;
    gfx_line(s, hx, hy + 0.6f, hx - d * 3.4f, hy - 3.4f, 1.7f, ic);
    gfx_line(s, hx, hy + 0.6f, hx + d * 3.6f, hy - 3.0f, 1.7f, ic);
    break;
  }
  case T_CUR: gfx_text_c(s, df, cx, ty, "$", ic); break;
  case T_PCT: gfx_text_c(s, df, cx, ty, "%", ic); break;
  case T_DECM:
    gfx_text(s, F_SMALL, cx - 11, cy - line_h(F_SMALL) / 2, ".0", ic);
    gfx_line(s, cx + 4, cy + 7, cx + 10, cy + 7, 1.4f, ic);
    gfx_line(s, cx + 4, cy + 7, cx + 6.5f, cy + 5, 1.4f, ic);
    break;
  case T_DECP:
    gfx_text(s, F_SMALL, cx - 12, cy - line_h(F_SMALL) / 2, ".00", ic);
    gfx_line(s, cx + 4, cy + 7, cx + 10, cy + 7, 1.4f, ic);
    gfx_line(s, cx + 10, cy + 7, cx + 7.5f, cy + 5, 1.4f, ic);
    break;
  case T_GEN: gfx_text_c(s, F_UI_MED, cx, cy - line_h(F_UI_MED) / 2, "123", ic); break;
  case T_BOLD: gfx_text_c(s, bf, cx, ty, "B", ic); break;
  case T_ITAL: gfx_text_c(s, itf, cx, ty, "I", ic); break;
  case T_STRIKE:
    gfx_text_c(s, df, cx, ty, "S", ic);
    gfx_rect(s, cx - 7, cy, 14, 1.6f, ic);
    break;
  case T_COLOR: {
    gfx_text_c(s, df, cx, ty - 3, "A", ic);
    Cell *x = G[S.ar][S.ac];
    int c = x ? x->color : 0;
    gfx_rect(s, cx - 8, cy + 8, 16, 3, c ? OFF_COLORS[c] : N_ICON);
    break;
  }
  case T_FILL: {
    gfx_line(s, cx - 6, cy - 1, cx, cy - 7, 1.6f, ic);
    gfx_line(s, cx, cy - 7, cx + 6, cy - 1, 1.6f, ic);
    gfx_line(s, cx + 6, cy - 1, cx, cy + 5, 1.6f, ic);
    gfx_line(s, cx, cy + 5, cx - 6, cy - 1, 1.6f, ic);
    Cell *x = G[S.ar][S.ac];
    int c = x ? x->fill : 0;
    gfx_rect(s, cx - 8, cy + 8, 16, 3, c ? FILL_D[c] : THEME(RGB(200, 200, 206), RGB(90, 92, 100)));
    break;
  }
  case T_ALEFT: icon_lines(s, cx, cy, AL_LEFT, ic); break;
  case T_ACENTER: icon_lines(s, cx, cy, AL_CENTER, ic); break;
  case T_ARIGHT: icon_lines(s, cx, cy, AL_RIGHT, ic); break;
  case T_SUM:
    gfx_line(s, cx + 6, cy - 8, cx - 6, cy - 8, 1.8f, ic);
    gfx_line(s, cx - 6, cy - 8, cx + 1, cy, 1.8f, ic);
    gfx_line(s, cx + 1, cy, cx - 6, cy + 8, 1.8f, ic);
    gfx_line(s, cx - 6, cy + 8, cx + 6, cy + 8, 1.8f, ic);
    break;
  case T_SORTA:
  case T_SORTD: {
    gfx_text(s, F_SMALL, cx - 11, cy - 11, id == T_SORTA ? "A" : "Z", ic);
    gfx_text(s, F_SMALL, cx - 11, cy - 1, id == T_SORTA ? "Z" : "A", ic);
    gfx_line(s, cx + 5, cy - 8, cx + 5, cy + 8, 1.5f, ic);
    gfx_line(s, cx + 5, cy + 8, cx + 2, cy + 4.5f, 1.5f, ic);
    gfx_line(s, cx + 5, cy + 8, cx + 8, cy + 4.5f, 1.5f, ic);
    break;
  }
  }
}

static void draw_popup(Surface *s, float ox, float oy, int hot) {
  float px, py, pw, ph;
  popup_rect(&px, &py, &pw, &ph);
  px += ox, py += oy;
  gfx_shadow(s, px, py + 6, pw, ph, 14, 22, RGBA(30, 28, 60, 50));
  gfx_rrect(s, px - 1, py - 1, pw + 2, ph + 2, 15, THEME(RGB(230, 228, 236), RGB(58, 60, 68)));
  gfx_rrect(s, px, py, pw, ph, 14, THEME(RGB(255, 255, 255), RGB(40, 42, 50)));
  if (S.popup <= POP_M4) {
    int m = S.popup - POP_M0;
    float y = py + 4;
    for (int i = 0; i < MENU_LEN[m]; i++) {
      const Item *it = &MENUS[m][i];
      if (!it->label) {
        gfx_rect(s, px + 10, y + 4, pw - 20, 1, N_LINE);
        y += 9;
        continue;
      }
      if (hot == Z_POPUP + i) gfx_rrect(s, px + 6, y + 1, pw - 12, 32, 8, N_TINT_HOT);
      gfx_text(s, F_UI, px + 18, y + (34 - line_h(F_UI)) / 2, it->label, C_TEXT);
      if (it->key[0]) gfx_text(s, F_SMALL, px + pw - 14 - gfx_text_w(F_SMALL, it->key), y + (34 - line_h(F_SMALL)) / 2, it->key, C_MUTED);
      y += 34;
    }
    return;
  }
  int fill = S.popup == POP_FILL;
  gfx_text(s, F_SMALL, px + 14, py + 12, fill ? "Fill color" : "Text color", C_MUTED);
  Cell *x = G[S.ar][S.ac];
  int cur = x ? (fill ? x->fill : x->color) : 0;
  for (int i = 0; i < 8; i++) {
    float cx = px + 14 + (i % 4) * 48, cy = py + 40 + (i / 4) * 32;
    if (hot == Z_POPUP + i) gfx_rrect(s, cx - 3, cy - 3, 46, 30, 7, N_TINT_HOT);
    if (i == 0) {
      gfx_rrect(s, cx, cy, 40, 24, 6, C_WIN_EDGE);
      gfx_rrect(s, cx + 1.5f, cy + 1.5f, 37, 21, 5, THEME(RGB(255, 255, 255), RGB(40, 42, 50)));
      gfx_line(s, cx + 4, cy + 20, cx + 36, cy + 4, 1.4f, RGB(217, 48, 37));
    } else gfx_rrect(s, cx, cy, 40, 24, 6, fill ? fill_col(i) : OFF_COLORS[i]);
    if (cur == i) gfx_ring(s, cx + 20, cy + 12, 5, 1.6f, fill || !i ? C_TEXT : RGB(255, 255, 255));
  }
}

static void sel_stats(double *sum, int *cnt, int *nums) {
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  *sum = 0, *cnt = 0, *nums = 0;
  for (int r = r0; r <= r1; r++)
    for (int c = c0; c <= c1; c++) {
      if (!G[r][c] || !G[r][c]->src) continue;
      Val v = cell_val(c, r);
      if (v.t == V_EMPTY) continue;
      (*cnt)++;
      if (v.t == V_NUM) *sum += v.n, (*nums)++;
    }
}

void sheets_draw(Panel *p, Surface *s, float ox, float oy, int hot) {
  float ch = content_h();
  gfx_rect(s, ox, oy, OFF_W, ch, N_CANVAS);
  draw_grid(p, s, ox, oy, hot);
  gfx_rect(s, ox, oy, OFF_W, OFF_HEAD, N_HEAD);
  gfx_rect(s, ox, oy + OFF_HEAD - 1, OFF_W, 1, N_LINE);
  if (hot == Z_HOME) gfx_rrect(s, ox + 12, oy + 10, 36, 36, 10, N_TINT_HOT);
  gfx_line(s, ox + 33, oy + 20, ox + 26, oy + 28, 2.2f, N_ICON);
  gfx_line(s, ox + 26, oy + 28, ox + 33, oy + 36, 2.2f, N_ICON);
  if (S.title_edit) {
    float tw = gfx_text_w(F_UI_MED, S.title_buf), bw = tw + 28 > 260 ? tw + 28 : 260;
    gfx_rrect(s, ox + 56, oy + 12, bw, 32, 9, S_ACC);
    gfx_rrect(s, ox + 57.5f, oy + 13.5f, bw - 3, 29, 8, N_PAGE);
    gfx_text(s, F_UI_MED, ox + 68, oy + 28 - line_h(F_UI_MED) / 2, S.title_buf, C_TEXT);
    if (S.blink) gfx_rect(s, ox + 69 + tw, oy + 19, 1.6f, 18, S_ACC);
  } else {
    float tw = gfx_text_w(F_UI_MED, S.title);
    if (tw > 400) tw = 400;
    if (hot == Z_TITLE) gfx_rrect(s, ox + 56, oy + 12, tw + 24, 32, 9, N_TINT_HOT);
    gfx_text_fit(s, F_UI_MED, ox + 68, oy + 28 - line_h(F_UI_MED) / 2, 400, S.title, C_TEXT);
  }
  for (int i = 0; i < 5; i++) {
    float mx = ox + menu_x(i);
    int open = S.popup == POP_M0 + i;
    if (open || hot == Z_MENU + i) gfx_rrect(s, mx - 10, oy + 12, gfx_text_w(F_UI, MENU_NAMES[i]) + 20, 32, 9, open ? S_TINT : N_TINT_HOT);
    gfx_text(s, F_UI, mx, oy + 28 - line_h(F_UI) / 2, MENU_NAMES[i], open ? S_ACC : C_TEXT);
  }
  gfx_shadow(s, ox + pill_x, oy + OFF_TOOL_Y + 3, pill_w, OFF_TOOL_H, 22, 16, RGBA(30, 28, 60, 40));
  gfx_rrect(s, ox + pill_x - 1, oy + OFF_TOOL_Y - 1, pill_w + 2, OFF_TOOL_H + 2, 23, THEME(RGB(230, 228, 236), RGB(54, 56, 64)));
  gfx_rrect(s, ox + pill_x, oy + OFF_TOOL_Y, pill_w, OFF_TOOL_H, 22, N_PAGE);
  for (int i = 0; i < nseps; i++) gfx_rect(s, ox + seps[i], oy + OFF_TOOL_Y + 13, 1, OFF_TOOL_H - 26, THEME(RGB(226, 224, 230), RGB(66, 68, 76)));
  for (int i = 1; i < T_COUNT; i++) draw_tool(s, i, ox, oy, hot == i);
  float fx = ox + GRID_X, fy = oy + FBAR_Y, fw = grid_r() - GRID_X;
  gfx_rrect(s, fx - 1, fy - 1, fw + 2, FBAR_H + 2, 11, S.editing && S.emode ? S_ACC : THEME(RGB(226, 224, 230), RGB(52, 54, 62)));
  gfx_rrect(s, fx, fy, fw, FBAR_H, 10, N_PAGE);
  char nm[24];
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  if (c0 == c1 && r0 == r1) ref_name(S.ac, S.ar, nm);
  else {
    char a[12], b[12];
    ref_name(c0, r0, a);
    ref_name(c1, r1, b);
    snprintf(nm, sizeof nm, "%s:%s", a, b);
  }
  gfx_text_c(s, F_UI_MED, fx + 48, fy + FBAR_H / 2 - line_h(F_UI_MED) / 2, nm, C_TEXT);
  gfx_rect(s, fx + 96, fy + 8, 1, FBAR_H - 16, N_LINE);
  gfx_text(s, doc_font(0, 0, 1), fx + 108, fy + FBAR_H / 2 - line_h(doc_font(0, 0, 1)) / 2, "fx", C_MUTED);
  gfx_rect(s, fx + 132, fy + 8, 1, FBAR_H - 16, N_LINE);
  const Font *bfn = doc_font(0, 0, 0);
  float tx = fx + 144, ty = fy + FBAR_H / 2 - line_h(bfn) / 2;
  if (S.editing) {
    draw_text_clip(s, bfn, tx, ty, S.ebuf, C_TEXT, fx + fw - 10);
    if (S.blink) {
      float kx = tx;
      for (int i = 0; i < S.ecur; i++) kx += doc_char_w(bfn, S.ebuf[i]);
      gfx_rect(s, kx, fy + 9, 1.6f, FBAR_H - 18, S_ACC);
    }
  } else {
    Cell *x = G[S.ar][S.ac];
    if (x && x->src) draw_text_clip(s, bfn, tx, ty, x->src, C_TEXT, fx + fw - 10);
  }
  double sum;
  int cnt, nums;
  sel_stats(&sum, &cnt, &nums);
  char st[160], a[64], b[64];
  const char *saved = S.dirty ? "Saving" : "Saved";
  if (nums > 1 || (cnt > 1 && (c0 != c1 || r0 != r1))) {
    Cell fake = {0};
    fake.fmt = FM_GEN, fake.dec = 255;
    Cell *ref = G[S.ar][S.ac] ? G[S.ar][S.ac] : &fake;
    fmt_val(ref, vnum(sum), a, sizeof a);
    fmt_val(ref, vnum(nums ? sum / nums : 0), b, sizeof b);
    if (nums) snprintf(st, sizeof st, "Sum %s   Average %s   Count %d", a, b, cnt);
    else snprintf(st, sizeof st, "Count %d", cnt);
  } else st[0] = 0;
  float sw = gfx_text_w(F_SMALL, saved), ww = st[0] ? gfx_text_w(F_SMALL, st) + 21 : 0;
  float pw = 28 + sw + ww + 14, ph = 30, px = ox + 16, py = oy + ch - ph - 11;
  gfx_rrect(s, px - 1, py - 1, pw + 2, ph + 2, 16, THEME(RGB(230, 228, 236), RGB(50, 52, 60)));
  gfx_rrect(s, px, py, pw, ph, 15, N_HEAD);
  float sty = py + ph / 2 - line_h(F_SMALL) / 2;
  if (S.dirty) gfx_ring(s, px + 16, py + ph / 2, 4, 1.6f, C_MUTED);
  else {
    gfx_line(s, px + 12, py + ph / 2, px + 15, py + ph / 2 + 3, 1.7f, S_ACC);
    gfx_line(s, px + 15, py + ph / 2 + 3, px + 20.5f, py + ph / 2 - 3.5f, 1.7f, S_ACC);
  }
  gfx_text(s, F_SMALL, px + 28, sty, saved, C_MUTED);
  if (st[0]) {
    gfx_disc(s, px + 28 + sw + 10, py + ph / 2, 1.5f, C_MUTED);
    gfx_text(s, F_SMALL, px + 28 + sw + 21, sty, st, C_TEXT);
  }
  if (S.popup) draw_popup(s, ox, oy, hot);
}

static void begin_edit(const char *init, int mode) {
  S.editing = 1;
  S.emode = mode;
  snprintf(S.ebuf, sizeof S.ebuf, "%s", init);
  S.elen = (int)strlen(S.ebuf);
  S.ecur = S.elen;
  S.ref_a = S.ref_b = -1;
  S.blink = 1;
  S.blink_t = now_ms();
  office_show_keyboard();
}

static void commit_edit(void) {
  if (!S.editing) return;
  S.editing = 0;
  Cell *x = G[S.ar][S.ac];
  const char *old = x && x->src ? x->src : "";
  if (!strcmp(old, S.ebuf)) return;
  push_undo();
  char src[512];
  snprintf(src, sizeof src, "%s", S.ebuf);
  if (src[0] == '=') {
    int depth = 0, instr = 0;
    for (char *q = src; *q; q++) {
      if (*q == '"') instr = !instr;
      if (!instr) *q = (char)toupper((unsigned char)*q);
      if (*q == '(') depth++;
      if (*q == ')') depth--;
    }
    int l = (int)strlen(src);
    while (depth-- > 0 && l < 510) src[l++] = ')', src[l] = 0;
  } else {
    double d;
    int fm;
    if (parse_number(src, &d, &fm) && fm != FM_GEN) {
      Cell *y = cell_mk(S.ac, S.ar);
      if (y->fmt == FM_GEN) y->fmt = (unsigned char)fm;
      snprintf(src, sizeof src, "%.15g", d);
    }
  }
  cell_set_src(S.ac, S.ar, src);
  changed();
}

static void move_to(int c, int r, int extend) {
  if (c < 0) c = 0;
  if (r < 0) r = 0;
  if (c >= MAXC) c = MAXC - 1;
  if (r >= MAXR) r = MAXR - 1;
  if (extend) {
    S.bc = c, S.br = r;
    int sc = S.ac, sr = S.ar;
    S.ac = c, S.ar = r;
    ensure_visible();
    S.ac = sc, S.ar = sr;
    int t = S.bc;
    (void)t;
    return;
  }
  S.ac = S.bc = c;
  S.ar = S.br = r;
  ensure_visible();
}

static void move_ext(int dc, int dr) {
  int c = S.bc + dc, r = S.br + dr;
  move_to(c, r, 1);
}

static int has_val(int c, int r) { return c >= 0 && r >= 0 && c < MAXC && r < MAXR && G[r][c] && G[r][c]->src; }

static void jump(int dc, int dr, int extend) {
  int c = extend ? S.bc : S.ac, r = extend ? S.br : S.ar;
  int filled = has_val(c, r) && has_val(c + dc, r + dr);
  c += dc, r += dr;
  if (filled) {
    while (has_val(c + dc, r + dr)) c += dc, r += dr;
  } else {
    while (c >= 0 && r >= 0 && c < MAXC && r < MAXR && !has_val(c, r)) c += dc, r += dr;
  }
  if (c < 0) c = 0;
  if (r < 0) r = 0;
  if (c >= MAXC) c = MAXC - 1;
  if (r >= MAXR) r = MAXR - 1;
  move_to(c, r, extend);
}

static void apply_fmt(void (*fn)(Cell *, int), int arg) {
  push_undo();
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  for (int r = r0; r <= r1; r++)
    for (int c = c0; c <= c1; c++) fn(cell_mk(c, r), arg);
  changed();
}

static void f_bold(Cell *x, int v) { x->bold = (unsigned char)v; }
static void f_ital(Cell *x, int v) { x->ital = (unsigned char)v; }
static void f_strike(Cell *x, int v) { x->strike = (unsigned char)v; }
static void f_align(Cell *x, int v) { x->align = (unsigned char)v; }
static void f_color(Cell *x, int v) { x->color = (unsigned char)v; }
static void f_fill(Cell *x, int v) { x->fill = (unsigned char)v; }
static void f_fmt(Cell *x, int v) {
  x->fmt = (unsigned char)v;
  x->dec = 255;
}
static void f_dec(Cell *x, int d) {
  int cur = x->dec != 255 ? x->dec : (x->fmt == FM_PCT ? 0 : 2);
  if (x->dec == 255 && x->fmt == FM_GEN) {
    double v = 0;
    Val vv = x->src ? eval_src(x->src) : (Val){V_EMPTY, 0, ""};
    if (vv.t == V_NUM) v = vv.n;
    char b[64];
    snprintf(b, sizeof b, "%.10g", v);
    char *dot = strchr(b, '.');
    cur = dot ? (int)strlen(dot + 1) : 0;
  }
  cur += d;
  if (cur < 0) cur = 0;
  if (cur > 8) cur = 8;
  x->dec = (unsigned char)cur;
}
static void f_clear(Cell *x, int v) {
  (void)v;
  x->bold = x->ital = x->strike = x->align = x->color = x->fill = x->fmt = 0;
  x->dec = 255;
}

static void tidy(void) {
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++)
      if (G[r][c] && !G[r][c]->src && cell_blank_style(G[r][c])) cell_free(c, r);
}

static void clear_values(void) {
  push_undo();
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  for (int r = r0; r <= r1; r++)
    for (int c = c0; c <= c1; c++)
      if (G[r][c]) {
        free(G[r][c]->src);
        G[r][c]->src = NULL;
      }
  tidy();
  changed();
}

static void clip_free(void) {
  if (!S.clip.cells) return;
  for (int i = 0; i < S.clip.w * S.clip.h; i++) free(S.clip.srcs[i]);
  free(S.clip.cells);
  free(S.clip.srcs);
  S.clip.cells = NULL;
  S.clip.srcs = NULL;
}

static void copy_sel(int cut) {
  clip_free();
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  int w = c1 - c0 + 1, h = r1 - r0 + 1;
  S.clip.w = w, S.clip.h = h, S.clip.c0 = c0, S.clip.r0 = r0;
  S.clip.cells = calloc((size_t)(w * h), sizeof(Cell));
  S.clip.srcs = calloc((size_t)(w * h), sizeof(char *));
  for (int r = 0; r < h; r++)
    for (int c = 0; c < w; c++) {
      Cell *x = G[r0 + r][c0 + c];
      if (!x) continue;
      S.clip.cells[r * w + c] = *x;
      S.clip.srcs[r * w + c] = x->src ? strdup(x->src) : NULL;
    }
  S.clip.cut = cut;
  if (cut) {
    push_undo();
    for (int r = r0; r <= r1; r++)
      for (int c = c0; c <= c1; c++) cell_free(c, r);
    changed();
  }
  office_toast(cut ? "Cut" : "Copied");
}

static void paste(int values_only) {
  if (!S.clip.cells) return;
  push_undo();
  int w = S.clip.w, h = S.clip.h;
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  int sw = c1 - c0 + 1, sh = r1 - r0 + 1;
  int tw = (sw > w && sw % w == 0) ? sw : w, th = (sh > h && sh % h == 0) ? sh : h;
  for (int r = 0; r < th; r++)
    for (int c = 0; c < tw; c++) {
      int tc = c0 + c, tr = r0 + r, ki = (r % h) * w + (c % w);
      if (tc >= MAXC || tr >= MAXR) continue;
      Cell *src = &S.clip.cells[ki];
      const char *ss = S.clip.srcs[ki];
      int oc = S.clip.c0 + c % w, orr = S.clip.r0 + r % h;
      if (values_only) {
        if (!ss) continue;
        Cell *x = cell_mk(tc, tr);
        char b[160];
        if (S.clip.cut || ss[0] != '=') snprintf(b, sizeof b, "%s", ss);
        else {
          Val v = cell_val(oc, orr);
          if (v.t == V_NUM) snprintf(b, sizeof b, "%.15g", v.n);
          else str_of(v, b, sizeof b);
        }
        free(x->src);
        x->src = b[0] ? strdup(b) : NULL;
        continue;
      }
      cell_free(tc, tr);
      Cell *x = cell_mk(tc, tr);
      *x = *src;
      x->gen = 0, x->busy = 0;
      if (ss && ss[0] == '=' && !S.clip.cut) {
        char b[1024];
        shift_formula(ss, b, sizeof b, 0, tc - oc, tr - orr);
        x->src = strdup(b);
      } else x->src = ss ? strdup(ss) : NULL;
      if (!x->src && cell_blank_style(x)) cell_free(tc, tr);
    }
  S.ac = c0, S.ar = r0;
  S.bc = c0 + tw - 1 < MAXC ? c0 + tw - 1 : MAXC - 1;
  S.br = r0 + th - 1 < MAXR ? r0 + th - 1 : MAXR - 1;
  if (S.clip.cut) clip_free();
  changed();
}

static void insert_rows(int at, int n) {
  push_undo();
  for (int r = MAXR - 1; r >= at + n; r--)
    for (int c = 0; c < MAXC; c++) {
      cell_free(c, r);
      G[r][c] = G[r - n][c];
      G[r - n][c] = NULL;
    }
  shift_all(1, at, n);
  changed();
}

static void insert_cols(int at, int n) {
  push_undo();
  for (int r = 0; r < MAXR; r++)
    for (int c = MAXC - 1; c >= at + n; c--) {
      cell_free(c, r);
      G[r][c] = G[r][c - n];
      G[r][c - n] = NULL;
    }
  for (int c = MAXC - 1; c >= at + n; c--) CW[c] = CW[c - n];
  for (int c = at; c < at + n; c++) CW[c] = DEF_CW;
  shift_all(2, at, n);
  changed();
}

static void delete_rows(int at, int n) {
  push_undo();
  for (int r = at; r < at + n; r++)
    for (int c = 0; c < MAXC; c++) cell_free(c, r);
  for (int r = at; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++) {
      G[r][c] = r + n < MAXR ? G[r + n][c] : NULL;
      if (r + n < MAXR) G[r + n][c] = NULL;
    }
  shift_all(3, at, n);
  changed();
}

static void delete_cols(int at, int n) {
  push_undo();
  for (int r = 0; r < MAXR; r++) {
    for (int c = at; c < at + n; c++) cell_free(c, r);
    for (int c = at; c < MAXC; c++) {
      G[r][c] = c + n < MAXC ? G[r][c + n] : NULL;
      if (c + n < MAXC) G[r][c + n] = NULL;
    }
  }
  for (int c = at; c < MAXC; c++) CW[c] = c + n < MAXC ? CW[c + n] : DEF_CW;
  shift_all(4, at, n);
  changed();
}

static int sort_col, sort_dir;

typedef struct {
  int row;
  Val v;
} SortRow;

static int sort_cmp(const void *a, const void *b) {
  const SortRow *x = a, *y = b;
  if (x->v.t == V_EMPTY && y->v.t != V_EMPTY) return 1;
  if (y->v.t == V_EMPTY && x->v.t != V_EMPTY) return -1;
  int c = val_cmp(x->v, y->v);
  if (!c) return x->row - y->row;
  return sort_dir ? -c : c;
}

static void used_bounds(int *maxc, int *maxr) {
  *maxc = -1, *maxr = -1;
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++)
      if (G[r][c] && G[r][c]->src) {
        if (c > *maxc) *maxc = c;
        if (r > *maxr) *maxr = r;
      }
}

static void sort_range(int desc) {
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  if (r0 == r1) {
    int mc, mr;
    used_bounds(&mc, &mr);
    if (mr < 1) return;
    int top = S.ar;
    while (top > 0 && has_val(S.ac, top - 1)) top--;
    int bot = S.ar;
    while (bot + 1 <= mr && has_val(S.ac, bot + 1)) bot++;
    int hdr = G[top][S.ac] && G[top][S.ac]->bold;
    r0 = top + (hdr ? 1 : 0), r1 = bot;
    c0 = 0, c1 = mc;
    if (r1 <= r0) return;
  }
  push_undo();
  int n = r1 - r0 + 1, w = c1 - c0 + 1;
  SortRow *rows = malloc(sizeof(SortRow) * (size_t)n);
  sort_col = S.ac, sort_dir = desc;
  for (int i = 0; i < n; i++) rows[i].row = r0 + i, rows[i].v = cell_val(S.ac, r0 + i);
  qsort(rows, (size_t)n, sizeof(SortRow), sort_cmp);
  Cell **tmp = calloc((size_t)(n * w), sizeof(Cell *));
  for (int i = 0; i < n; i++)
    for (int c = 0; c < w; c++) {
      tmp[i * w + c] = G[rows[i].row][c0 + c];
      Cell *x = tmp[i * w + c];
      int dr = (r0 + i) - rows[i].row;
      if (x && x->src && x->src[0] == '=' && dr) {
        char b[1024];
        shift_formula(x->src, b, sizeof b, 0, 0, dr);
        free(x->src);
        x->src = strdup(b);
      }
    }
  for (int i = 0; i < n; i++)
    for (int c = 0; c < w; c++) G[r0 + i][c0 + c] = tmp[i * w + c];
  free(tmp);
  free(rows);
  changed();
}

static void auto_sum(void) {
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  char a[12], b[12], f[64];
  if (c0 == c1 && r0 == r1) {
    int r = S.ar - 1;
    while (r >= 0 && !has_val(S.ac, r)) r--;
    int end = r;
    while (r >= 0 && has_val(S.ac, r) && cell_val(S.ac, r).t == V_NUM) r--;
    if (end < 0 || end == r) {
      begin_edit("=SUM()", 1);
      S.ecur = 5;
      return;
    }
    ref_name(S.ac, r + 1, a);
    ref_name(S.ac, end, b);
    snprintf(f, sizeof f, "=SUM(%s:%s)", a, b);
    begin_edit(f, 1);
    return;
  }
  push_undo();
  for (int c = c0; c <= c1; c++) {
    int tr = r1 + 1;
    if (tr >= MAXR) break;
    ref_name(c, r0, a);
    ref_name(c, r1, b);
    snprintf(f, sizeof f, "=SUM(%s:%s)", a, b);
    cell_set_src(c, tr, f);
    Cell *x = cell_mk(c, tr);
    Cell *y = G[r1][c];
    if (y) x->fmt = y->fmt, x->dec = y->dec;
    x->bold = 1;
  }
  changed();
}

static void do_fill(void) {
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  int vert = S.filling == 1;
  int t0 = vert ? (S.fill_r < r0 ? S.fill_r : r1 + 1) : (S.fill_c < c0 ? S.fill_c : c1 + 1);
  int t1 = vert ? (S.fill_r < r0 ? r0 - 1 : S.fill_r) : (S.fill_c < c0 ? c0 - 1 : S.fill_c);
  if (t1 < t0) return;
  push_undo();
  int len = vert ? r1 - r0 + 1 : c1 - c0 + 1;
  int across0 = vert ? c0 : r0, across1 = vert ? c1 : r1;
  for (int k = across0; k <= across1; k++) {
    int series = len >= 2;
    double a = 0, step = 0;
    for (int i = 0; i < len && series; i++) {
      int sc = vert ? k : c0 + i, sr = vert ? r0 + i : k;
      Cell *x = G[sr][sc];
      double d;
      if (!x || !x->src || x->src[0] == '=' || !parse_number(x->src, &d, NULL)) series = 0;
      else {
        if (i == 0) a = d;
        if (i == 1) step = d - a;
        if (i > 1 && fabs(d - (a + step * i)) > 1e-9) series = 0;
      }
    }
    for (int t = t0; t <= t1; t++) {
      int off = vert ? t - r0 : t - c0;
      int idx = ((off % len) + len) % len;
      int sc = vert ? k : c0 + idx, sr = vert ? r0 + idx : k;
      int tc = vert ? k : t, tr = vert ? t : k;
      Cell *src = G[sr][sc];
      cell_free(tc, tr);
      if (!src) continue;
      Cell *x = cell_mk(tc, tr);
      *x = *src;
      x->gen = 0, x->busy = 0;
      if (series) {
        char b[64];
        snprintf(b, sizeof b, "%.15g", a + step * off);
        x->src = strdup(b);
      } else if (src->src && src->src[0] == '=') {
        char b[1024];
        shift_formula(src->src, b, sizeof b, 0, tc - sc, tr - sr);
        x->src = strdup(b);
      } else x->src = src->src ? strdup(src->src) : NULL;
    }
  }
  if (vert) {
    if (S.fill_r < r0) S.ar = S.fill_r, S.br = r1;
    else S.ar = r0, S.br = S.fill_r;
    S.ac = c0, S.bc = c1;
  } else {
    if (S.fill_c < c0) S.ac = S.fill_c, S.bc = c1;
    else S.ac = c0, S.bc = S.fill_c;
    S.ar = r0, S.br = r1;
  }
  changed();
}

static void export_csv(void) {
  char dir[512], path[700], name[96];
  snprintf(dir, sizeof dir, "%s/Documents", user_home());
  office_mkdirs(dir);
  int k = 0;
  for (const char *t = S.title; *t && k < 80; t++) name[k++] = (isalnum((unsigned char)*t) || *t == '-' || *t == '_' || *t == ' ') ? *t : '_';
  name[k] = 0;
  if (!k) snprintf(name, sizeof name, "Untitled");
  snprintf(path, sizeof path, "%s/%s.csv", dir, name);
  FILE *f = fopen(path, "w");
  if (!f) {
    office_toast("Could not save the file");
    return;
  }
  int mc, mr;
  used_bounds(&mc, &mr);
  for (int r = 0; r <= mr; r++) {
    for (int c = 0; c <= mc; c++) {
      if (c) fputc(',', f);
      Val v = cell_val(c, r);
      char b[160];
      if (v.t == V_NUM) snprintf(b, sizeof b, "%.15g", v.n);
      else str_of(v, b, sizeof b);
      if (strpbrk(b, ",\"\n")) {
        fputc('"', f);
        for (char *q = b; *q; q++) {
          if (*q == '"') fputc('"', f);
          fputc(*q, f);
        }
        fputc('"', f);
      } else fputs(b, f);
    }
    fputc('\n', f);
  }
  fclose(f);
  char m[200];
  snprintf(m, sizeof m, "Saved to Documents/%s.csv", name);
  office_toast(m);
}

static void begin_title_edit(void) {
  S.title_edit = 1;
  snprintf(S.title_buf, sizeof S.title_buf, "%s", S.title);
  office_show_keyboard();
}

static void commit_title(void) {
  if (!S.title_edit) return;
  S.title_edit = 0;
  char *t = S.title_buf;
  while (*t == ' ') t++;
  if (*t && strcmp(t, S.title)) {
    snprintf(S.title, sizeof S.title, "%s", t);
    save_sheet();
    office_set_title();
  }
}

const char *sheets_title(void) { return S.title; }

static void run_cmd(int c) {
  S.popup = 0;
  int c0, r0, c1, r1;
  sel_rect(&c0, &r0, &c1, &r1);
  Cell *a = G[S.ar][S.ac];
  switch (c) {
  case C_NEW:
    sheets_new_from_template(0);
    office_set_title();
    break;
  case C_COPYDOC: {
    char *s = serialize(), t[120];
    snprintf(t, sizeof t, "Copy of %.80s", S.title);
    new_sheet(t);
    deserialize(s);
    snprintf(S.title, sizeof S.title, "%.95s", t);
    free(s);
    save_sheet();
    office_set_title();
    office_toast("Copy created");
    break;
  }
  case C_RENAME: begin_title_edit(); break;
  case C_CSV: export_csv(); break;
  case C_XLSX: export_xlsx(); break;
  case C_DELETE: {
    char path[700];
    sheet_path(S.id, path, sizeof path);
    unlink(path);
    S.dirty = 0;
    S.id[0] = 0;
    office_go_home();
    office_toast("Moved to trash");
    break;
  }
  case C_UNDO: undo_redo(0); break;
  case C_REDO: undo_redo(1); break;
  case C_CUT: copy_sel(1); break;
  case C_COPY: copy_sel(0); break;
  case C_PASTE: paste(0); break;
  case C_PASTEV: paste(1); break;
  case C_SELALL:
    S.ac = S.ar = 0;
    {
      int mc, mr;
      used_bounds(&mc, &mr);
      S.bc = mc < 0 ? MAXC - 1 : mc;
      S.br = mr < 0 ? MAXR - 1 : mr;
    }
    break;
  case C_CLEARV: clear_values(); break;
  case C_ROWA: insert_rows(r0, r1 - r0 + 1); break;
  case C_ROWB:
    insert_rows(r1 + 1, r1 - r0 + 1);
    break;
  case C_COLL: insert_cols(c0, c1 - c0 + 1); break;
  case C_COLR: insert_cols(c1 + 1, c1 - c0 + 1); break;
  case C_DELROW:
    delete_rows(r0, r1 - r0 + 1);
    S.br = S.ar = r0;
    break;
  case C_DELCOL:
    delete_cols(c0, c1 - c0 + 1);
    S.bc = S.ac = c0;
    break;
  case C_BOLD: apply_fmt(f_bold, !(a && a->bold)); break;
  case C_ITAL: apply_fmt(f_ital, !(a && a->ital)); break;
  case C_STRIKE: apply_fmt(f_strike, !(a && a->strike)); break;
  case C_FGEN: apply_fmt(f_fmt, FM_GEN); break;
  case C_FNUM: apply_fmt(f_fmt, FM_NUM); break;
  case C_FCUR: apply_fmt(f_fmt, a && a->fmt == FM_CUR ? FM_GEN : FM_CUR); break;
  case C_FPCT: apply_fmt(f_fmt, a && a->fmt == FM_PCT ? FM_GEN : FM_PCT); break;
  case C_ALEFT: apply_fmt(f_align, a && a->align == AL_LEFT ? AL_AUTO : AL_LEFT); break;
  case C_ACENTER: apply_fmt(f_align, a && a->align == AL_CENTER ? AL_AUTO : AL_CENTER); break;
  case C_ARIGHT: apply_fmt(f_align, a && a->align == AL_RIGHT ? AL_AUTO : AL_RIGHT); break;
  case C_CLEARF:
    apply_fmt(f_clear, 0);
    tidy();
    break;
  case C_SORTA: sort_range(0); break;
  case C_SORTD: sort_range(1); break;
  case C_SUM: auto_sum(); break;
  }
  ensure_visible();
}

static void tool_click(int t) {
  switch (t) {
  case T_UNDO: run_cmd(C_UNDO); break;
  case T_REDO: run_cmd(C_REDO); break;
  case T_CUR: run_cmd(C_FCUR); break;
  case T_PCT: run_cmd(C_FPCT); break;
  case T_DECM: apply_fmt(f_dec, -1); break;
  case T_DECP: apply_fmt(f_dec, 1); break;
  case T_GEN: run_cmd(C_FGEN); break;
  case T_BOLD: run_cmd(C_BOLD); break;
  case T_ITAL: run_cmd(C_ITAL); break;
  case T_STRIKE: run_cmd(C_STRIKE); break;
  case T_COLOR: S.popup = S.popup == POP_COLOR ? 0 : POP_COLOR; break;
  case T_FILL: S.popup = S.popup == POP_FILL ? 0 : POP_FILL; break;
  case T_ALEFT: run_cmd(C_ALEFT); break;
  case T_ACENTER: run_cmd(C_ACENTER); break;
  case T_ARIGHT: run_cmd(C_ARIGHT); break;
  case T_SUM: run_cmd(C_SUM); break;
  case T_SORTA: run_cmd(C_SORTA); break;
  case T_SORTD: run_cmd(C_SORTD); break;
  }
}

static int ref_insert_ok(void) {
  if (!S.editing || S.ebuf[0] != '=') return 0;
  if (S.ref_a >= 0 && S.ref_b == S.ecur) return 1;
  int i = S.ecur - 1;
  while (i > 0 && S.ebuf[i] == ' ') i--;
  if (i < 0) return 0;
  return strchr("=+-*/^(,:<>&", S.ebuf[i]) != NULL;
}

static void ref_put(int c0, int r0, int c1, int r1) {
  char t[32], a[12], b[12];
  ref_name(c0 < c1 ? c0 : c1, r0 < r1 ? r0 : r1, a);
  ref_name(c0 < c1 ? c1 : c0, r0 < r1 ? r1 : r0, b);
  if (c0 == c1 && r0 == r1) snprintf(t, sizeof t, "%s", a);
  else snprintf(t, sizeof t, "%s:%s", a, b);
  int at = S.ecur;
  if (S.ref_a >= 0 && S.ref_b == S.ecur) {
    memmove(S.ebuf + S.ref_a, S.ebuf + S.ref_b, (size_t)(S.elen - S.ref_b + 1));
    S.elen -= S.ref_b - S.ref_a;
    at = S.ref_a;
  }
  int l = (int)strlen(t);
  if (S.elen + l >= (int)sizeof S.ebuf - 1) return;
  memmove(S.ebuf + at + l, S.ebuf + at, (size_t)(S.elen - at + 1));
  memcpy(S.ebuf + at, t, (size_t)l);
  S.elen += l;
  S.ref_a = at;
  S.ref_b = S.ecur = at + l;
}

void sheets_press(Panel *p, float x, float y, int button, int down) {
  (void)p;
  if (button != 1) return;
  int z = sheets_zone(x, y);
  if (down) {
    S.press = z;
    if (S.popup && (z <= 0 || z == Z_GRID || z == Z_COLH || z == Z_ROWH)) {
      S.popup = 0;
      S.press = 0;
      return;
    }
    if (z == Z_GRID) {
      int c, r;
      if (!hit_cell(x, y, &c, &r)) return;
      if (ref_insert_ok() && !(c == S.ac && r == S.ar)) {
        S.dragref = 1;
        S.ref_c0 = c, S.ref_r0 = r;
        ref_put(c, r, c, r);
        return;
      }
      uint32_t now = now_ms();
      int dbl = now - S.last_click < 420 && c == S.last_cc && r == S.last_cr;
      S.last_click = now, S.last_cc = c, S.last_cr = r;
      commit_edit();
      commit_title();
      if (dbl) {
        Cell *xx = G[r][c];
        move_to(c, r, 0);
        begin_edit(xx && xx->src ? xx->src : "", 1);
        return;
      }
      move_to(c, r, (input_mods() & MOD_SHIFT) != 0);
      S.dragsel = 1;
      return;
    }
    if (z == Z_HANDLE) {
      S.filling = 1;
      int c0, r0, c1, r1;
      sel_rect(&c0, &r0, &c1, &r1);
      S.fill_c = c1, S.fill_r = r1;
      return;
    }
    if (z == Z_RESIZE) {
      S.resize_col = resize_hit(x);
      S.resize_x0 = x;
      S.resize_w0 = S.resize_col >= 0 ? CW[S.resize_col] : 0;
      if (S.resize_col >= 0) push_undo();
      return;
    }
    if (z == Z_COLH || z == Z_ROWH || z == Z_CORNER) {
      commit_edit();
      if (z == Z_CORNER) {
        S.ac = S.ar = 0, S.bc = MAXC - 1, S.br = MAXR - 1;
      } else if (z == Z_COLH) {
        int c = hit_col(x);
        if (input_mods() & MOD_SHIFT) S.bc = c;
        else S.ac = S.bc = c;
        S.ar = 0, S.br = MAXR - 1;
      } else {
        int r = (int)floorf((y - (GRID_Y + CH_H) + S.sy) / ROW_H);
        if (r < 0) r = 0;
        if (r >= MAXR) r = MAXR - 1;
        if (input_mods() & MOD_SHIFT) S.br = r;
        else S.ar = S.br = r;
        S.ac = 0, S.bc = MAXC - 1;
      }
      return;
    }
    return;
  }
  int pz = S.press;
  S.press = 0;
  if (S.dragsel) {
    S.dragsel = 0;
    return;
  }
  if (S.dragref) {
    S.dragref = 0;
    return;
  }
  if (S.filling) {
    if (S.filling > 0) {
      int c0, r0, c1, r1;
      sel_rect(&c0, &r0, &c1, &r1);
      if (S.fill_r != r1 || S.fill_c != c1) {
        if (S.fill_r < r0 || S.fill_r > r1) S.filling = 1;
        else S.filling = 2;
        do_fill();
      }
    }
    S.filling = 0;
    return;
  }
  if (S.resize_col >= 0) {
    S.resize_col = -1;
    changed();
    return;
  }
  if (!pz || z != pz) return;
  if (S.popup && z >= Z_POPUP) {
    int i = z - Z_POPUP;
    if (S.popup <= POP_M4) run_cmd(MENUS[S.popup - POP_M0][i].cmd);
    else {
      int fill = S.popup == POP_FILL;
      S.popup = 0;
      apply_fmt(fill ? f_fill : f_color, i);
      tidy();
    }
    return;
  }
  if (z != Z_TITLE) commit_title();
  if (z >= Z_MENU && z < Z_MENU + 5) {
    commit_edit();
    int m = POP_M0 + z - Z_MENU;
    S.popup = S.popup == m ? 0 : m;
  } else if (z > 0 && z < T_COUNT) {
    commit_edit();
    if (z != T_COLOR && z != T_FILL) S.popup = 0;
    tool_click(z);
  } else {
    S.popup = 0;
    if (z == Z_HOME) {
      commit_edit();
      office_go_home();
    } else if (z == Z_TITLE) {
      commit_edit();
      begin_title_edit();
    } else if (z == Z_FBAR) {
      if (!S.editing) {
        Cell *xx = G[S.ar][S.ac];
        begin_edit(xx && xx->src ? xx->src : "", 1);
      } else S.emode = 1;
    }
  }
}

void sheets_scroll(float x, float y, int steps) {
  (void)x, (void)y;
  if (input_mods() & MOD_SHIFT) S.sx -= steps * 60;
  else S.sy -= steps * ROW_H * 3;
  float mx = 0;
  for (int c = 0; c < MAXC; c++) mx += CW[c];
  mx -= grid_r() - GRID_X - RH_W - 40;
  float my = MAXR * ROW_H - (grid_b() - GRID_Y - CH_H) + 20;
  if (S.sx > mx) S.sx = mx;
  if (S.sy > my) S.sy = my;
  if (S.sx < 0) S.sx = 0;
  if (S.sy < 0) S.sy = 0;
}

static void edit_insert(char ch) {
  if (S.elen >= (int)sizeof S.ebuf - 2) return;
  memmove(S.ebuf + S.ecur + 1, S.ebuf + S.ecur, (size_t)(S.elen - S.ecur + 1));
  S.ebuf[S.ecur++] = ch;
  S.elen++;
  S.ref_a = S.ref_b = -1;
}

void sheets_key(Panel *p, int code, int mods) {
  (void)p;
  int ctrl = mods & MOD_CTRL, shift = mods & MOD_SHIFT, alt = mods & MOD_ALT;
  S.blink = 1;
  S.blink_t = now_ms();
  if (code == KEY_ESC && S.popup) {
    S.popup = 0;
    return;
  }
  if (S.title_edit) {
    if (code == KEY_ENTER || code == KEY_KPENTER || code == KEY_TAB) commit_title();
    else if (code == KEY_ESC) S.title_edit = 0;
    else if (code == KEY_BACKSPACE) {
      int l = (int)strlen(S.title_buf);
      if (l) S.title_buf[l - 1] = 0;
    } else if (!ctrl) {
      char b[8];
      int n = key_to_bytes(code, mods, b);
      int l = (int)strlen(S.title_buf);
      if (n == 1 && b[0] >= 32 && b[0] < 127 && l < 90) S.title_buf[l] = b[0], S.title_buf[l + 1] = 0;
    }
    return;
  }
  if (S.editing) {
    switch (code) {
    case KEY_ENTER:
    case KEY_KPENTER:
      commit_edit();
      move_to(S.ac, S.ar + (shift ? -1 : 1), 0);
      return;
    case KEY_TAB:
      commit_edit();
      move_to(S.ac + (shift ? -1 : 1), S.ar, 0);
      return;
    case KEY_ESC: S.editing = 0; return;
    case KEY_BACKSPACE:
      if (S.ecur > 0) {
        memmove(S.ebuf + S.ecur - 1, S.ebuf + S.ecur, (size_t)(S.elen - S.ecur + 1));
        S.ecur--, S.elen--;
      }
      S.ref_a = S.ref_b = -1;
      return;
    case KEY_DELETE:
      if (S.ecur < S.elen) {
        memmove(S.ebuf + S.ecur, S.ebuf + S.ecur + 1, (size_t)(S.elen - S.ecur));
        S.elen--;
      }
      return;
    case KEY_HOME: S.ecur = 0; return;
    case KEY_END: S.ecur = S.elen; return;
    case KEY_LEFT:
    case KEY_RIGHT:
    case KEY_UP:
    case KEY_DOWN:
      if (S.emode || code == KEY_LEFT || code == KEY_RIGHT) {
        if (S.emode || (S.ebuf[0] == '=')) {
          if (code == KEY_LEFT && S.ecur > 0) S.ecur--;
          else if (code == KEY_RIGHT && S.ecur < S.elen) S.ecur++;
          else if (code == KEY_UP || code == KEY_DOWN) {
            commit_edit();
            move_to(S.ac, S.ar + (code == KEY_UP ? -1 : 1), 0);
          }
          return;
        }
      }
      commit_edit();
      move_to(S.ac + (code == KEY_LEFT ? -1 : code == KEY_RIGHT ? 1 : 0), S.ar + (code == KEY_UP ? -1 : code == KEY_DOWN ? 1 : 0), 0);
      return;
    }
    if (ctrl) return;
    char b[8];
    int n = key_to_bytes(code, mods, b);
    if (n == 1 && b[0] >= 32 && b[0] < 127) edit_insert(b[0]);
    return;
  }
  if (ctrl) {
    int cmd = 0;
    switch (code) {
    case KEY_C: cmd = C_COPY; break;
    case KEY_X: cmd = C_CUT; break;
    case KEY_V: cmd = shift ? C_PASTEV : C_PASTE; break;
    case KEY_Z: cmd = shift ? C_REDO : C_UNDO; break;
    case KEY_Y: cmd = C_REDO; break;
    case KEY_A: cmd = C_SELALL; break;
    case KEY_B: cmd = C_BOLD; break;
    case KEY_I: cmd = C_ITAL; break;
    case KEY_BACKSLASH: cmd = C_CLEARF; break;
    case KEY_N: cmd = C_NEW; break;
    case KEY_S:
      save_sheet();
      office_toast("Saved");
      return;
    case KEY_HOME: move_to(0, 0, shift); return;
    case KEY_UP: jump(0, -1, shift); return;
    case KEY_DOWN: jump(0, 1, shift); return;
    case KEY_LEFT: jump(-1, 0, shift); return;
    case KEY_RIGHT: jump(1, 0, shift); return;
    }
    if (cmd) run_cmd(cmd);
    return;
  }
  if (alt && code == KEY_EQUAL) {
    run_cmd(C_SUM);
    return;
  }
  if (alt && shift && code == KEY_5) {
    run_cmd(C_STRIKE);
    return;
  }
  switch (code) {
  case KEY_UP: shift ? move_ext(0, -1) : move_to(S.ac, S.ar - 1, 0); return;
  case KEY_DOWN: shift ? move_ext(0, 1) : move_to(S.ac, S.ar + 1, 0); return;
  case KEY_LEFT: shift ? move_ext(-1, 0) : move_to(S.ac - 1, S.ar, 0); return;
  case KEY_RIGHT: shift ? move_ext(1, 0) : move_to(S.ac + 1, S.ar, 0); return;
  case KEY_PAGEUP: move_to(S.ac, S.ar - 15, shift); return;
  case KEY_PAGEDOWN: move_to(S.ac, S.ar + 15, shift); return;
  case KEY_HOME: move_to(0, S.ar, shift); return;
  case KEY_ENTER:
  case KEY_KPENTER: move_to(S.ac, S.ar + (shift ? -1 : 1), 0); return;
  case KEY_TAB: move_to(S.ac + (shift ? -1 : 1), S.ar, 0); return;
  case KEY_DELETE: clear_values(); return;
  case KEY_BACKSPACE:
    clear_values();
    begin_edit("", 0);
    return;
  case KEY_F2: {
    Cell *x = G[S.ar][S.ac];
    begin_edit(x && x->src ? x->src : "", 1);
    return;
  }
  case KEY_ESC: S.bc = S.ac, S.br = S.ar; return;
  }
  char b[8];
  int n = key_to_bytes(code, mods, b);
  if (n == 1 && b[0] >= 32 && b[0] < 127) {
    S.bc = S.ac, S.br = S.ar;
    b[1] = 0;
    begin_edit(b, 0);
  }
}

int sheets_tick(Panel *p, uint32_t now) {
  int r = 0;
  int me = W.hover == (int)(p - P);
  if (S.dragsel && me) {
    int c, rr;
    if (hit_cell(W.hs, W.ht - BAR_H, &c, &rr) && (c != S.bc || rr != S.br)) {
      S.bc = c, S.br = rr;
      r = 1;
    }
  }
  if (S.dragref && me) {
    int c, rr;
    if (hit_cell(W.hs, W.ht - BAR_H, &c, &rr)) {
      ref_put(S.ref_c0, S.ref_r0, c, rr);
      r = 1;
    }
  }
  if (S.filling && me) {
    int c, rr;
    if (hit_cell(W.hs, W.ht - BAR_H, &c, &rr)) {
      int c0, r0, c1, r1;
      sel_rect(&c0, &r0, &c1, &r1);
      int dv = rr > r1 ? rr - r1 : rr < r0 ? r0 - rr : 0, dh = c > c1 ? c - c1 : c < c0 ? c0 - c : 0;
      if (dv >= dh) S.filling = 1, S.fill_r = rr, S.fill_c = c1;
      else S.filling = 2, S.fill_c = c, S.fill_r = r1;
      r = 1;
    }
  }
  if (S.resize_col >= 0 && me) {
    int w = S.resize_w0 + (int)(W.hs - S.resize_x0);
    if (w < 30) w = 30;
    if (w > 600) w = 600;
    if (w != CW[S.resize_col]) CW[S.resize_col] = w, r = 1;
  }
  if (S.dirty && now - S.dirty_at > 900 && !S.editing) {
    save_sheet();
    r = 1;
  }
  if (now - S.blink_t > 530) {
    S.blink_t = now;
    S.blink = !S.blink;
    if (S.editing || S.title_edit) r = 1;
  }
  return r;
}

void sheets_home_scan(void) {
  if (!S.loaded) {
    S.loaded = 1;
    S.resize_col = -1;
    S.confirm_del = -1;
    for (int c = 0; c < MAXC; c++) CW[c] = DEF_CW;
    tool_layout();
  }
  scan_list();
}

int sheets_home_confirm(void) { return S.confirm_del; }

void sheets_home_reset(void) { S.confirm_del = -1; }

static float home_tpl_y(float top) { return top + 52; }

static float home_band_b(float top) { return top + 52 + OFF_TPL_H + 56; }

static float card_x(int i) {
  return (OFF_W - (5 * OFF_CARD_W + 4 * OFF_CARD_GAP)) * 0.5f + (i % 5) * (OFF_CARD_W + OFF_CARD_GAP);
}

static float card_y(int i, float top) { return home_band_b(top) + 64 + (i / 5) * OFF_CARD_STEP; }

float sheets_home_h(void) {
  int rows = S.nlist ? (S.nlist + 4) / 5 : 1;
  return 52 + OFF_TPL_H + 56 + 64 + rows * OFF_CARD_STEP + 20;
}

int sheets_home_zone(float x, float y, float top) {
  for (int i = 0; i < NSTPL; i++) {
    float tx = office_tpl_x(i, NSTPL), ty = home_tpl_y(top);
    if (x >= tx && x < tx + OFF_TPL_W && y >= ty && y < ty + OFF_TPL_H + 30) return 5000 + i;
  }
  for (int i = 0; i < S.nlist; i++) {
    float cx = card_x(i), cy = card_y(i, top);
    if (x >= cx && x < cx + OFF_CARD_W && y >= cy && y < cy + OFF_CARD_TH + 58) {
      if (x >= cx + OFF_CARD_W - 40 && y < cy + 40) return 5400 + i;
      return 5100 + i;
    }
  }
  return 0;
}

static void mini_grid(Surface *s, float x, float y, float w, float h, const unsigned char (*pv)[4], int n) {
  float cw = w / 6.f, rh = h / 16.f;
  uint32_t ln = THEME(RGB(236, 236, 238), RGB(50, 52, 60));
  for (int i = 0; i < n; i++) {
    int c = pv[i][0], r = pv[i][1], fl = pv[i][3];
    if (fl) gfx_rect(s, x + c * cw, y + r * rh, cw, rh, fill_col(fl));
  }
  for (int r = 0; r <= 16; r++) gfx_rect(s, x, y + r * rh, w, 0.8f, ln);
  for (int c = 0; c <= 6; c++) gfx_rect(s, x + c * cw, y, 0.8f, h, ln);
  for (int i = 0; i < n; i++) {
    int c = pv[i][0], r = pv[i][1], bold = pv[i][2] & 1, num = (pv[i][2] >> 1) & 1;
    float bw = cw * (num ? 0.45f : 0.62f), bx = num ? x + (c + 1) * cw - bw - cw * 0.12f : x + c * cw + cw * 0.12f;
    gfx_rrect(s, bx, y + r * rh + rh * 0.3f, bw, rh * 0.4f, rh * 0.2f,
              bold ? THEME(RGB(60, 64, 67), RGB(200, 204, 210)) : THEME(RGB(176, 180, 188), RGB(110, 114, 124)));
  }
}

static void tpl_pv(int t, unsigned char (*pv)[4], int *n) {
  const STpl *tp = &STPLS[t];
  *n = 0;
  for (int i = 0; i < tp->n && *n < MAXPV; i++) {
    int c, r;
    if (!ref_parse_str(tp->cells[i].ref, &c, &r) || c >= 6 || r >= 16) continue;
    int st = tp->cells[i].st;
    double d;
    int num = tp->cells[i].src[0] == '=' || parse_number(tp->cells[i].src, &d, NULL);
    if (!tp->cells[i].src[0] && !((st >> 8) & 7)) continue;
    pv[*n][0] = (unsigned char)c, pv[*n][1] = (unsigned char)r;
    pv[*n][2] = (unsigned char)((st & TB ? 1 : 0) | (num << 1));
    pv[*n][3] = (unsigned char)((st >> 8) & 7);
    if (!tp->cells[i].src[0]) pv[*n][2] |= 4;
    (*n)++;
  }
}

void sheets_home_draw(Surface *s, float ox, float oy, int hot, float top) {
  float lx = ox + office_tpl_x(0, NSTPL);
  gfx_text(s, F_UI_MED, lx, oy + top + 18, "Start something new", C_TEXT);
  for (int i = 0; i < NSTPL; i++) {
    float x = ox + office_tpl_x(i, NSTPL), y = oy + home_tpl_y(top);
    int h = hot == 5000 + i;
    office_card(s, x, y, OFF_TPL_W, OFF_TPL_H, h, S_ACC);
    if (i == 0) {
      float cx = x + OFF_TPL_W / 2, cy = y + OFF_TPL_H / 2;
      gfx_disc(s, cx, cy, 24, S_TINT);
      gfx_rrect(s, cx - 10, cy - 1.5f, 20, 3, 1.5f, S_ACC);
      gfx_rrect(s, cx - 1.5f, cy - 10, 3, 20, 1.5f, S_ACC);
    } else {
      unsigned char pv[MAXPV][4];
      int n;
      tpl_pv(i, pv, &n);
      int k = 0;
      for (int j = 0; j < n; j++)
        if (!(pv[j][2] & 4) || pv[j][3]) {
          memcpy(pv[k], pv[j], 4);
          pv[k][2] &= 3;
          k++;
        }
      gfx_clip(s, x + 8, y + 10, OFF_TPL_W - 16, OFF_TPL_H - 20);
      mini_grid(s, x + 8, y + 10, OFF_TPL_W * 1.25f, OFF_TPL_H - 20, (const unsigned char (*)[4])pv, k);
      gfx_clip(s, ox, oy + OFF_HOME_HEAD, OFF_W, content_h() - OFF_HOME_HEAD);
    }
    gfx_text_fit(s, F_UI, x + 4, y + OFF_TPL_H + 10, OFF_TPL_W - 8, STPLS[i].name, h ? S_ACC : C_TEXT);
  }
  float bb = oy + home_band_b(top);
  gfx_rect(s, lx, bb + 4, OFF_W - 2 * (lx - ox), 1, N_LINE);
  gfx_text(s, F_UI_MED, lx, bb + 24, "Recent", C_TEXT);
  if (!S.nlist) gfx_text(s, F_UI, lx, bb + 68, "No spreadsheets yet. Choose a template above to get started.", C_MUTED);
  for (int i = 0; i < S.nlist; i++) {
    float x = ox + card_x(i), y = oy + card_y(i, top);
    if (y > oy + content_h() || y + OFF_CARD_STEP < oy + OFF_HOME_HEAD) continue;
    int h = hot == 5100 + i || hot == 5400 + i;
    office_card(s, x, y, OFF_CARD_W, OFF_CARD_TH + 58, h, S_ACC);
    gfx_rect(s, x + 12, y + OFF_CARD_TH, OFF_CARD_W - 24, 1, N_LINE);
    float cy0 = y + 14 > oy + OFF_HOME_HEAD ? y + 14 : oy + OFF_HOME_HEAD;
    gfx_clip(s, x + 12, cy0, OFF_CARD_W - 24, y + OFF_CARD_TH - 8 - cy0);
    mini_grid(s, x + 12, y + 14, (OFF_CARD_W - 24) * 1.2f, OFF_CARD_TH - 22, (const unsigned char (*)[4])S.list[i].pv, S.list[i].npv);
    gfx_clip(s, ox, oy + OFF_HOME_HEAD, OFF_W, content_h() - OFF_HOME_HEAD);
    gfx_rrect(s, x + 14, y + OFF_CARD_TH + 12, 14, 14, 4, S_ACC);
    gfx_rect(s, x + 17, y + OFF_CARD_TH + 18.5f, 8, 1.2f, RGB(255, 255, 255));
    gfx_rect(s, x + 20.5f, y + OFF_CARD_TH + 15, 1.2f, 8, RGB(255, 255, 255));
    gfx_text_fit(s, F_UI_MED, x + 36, y + OFF_CARD_TH + 9, OFF_CARD_W - 50, S.list[i].title, C_TEXT);
    char d[48];
    office_fmt_date(S.list[i].mtime, d, sizeof d);
    gfx_text(s, F_SMALL, x + 14, y + OFF_CARD_TH + 34, d, C_MUTED);
    if (S.confirm_del == i) {
      gfx_rrect(s, x + OFF_CARD_W - 86, y + 8, 78, 28, 14, RGB(217, 48, 37));
      gfx_text_c(s, F_SMALL, x + OFF_CARD_W - 47, y + 22 - line_h(F_SMALL) / 2, "Delete?", RGB(255, 255, 255));
    } else if (h) office_trash(s, x + OFF_CARD_W - 22, y + 22, hot == 5400 + i);
  }
}

int sheets_home_press(int z) {
  if (z >= 5000 && z < 5000 + NSTPL) {
    S.confirm_del = -1;
    sheets_new_from_template(z - 5000);
    S.ac = S.ar = S.bc = S.br = 0;
    return 1;
  } else if (z >= 5400 && z < 5400 + MAXSHEETS) {
    int i = z - 5400;
    if (S.confirm_del == i) {
      char path[700];
      sheet_path(S.list[i].id, path, sizeof path);
      unlink(path);
      if (!strcmp(S.list[i].id, S.id)) S.id[0] = 0;
      S.confirm_del = -1;
      scan_list();
      office_toast("Moved to trash");
      return 0;
    }
    S.confirm_del = i;
    return 0;
  } else if (z >= 5100 && z < 5100 + MAXSHEETS) {
    int i = z - 5100;
    if (S.confirm_del == i) {
      S.confirm_del = -1;
      return 0;
    }
    S.confirm_del = -1;
    open_sheet(S.list[i].id);
    return 1;
  }
  S.confirm_del = -1;
  return 0;
}

#define SN_C 12
#define SN_R 18

typedef struct {
  char id[40], title[96];
  long mtime;
  uint32_t at;
  unsigned gen;
  int ok, nc, nr;
  short cw[SN_C];
  char txt[SN_R][SN_C][40];
  unsigned char st[SN_R][SN_C][5];
} SheetSnap;

static SheetSnap SNAP[4];
static int snap_next;

static void snap_fill(SheetSnap *sn) {
  int mc, mr;
  used_bounds(&mc, &mr);
  sn->nc = mc + 1 < 3 ? 3 : mc + 1 > SN_C ? SN_C : mc + 1;
  sn->nr = mr + 1 < 4 ? 4 : mr + 1 > SN_R ? SN_R : mr + 1;
  for (int c = 0; c < sn->nc; c++) sn->cw[c] = (short)CW[c];
  for (int r = 0; r < sn->nr; r++)
    for (int c = 0; c < sn->nc; c++) {
      Cell *x = G[r][c];
      unsigned char *st = sn->st[r][c];
      sn->txt[r][c][0] = 0;
      memset(st, 0, 5);
      if (!x) continue;
      Val v = cell_val(c, r);
      fmt_val(x, v, sn->txt[r][c], sizeof sn->txt[r][c]);
      int al = x->align;
      if (al == AL_AUTO) al = v.t == V_NUM ? AL_RIGHT : (v.t == V_BOOL || v.t == V_ERR) ? AL_CENTER : AL_LEFT;
      st[0] = x->bold, st[1] = (unsigned char)al, st[2] = v.t == V_ERR ? 8 : x->color, st[3] = x->fill, st[4] = x->ital;
    }
}

static SheetSnap *snap_get(const char *id) {
  char path[700];
  sheet_path(id, path, sizeof path);
  uint32_t now = now_ms();
  int live = S.id[0] && !strcmp(S.id, id);
  SheetSnap *sn = NULL;
  for (int i = 0; i < 4; i++)
    if (!strcmp(SNAP[i].id, id)) sn = &SNAP[i];
  if (sn && live && sn->gen == GEN) return sn;
  if (sn && !live && now - sn->at < 700) return sn;
  struct stat st;
  long mt = stat(path, &st) ? -1 : (long)st.st_mtime;
  if (sn && !live && sn->mtime == mt) {
    sn->at = now;
    return sn;
  }
  if (!sn) {
    sn = &SNAP[snap_next];
    snap_next = (snap_next + 1) % 4;
  }
  memset(sn, 0, sizeof *sn);
  snprintf(sn->id, sizeof sn->id, "%s", id);
  sn->at = now, sn->mtime = mt;
  if (live) {
    snprintf(sn->title, sizeof sn->title, "%s", S.title);
    snap_fill(sn);
    sn->gen = GEN;
    sn->ok = 1;
    return sn;
  }
  if (mt < 0) return sn;
  char *body = office_read_file(path);
  if (!body) return sn;
  static Cell *saved[MAXR][MAXC];
  int scw[MAXC];
  char stitle[96];
  memcpy(saved, G, sizeof G);
  memcpy(scw, CW, sizeof CW);
  memcpy(stitle, S.title, sizeof stitle);
  memset(G, 0, sizeof G);
  deserialize(body);
  free(body);
  snprintf(sn->title, sizeof sn->title, "%s", S.title);
  snap_fill(sn);
  sheet_clear();
  memcpy(G, saved, sizeof G);
  memcpy(CW, scw, sizeof CW);
  memcpy(S.title, stitle, sizeof stitle);
  GEN++;
  sn->ok = 1;
  return sn;
}

int sheets_embed_size(const char *id, float *w, float *h) {
  SheetSnap *sn = snap_get(id);
  if (!sn->ok) return 0;
  *w = RH_W, *h = CH_H + sn->nr * ROW_H + 1;
  for (int c = 0; c < sn->nc; c++) *w += sn->cw[c];
  return 1;
}

int sheets_embed(Surface *s, const char *id, float x, float y, float w, float h, char *title, int tn) {
  SheetSnap *sn = snap_get(id);
  if (!sn->ok) return 0;
  snprintf(title, (size_t)tn, "%s", sn->title);
  if (!s) return 1;
  float nat_w = RH_W, nat_h = CH_H + sn->nr * ROW_H + 1;
  for (int c = 0; c < sn->nc; c++) nat_w += sn->cw[c];
  float u = w / nat_w;
  if (h / nat_h < u) u = h / nat_h;
  if (u > 2.5f) u = 2.5f;
  if (s->scale == SCALE && u > 1.4f) u = 1.4f;
  if (u < 0.2f) u = 0.2f;
  if (nat_w * u < w - 1) x += (w - nat_w * u) / 2;
  w = nat_w * u < w ? nat_w * u : w;
  h = nat_h * u < h ? nat_h * u : h;
  float q = u * s->scale / SCALE;
  uint32_t grid = THEME(RGB(226, 227, 231), RGB(54, 57, 64)), head = THEME(RGB(246, 247, 249), RGB(40, 42, 49));
  uint32_t ink = THEME(RGB(32, 33, 36), RGB(226, 228, 233)), page = THEME(RGB(255, 255, 255), RGB(34, 36, 42));
  gfx_rect(s, x, y, w, h, page);
  gfx_rect(s, x, y, w, CH_H * u, head);
  gfx_rect(s, x, y, RH_W * u, h, head);
  const Font *hf = doc_font(0, 0, 0);
  float cx = x + RH_W * u;
  for (int c = 0; c < sn->nc && cx < x + w; c++) {
    char cn[4];
    col_name(c, cn);
    float cw = sn->cw[c] * u, tw = text_w(hf, cn) * u * 0.8f;
    gfx_text_scaled(s, hf, cx + (cw - tw) / 2, y + (CH_H * u - line_h(hf) * u * 0.8f) / 2, cn, -1, C_MUTED, q * 0.8f);
    gfx_rect(s, cx, y, 1, h, grid);
    cx += cw;
  }
  for (int r = 0; r <= sn->nr; r++) {
    float ry = y + (CH_H + r * ROW_H) * u;
    if (ry > y + h) break;
    gfx_rect(s, x, ry, w, 1, grid);
    if (r == sn->nr) break;
    char rn[16];
    snprintf(rn, sizeof rn, "%d", r + 1);
    float tw = text_w(hf, rn) * u * 0.8f;
    gfx_text_scaled(s, hf, x + (RH_W * u - tw) / 2, ry + (ROW_H * u - line_h(hf) * u * 0.8f) / 2, rn, -1, C_MUTED, q * 0.8f);
    float xx = x + RH_W * u;
    for (int c = 0; c < sn->nc && xx < x + w; c++) {
      float cw = sn->cw[c] * u;
      unsigned char *st = sn->st[r][c];
      if (st[3]) gfx_rect(s, xx + 1, ry + 1, cw - 1, ROW_H * u - 1, fill_col(st[3]));
      const char *t = sn->txt[r][c];
      if (t[0]) {
        const Font *f = doc_font(0, st[0], st[4]);
        float tw2 = text_w(f, t) * u;
        float tx = st[1] == AL_RIGHT ? xx + cw - 7 * u - tw2 : st[1] == AL_CENTER ? xx + (cw - tw2) / 2 : xx + 7 * u;
        uint32_t col = st[2] == 8 ? RGB(217, 48, 37) : st[2] && !(g_dark && st[2] == 1) ? OFF_COLORS[st[2]] : ink;
        int sv[4];
        office_clip_push(s, xx + 2 * u, ry, cw - 4 * u, ROW_H * u, sv);
        gfx_text_scaled(s, f, tx, ry + (ROW_H * u - line_h(f) * u) / 2, t, -1, col, q);
        office_clip_pop(s, sv);
      }
      xx += cw;
    }
  }
  gfx_rect(s, x + RH_W * u, y, 1, h, grid);
  return 1;
}

void sheets_open(const char *id) {
  sheets_home_scan();
  open_sheet(id);
}

int sheets_embed_dims(const char *id, int *nc, int *nr) {
  SheetSnap *sn = snap_get(id);
  if (!sn->ok) return 0;
  int mc = 0, mr = 0;
  for (int r = 0; r < sn->nr; r++)
    for (int c = 0; c < sn->nc; c++)
      if (sn->txt[r][c][0]) {
        if (c + 1 > mc) mc = c + 1;
        if (r + 1 > mr) mr = r + 1;
      }
  *nc = mc, *nr = mr;
  return mc > 0;
}

const char *sheets_embed_cell(const char *id, int r, int c, int *bold, int *right) {
  SheetSnap *sn = snap_get(id);
  if (!sn->ok || r < 0 || c < 0 || r >= sn->nr || c >= sn->nc) return "";
  if (bold) *bold = sn->st[r][c][0];
  if (right) *right = sn->st[r][c][1] == AL_RIGHT;
  return sn->txt[r][c];
}

typedef struct {
  unsigned char bold, ital, strike, color, fill, fmt, dec, align;
} XStyle;

static void numfmt_code(int fm, int dec, char *out, int n) {
  char d[24] = "";
  if (dec > 0) {
    d[0] = '.';
    for (int i = 0; i < dec && i < 20; i++) d[i + 1] = '0';
    d[dec + 1 < 22 ? dec + 1 : 21] = 0;
  }
  if (fm == FM_NUM) snprintf(out, (size_t)n, "#,##0%s", dec < 0 ? ".00" : d);
  else if (fm == FM_CUR) snprintf(out, (size_t)n, "\"$\"#,##0%s", dec < 0 ? ".00" : d);
  else if (fm == FM_PCT) snprintf(out, (size_t)n, "0%s%%", dec < 0 ? "" : d);
  else if (dec >= 0) snprintf(out, (size_t)n, "0%s", d);
  else out[0] = 0;
}

static void export_xlsx(void) {
  char path[700], shown[200];
  office_export_path(S.title, "xlsx", path, sizeof path, shown, sizeof shown);
  ZipW *z = zw_open(path);
  if (!z) {
    office_toast("Could not save the file");
    return;
  }
  static XStyle xs[256];
  static unsigned char sidx[MAXR][MAXC];
  int nxs = 1;
  memset(&xs[0], 0, sizeof xs[0]);
  xs[0].dec = 255;
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++) {
      Cell *x = G[r][c];
      sidx[r][c] = 0;
      if (!x) continue;
      XStyle k = {x->bold, x->ital, x->strike, x->color, x->fill, x->fmt, x->dec, x->align};
      int f = -1;
      for (int i = 0; i < nxs; i++)
        if (!memcmp(&xs[i], &k, sizeof k)) f = i;
      if (f < 0 && nxs < 256) xs[f = nxs++] = k;
      sidx[r][c] = (unsigned char)(f < 0 ? 0 : f);
    }
  Buf b = {0};
  zw_adds(z, "[Content_Types].xml",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
          "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
          "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
          "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
          "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
          "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
          "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
          "</Types>");
  zw_adds(z, "_rels/.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
          "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
          "</Relationships>");
  zw_adds(z, "xl/_rels/workbook.xml.rels",
          "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
          "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
          "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
          "</Relationships>");
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>");
  buf_esc(&b, S.title, -1);
  buf_printf(&b, "</dc:title><dc:creator>Oreon Office</dc:creator></cp:coreProperties>");
  zw_add(z, "docProps/core.xml", b.s, b.n);
  b.n = 0;
  char sname[32];
  int k = 0;
  for (const char *t = S.title; *t && k < 31; t++)
    if (!strchr("[]:*?/\\", *t)) sname[k++] = *t;
  sname[k] = 0;
  if (!k) snprintf(sname, sizeof sname, "Sheet1");
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                 "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><bookViews><workbookView/></bookViews><sheets><sheet name=\"");
  buf_esc(&b, sname, -1);
  buf_printf(&b, "\" sheetId=\"1\" r:id=\"rId1\"/></sheets><calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>");
  zw_add(z, "xl/workbook.xml", b.s, b.n);
  b.n = 0;
  char codes[256][40];
  int nfid[256];
  int ncodes = 0;
  for (int i = 0; i < nxs; i++) {
    char cd[40];
    numfmt_code(xs[i].fmt, xs[i].dec == 255 ? -1 : xs[i].dec, cd, sizeof cd);
    nfid[i] = 0;
    if (!cd[0]) continue;
    int f = -1;
    for (int j = 0; j < ncodes; j++)
      if (!strcmp(codes[j], cd)) f = j;
    if (f < 0) snprintf(codes[f = ncodes++], sizeof codes[0], "%s", cd);
    nfid[i] = 164 + f;
  }
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
  if (ncodes) {
    buf_printf(&b, "<numFmts count=\"%d\">", ncodes);
    for (int j = 0; j < ncodes; j++) {
      buf_printf(&b, "<numFmt numFmtId=\"%d\" formatCode=\"", 164 + j);
      buf_esc(&b, codes[j], -1);
      buf_printf(&b, "\"/>");
    }
    buf_printf(&b, "</numFmts>");
  }
  buf_printf(&b, "<fonts count=\"%d\">", nxs);
  for (int i = 0; i < nxs; i++) {
    buf_printf(&b, "<font>%s%s%s<sz val=\"11\"/>", xs[i].bold ? "<b/>" : "", xs[i].ital ? "<i/>" : "", xs[i].strike ? "<strike/>" : "");
    if (xs[i].color) buf_printf(&b, "<color rgb=\"FF%06X\"/>", (unsigned)(OFF_COLORS[xs[i].color] & 0xffffff));
    buf_printf(&b, "<name val=\"Arial\"/><family val=\"2\"/></font>");
  }
  buf_printf(&b, "</fonts><fills count=\"%d\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>", nxs + 2);
  for (int i = 0; i < nxs; i++) {
    if (xs[i].fill) buf_printf(&b, "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF%06X\"/><bgColor indexed=\"64\"/></patternFill></fill>", (unsigned)(FILL_L[xs[i].fill] & 0xffffff));
    else buf_printf(&b, "<fill><patternFill patternType=\"none\"/></fill>");
  }
  buf_printf(&b, "</fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                 "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"%d\">", nxs);
  static const char *const HA[4] = {NULL, "left", "center", "right"};
  for (int i = 0; i < nxs; i++) {
    buf_printf(&b, "<xf numFmtId=\"%d\" fontId=\"%d\" fillId=\"%d\" borderId=\"0\" xfId=\"0\"%s%s%s", nfid[i], i, i + 2, nfid[i] ? " applyNumberFormat=\"1\"" : "",
               i ? " applyFont=\"1\"" : "", xs[i].fill ? " applyFill=\"1\"" : "");
    if (HA[xs[i].align & 3]) buf_printf(&b, " applyAlignment=\"1\"><alignment horizontal=\"%s\"/></xf>", HA[xs[i].align & 3]);
    else buf_printf(&b, "/>");
  }
  buf_printf(&b, "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
  zw_add(z, "xl/styles.xml", b.s, b.n);
  b.n = 0;
  int mc, mr;
  used_bounds(&mc, &mr);
  for (int r = 0; r < MAXR; r++)
    for (int c = 0; c < MAXC; c++)
      if (G[r][c]) {
        if (c > mc) mc = c;
        if (r > mr) mr = r;
      }
  buf_printf(&b, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                 "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
  if (mc >= 0) {
    char a[8], e[8];
    ref_name(0, 0, a);
    ref_name(mc, mr, e);
    buf_printf(&b, "<dimension ref=\"%s:%s\"/>", a, e);
  }
  buf_printf(&b, "<sheetViews><sheetView workbookViewId=\"0\"/></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/><cols>");
  for (int c = 0; c < MAXC && c <= (mc > 12 ? mc : 12); c++) buf_printf(&b, "<col min=\"%d\" max=\"%d\" width=\"%.2f\" customWidth=\"1\"/>", c + 1, c + 1, CW[c] / 7.0);
  buf_printf(&b, "</cols><sheetData>");
  GEN++;
  for (int r = 0; r <= mr; r++) {
    int any = 0;
    for (int c = 0; c <= mc; c++)
      if (G[r][c]) any = 1;
    if (!any) continue;
    buf_printf(&b, "<row r=\"%d\">", r + 1);
    for (int c = 0; c <= mc; c++) {
      Cell *x = G[r][c];
      if (!x) continue;
      char rn[12];
      ref_name(c, r, rn);
      int si = sidx[r][c];
      char sattr[16] = "";
      if (si) snprintf(sattr, sizeof sattr, " s=\"%d\"", si);
      if (!x->src) {
        buf_printf(&b, "<c r=\"%s\"%s/>", rn, sattr);
        continue;
      }
      Val v = cell_val(c, r);
      char vs[160];
      if (x->src[0] == '=') {
        const char *t = v.t == V_STR ? " t=\"str\"" : v.t == V_BOOL ? " t=\"b\"" : v.t == V_ERR ? " t=\"e\"" : "";
        buf_printf(&b, "<c r=\"%s\"%s%s><f>", rn, sattr, t);
        buf_esc(&b, x->src + 1, -1);
        buf_printf(&b, "</f>");
        if (v.t == V_NUM) buf_printf(&b, "<v>%.15g</v>", v.n);
        else if (v.t == V_BOOL) buf_printf(&b, "<v>%d</v>", v.n != 0);
        else if (v.t != V_EMPTY) {
          str_of(v, vs, sizeof vs);
          buf_printf(&b, "<v>");
          buf_esc(&b, vs, -1);
          buf_printf(&b, "</v>");
        }
        buf_printf(&b, "</c>");
      } else if (v.t == V_NUM) buf_printf(&b, "<c r=\"%s\"%s><v>%.15g</v></c>", rn, sattr, v.n);
      else if (v.t == V_BOOL) buf_printf(&b, "<c r=\"%s\"%s t=\"b\"><v>%d</v></c>", rn, sattr, v.n != 0);
      else {
        str_of(v, vs, sizeof vs);
        buf_printf(&b, "<c r=\"%s\"%s t=\"inlineStr\"><is><t xml:space=\"preserve\">", rn, sattr);
        buf_esc(&b, vs, -1);
        buf_printf(&b, "</t></is></c>");
      }
    }
    buf_printf(&b, "</row>");
  }
  buf_printf(&b, "</sheetData><pageMargins left=\"0.7\" right=\"0.7\" top=\"0.75\" bottom=\"0.75\" header=\"0.3\" footer=\"0.3\"/></worksheet>");
  zw_add(z, "xl/worksheets/sheet1.xml", b.s, b.n);
  free(b.s);
  office_toast(zw_close(z) ? "Could not save the file" : shown);
}

static int parse_ref_str(const char *s, int *c, int *r) {
  int col = 0, i = 0;
  while (isalpha((unsigned char)s[i])) col = col * 26 + (toupper((unsigned char)s[i]) - 'A' + 1), i++;
  if (!i || !isdigit((unsigned char)s[i])) return 0;
  *c = col - 1, *r = atoi(s + i) - 1;
  return 1;
}

static int fill_near(unsigned rgb) {
  int best = 0;
  long bd = 1L << 40;
  for (int i = 1; i < 8; i++) {
    uint32_t c = FILL_L[i];
    long dr = (long)((c >> 16) & 255) - (rgb >> 16 & 255), dg = (long)((c >> 8) & 255) - (rgb >> 8 & 255), db = (long)(c & 255) - (rgb & 255);
    long d = dr * dr + dg * dg + db * db;
    if (d < bd) bd = d, best = i;
  }
  return (rgb & 0xffffff) == 0xffffff ? 0 : best;
}

static int font_near(unsigned rgb) {
  if (((rgb >> 16 & 255) + (rgb >> 8 & 255) + (rgb & 255)) < 200) return 0;
  int best = 0;
  long bd = 1L << 40;
  for (int i = 2; i < 8; i++) {
    uint32_t c = OFF_COLORS[i];
    long dr = (long)((c >> 16) & 255) - (rgb >> 16 & 255), dg = (long)((c >> 8) & 255) - (rgb >> 8 & 255), db = (long)(c & 255) - (rgb & 255);
    long d = dr * dr + dg * dg + db * db;
    if (d < bd) bd = d, best = i;
  }
  return best;
}

typedef struct {
  unsigned char bold, ital, strike, color;
} XFont;

typedef struct {
  int c, r;
  char v[64];
} Cached;

static void fmt_from_code(int id, const char *code, unsigned char *fm, unsigned char *dec) {
  *fm = FM_GEN, *dec = 255;
  if (id == 9) *fm = FM_PCT, *dec = 0;
  else if (id == 10) *fm = FM_PCT, *dec = 2;
  else if (id == 3) *fm = FM_NUM, *dec = 0;
  else if (id == 4) *fm = FM_NUM, *dec = 2;
  else if (id == 2) *dec = 2;
  else if (id >= 5 && id <= 8) *fm = FM_CUR, *dec = 2;
  if (!code || !code[0]) return;
  int pct = strchr(code, '%') != NULL, cur = strchr(code, '$') != NULL || strstr(code, "[$") != NULL, grp = strstr(code, "#,##") != NULL;
  const char *dot = strchr(code, '.');
  int d = 0;
  if (dot)
    for (const char *q = dot + 1; *q == '0' || *q == '#'; q++) d++;
  if (pct) *fm = FM_PCT, *dec = (unsigned char)d;
  else if (cur) *fm = FM_CUR, *dec = (unsigned char)d;
  else if (grp) *fm = FM_NUM, *dec = (unsigned char)d;
  else if (dot) *dec = (unsigned char)d;
}

static int xlsx_load(Zip *z) {
  char v[256], target[300] = "xl/worksheets/sheet1.xml", rid[64] = "";
  size_t n;
  char *x = zip_read(z, "xl/workbook.xml", &n);
  if (!x) return 0;
  Xml X;
  xml_init(&X, x, n);
  while (xml_next(&X) != X_EOF)
    if (X.type == X_OPEN && xml_is(&X, "sheet")) {
      xml_attr(&X, "r:id", rid, sizeof rid);
      break;
    }
  free(x);
  x = zip_read(z, "xl/_rels/workbook.xml.rels", &n);
  if (x && rid[0]) {
    xml_init(&X, x, n);
    while (xml_next(&X) != X_EOF)
      if (X.type == X_OPEN && xml_is(&X, "Relationship")) {
        xml_attr(&X, "Id", v, sizeof v);
        if (strcmp(v, rid)) continue;
        xml_attr(&X, "Target", v, sizeof v);
        if (v[0] == '/') snprintf(target, sizeof target, "%s", v + 1);
        else snprintf(target, sizeof target, "xl/%s", v);
        break;
      }
  }
  free(x);
  int nss = 0, css = 0;
  char **ss = NULL;
  x = zip_read(z, "xl/sharedStrings.xml", &n);
  if (x) {
    xml_init(&X, x, n);
    Buf cur = {0};
    int in_si = 0, in_t = 0, skip = 0;
    while (xml_next(&X) != X_EOF) {
      if (X.type == X_OPEN) {
        if (xml_is(&X, "si")) in_si = 1, cur.n = 0, buf_put(&cur, "", 0);
        else if (xml_is(&X, "rPh")) skip = 1;
        else if (xml_is(&X, "t") && !X.empty) in_t = 1;
      } else if (X.type == X_CLOSE) {
        if (xml_is(&X, "t")) in_t = 0;
        else if (xml_is(&X, "rPh")) skip = 0;
        else if (xml_is(&X, "si") && in_si) {
          if (nss == css) css = css ? css * 2 : 256, ss = realloc(ss, sizeof(char *) * (size_t)css);
          ss[nss++] = strdup(cur.s ? cur.s : "");
          in_si = 0;
        }
      } else if (X.type == X_TEXT && in_t && !skip) {
        char *t = malloc((size_t)X.tlen * 3 + 8);
        int l = xml_text(&X, t, X.tlen * 3 + 8);
        buf_put(&cur, t, (size_t)l);
        free(t);
      }
    }
    free(cur.s);
    free(x);
  }
  static XStyle xf[512];
  XFont fonts[256];
  int fills[256], nfont = 0, nfill = 0, nxf = 0, nfmts = 0;
  int fmt_id[128];
  char fmt_code[128][48];
  memset(xf, 0, sizeof xf);
  x = zip_read(z, "xl/styles.xml", &n);
  if (x) {
    xml_init(&X, x, n);
    int sect = 0;
    XFont *cf = NULL;
    while (xml_next(&X) != X_EOF) {
      if (X.type == X_OPEN) {
        if (xml_is(&X, "numFmt") && nfmts < 128) {
          xml_attr(&X, "numFmtId", v, sizeof v);
          fmt_id[nfmts] = atoi(v);
          xml_attr(&X, "formatCode", fmt_code[nfmts], sizeof fmt_code[0]);
          nfmts++;
        } else if (xml_is(&X, "fonts")) sect = 1;
        else if (xml_is(&X, "fills")) sect = 2;
        else if (xml_is(&X, "cellXfs")) sect = 3;
        else if (xml_is(&X, "cellStyleXfs") || xml_is(&X, "dxfs")) sect = 9;
        else if (sect == 1 && xml_is(&X, "font") && nfont < 256) {
          cf = &fonts[nfont++];
          memset(cf, 0, sizeof *cf);
        } else if (sect == 1 && cf) {
          int on = !xml_attr(&X, "val", v, sizeof v) || (strcmp(v, "0") && strcmp(v, "false"));
          if (xml_is(&X, "b")) cf->bold = (unsigned char)on;
          else if (xml_is(&X, "i")) cf->ital = (unsigned char)on;
          else if (xml_is(&X, "strike")) cf->strike = (unsigned char)on;
          else if (xml_is(&X, "color") && xml_attr(&X, "rgb", v, sizeof v)) cf->color = (unsigned char)font_near((unsigned)strtoul(v, NULL, 16));
        } else if (sect == 2 && xml_is(&X, "fill") && nfill < 256) fills[nfill++] = 0;
        else if (sect == 2 && xml_is(&X, "fgColor") && nfill > 0 && xml_attr(&X, "rgb", v, sizeof v))
          fills[nfill - 1] = fill_near((unsigned)strtoul(v, NULL, 16));
        else if (sect == 3 && xml_is(&X, "xf") && nxf < 512) {
          XStyle *s = &xf[nxf++];
          s->dec = 255;
          xml_attr(&X, "fontId", v, sizeof v);
          int fi = atoi(v);
          if (fi >= 0 && fi < nfont) s->bold = fonts[fi].bold, s->ital = fonts[fi].ital, s->strike = fonts[fi].strike, s->color = fonts[fi].color;
          xml_attr(&X, "fillId", v, sizeof v);
          fi = atoi(v);
          if (fi >= 0 && fi < nfill) s->fill = (unsigned char)fills[fi];
          xml_attr(&X, "numFmtId", v, sizeof v);
          int id = atoi(v);
          const char *code = NULL;
          for (int j = 0; j < nfmts; j++)
            if (fmt_id[j] == id) code = fmt_code[j];
          fmt_from_code(id, code, &s->fmt, &s->dec);
        } else if (sect == 3 && xml_is(&X, "alignment") && nxf > 0 && xml_attr(&X, "horizontal", v, sizeof v))
          xf[nxf - 1].align = !strcmp(v, "left") ? AL_LEFT : !strcmp(v, "center") ? AL_CENTER : !strcmp(v, "right") ? AL_RIGHT : AL_AUTO;
      } else if (X.type == X_CLOSE) {
        if (xml_is(&X, "fonts") || xml_is(&X, "fills") || xml_is(&X, "cellXfs") || xml_is(&X, "cellStyleXfs") || xml_is(&X, "dxfs")) sect = 0;
        else if (xml_is(&X, "font")) cf = NULL;
      }
    }
    free(x);
  }
  x = zip_read(z, target, &n);
  if (!x) {
    for (int i = 0; i < nss; i++) free(ss[i]);
    free(ss);
    return 0;
  }
  static Cached cache[4096];
  int ncache = 0;
  xml_init(&X, x, n);
  int cc = -1, cr = -1, cs = 0, in_v = 0, in_f = 0, in_t = 0, row = -1, col_auto = 0;
  char ct[16] = "";
  Buf val = {0}, form = {0};
  while (xml_next(&X) != X_EOF) {
    if (X.type == X_OPEN) {
      if (xml_is(&X, "col")) {
        int a = xml_attr(&X, "min", v, sizeof v) ? atoi(v) : 0;
        int bmax = xml_attr(&X, "max", v, sizeof v) ? atoi(v) : a;
        if (xml_attr(&X, "width", v, sizeof v)) {
          int w = (int)(atof(v) * 7 + 0.5);
          if (w < 30) w = 30;
          if (w > 600) w = 600;
          for (int c = a - 1; c < bmax && c < MAXC; c++)
            if (c >= 0) CW[c] = w;
        }
      } else if (xml_is(&X, "row")) {
        row = xml_attr(&X, "r", v, sizeof v) ? atoi(v) - 1 : row + 1;
        col_auto = 0;
      } else if (xml_is(&X, "c")) {
        if (!xml_attr(&X, "r", v, sizeof v) || !parse_ref_str(v, &cc, &cr)) cc = col_auto, cr = row;
        col_auto = cc + 1;
        cs = xml_attr(&X, "s", v, sizeof v) ? atoi(v) : 0;
        xml_attr(&X, "t", ct, sizeof ct);
        val.n = 0, form.n = 0;
        buf_put(&val, "", 0), buf_put(&form, "", 0);
        if (X.empty && cs > 0 && cs < nxf && cc >= 0 && cc < MAXC && cr >= 0 && cr < MAXR) {
          Cell *c = cell_mk(cc, cr);
          XStyle *s = &xf[cs];
          c->bold = s->bold, c->ital = s->ital, c->strike = s->strike, c->color = s->color, c->fill = s->fill, c->fmt = s->fmt, c->dec = s->dec, c->align = s->align;
        }
      } else if (xml_is(&X, "v")) in_v = !X.empty;
      else if (xml_is(&X, "f")) in_f = !X.empty;
      else if (xml_is(&X, "t")) in_t = !X.empty;
    } else if (X.type == X_CLOSE) {
      if (xml_is(&X, "v")) in_v = 0;
      else if (xml_is(&X, "f")) in_f = 0;
      else if (xml_is(&X, "t")) in_t = 0;
      else if (xml_is(&X, "c")) {
        if (cc < 0 || cc >= MAXC || cr < 0 || cr >= MAXR) continue;
        char src[600] = "";
        const char *vs = val.s ? val.s : "";
        if (form.s && form.s[0]) {
          const char *f = form.s;
          char tmp[580];
          int k = 0;
          for (int i = 0; f[i] && k < 570; i++) {
            if (!strncmp(f + i, "_xlfn.", 6)) i += 5;
            else if (!strncmp(f + i, "_xlws.", 6)) i += 5;
            else tmp[k++] = f[i];
          }
          tmp[k] = 0;
          snprintf(src, sizeof src, "=%s", tmp);
          if (ncache < 4096) {
            cache[ncache].c = cc, cache[ncache].r = cr;
            if (!strcmp(ct, "s") && atoi(vs) >= 0 && atoi(vs) < nss) snprintf(cache[ncache].v, sizeof cache[0].v, "%s", ss[atoi(vs)]);
            else if (!strcmp(ct, "b")) snprintf(cache[ncache].v, sizeof cache[0].v, "%s", atoi(vs) ? "TRUE" : "FALSE");
            else snprintf(cache[ncache].v, sizeof cache[0].v, "%s", vs);
            ncache++;
          }
        } else if (!strcmp(ct, "s")) {
          int i = atoi(vs);
          if (i >= 0 && i < nss) snprintf(src, sizeof src, "%s", ss[i]);
        } else if (!strcmp(ct, "b")) snprintf(src, sizeof src, "%s", atoi(vs) ? "TRUE" : "FALSE");
        else snprintf(src, sizeof src, "%s", vs);
        if (src[0] && strcmp(ct, "s") && strcmp(ct, "inlineStr") && strcmp(ct, "str") && src[0] != '=') {
          char *e;
          double d = strtod(src, &e);
          if (*e == 0) snprintf(src, sizeof src, "%.15g", d);
        }
        if (src[0] && (!strcmp(ct, "s") || !strcmp(ct, "inlineStr") || !strcmp(ct, "str")) && src[0] == '=') {
          memmove(src + 1, src, strlen(src) + 1);
          src[0] = '\'';
        }
        if (src[0] || cs) {
          Cell *c = cell_mk(cc, cr);
          if (!c) continue;
          free(c->src);
          c->src = src[0] ? strdup(src) : NULL;
          if (cs > 0 && cs < nxf) {
            XStyle *s = &xf[cs];
            c->bold = s->bold, c->ital = s->ital, c->strike = s->strike, c->color = s->color, c->fill = s->fill, c->fmt = s->fmt, c->dec = s->dec, c->align = s->align;
          }
        }
      }
    } else if (X.type == X_TEXT && (in_v || in_f || in_t)) {
      char *t = malloc((size_t)X.tlen * 3 + 8);
      int l = xml_text(&X, t, X.tlen * 3 + 8);
      buf_put(in_f ? &form : &val, t, (size_t)l);
      free(t);
    }
  }
  free(val.s);
  free(form.s);
  free(x);
  for (int i = 0; i < nss; i++) free(ss[i]);
  free(ss);
  GEN++;
  for (int i = 0; i < ncache; i++) {
    Val r = cell_val(cache[i].c, cache[i].r);
    if (r.t == V_ERR && cache[i].v[0]) {
      Cell *c = G[cache[i].r][cache[i].c];
      free(c->src);
      c->src = strdup(cache[i].v);
      GEN++;
    }
  }
  return 1;
}

static void csv_load(const char *s) {
  int r = 0, c = 0;
  char cell[600];
  int k = 0, q = 0;
  for (const char *p = s;; p++) {
    char ch = *p;
    if (q) {
      if (ch == '"' && p[1] == '"') cell[k < 590 ? k++ : k] = '"', p++;
      else if (ch == '"') q = 0;
      else if (ch) {
        if (k < 590) cell[k++] = ch == '\n' ? ' ' : ch;
      } else break;
      continue;
    }
    if (ch == '"' && k == 0) {
      q = 1;
      continue;
    }
    if (ch == ',' || ch == '\n' || ch == 0 || ch == '\r') {
      if (ch == '\r' && p[1] == '\n') continue;
      cell[k] = 0;
      char a[600];
      office_ascii(cell, k, a, sizeof a);
      if (a[0] && r < MAXR && c < MAXC) cell_set_src(c, r, a);
      k = 0;
      if (ch == ',') c++;
      else {
        r++, c = 0;
        if (!ch) break;
      }
      continue;
    }
    if (k < 590) cell[k++] = ch;
  }
}

int sheets_import(const char *path) {
  char title[96];
  office_title_from_path(path, title, sizeof title);
  size_t l = strlen(path);
  int csv = l > 4 && !strcasecmp(path + l - 4, ".csv");
  Zip *z = NULL;
  char *body = NULL;
  if (csv) {
    body = office_read_file(path);
    if (!body) return 0;
  } else {
    z = zip_open(path);
    char *chk = z ? zip_read(z, "xl/workbook.xml", NULL) : NULL;
    if (!chk) {
      zip_close(z);
      return 0;
    }
    free(chk);
  }
  sheets_home_scan();
  new_sheet(title);
  int ok = csv ? (csv_load(body), 1) : xlsx_load(z);
  free(body);
  zip_close(z);
  GEN++;
  save_sheet();
  return ok;
}
