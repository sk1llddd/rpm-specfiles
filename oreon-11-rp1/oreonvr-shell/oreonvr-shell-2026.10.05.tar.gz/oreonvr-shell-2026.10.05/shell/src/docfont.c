#include "oreonvr.h"

#include "font_doc.h"

static const Font *const DOCF[4][4] = {
    {&FONT_DOC_NORMAL_R_DATA, &FONT_DOC_NORMAL_B_DATA, &FONT_DOC_NORMAL_I_DATA, &FONT_DOC_NORMAL_BI_DATA},
    {&FONT_DOC_H2_R_DATA, &FONT_DOC_H2_B_DATA, &FONT_DOC_H2_I_DATA, &FONT_DOC_H2_BI_DATA},
    {&FONT_DOC_H1_R_DATA, &FONT_DOC_H1_B_DATA, &FONT_DOC_H1_I_DATA, &FONT_DOC_H1_BI_DATA},
    {&FONT_DOC_TITLE_R_DATA, &FONT_DOC_TITLE_B_DATA, &FONT_DOC_TITLE_I_DATA, &FONT_DOC_TITLE_BI_DATA},
};

const Font *doc_font(int size, int bold, int italic) {
  if (size < 0) size = 0;
  if (size > 3) size = 3;
  return DOCF[size][(bold ? 1 : 0) | (italic ? 2 : 0)];
}

float doc_char_w(const Font *f, char c) {
  unsigned ch = (unsigned char)c;
  if (ch < 32 || ch > 126) ch = '?';
  return (float)f->glyphs[ch - 32].adv16 / 16.f / SCALE;
}
