#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "oreonvr.h"

#define LK_W 720
#define LK_H 290
#define GRACE_MS 900

static int lock_idx = -1;
static unsigned long hidden_mask;
static int shown_min = -1;
static uint32_t started;
static int armed;
static float base[6];

static void lock_unlock(void) {
  if (lock_idx < 0) return;
  int i = lock_idx;
  lock_idx = -1;
  for (int k = 0; k < MAXP; k++)
    if (k != i && P[k].used && (hidden_mask >> k & 1)) {
      P[k].visible = 1;
      P[k].dirty = 1;
    }
  hidden_mask = 0;
  panel_close(i);
}

static void lock_draw(Panel *p, Surface *s, float ox, float oy) {
  gfx_rrect(s, ox, oy, LK_W, LK_H, 28, RGBA(16, 20, 30, 242));
  time_t t = time(NULL);
  struct tm tm;
  localtime_r(&t, &tm);
  char tb[16], db[48];
  strftime(tb, sizeof tb, "%H:%M", &tm);
  strftime(db, sizeof db, "%A, %B %-d", &tm);
  float q = 2.9f;
  gfx_text_scaled(s, F_CLOCK, ox + (LK_W - gfx_text_w(F_CLOCK, tb) * q) * 0.5f, oy + 34, tb, -1, RGB(255, 255, 255), q);
  float dq = 1.9f;
  gfx_text_scaled(s, F_BODY, ox + (LK_W - gfx_text_w(F_BODY, db) * dq) * 0.5f, oy + 222, db, -1, RGB(160, 170, 190), dq);
}

static void lock_key(Panel *p, int code, int mods) {
  (void)p, (void)mods;
  lock_unlock();
}

static void snapshot(void) {
  base[0] = W.gyaw, base[1] = W.gpitch, base[2] = W.gx, base[3] = W.gy + W.gz, base[4] = (float)W.mx, base[5] = (float)W.my;
}

static int lock_tick_app(Panel *p, uint32_t now) {
  if (!armed) {
    if (now - started < GRACE_MS) return 0;
    armed = 1;
    snapshot();
    return 0;
  }
  float turn = fabsf(W.gyaw - base[0]) + fabsf(W.gpitch - base[1]);
  float step = fabsf(W.gx - base[2]) + fabsf(W.gy + W.gz - base[3]);
  float ptr = fabsf((float)W.mx - base[4]) + fabsf((float)W.my - base[5]);
  if (turn > 0.06f || step > 20.f || ptr > 24.f) {
    lock_unlock();
    return 0;
  }
  time_t t = time(NULL);
  struct tm tm;
  localtime_r(&t, &tm);
  int m = tm.tm_hour * 60 + tm.tm_min;
  if (m == shown_min) return 0;
  shown_min = m;
  return 1;
}

static App lock_app = {"lock", "Lock", IC_SETTINGS, LK_W, LK_H, NULL, lock_draw, NULL, NULL, lock_key, NULL, lock_tick_app, NULL};

void lock_start(void) {
  if (lock_idx >= 0 || OV.draw) return;
  hidden_mask = 0;
  for (int k = 0; k < MAXP; k++)
    if (P[k].used && P[k].visible) {
      hidden_mask |= 1ul << k;
      P[k].visible = 0;
    }
  int i = panel_create(PK_WINDOW, LK_W, LK_H, "Lock", &lock_app);
  if (i < 0) {
    for (int k = 0; k < MAXP; k++)
      if (hidden_mask >> k & 1) P[k].visible = 1;
    return;
  }
  lock_idx = i;
  P[i].nobar = 1;
  shown_min = -1;
  started = now_ms();
  armed = 0;
  scene_place_in_view(&P[i], 760.f, 0.f);
  P[i].appear = 0.f;
  panel_raise(i);
  W.focus = i;
}

int lock_active(void) { return lock_idx >= 0; }
