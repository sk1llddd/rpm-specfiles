#ifndef OREONVR_OFFICE_H
#define OREONVR_OFFICE_H

#include <stddef.h>

#include "oreonvr.h"

#define OFF_W 1080
#define OFF_H 720
#define OFF_HEAD 56
#define OFF_TOOL_Y 68
#define OFF_TOOL_H 44
#define OFF_HOME_HEAD 64
#define OFF_TPL_W 124
#define OFF_TPL_H 160
#define OFF_TPL_GAP 18
#define OFF_CARD_W 176
#define OFF_CARD_GAP 24
#define OFF_CARD_TH 200
#define OFF_CARD_STEP 278

#define N_ACC THEME(RGB(84, 76, 230), RGB(138, 130, 255))
#define N_TINT THEME(RGB(236, 235, 253), RGB(50, 48, 88))
#define N_TINT_HOT THEME(RGB(241, 240, 244), RGB(52, 54, 62))
#define N_CANVAS THEME(RGB(243, 242, 239), RGB(22, 23, 27))
#define N_HEAD THEME(RGB(250, 249, 247), RGB(28, 29, 34))
#define N_PAGE THEME(RGB(255, 255, 255), RGB(34, 36, 42))
#define N_SEL THEME(RGB(219, 216, 252), RGB(64, 60, 120))
#define N_LINE THEME(RGB(232, 230, 226), RGB(44, 46, 52))
#define N_ICON THEME(RGB(64, 64, 72), RGB(220, 222, 230))

#define S_ACC THEME(RGB(16, 140, 92), RGB(70, 200, 140))
#define S_TINT THEME(RGB(224, 243, 234), RGB(28, 64, 50))
#define S_SEL THEME(RGBA(16, 140, 92, 34), RGBA(70, 200, 140, 40))

#define P_ACC THEME(RGB(222, 96, 24), RGB(255, 150, 82))
#define P_TINT THEME(RGB(253, 236, 224), RGB(84, 50, 30))

extern const uint32_t OFF_COLORS[8];

const char *user_home(void);
void office_go_home(void);
void office_toast(const char *m);
void office_show_keyboard(void);
void office_set_title(void);
void office_dirs(char *out, size_t n, const char *sub, const char *env);
void office_mkdirs(const char *path);
char *office_read_file(const char *path);
void office_fmt_date(long t, char *out, size_t n);
void office_card(Surface *s, float x, float y, float w, float h, int hot, uint32_t acc);
void office_trash(Surface *s, float tx, float ty, int hot);
void office_mark(Surface *s, float x, float y, int app);
void office_mark_k(Surface *s, float x, float y, float k, int app);
float office_tpl_x(int i, int n);

void sheets_home_draw(Surface *s, float ox, float oy, int hot, float top);
int sheets_home_zone(float x, float y, float top);
int sheets_home_press(int z);
float sheets_home_h(void);
void sheets_home_scan(void);
int sheets_home_confirm(void);
void sheets_home_reset(void);
void sheets_draw(Panel *p, Surface *s, float ox, float oy, int hot);
int sheets_zone(float x, float y);
void sheets_press(Panel *p, float x, float y, int button, int down);
void sheets_key(Panel *p, int code, int mods);
void sheets_scroll(float x, float y, int steps);
int sheets_tick(Panel *p, uint32_t now);
void sheets_save_now(void);
const char *sheets_title(void);
int sheets_new_from_template(int t);

void slides_home_draw(Surface *s, float ox, float oy, int hot, float top);
int slides_home_zone(float x, float y, float top);
int slides_home_press(int z);
float slides_home_h(void);
void slides_home_scan(void);
void slides_home_reset(void);
void slides_draw(Panel *p, Surface *s, float ox, float oy, int hot);
int slides_zone(float x, float y);
void slides_press(Panel *p, float x, float y, int button, int down);
void slides_key(Panel *p, int code, int mods);
void slides_scroll(float x, float y, int steps);
int slides_tick(Panel *p, uint32_t now);
void slides_save_now(void);
const char *slides_title(void);
int slides_new(void);
int slides_presenting(void);
void slides_stop_present(void);

enum { EMB_CHROME = 1, EMB_SEL = 2 };
enum { PZ_BLOCK = 8000, PZ_DIM, PZ_CLOSE, PZ_BACK, PZ_TAB = 8010, PZ_LOC = 8020, PZ_ROW = 8100, PZ_SLIDE = 8300 };

uint32_t office_acc(int kind);
void office_clip_push(Surface *s, float x, float y, float w, float h, int *save);
void office_clip_pop(Surface *s, const int *save);
int office_embed_parse(const char *ref, int *kind, char *id, int idn, int *sub);
void office_embed_ref(char *out, int n, int kind, const char *id, int sub);
void office_embed_draw(Surface *s, int kind, const char *id, int sub, float x, float y, float w, float h, int flags);
void office_embed_open(int kind, const char *id, int sub);
void office_new(int kind);
int office_embed_title(int kind, const char *id, int sub, char *t, int tn);
void slides_insert_embed(int kind, const char *id, int sub);
void office_picker_open(int tab, int host_kind, const char *host_id);
int office_picker_on(void);
void office_picker_close(void);
void office_picker_draw(Surface *s, float ox, float oy, float w, float h, int hot);
int office_picker_zone(float x, float y, float w, float h);
int office_picker_press(int z, int *kind, char *id, int idn, int *sub);
void office_picker_scroll(int steps);
int docs_embed(Surface *s, const char *id, float x, float y, float w, float h, char *title, int tn);
int sheets_embed_size(const char *id, float *w, float *h);
int sheets_embed_dims(const char *id, int *nc, int *nr);
const char *sheets_embed_cell(const char *id, int r, int c, int *bold, int *right);
int sheets_embed(Surface *s, const char *id, float x, float y, float w, float h, char *title, int tn);
int slides_embed(Surface *s, const char *id, int sub, float x, float y, float w, float h, char *title, int tn);
void sheets_open(const char *id);
void slides_open(const char *id, int sub);

typedef struct {
  char *s;
  size_t n, cap;
} Buf;

typedef struct ZipW ZipW;
typedef struct Zip Zip;

enum { X_EOF, X_OPEN, X_CLOSE, X_TEXT };

typedef struct {
  const char *p, *end;
  int type;
  const char *name, *lname, *attrs, *text;
  int nlen, llen, alen, tlen, empty;
} Xml;

void buf_printf(Buf *b, const char *fmt, ...);
void buf_put(Buf *b, const char *t, size_t n);
void buf_esc(Buf *b, const char *t, int n);
ZipW *zw_open(const char *path);
void zw_add(ZipW *z, const char *name, const char *data, size_t len);
void zw_adds(ZipW *z, const char *name, const char *s);
int zw_close(ZipW *z);
Zip *zip_open(const char *path);
char *zip_read(Zip *z, const char *name, size_t *len);
void zip_close(Zip *z);
int office_ascii(const char *s, int n, char *out, int cap);
void xml_init(Xml *x, const char *s, size_t n);
int xml_next(Xml *x);
int xml_is(const Xml *x, const char *lname);
int xml_attr(const Xml *x, const char *name, char *out, int cap);
int xml_text(const Xml *x, char *out, int cap);
void xml_skip(Xml *x);
int office_export_path(const char *title, const char *ext, char *path, int n, char *shown, int sn);
void office_title_from_path(const char *path, char *out, int n);
void office_import_open(int kind);
const char *office_import_path(void);
int docs_import(const char *path);
int sheets_import(const char *path);
int slides_import(const char *path);

#endif
