#ifndef OREONVR_H
#define OREONVR_H

#include <stdint.h>
#include <sys/types.h>

#define PI_F 3.14159265f
#define SCALE 2
#define MARGIN 28
#define BAR_H 40
#define WORLD_PER_PX 1.0f

#define RGB(r, g, b) (0xff000000u | ((uint32_t)(r) << 16) | ((uint32_t)(g) << 8) | (uint32_t)(b))
#define RGBA(r, g, b, a) (((uint32_t)(a) << 24) | ((uint32_t)(r) << 16) | ((uint32_t)(g) << 8) | (uint32_t)(b))

extern int g_dark;
#define THEME(l, d) (g_dark ? (d) : (l))

#define C_WIN THEME(RGB(247, 248, 250), RGB(30, 33, 39))
#define C_WIN_EDGE THEME(RGB(212, 216, 222), RGB(58, 63, 72))
#define C_BAR THEME(RGB(255, 255, 255), RGB(38, 42, 49))
#define C_BAR_LINE THEME(RGB(236, 238, 242), RGB(52, 57, 65))
#define C_TITLE THEME(RGB(61, 67, 76), RGB(222, 226, 232))
#define C_TEXT THEME(RGB(42, 47, 54), RGB(232, 235, 240))
#define C_MUTED THEME(RGB(108, 115, 125), RGB(150, 157, 168))
#define C_CLOSE THEME(RGB(92, 99, 108), RGB(170, 176, 186))
#define C_CLOSE_HOT RGB(232, 17, 35)
#define C_HOVER THEME(RGB(236, 239, 244), RGB(52, 57, 66))
#define C_ACCENT RGB(47, 107, 255)
#define C_TERM_BG RGB(23, 27, 32)
#define C_TERM_FG RGB(232, 237, 242)
#define C_TERM_GREEN RGB(94, 233, 160)

typedef struct {
  short adv16;
  short w, h;
  short ox, oy;
  int off;
} Glyph;

typedef struct {
  int ascent, descent;
  const Glyph *glyphs;
  const unsigned char *bits;
} Font;

extern const Font *F_UI, *F_UI_MED, *F_BODY, *F_SMALL, *F_H1, *F_CLOCK, *F_MONO;

typedef struct {
  int w, h;
  int stride;
  int scale;
  uint32_t *px;
  int owned;

  int cx0, cy0, cx1, cy1;
} Surface;

int surf_init(Surface *s, int lw, int lh, int scale);
void surf_wrap(Surface *s, uint32_t *px, int w, int h, int stride);
void surf_free(Surface *s);
void surf_clear(Surface *s, uint32_t argb);
void gfx_clip(Surface *s, float x, float y, float w, float h);
void gfx_noclip(Surface *s);

void gfx_rect(Surface *s, float x, float y, float w, float h, uint32_t c);
void gfx_rrect(Surface *s, float x, float y, float w, float h, float r, uint32_t c);
void gfx_rrect_band(Surface *s, float x, float y, float w, float h, float r, float y0, float y1, uint32_t c);
void gfx_shadow(Surface *s, float x, float y, float w, float h, float r, float blur, uint32_t c);
void gfx_disc(Surface *s, float cx, float cy, float r, uint32_t c);
void gfx_ring(Surface *s, float cx, float cy, float r, float th, uint32_t c);
void gfx_line(Surface *s, float x0, float y0, float x1, float y1, float th, uint32_t c);
void gfx_tri(Surface *s, float x0, float y0, float x1, float y1, float x2, float y2, uint32_t c);
float gfx_text(Surface *s, const Font *f, float x, float y, const char *t, uint32_t c);
float gfx_text_w(const Font *f, const char *t);
float gfx_text_scaled(Surface *s, const Font *f, float x, float y, const char *t, int n, uint32_t c, float q);
void gfx_text_c(Surface *s, const Font *f, float cx, float y, const char *t, uint32_t c);
void gfx_text_fit(Surface *s, const Font *f, float x, float y, float maxw, const char *t, uint32_t c);
void gfx_blit_bilinear(Surface *s, const uint32_t *src, int sw, int sh, float x, float y, float w, float h,
                       float r_bottom);
void gfx_blit_premul(Surface *s, const uint32_t *src, int sw, int sh, float x, float y, float w, float h);

enum { IC_APPS, IC_TERM, IC_FILES, IC_NOTES, IC_SETTINGS, IC_FOLDER, IC_DOC, IC_DESKTOP, IC_TASKS, IC_KEYBOARD, IC_OFFICE, IC_STORE, IC_SURF, IC_INSTALL };
void gfx_icon(Surface *s, int icon, float x, float y, float size);
const Font *doc_font(int size, int bold, int italic);
float doc_char_w(const Font *f, char c);

typedef struct App App;

typedef enum { PK_WINDOW, PK_DOCK, PK_CHILD } PanelKind;

typedef struct Panel {
  int used, visible;
  PanelKind kind;
  float x, y, z;
  float yaw, tilt;
  int lw, lh;
  Surface surf;
  Surface base;
  int chrome_key;
  int zone;
  int dirty;
  float appear;
  int seq;
  char title[64];
  App *app;
  void *state;
  int parent;
  int nobar;
} Panel;

#define BARH(p) ((p)->nobar ? 0 : BAR_H)

#define MAXP 24

typedef struct {

  float cx, cy, cz, yaw, pitch;
  float gx, gy, gz, gyaw, gpitch;

  int vr;
  int lens;
  float ipd;
  float sens;
  int sky_on;
  float sky_yaw;
  int bg_gen; /* bumped when the background changes, to force a redraw */

  int mx, my;
  int hover;
  float hs, ht;
  float hdist;
  int focus;

  float fps;
  int out_w, out_h;
  const char *backend;
} World;

extern World W;
extern Panel P[MAXP];

typedef struct {
  void (*draw)(Surface *s, float x, float y, float w, float h, float mx, float my);
  void (*press)(float x, float y, int button, int down);
  void (*key)(int code, int mods);
  void (*wheel)(int steps);
  float w, h;
  int dirty;
} Overlay;

extern Overlay OV;

void scene_init(void);
int scene_load_sky(const char *path);
const char *scene_sky_path(void);
int scene_load_image(const char *path);
void scene_bg_solid(uint32_t c);
void scene_bg_gradient(uint32_t top, uint32_t bottom);
void bg_restore(void);
void scene_render(Surface *out);
void scene_tick(float dt);
void scene_pointer_ray(float *dx, float *dy, float *dz);
int scene_pick(float dx, float dy, float dz, float *s, float *t, float *dist);
void scene_place_in_view(Panel *p, float dist, float side);
void scene_face_head(Panel *p);
void scene_basis(float yaw, float pitch, float *f, float *r, float *u);
void scene_recenter(void);
int scene_panel_point(const Panel *p, float lx, float ly, int *sx, int *sy);

struct App {
  const char *id;
  const char *name;
  int icon;
  int w, h;
  void (*open)(Panel *p);
  void (*draw)(Panel *p, Surface *s, float ox, float oy);
  void (*click)(Panel *p, float x, float y);
  void (*scroll)(Panel *p, float x, float y, int steps);
  void (*key)(Panel *p, int code, int mods);
  int (*zone)(Panel *p, float x, float y);
  int (*tick)(Panel *p, uint32_t now_ms);
  void (*close)(Panel *p);

  void (*press)(Panel *p, float x, float y, int button, int down);
  void (*rawkey)(Panel *p, int code, int down);
  int (*close_request)(Panel *p);
};

extern App *APPS[];
extern App desktop_app;
extern App tasks_app;
extern App notes_app;
extern App store_app;
extern App surf_app;
extern App install_app;
extern App keyboard_app;
void keyboard_place(int i);
void keyboard_clear_echo(void);

typedef struct {
  char id[128];
  char name[96];
  uint32_t *icon;
  int iw, ih;
  char path[256];
} GApp;

void gnome_init(void);
void gnome_poll(uint32_t now);
int gnome_app_count(void);
GApp *gnome_app(int i);
GApp *gnome_app_by_id(const char *id);
int gnome_app_running(const char *id);
void gnome_launch(const char *id);

void wl_init(void);
void wl_poll(uint32_t now);
int wl_launch(const char *desktop_file);
int wl_surface_count(void);
int gnome_focus_app(const char *id);
void gnome_desktop(int on);
extern int gnome_apps_changed;

int panel_create(PanelKind kind, int lw, int lh, const char *title, App *app);
void panel_resize(int i, int lw, int lh);
void panel_place_new(int i);
extern int NAPPS;
App *app_by_id(const char *id);
int panel_open_app(const char *id);
void panel_close(int i);
void panel_raise(int i);
void panel_redraw(Panel *p);
int panel_zone(Panel *p, float x, float y);
void dock_init(void);
void dock_follow(float dt, int snap);
void shell_power(const char *what);
void lock_start(void);
void widgets_init(void);
void widgets_tick(uint32_t now);
int widget_panel(const Panel *p);
int widget_def_count(void);
int widgets_enabled_count(void);
int widgets_animating(void);
int widgets_page(void);
int widgets_editing(void);
int home_app_count(void);
const char *home_app_name(int i);
void home_app_icon(int i, Surface *s, float x, float y, float size);
void home_app_launch(int i);
int tasks_total(void);
int tasks_done_count(void);
const char *tasks_title_at(int k);
void tasks_complete_at(int k);
void files_open_path(const char *path);
void surf_open_url(const char *url);
int surf_shortcuts(char (*names)[60], char (*urls)[600], int max);
int lock_active(void);

enum { MOD_SHIFT = 1, MOD_CTRL = 2, MOD_ALT = 4, MOD_CAPS = 8 };
void input_pointer_move(int x, int y);
void input_pointer_rel(int dx, int dy);
void input_button(int button, int down);
void input_wheel(int steps);
void input_key(int code, int down, int repeat);
int input_mods(void);
void input_begin_drag(int panel);
int input_dragging(void);
int key_to_bytes(int code, int mods, char *out);
int key_from_char(char c, int *shift);

int evdev_open_all(void);
void evdev_poll(void);
int evdev_fd_count(void);

typedef struct Term Term;
Term *term_new(int cols, int rows);
void term_free(Term *t);
int term_poll(Term *t);
int term_alive(Term *t);
void term_write(Term *t, const char *b, int n);
void term_draw(Term *t, Surface *s, float x, float y, float cw, float ch, int cursor_on);
void term_scroll(Term *t, int lines);
void term_feed(Term *t, const char *b, int n);

typedef struct {
  const char *name;
  int w, h;
  uint32_t *(*begin)(int *stride);
  void (*end)(void);
  int (*pump)(void);
  void (*shutdown)(void);
} Output;

int out_drm(Output *o);
int out_fbdev(Output *o);
int out_sdl(Output *o, int w, int h);
int out_headless(Output *o, int w, int h);
void out_headless_shot(const char *path);

uint32_t now_ms(void);
extern int g_running;
extern int g_dev;

#endif
