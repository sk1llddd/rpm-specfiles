#include <ctype.h>
#include <dirent.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <time.h>
#include <unistd.h>

#include <linux/input.h>

#include "store.h"

#define CU 240
#define CWIDE 500
#define CH 240
#define WI 14
#define WGAP 20
#define GCOLS 6
#define GROWS 3
#define MAXPG 8
#define GSX (CU + WGAP)
#define GSY (CH + WGAP)
#define GPW (GCOLS * GSX - WGAP)
#define WDIST 1500.f
#define WHOME_Y 36.f
#define WHOME_Z 880.f
#define CENTER_Y (WHOME_Y + 60.f)
#define PAGE_ANG (GPW / WDIST + 0.3f)
#define NW_DEF 8
#define PG_W 640
#define PG_H 64
#define GAL_W 1100
#define GAL_H 640

#define K_CARD THEME(RGBA(255, 255, 255, 248), RGBA(34, 38, 45, 248))
#define K_EDGE THEME(RGBA(255, 255, 255, 150), RGBA(255, 255, 255, 26))
#define K_SUB THEME(RGB(243, 245, 248), RGB(45, 50, 59))
#define K_SUB_HOT THEME(RGB(231, 235, 242), RGB(58, 64, 75))
#define K_LINE THEME(RGB(234, 237, 242), RGB(54, 59, 68))
#define K_ACC THEME(RGB(14, 116, 224), RGB(88, 166, 255))
#define K_TINT THEME(RGB(224, 238, 253), RGB(30, 54, 90))
#define K_FAINT THEME(RGB(192, 197, 205), RGB(88, 94, 106))
#define K_RED RGB(255, 99, 71)

typedef struct WDef WDef;
struct WDef {
  const char *id, *name, *app_name, *desc;
  int icon, wide;
  void (*draw)(Surface *s, float ox, float oy, float w, float h, int hot);
  int (*zone)(float x, float y, float w, float h);
  void (*click)(int z);
  int (*tick)(uint32_t now);
};

enum { Z_CARD = 98, Z_REMOVE = 99 };

static const WDef *DEFS[NW_DEF];
static App WAPP[NW_DEF], PAGER, SLOT, GAL;
static int on[NW_DEF], wp[NW_DEF], wc[NW_DEF], wr[NW_DEF];
static int pidx[NW_DEF], pager = -1, slot = -1, gal = -1;
static int npages = 1, page, edit, gal_open, moving;
static float page_pos, pager_y = -10000.f;
static float tx_[NW_DEF], ty_[NW_DEF], cur_a[NW_DEF], cur_y[NW_DEF];
static int drag_k = -1, drag_live, drag_p, drag_c, drag_r, swap_k = -1, slot_ok = 1;
static float off_a, off_y;
static int press_k = -1, press_x, press_y;
static uint32_t press_at, edge_at;
static int home_shown = -1, inited, pend_remove = -1;
static int new_k = -1, gal_k = -1, gal_px, gal_py;
static uint32_t new_at, gal_at;
static char note[64];
static uint32_t wheel_at;

static float lh(const Font *f) { return (float)(f->ascent + f->descent) / SCALE; }

static int in_r(float x, float y, float rx, float ry, float rw, float rh) { return x >= rx && y >= ry && x < rx + rw && y < ry + rh; }

static void text_q(Surface *s, const Font *f, float x, float y, const char *t, uint32_t c, float q) { gfx_text_scaled(s, f, x, y, t, -1, c, q); }

static void head(Surface *s, float ox, float oy, int icon, const char *label) {
  gfx_icon(s, icon, ox + 18, oy + 17, 20);
  gfx_text(s, F_UI_MED, ox + 46, oy + 27 - lh(F_UI_MED) * 0.5f, label, C_MUTED);
}

static uint32_t tile_col(const char *s) {
  static const uint32_t pal[8] = {RGB(66, 133, 244), RGB(234, 67, 53), RGB(15, 157, 88),  RGB(124, 77, 255),
                                  RGB(255, 112, 67), RGB(0, 150, 136), RGB(233, 30, 99), RGB(96, 125, 139)};
  unsigned hsh = 5381;
  for (; *s; s++) hsh = hsh * 33 + (unsigned char)*s;
  return pal[hsh % 8];
}

static void letter_tile(Surface *s, float x, float y, float sz, const char *seed, const char *name) {
  gfx_rrect(s, x, y, sz, sz, sz * 0.28f, tile_col(seed));
  char l[2] = {(char)toupper((unsigned char)name[0]), 0};
  gfx_text_c(s, F_BODY, x + sz * 0.5f, y + (sz - lh(F_BODY)) * 0.5f, l, RGB(255, 255, 255));
}

static void label_c(Surface *s, const Font *f, float cx, float y, float maxw, const char *t, uint32_t c) {
  if (gfx_text_w(f, t) > maxw) gfx_text_fit(s, f, cx - maxw * 0.5f, y, maxw, t, c);
  else gfx_text_c(s, f, cx, y, t, c);
}

static struct tm now_tm(void) {
  time_t t = time(NULL);
  struct tm tm;
  localtime_r(&t, &tm);
  return tm;
}

static int clock_tick(uint32_t now) {
  static int last = -1;
  (void)now;
  struct tm tm = now_tm();
  if (tm.tm_sec == last) return 0;
  last = tm.tm_sec;
  return 1;
}

static void hand(Surface *s, float cx, float cy, float a, float back, float len, float th, uint32_t c) {
  float dx = sinf(a), dy = -cosf(a);
  gfx_line(s, cx - dx * back, cy - dy * back, cx + dx * len, cy + dy * len, th, c);
  gfx_disc(s, cx + dx * len, cy + dy * len, th * 0.5f, c);
}

static void clock_face(Surface *s, float cx, float cy, float r, const struct tm *tm) {
  float k = r / 90.f;
  gfx_disc(s, cx, cy, r, K_SUB);
  gfx_ring(s, cx, cy, r - 0.5f, 1.f, K_LINE);
  for (int i = 0; i < 60; i++) {
    float a = (float)i / 60.f * 6.2831853f, dx = sinf(a), dy = -cosf(a);
    int major = i % 5 == 0;
    float r0 = r - (major ? 15 : 9) * k, r1 = r - 6 * k;
    gfx_line(s, cx + dx * r0, cy + dy * r0, cx + dx * r1, cy + dy * r1, (major ? (i % 15 ? 2.4f : 3.4f) : 1.f) * fminf(k, 1.6f), major ? C_TEXT : K_FAINT);
  }
  float hr = ((float)(tm->tm_hour % 12) + tm->tm_min / 60.f) / 12.f * 6.2831853f;
  float mn = ((float)tm->tm_min + tm->tm_sec / 60.f) / 60.f * 6.2831853f;
  float sc = (float)tm->tm_sec / 60.f * 6.2831853f;
  float t = fminf(k, 1.7f);
  hand(s, cx, cy, hr, 8 * k, r * 0.48f, 6.f * t, C_TEXT);
  hand(s, cx, cy, mn, 10 * k, r * 0.72f, 4.f * t, C_TEXT);
  hand(s, cx, cy, sc, 16 * k, r * 0.8f, 1.8f * t, K_RED);
  gfx_disc(s, cx, cy, 5.5f * t, K_RED);
  gfx_disc(s, cx, cy, 2 * t, THEME(RGB(255, 255, 255), RGB(34, 38, 45)));
}

static void clock_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  struct tm tm = now_tm();
  clock_face(s, ox + 122, oy + h * 0.5f, 90, &tm);
  char tb[16], db[40], yb[40], wk[24];
  strftime(tb, sizeof tb, "%H:%M", &tm);
  strftime(db, sizeof db, "%A", &tm);
  strftime(yb, sizeof yb, "%B %-d, %Y", &tm);
  strftime(wk, sizeof wk, "Week %V", &tm);
  float tx = ox + 244;
  text_q(s, F_CLOCK, tx - 2, oy + 40, tb, C_TEXT, 1.22f);
  text_q(s, F_UI_MED, tx, oy + 140, db, K_ACC, 1.3f);
  gfx_text(s, F_UI, tx, oy + 172, yb, C_MUTED);
  gfx_text(s, F_SMALL, tx, oy + 196, wk, C_MUTED);
}

static const WDef W_CLOCK = {"clock", "Clock", "Settings", "Analog and digital time with the date", IC_SETTINGS, 1, clock_draw, NULL, NULL, clock_tick};

static int cal_off;

static int days_in(int y, int m) {
  static const int d[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  if (m == 1 && ((y % 4 == 0 && y % 100) || y % 400 == 0)) return 29;
  return d[m];
}

#define CAL_X 14
#define CAL_Y 80
#define CAL_CW 30.3f
#define CAL_CH 24

static void cal_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  struct tm tm = now_tm();
  int t = tm.tm_year * 12 + tm.tm_mon + cal_off, y = t / 12 + 1900, m = t % 12;
  struct tm first = {0};
  first.tm_year = y - 1900, first.tm_mon = m, first.tm_mday = 1, first.tm_hour = 12;
  mktime(&first);
  int lead = (first.tm_wday + 6) % 7;
  char mon[24], yr[12];
  strftime(mon, sizeof mon, "%B", &first);
  snprintf(yr, sizeof yr, "%d", y);
  float mw = gfx_text_w(F_BODY, mon);
  if (hot == 3) gfx_rrect(s, ox + 10, oy + 12, mw + gfx_text_w(F_UI, yr) + 28, 32, 10, K_SUB);
  gfx_text(s, F_BODY, ox + 18, oy + 28 - lh(F_BODY) * 0.5f, mon, cal_off ? K_ACC : C_TEXT);
  gfx_text(s, F_UI, ox + 24 + mw, oy + 28 - lh(F_UI) * 0.5f + 1, yr, C_MUTED);
  for (int k = 0; k < 2; k++) {
    float bx = ox + w - 74 + k * 32, by = oy + 28;
    gfx_disc(s, bx + 13, by, 14, hot == 1 + k ? K_SUB_HOT : K_SUB);
    float d = k ? -1 : 1;
    gfx_line(s, bx + 13 + 2.5f * d, by - 5, bx + 13 - 2.5f * d, by, 2.f, C_TEXT);
    gfx_line(s, bx + 13 - 2.5f * d, by, bx + 13 + 2.5f * d, by + 5, 2.f, C_TEXT);
  }
  static const char wd[] = "MTWTFSS";
  for (int i = 0; i < 7; i++) {
    char c[2] = {wd[i], 0};
    gfx_text_c(s, F_SMALL, ox + CAL_X + CAL_CW * (i + 0.5f), oy + 56, c, i >= 5 ? K_FAINT : C_MUTED);
  }
  int today = cal_off == 0 ? tm.tm_mday : -1;
  int dim = days_in(y, m), pdim = days_in(m ? y : y - 1, m ? m - 1 : 11);
  int rows = (lead + dim + 6) / 7;
  float chh = rows > 5 ? 22.f : CAL_CH;
  if (today > 0) {
    int tr = (lead + today - 1) / 7;
    gfx_rrect(s, ox + CAL_X - 2, oy + CAL_Y + chh * tr + 1, CAL_CW * 7 + 4, chh - 2, (chh - 2) * 0.5f, K_SUB);
  }
  for (int cell = 0; cell < rows * 7; cell++) {
    int r = cell / 7, c = cell % 7, day = cell - lead + 1, cur = day >= 1 && day <= dim;
    int shown = cur ? day : day < 1 ? pdim + day : day - dim;
    float cx = ox + CAL_X + CAL_CW * (c + 0.5f), cy = oy + CAL_Y + chh * (r + 0.5f);
    char b[12];
    snprintf(b, sizeof b, "%d", shown);
    uint32_t col = !cur ? THEME(RGB(206, 210, 216), RGB(76, 82, 94)) : c >= 5 ? C_MUTED : C_TEXT;
    if (cur && day == today) {
      gfx_disc(s, cx, cy, 11.5f, C_ACCENT);
      col = RGB(255, 255, 255);
    }
    gfx_text_c(s, cur && day == today ? F_UI_MED : F_UI, cx, cy - lh(F_UI) * 0.5f, b, col);
  }
}

static int cal_zone(float x, float y, float w, float h) {
  for (int k = 0; k < 2; k++)
    if (in_r(x, y, w - 76 + k * 32, 10, 30, 36)) return 1 + k;
  if (in_r(x, y, 10, 10, w - 90, 36)) return 3;
  return 0;
}

static void cal_click(int z) {
  if (z == 1) cal_off--;
  else if (z == 2) cal_off++;
  else cal_off = 0;
}

static int cal_tick(uint32_t now) {
  static int last = -1;
  (void)now;
  struct tm tm = now_tm();
  if (tm.tm_yday == last) return 0;
  last = tm.tm_yday;
  return 1;
}

static const WDef W_CAL = {"calendar", "Calendar", "Settings", "This month at a glance", IC_SETTINGS, 0, cal_draw, cal_zone, cal_click, cal_tick};

#define SH_N 60

typedef struct {
  long long tot, idle, mem_tot, mem_used;
  float cpu, mem, disk;
  int ncore;
  double disk_free, up;
  float cpu_h[SH_N];
  int nh;
  uint32_t at;
} Sys;

static Sys SY = {.cpu = -1};

static void human_gb(double b, char *o, int n) {
  if (b >= 1e12) snprintf(o, (size_t)n, "%.1f TB", b / 1e12);
  else if (b >= 1e9) snprintf(o, (size_t)n, "%.1f GB", b / 1e9);
  else snprintf(o, (size_t)n, "%.0f MB", b / 1e6);
}

static void sys_sample(void) {
  FILE *f = fopen("/proc/stat", "r");
  if (f) {
    char line[512];
    int nc = 0;
    while (fgets(line, sizeof line, f)) {
      if (strncmp(line, "cpu", 3)) break;
      if (line[3] != ' ') {
        nc++;
        continue;
      }
      long long v[8] = {0};
      if (sscanf(line + 3, "%lld %lld %lld %lld %lld %lld %lld %lld", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7]) < 4) continue;
      long long tot = 0;
      for (int i = 0; i < 8; i++) tot += v[i];
      long long idle = v[3] + v[4];
      if (SY.tot && tot > SY.tot) SY.cpu = 1.f - (float)(idle - SY.idle) / (float)(tot - SY.tot);
      SY.tot = tot, SY.idle = idle;
    }
    SY.ncore = nc;
    fclose(f);
  }
  f = fopen("/proc/meminfo", "r");
  if (f) {
    char line[128];
    long long mt = 0, ma = 0;
    while (fgets(line, sizeof line, f)) {
      sscanf(line, "MemTotal: %lld", &mt);
      sscanf(line, "MemAvailable: %lld", &ma);
    }
    fclose(f);
    if (mt > 0) SY.mem = 1.f - (float)ma / (float)mt, SY.mem_tot = mt * 1024, SY.mem_used = (mt - ma) * 1024;
  }
  struct statvfs vf;
  if (!statvfs(user_home(), &vf) && vf.f_blocks) {
    double tot = (double)vf.f_blocks * vf.f_frsize;
    SY.disk_free = (double)vf.f_bavail * vf.f_frsize;
    SY.disk = (float)(1.0 - SY.disk_free / tot);
  }
  f = fopen("/proc/uptime", "r");
  if (f) {
    if (fscanf(f, "%lf", &SY.up) != 1) SY.up = 0;
    fclose(f);
  }
  if (SY.cpu < 0) return;
  if (!SY.nh)
    for (int i = 0; i < SH_N; i++) SY.cpu_h[i] = SY.cpu;
  memmove(SY.cpu_h, SY.cpu_h + 1, sizeof(float) * (SH_N - 1));
  SY.cpu_h[SH_N - 1] = SY.cpu;
  SY.nh = SH_N;
}

static int sys_tick(uint32_t now) {
  if (SY.at && now - SY.at < 1000) return 0;
  SY.at = now ? now : 1;
  sys_sample();
  return 1;
}

static uint32_t level_col(uint32_t base, float v) {
  if (v > 0.9f) return THEME(RGB(222, 64, 52), RGB(255, 120, 108));
  if (v > 0.75f) return THEME(RGB(230, 140, 20), RGB(255, 178, 84));
  return base;
}

#define C_CPU THEME(RGB(47, 107, 255), RGB(96, 150, 255))
#define C_MEM THEME(RGB(124, 77, 255), RGB(160, 130, 255))
#define C_DSK THEME(RGB(0, 158, 124), RGB(64, 210, 170))

static uint32_t with_a(uint32_t c, int a) { return (c & 0x00ffffffu) | ((uint32_t)a << 24); }

static void spark(Surface *s, float x, float y, float w, float h, const float *v, int nv, float vmax, uint32_t c, int fill, float lw) {
  if (vmax <= 0) vmax = 1;
  int n = nv < 2 ? 2 : nv;
  const float *src = v + (SH_N - n);
  float dx = w / (float)(SH_N - 1), x0 = x + w - dx * (float)(n - 1);
  if (fill) {
    int cols = (int)(w);
    for (int i = 0; i < cols; i++) {
      float px = x + (float)i;
      if (px < x0) continue;
      float t = (px - x0) / dx;
      int k = (int)t;
      float f = t - k;
      float a = src[k < n ? k : n - 1], b = src[k + 1 < n ? k + 1 : n - 1];
      float val = a + (b - a) * f;
      if (val > vmax) val = vmax;
      float top = y + h - h * val / vmax, span = y + h - top;
      for (int g = 0; g < 10; g++) gfx_rect(s, px, top + span * g / 10.f, 1.01f, span / 10.f + 0.3f, with_a(c, 58 - g * 5));
    }
  }
  for (int i = 1; i < n; i++) {
    float a = src[i - 1] > vmax ? vmax : src[i - 1], b = src[i] > vmax ? vmax : src[i];
    gfx_line(s, x0 + dx * (i - 1), y + h - h * a / vmax, x0 + dx * i, y + h - h * b / vmax, lw, c);
  }
}


static void uptime_str(char *o, int n) {
  int mins = (int)(SY.up / 60);
  if (mins >= 1440) snprintf(o, (size_t)n, "%dd %dh", mins / 1440, mins / 60 % 24);
  else if (mins >= 60) snprintf(o, (size_t)n, "%dh %dm", mins / 60, mins % 60);
  else snprintf(o, (size_t)n, "%dm", mins);
}

static void pct_big(Surface *s, float x, float y, float v, int valid, float q, uint32_t c) {
  char b[8];
  if (valid) snprintf(b, sizeof b, "%d", (int)(v * 100 + 0.5f));
  else snprintf(b, sizeof b, "--");
  text_q(s, F_UI_MED, x, y, b, c, q);
  float asc = (float)F_UI_MED->ascent / SCALE;
  gfx_text(s, F_UI_MED, x + gfx_text_w(F_UI_MED, b) * q + 1, y + asc * q - asc - 1, "%", C_MUTED);
}

static void arc(Surface *s, float cx, float cy, float r, float th, float frac, uint32_t c) {
  if (frac <= 0) return;
  if (frac > 1) frac = 1;
  int n = (int)(frac * 6.2831853f * r / 0.9f) + 2;
  for (int i = 0; i <= n; i++) {
    float a = -1.5707963f + frac * 6.2831853f * (float)i / (float)n;
    gfx_disc(s, cx + cosf(a) * r, cy + sinf(a) * r, th * 0.5f, c);
  }
}

static void gauge(Surface *s, float cx, float cy, float r, float v, uint32_t c, const char *label, const char *detail) {
  if (v < 0) v = 0;
  if (v > 1) v = 1;
  arc(s, cx, cy, r, 10, 1.f, K_SUB);
  arc(s, cx, cy, r, 10, v < 0.015f ? 0.015f : v, c);
  char b[8];
  snprintf(b, sizeof b, "%d", (int)(v * 100 + 0.5f));
  float q = 1.45f, bw = gfx_text_w(F_UI_MED, b) * q, pw = gfx_text_w(F_SMALL, "%");
  float asc = (float)F_UI_MED->ascent / SCALE;
  float ty = cy - lh(F_UI_MED) * q * 0.5f;
  text_q(s, F_UI_MED, cx - (bw + pw + 1) * 0.5f, ty, b, C_TEXT, q);
  gfx_text(s, F_SMALL, cx - (bw + pw + 1) * 0.5f + bw + 1, ty + asc * q - (float)F_SMALL->ascent / SCALE - 1, "%", C_MUTED);
  gfx_text_c(s, F_UI_MED, cx, cy + r + 14, label, C_TEXT);
  gfx_text_c(s, F_SMALL, cx, cy + r + 34, detail, C_MUTED);
}

static void sys_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  head(s, ox, oy, IC_SETTINGS, "System");
  char up[24], b[64];
  uptime_str(up, sizeof up);
  snprintf(b, sizeof b, "Up %s", up);
  float bw = gfx_text_w(F_SMALL, b) + 30;
  float chx = ox + w - 16 - bw;
  gfx_rrect(s, chx, oy + 15, bw, 24, 12, K_SUB);
  gfx_disc(s, chx + 12, oy + 27, 3.5f, RGB(24, 170, 100));
  gfx_text(s, F_SMALL, chx + 21, oy + 27 - lh(F_SMALL) * 0.5f, b, C_MUTED);
  float lw = w * 0.5f - 6;
  float cpu = SY.cpu < 0 ? 0 : SY.cpu;
  uint32_t cc = level_col(C_CPU, cpu);
  gfx_rrect(s, ox + 14, oy + 50, lw - 14, h - 64, 18, K_SUB);
  float px = ox + 28, pw = lw - 42;
  gfx_text(s, F_SMALL, px, oy + 62, "Processor", C_MUTED);
  pct_big(s, px, oy + 78, cpu, SY.cpu >= 0, 1.9f, C_TEXT);
  char cores[24];
  snprintf(cores, sizeof cores, "%d cores", SY.ncore);
  gfx_text(s, F_SMALL, ox + lw - 14 - gfx_text_w(F_SMALL, cores), oy + 62, cores, C_MUTED);
  float gy = oy + 128, gh = h - 64 - 92;
  for (int i = 0; i <= 2; i++) gfx_rect(s, px, gy + gh * i / 2.f, pw, 1, with_a(K_LINE, i == 2 ? 255 : 170));
  spark(s, px, gy, pw, gh, SY.cpu_h, SY.nh, 1.f, cc, 1, 2.2f);
  float ex = px + pw, ey = gy + gh - gh * cpu;
  gfx_disc(s, ex, ey, 5, THEME(RGB(243, 245, 248), RGB(45, 50, 59)));
  gfx_disc(s, ex, ey, 3.2f, cc);
  float rx = ox + lw + 6, rw = w - lw - 6 - 14;
  char a1[16], a2[16], d1[40], d2[40];
  human_gb((double)SY.mem_used, a1, sizeof a1);
  human_gb((double)SY.mem_tot, a2, sizeof a2);
  snprintf(d1, sizeof d1, "%s of %s", a1, a2);
  human_gb(SY.disk_free, a1, sizeof a1);
  snprintf(d2, sizeof d2, "%s free", a1);
  float r = 38, gy2 = oy + 50 + 50;
  gauge(s, rx + rw * 0.25f, gy2, r, SY.mem, level_col(C_MEM, SY.mem), "Memory", d1);
  gauge(s, rx + rw * 0.75f, gy2, r, SY.disk, level_col(C_DSK, SY.disk), "Storage", d2);
}

static const WDef W_SYS = {"system", "System", "Settings", "Live CPU, memory and storage", IC_SETTINGS, 1, sys_draw, NULL, NULL, sys_tick};

#define TK_ROWS 4
#define TK_Y 58
#define TK_RH 40

static void tasks_w_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  int n = tasks_total();
  head(s, ox, oy, IC_TASKS, "Tasks");
  if (n) {
    char b[16];
    snprintf(b, sizeof b, "%d", n);
    float bw = gfx_text_w(F_SMALL, b) + 16, bx = ox + 46 + gfx_text_w(F_UI_MED, "Tasks") + 8;
    gfx_rrect(s, bx, oy + 17, bw, 20, 10, K_TINT);
    gfx_text_c(s, F_SMALL, bx + bw * 0.5f, oy + 27 - lh(F_SMALL) * 0.5f, b, K_ACC);
  }
  float bx = ox + w - 50, by = oy + 11;
  gfx_disc(s, bx + 16, by + 16, 16, hot == 1 ? C_ACCENT : K_TINT);
  uint32_t pc = hot == 1 ? RGB(255, 255, 255) : K_ACC;
  gfx_rrect(s, bx + 10, by + 14.8f, 12, 2.4f, 1.2f, pc);
  gfx_rrect(s, bx + 14.8f, by + 10, 2.4f, 12, 1.2f, pc);
  if (!n) {
    float cx = ox + w * 0.5f, cy = oy + 112;
    gfx_disc(s, cx, cy, 26, K_TINT);
    gfx_line(s, cx - 10, cy + 1, cx - 3, cy + 8, 3.f, K_ACC);
    gfx_line(s, cx - 3, cy + 8, cx + 11, cy - 7, 3.f, K_ACC);
    gfx_text_c(s, F_BODY, cx, cy + 38, "All caught up", C_TEXT);
    char b[48];
    int dn = tasks_done_count();
    if (dn) snprintf(b, sizeof b, "%d task%s completed", dn, dn == 1 ? "" : "s");
    else snprintf(b, sizeof b, "Add something to get started");
    gfx_text_c(s, F_UI, cx, cy + 66, b, C_MUTED);
    return;
  }
  for (int i = 0; i < TK_ROWS && i < n; i++) {
    float y = oy + TK_Y + i * TK_RH;
    int rh = hot == 10 + i;
    if (rh) gfx_rrect(s, ox + 10, y, w - 20, TK_RH - 4, 10, K_SUB);
    float cx = ox + 32, cy = y + (TK_RH - 4) * 0.5f;
    if (rh) {
      gfx_disc(s, cx, cy, 10, C_ACCENT);
      gfx_line(s, cx - 4.5f, cy, cx - 1.5f, cy + 3.5f, 2.f, RGB(255, 255, 255));
      gfx_line(s, cx - 1.5f, cy + 3.5f, cx + 5, cy - 4, 2.f, RGB(255, 255, 255));
    } else gfx_ring(s, cx, cy, 10, 2.f, K_FAINT);
    gfx_text_fit(s, F_BODY, ox + 54, cy - lh(F_BODY) * 0.5f, w - 76, tasks_title_at(i), C_TEXT);
    if (i < n - 1 && i < TK_ROWS - 1 && !rh && hot != 11 + i) gfx_rect(s, ox + 54, y + TK_RH - 3, w - 72, 1, K_LINE);
  }
  char b[48];
  int dn = tasks_done_count();
  if (n > TK_ROWS) {
    snprintf(b, sizeof b, "+%d more", n - TK_ROWS);
    gfx_text(s, F_SMALL, ox + w - 18 - gfx_text_w(F_SMALL, b), oy + h - 24, b, C_MUTED);
  } else if (dn) {
    snprintf(b, sizeof b, "%d completed", dn);
    float fx = ox + 24, fy = oy + h - 24 + lh(F_SMALL) * 0.5f;
    gfx_line(s, fx - 4, fy, fx - 1, fy + 3, 1.8f, RGB(24, 160, 96));
    gfx_line(s, fx - 1, fy + 3, fx + 5, fy - 3, 1.8f, RGB(24, 160, 96));
    gfx_text(s, F_SMALL, fx + 12, oy + h - 24, b, C_MUTED);
  }
}

static int tasks_w_zone(float x, float y, float w, float h) {
  if (in_r(x, y, w - 52, 6, 44, 42)) return 1;
  int n = tasks_total();
  if (!n && y > 50) return 1;
  for (int i = 0; i < TK_ROWS && i < n; i++)
    if (in_r(x, y, 10, TK_Y + i * TK_RH, w - 20, TK_RH - 4)) return 10 + i;
  return 0;
}

static void tasks_w_click(int z) {
  if (z == 1) panel_open_app("tasks");
  else if (z >= 10) tasks_complete_at(z - 10);
}

static int tasks_w_tick(uint32_t now) {
  static int ln = -1, ld = -1;
  (void)now;
  int n = tasks_total(), d = tasks_done_count();
  if (n == ln && d == ld) return 0;
  ln = n, ld = d;
  return 1;
}

static const WDef W_TASKS = {"tasks", "Tasks", "Tasks", "Your to-do list, check items off", IC_TASKS, 1, tasks_w_draw, tasks_w_zone, tasks_w_click, tasks_w_tick};

static char SC_NAME[8][60], SC_URL[8][600];
static int nsc;

static Img *favicon_img(const char *url, char *host, int hn) {
  const char *h = strstr(url, "://");
  h = h ? h + 3 : url;
  int i = 0;
  while (h[i] && h[i] != '/' && h[i] != ':' && i < hn - 1) host[i] = h[i], i++;
  host[i] = 0;
  if (!host[0]) return NULL;
  char fu[300];
  snprintf(fu, sizeof fu, "https://www.google.com/s2/favicons?domain=%s&sz=128", host);
  return img_get(fu, 96, 0);
}

static int sites_tick(uint32_t now) {
  static uint32_t at;
  static int ready = -1;
  int ch = net_poll() ? 1 : 0;
  if (!at || now - at >= 5000) {
    at = now ? now : 1;
    static char nn[8][60], uu[8][600];
    int n = surf_shortcuts(nn, uu, 8);
    if (n != nsc || memcmp(nn, SC_NAME, sizeof nn) || memcmp(uu, SC_URL, sizeof uu)) ch = 1;
    memcpy(SC_NAME, nn, sizeof nn);
    memcpy(SC_URL, uu, sizeof uu);
    nsc = n;
  }
  int r = 0;
  for (int i = 0; i < nsc && i < 5; i++) {
    char host[200];
    Img *im = favicon_img(SC_URL[i], host, sizeof host);
    if (im && im->state >= IMG_READY) r++;
  }
  if (r != ready) ready = r, ch = 1;
  return ch;
}

static void favicon_tile(Surface *s, float x, float y, float sz, const char *url, const char *name) {
  char host[200];
  Img *im = favicon_img(url, host, sizeof host);
  if (im && im->state == IMG_READY && im->px && im->w > 8) {
    gfx_rrect(s, x - 1, y - 1, sz + 2, sz + 2, sz * 0.28f + 1, K_LINE);
    gfx_rrect(s, x, y, sz, sz, sz * 0.28f, THEME(RGB(255, 255, 255), RGB(58, 64, 75)));
    float isz = sz * 0.58f;
    gfx_blit_premul(s, im->px, im->w, im->h, x + (sz - isz) * 0.5f, y + (sz - isz) * 0.5f, isz, isz);
  } else letter_tile(s, x, y, sz, host[0] ? host : url, name);
}

#define SR_Y 56
#define SR_H 46
#define ST_Y 114

static void sites_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  head(s, ox, oy, IC_SURF, "Surf");
  float sx = ox + 18, sw = w - 36;
  gfx_rrect(s, sx, oy + SR_Y, sw, SR_H, SR_H * 0.5f, hot == 1 ? K_SUB_HOT : K_SUB);
  float gx = sx + 24, gy = oy + SR_Y + SR_H * 0.5f;
  gfx_ring(s, gx - 1, gy - 1, 7, 2.f, C_MUTED);
  gfx_line(s, gx + 4, gy + 4, gx + 9, gy + 9, 2.2f, C_MUTED);
  gfx_text(s, F_BODY, sx + 46, gy - lh(F_BODY) * 0.5f, "Search or type a web address", C_MUTED);
  int n = nsc < 5 ? nsc : 5;
  float cw = sw / 5.f;
  for (int i = 0; i < n; i++) {
    float x = sx + i * cw, y = oy + ST_Y;
    if (hot == 10 + i) gfx_rrect(s, x + 4, y, cw - 8, 100, 16, K_SUB);
    favicon_tile(s, x + (cw - 50) * 0.5f, y + 12, 50, SC_URL[i], SC_NAME[i]);
    label_c(s, F_SMALL, x + cw * 0.5f, y + 72, cw - 12, SC_NAME[i], hot == 10 + i ? K_ACC : C_TEXT);
  }
}

static int sites_zone(float x, float y, float w, float h) {
  if (in_r(x, y, 18, SR_Y, w - 36, SR_H)) return 1;
  int n = nsc < 5 ? nsc : 5;
  float cw = (w - 36) / 5.f;
  for (int i = 0; i < n; i++)
    if (in_r(x, y, 18 + i * cw + 4, ST_Y, cw - 8, 100)) return 10 + i;
  return 0;
}

static void sites_click(int z) {
  if (z == 1) surf_open_url("surf:search");
  else surf_open_url(SC_URL[z - 10]);
}

static const WDef W_SITES = {"surf", "Surf", "Surf", "Search the web and open your shortcuts", IC_SURF, 1, sites_draw, sites_zone, sites_click, sites_tick};

static const char *const FOLD[4] = {"", "Documents", "Downloads", "Pictures"};
static const char *const FOLD_NAME[4] = {"Home", "Documents", "Downloads", "Pictures"};
static int fold_n[4];

static void fold_path(int i, char *o, int n) {
  if (!i) snprintf(o, (size_t)n, "%s", user_home());
  else snprintf(o, (size_t)n, "%s/%s", user_home(), FOLD[i]);
}

static int fold_tick(uint32_t now) {
  static uint32_t at;
  if (at && now - at < 5000) return 0;
  at = now ? now : 1;
  int ch = 0;
  for (int i = 0; i < 4; i++) {
    char path[600];
    fold_path(i, path, sizeof path);
    int n = -1;
    DIR *d = opendir(path);
    if (d) {
      n = 0;
      struct dirent *e;
      while ((e = readdir(d)))
        if (e->d_name[0] != '.') n++;
      closedir(d);
    }
    if (n != fold_n[i]) fold_n[i] = n, ch = 1;
  }
  return ch;
}

static void fold_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  head(s, ox, oy, IC_FILES, "Files");
  float tw2 = (w - 36 - 10) * 0.5f, th = 80;
  for (int i = 0; i < 4; i++) {
    float x = ox + 18 + (i % 2) * (tw2 + 10), y = oy + 54 + (i / 2) * (th + 10);
    gfx_rrect(s, x, y, tw2, th, 16, hot == 1 + i ? K_SUB_HOT : K_SUB);
    gfx_icon(s, IC_FOLDER, x + 12, y + 10, 30);
    gfx_text_fit(s, F_UI_MED, x + 13, y + 44, tw2 - 22, FOLD_NAME[i], C_TEXT);
    char b[24];
    if (fold_n[i] > 0) snprintf(b, sizeof b, "%d item%s", fold_n[i], fold_n[i] == 1 ? "" : "s");
    else snprintf(b, sizeof b, fold_n[i] == 0 ? "Empty" : "Not created");
    gfx_text_fit(s, F_SMALL, x + 13, y + 62, tw2 - 22, b, C_MUTED);
  }
}

static int fold_zone(float x, float y, float w, float h) {
  float tw2 = (w - 36 - 10) * 0.5f, th = 80;
  for (int i = 0; i < 4; i++)
    if (in_r(x, y, 18 + (i % 2) * (tw2 + 10), 54 + (i / 2) * (th + 10), tw2, th)) return 1 + i;
  return 0;
}

static void fold_click(int z) {
  char path[600];
  fold_path(z - 1, path, sizeof path);
  mkdir(path, 0755);
  files_open_path(path);
}

static const WDef W_FOLD = {"folders", "Folders", "Files", "Jump straight into your main folders", IC_FILES, 0, fold_draw, fold_zone, fold_click, fold_tick};

typedef struct {
  char id[40], title[96], path[600];
  int kind;
  long mtime;
} Doc;

#define NDOC 5

static Doc DOCS[NDOC];
static int ndocs;

static const char *const DK_SUB[3] = {"Docs", "Sheets", "Slides"};
static const char *const DK_ENV[3] = {"OREONVR_DOCS_DIR", "OREONVR_SHEETS_DIR", "OREONVR_SLIDES_DIR"};
static const char *const DK_EXT[3] = {".odoc", ".osheet", ".oslides"};

static void doc_title(const char *path, char *o, int n) {
  snprintf(o, (size_t)n, "Untitled");
  FILE *f = fopen(path, "r");
  if (!f) return;
  char line[300];
  for (int k = 0; k < 40 && fgets(line, sizeof line, f); k++)
    if (!strncmp(line, "title\t", 6)) {
      line[strcspn(line, "\r\n")] = 0;
      if (line[6]) snprintf(o, (size_t)n, "%.95s", line + 6);
      break;
    }
  fclose(f);
}

static int docs_tick(uint32_t now) {
  static uint32_t at;
  if (at && now - at < 4000) return 0;
  at = now ? now : 1;
  static Doc best[NDOC];
  int nb = 0;
  memset(best, 0, sizeof best);
  for (int k = 0; k < 3; k++) {
    char dir[512];
    office_dirs(dir, sizeof dir, DK_SUB[k], DK_ENV[k]);
    DIR *d = opendir(dir);
    if (!d) continue;
    struct dirent *e;
    size_t el = strlen(DK_EXT[k]);
    while ((e = readdir(d))) {
      size_t l = strlen(e->d_name);
      if (l <= el || strcmp(e->d_name + l - el, DK_EXT[k]) || l - el >= 40) continue;
      char path[800];
      snprintf(path, sizeof path, "%s/%s", dir, e->d_name);
      struct stat st;
      if (stat(path, &st)) continue;
      int pos = nb;
      while (pos > 0 && best[pos - 1].mtime < (long)st.st_mtime) pos--;
      if (pos >= NDOC) continue;
      if (nb < NDOC) nb++;
      memmove(&best[pos + 1], &best[pos], sizeof(Doc) * (size_t)(nb - 1 - pos));
      memset(&best[pos], 0, sizeof best[pos]);
      snprintf(best[pos].id, sizeof best[pos].id, "%.*s", (int)(l - el), e->d_name);
      snprintf(best[pos].path, sizeof best[pos].path, "%.599s", path);
      best[pos].kind = k, best[pos].mtime = (long)st.st_mtime;
    }
    closedir(d);
  }
  for (int i = 0; i < nb; i++) doc_title(best[i].path, best[i].title, sizeof best[i].title);
  int ch = nb != ndocs || memcmp(best, DOCS, sizeof(Doc) * (size_t)nb);
  memcpy(DOCS, best, sizeof(Doc) * (size_t)nb);
  ndocs = nb;
  return ch;
}

static void rel_date(long t, char *o, int n) {
  time_t tt = (time_t)t, now = time(NULL);
  struct tm a, b;
  localtime_r(&tt, &a);
  localtime_r(&now, &b);
  long days = (long)(b.tm_year - a.tm_year) * 366 + (b.tm_yday - a.tm_yday);
  if (days == 0) strftime(o, (size_t)n, "Today, %H:%M", &a);
  else if (days == 1) snprintf(o, (size_t)n, "Yesterday");
  else if (days < 7 && days > 0) strftime(o, (size_t)n, "%A", &a);
  else if (a.tm_year == b.tm_year) strftime(o, (size_t)n, "%b %-d", &a);
  else strftime(o, (size_t)n, "%b %-d, %Y", &a);
}

#define DK_HEAD 56
#define DK_GAP 12

static const char *const DK_NEW[3] = {"Document", "Spreadsheet", "Presentation"};

static void docs_cell(float w, float h, int i, float *x, float *y, float *cw, float *ch) {
  *cw = (w - 36 - 2 * DK_GAP) / 3.f, *ch = (h - DK_HEAD - 18 - DK_GAP) / 2.f;
  *x = 18 + (i % 3) * (*cw + DK_GAP), *y = DK_HEAD + (i / 3) * (*ch + DK_GAP);
}

static void docs_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  head(s, ox, oy, IC_OFFICE, "Office");
  const char *all = "Open Office";
  float aw = gfx_text_w(F_UI_MED, all);
  if (hot == 9) gfx_rrect(s, ox + w - aw - 36, oy + 13, aw + 20, 30, 15, K_SUB);
  gfx_text(s, F_UI_MED, ox + w - aw - 26, oy + 28 - lh(F_UI_MED) * 0.5f, all, K_ACC);
  float x, y, cw, ch;
  docs_cell(w, h, 0, &x, &y, &cw, &ch);
  x += ox, y += oy;
  gfx_rrect(s, x, y, cw, ch, 18, K_TINT);
  gfx_text(s, F_UI_MED, x + 14, y + 14, "Create new", K_ACC);
  float bh = (ch - 48 - 2 * 8) / 3.f;
  for (int k = 0; k < 3; k++) {
    float by = y + 42 + k * (bh + 8);
    int hv = hot == 20 + k;
    uint32_t acc = office_acc(k);
    gfx_rrect(s, x + 8, by, cw - 16, bh, 12, hv ? THEME(RGB(255, 255, 255), RGB(58, 64, 75)) : with_a(THEME(RGB(255, 255, 255), RGB(44, 50, 60)), 190));
    if (hv) gfx_rrect(s, x + 8, by, 3, bh, 1.5f, acc);
    office_mark_k(s, x + 18, by + bh * 0.5f - 9, 1.f, k == 2 ? 3 : k);
    gfx_text_fit(s, F_UI_MED, x + 46, by + (bh - lh(F_UI_MED)) * 0.5f, cw - 64, DK_NEW[k], hv ? acc : C_TEXT);
  }
  if (!ndocs) {
    float ex, ey, ew, eh;
    docs_cell(w, h, 1, &ex, &ey, &ew, &eh);
    ex += ox, ey += oy;
    float fw = ew * 2 + DK_GAP, fh = eh * 2 + DK_GAP;
    gfx_rrect(s, ex, ey, fw, fh, 18, K_SUB);
    float cx = ex + fw * 0.5f, cy = ey + fh * 0.5f - 30;
    for (int k = 0; k < 3; k++) office_mark_k(s, cx - 70 + k * 50, cy - 20, 1.6f, k == 2 ? 3 : k);
    gfx_text_c(s, F_BODY, cx, cy + 30, "No recent files", C_TEXT);
    gfx_text_c(s, F_UI, cx, cy + 58, "Files you create or open show up here", C_MUTED);
    docs_cell(w, h, 3, &ex, &ey, &ew, &eh);
    gfx_rrect(s, ox + ex, oy + ey, ew, eh, 18, K_SUB);
    float cx2 = ox + ex + ew * 0.5f, cy2 = oy + ey + eh * 0.5f;
    gfx_text_c(s, F_SMALL, cx2, cy2 - 8, "Tip", K_ACC);
    gfx_text_c(s, F_SMALL, cx2, cy2 + 10, "Use Create new", C_MUTED);
    return;
  }
  for (int i = 0; i < NDOC; i++) {
    docs_cell(w, h, i + 1, &x, &y, &cw, &ch);
    x += ox, y += oy;
    if (i >= ndocs) {
      gfx_rrect(s, x, y, cw, ch, 18, with_a(K_SUB, 140));
      continue;
    }
    Doc *d = &DOCS[i];
    int hv = hot == 1 + i;
    uint32_t acc = office_acc(d->kind);
    if (hv) gfx_rrect(s, x - 2, y - 2, cw + 4, ch + 4, 20, with_a(acc, 210));
    gfx_rrect(s, x, y, cw, ch, 18, K_SUB);
    float tx = x + 8, ty = y + 8, tw2 = cw - 16, th = ch - 72;
    gfx_rrect(s, tx, ty, tw2, th, 12, THEME(RGB(255, 255, 255), RGB(40, 44, 52)));
    int sv[4];
    office_clip_push(s, tx + 4, ty + 4, tw2 - 8, th - 8, sv);
    office_embed_draw(s, d->kind, d->id, 0, tx + 4, ty + 4, tw2 - 8, th - 8, 0);
    office_clip_pop(s, sv);
    gfx_rrect_band(s, tx, ty, tw2, th, 12, ty + th - 3, ty + th, with_a(acc, 170));
    gfx_text_fit(s, F_UI_MED, x + 12, y + th + 18, cw - 24, d->title, C_TEXT);
    office_mark_k(s, x + 12, y + th + 44, 0.62f, d->kind == 2 ? 3 : d->kind);
    char db[48];
    rel_date(d->mtime, db, sizeof db);
    gfx_text_fit(s, F_SMALL, x + 28, y + th + 45, cw - 40, db, C_MUTED);
  }
}

static int docs_zone(float x, float y, float w, float h) {
  float aw = gfx_text_w(F_UI_MED, "Open Office");
  if (in_r(x, y, w - aw - 36, 10, aw + 24, 36)) return 9;
  float cx, cy, cw, ch;
  docs_cell(w, h, 0, &cx, &cy, &cw, &ch);
  float bh = (ch - 48 - 2 * 8) / 3.f;
  for (int k = 0; k < 3; k++)
    if (in_r(x, y, cx + 8, cy + 42 + k * (bh + 8), cw - 16, bh)) return 20 + k;
  for (int i = 0; i < ndocs && i < NDOC; i++) {
    docs_cell(w, h, i + 1, &cx, &cy, &cw, &ch);
    if (in_r(x, y, cx, cy, cw, ch)) return 1 + i;
  }
  return 0;
}

static void docs_click(int z) {
  if (z == 9) {
    panel_open_app("office");
    return;
  }
  if (z >= 20) {
    if (panel_open_app("office") >= 0) office_new(z - 20);
    return;
  }
  Doc d = DOCS[z - 1];
  if (panel_open_app("office") >= 0) office_embed_open(d.kind, d.id, 0);
}

static const WDef W_DOCS = {"documents", "Office", "Office", "Create new files and pick up recent ones", IC_OFFICE, 2, docs_draw, docs_zone, docs_click, docs_tick};

static unsigned apps_sig(void) {
  unsigned h = 2166136261u;
  int n = home_app_count();
  for (int i = 0; i < n; i++)
    for (const char *c = home_app_name(i); *c; c++) h = (h ^ (unsigned char)*c) * 16777619u;
  return h ^ (unsigned)n;
}

static int apps_tick(uint32_t now) {
  static uint32_t at;
  static unsigned sig;
  if (at && now - at < 1500) return 0;
  at = now ? now : 1;
  unsigned g = apps_sig();
  if (g == sig) return 0;
  sig = g;
  return 1;
}

static void apps_draw(Surface *s, float ox, float oy, float w, float h, int hot) {
  head(s, ox, oy, IC_APPS, "Apps");
  const char *more = "All";
  float mw = gfx_text_w(F_UI_MED, more);
  if (hot == 9) gfx_rrect(s, ox + w - mw - 34, oy + 12, mw + 20, 30, 15, K_SUB);
  gfx_text(s, F_UI_MED, ox + w - mw - 24, oy + 27 - lh(F_UI_MED) * 0.5f, more, K_ACC);
  int n = home_app_count();
  float cw = (w - 20) / 3.f, chh = 86;
  for (int i = 0; i < n; i++) {
    float x = ox + 10 + (i % 3) * cw, y = oy + 50 + (i / 3) * (chh + 2);
    if (hot == 1 + i) gfx_rrect(s, x + 3, y, cw - 6, chh, 16, K_SUB);
    float cx = x + cw * 0.5f;
    home_app_icon(i, s, cx - 23, y + 7, 46);
    label_c(s, F_SMALL, cx, y + 60, cw - 10, home_app_name(i), C_TEXT);
  }
}

static int apps_zone(float x, float y, float w, float h) {
  float mw = gfx_text_w(F_UI_MED, "All");
  if (in_r(x, y, w - mw - 34, 10, mw + 24, 34)) return 9;
  int n = home_app_count();
  float cw = (w - 20) / 3.f, chh = 86;
  for (int i = 0; i < n; i++)
    if (in_r(x, y, 10 + (i % 3) * cw + 3, 50 + (i / 3) * (chh + 2), cw - 6, chh)) return 1 + i;
  return 0;
}

static void apps_click(int z) {
  if (z == 9) panel_open_app("apps");
  else home_app_launch(z - 1);
}

static const WDef W_APPS = {"apps", "Apps", "Apps", "Your installed apps, one tap to open", IC_APPS, 0, apps_draw, apps_zone, apps_click, apps_tick};

static const char *card_app(int k) {
  static const char *const map[][2] = {{"tasks", "tasks"}, {"surf", "surf"}, {"folders", "files"}, {"documents", "office"}, {"apps", "apps"}};
  for (int i = 0; i < 5; i++)
    if (!strcmp(DEFS[k]->id, map[i][0])) return map[i][1];
  return NULL;
}

static int wunits(int k) { return DEFS[k]->wide ? 2 : 1; }

static int wrows(int k) { return DEFS[k]->wide == 2 ? 2 : 1; }

static int wpx(int k) { return DEFS[k]->wide ? CWIDE : CU; }

static int hpx(int k) { return DEFS[k]->wide == 2 ? 2 * CH + WGAP : CH; }

static const char *size_name(int k) { return DEFS[k]->wide == 2 ? "Large" : DEFS[k]->wide ? "Wide" : "Small"; }

static const char *cfg_path(void) {
  static char p[600];
  const char *e = getenv("OREONVR_WIDGETS_FILE");
  if (e && *e) return e;
  snprintf(p, sizeof p, "%s/.config/oreonvr/widgets", user_home());
  return p;
}

static void save_cfg(void) {
  char dir[600];
  snprintf(dir, sizeof dir, "%s", cfg_path());
  char *sl = strrchr(dir, '/');
  if (sl) {
    *sl = 0;
    office_mkdirs(dir);
  }
  FILE *f = fopen(cfg_path(), "w");
  if (!f) return;
  for (int k = 0; k < NW_DEF; k++)
    if (on[k]) fprintf(f, "%s %d %d %d\n", DEFS[k]->id, wp[k], wc[k], wr[k]);
  fclose(f);
}

static int def_by_id(const char *id) {
  if (!strcmp(id, "sites")) id = "surf";
  for (int i = 0; i < NW_DEF; i++)
    if (!strcmp(DEFS[i]->id, id)) return i;
  return -1;
}

static int fits(int k, int p, int c, int r, int ign) {
  if (p < 0 || p >= MAXPG || c < 0 || r < 0 || c + wunits(k) > GCOLS || r + wrows(k) > GROWS) return 0;
  for (int j = 0; j < NW_DEF; j++) {
    if (!on[j] || j == k || j == ign || wp[j] != p) continue;
    if (c < wc[j] + wunits(j) && wc[j] < c + wunits(k) && r < wr[j] + wrows(j) && wr[j] < r + wrows(k)) return 0;
  }
  return 1;
}

static int auto_place(int k, int from) {
  for (int n = 0; n < MAXPG; n++) {
    int p = (from + n) % MAXPG;
    for (int r = 0; r < GROWS; r++)
      for (int c = 0; c < GCOLS; c++)
        if (fits(k, p, c, r, -1)) {
          wp[k] = p, wc[k] = c, wr[k] = r;
          return 1;
        }
  }
  return 0;
}

static void set_pos(int k, int p, int c, int r) { wp[k] = p, wc[k] = c, wr[k] = r; }

static void default_layout(void) {
  static const struct {
    const char *id;
    int p, c, r;
  } d[] = {{"clock", 0, 0, 0}, {"system", 0, 2, 0}, {"documents", 0, 4, 0}, {"tasks", 0, 0, 1}, {"surf", 0, 2, 1},
           {"calendar", 1, 0, 0}, {"folders", 1, 1, 0}, {"apps", 1, 2, 0}};
  for (unsigned i = 0; i < sizeof d / sizeof *d; i++) {
    int k = def_by_id(d[i].id);
    if (k >= 0) on[k] = 1, set_pos(k, d[i].p, d[i].c, d[i].r);
  }
}

static void load_cfg(void) {
  memset(on, 0, sizeof on);
  FILE *f = fopen(cfg_path(), "r");
  if (!f) {
    default_layout();
    return;
  }
  char line[96];
  int pend[NW_DEF], np = 0;
  while (fgets(line, sizeof line, f)) {
    char id[32];
    int p, c, r;
    int n = sscanf(line, "%31s %d %d %d", id, &p, &c, &r);
    if (n < 1) continue;
    int k = def_by_id(id);
    if (k < 0 || on[k]) continue;
    on[k] = 1;
    if (n == 4 && fits(k, p, c, r, -1)) set_pos(k, p, c, r);
    else wp[k] = -1, pend[np++] = k;
  }
  fclose(f);
  for (int i = 0; i < np; i++)
    if (!auto_place(pend[i], 0)) on[pend[i]] = 0;
}

static int npages_used(void) {
  int n = 0;
  for (int k = 0; k < NW_DEF; k++)
    if (on[k] && wp[k] + 1 > n) n = wp[k] + 1;
  return n ? n : 1;
}

static void compact_pages(void) {
  int map[MAXPG], used[MAXPG] = {0}, n = 0;
  for (int k = 0; k < NW_DEF; k++)
    if (on[k]) used[wp[k]] = 1;
  for (int p = 0; p < MAXPG; p++) map[p] = used[p] ? n++ : -1;
  for (int k = 0; k < NW_DEF; k++)
    if (on[k]) wp[k] = map[wp[k]];
  npages = n ? n : 1;
  if (page > npages - 1) page = npages - 1;
}

static int def_of(const Panel *p) {
  if (!p->app || p->app < WAPP || p->app >= WAPP + NW_DEF) return -1;
  return (int)(p->app - WAPP);
}

int widget_panel(const Panel *p) { return def_of(p) >= 0 || p->app == &PAGER || p->app == &SLOT || p->app == &GAL; }

static void dirty_all(void) {
  for (int k = 0; k < NW_DEF; k++)
    if (pidx[k] >= 0) P[pidx[k]].dirty = 1;
  if (pager >= 0) P[pager].dirty = 1;
  if (gal >= 0) P[gal].dirty = 1;
}

static void go_page(int n) {
  int lim = edit ? (npages_used() < MAXPG ? npages_used() + 1 : MAXPG) : npages;
  if (n < 0) n = 0;
  if (n > lim - 1) n = lim - 1;
  if (n == page) return;
  page = n;
  if (pager >= 0) P[pager].dirty = 1;
}

static void page_box(int p, float *bx, float *by, float *bw, float *bh) {
  int c0 = GCOLS, c1 = 0, r0 = GROWS, r1 = 0;
  if (edit) c0 = 0, c1 = GCOLS, r0 = 0, r1 = GROWS;
  else
    for (int k = 0; k < NW_DEF; k++) {
      if (!on[k] || wp[k] != p) continue;
      if (wc[k] < c0) c0 = wc[k];
      if (wr[k] < r0) r0 = wr[k];
      if (wc[k] + wunits(k) > c1) c1 = wc[k] + wunits(k);
      if (wr[k] + wrows(k) > r1) r1 = wr[k] + wrows(k);
    }
  if (c1 <= c0) c0 = 0, c1 = GCOLS, r0 = 0, r1 = 2;
  *bx = (c0 * GSX + c1 * GSX - WGAP) * 0.5f;
  *by = (r0 * GSY + r1 * GSY - WGAP) * 0.5f;
  *bw = (c1 - c0) * GSX - WGAP;
  *bh = (r1 - r0) * GSY - WGAP;
}

static void cell_xy(int p, int c, int r, int u, int rr, float *x, float *y) {
  float bx, by, bw, bh;
  page_box(p, &bx, &by, &bw, &bh);
  *x = c * GSX + (u * GSX - WGAP) * 0.5f - bx;
  *y = r * GSY + (rr * GSY - WGAP) * 0.5f - by;
}

static void put(Panel *p, float ang, float y, float rad) {
  p->x = sinf(ang) * rad;
  p->z = WHOME_Z - cosf(ang) * rad;
  p->y = y;
  float vx = 0 - p->x, vy = WHOME_Y - p->y, vz = WHOME_Z - p->z;
  float l = sqrtf(vx * vx + vy * vy + vz * vz);
  p->yaw = atan2f(-vx, vz);
  p->tilt = l > 1e-3f ? -asinf(vy / l) : 0;
}

static void targets(void) {
  for (int k = 0; k < NW_DEF; k++) {
    if (!on[k]) continue;
    float x, y;
    cell_xy(wp[k], wc[k], wr[k], wunits(k), wrows(k), &x, &y);
    tx_[k] = x / WDIST + ((float)wp[k] - page_pos) * PAGE_ANG;
    ty_[k] = CENTER_Y - y;
  }
}

static int ptr_wall(float *ang, float *y) {
  float d[3];
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  float cx = W.cx, cz = W.cz - WHOME_Z;
  float a = d[0] * d[0] + d[2] * d[2];
  if (a < 1e-6f) return 0;
  float b = 2 * (cx * d[0] + cz * d[2]), c = cx * cx + cz * cz - WDIST * WDIST, disc = b * b - 4 * a * c;
  if (disc < 0) return 0;
  float t = (-b + sqrtf(disc)) / (2 * a);
  if (t <= 0) return 0;
  float px = cx + t * d[0], pz = cz + t * d[2];
  *ang = atan2f(px, -pz);
  *y = W.cy + t * d[1];
  return 1;
}

static void drag_target(int *c, int *r, int *ok) {
  int k = drag_k;
  float x = (cur_a[k] - ((float)page - page_pos) * PAGE_ANG) * WDIST, y = CENTER_Y - cur_y[k];
  float bx = (GCOLS * GSX - WGAP) * 0.5f, by = (GROWS * GSY - WGAP) * 0.5f;
  int cc = (int)floorf((x - wpx(k) * 0.5f + bx) / GSX + 0.5f), rr = (int)floorf((y - hpx(k) * 0.5f + by) / GSY + 0.5f);
  if (cc < 0) cc = 0;
  if (rr < 0) rr = 0;
  if (cc + wunits(k) > GCOLS) cc = GCOLS - wunits(k);
  if (rr + wrows(k) > GROWS) rr = GROWS - wrows(k);
  *c = cc, *r = rr;
  swap_k = -1;
  *ok = fits(k, page, cc, rr, -1);
  if (!*ok) {
    int hit = -1, n = 0;
    for (int j = 0; j < NW_DEF; j++)
      if (on[j] && j != k && wp[j] == page && cc < wc[j] + wunits(j) && wc[j] < cc + wunits(k) && rr < wr[j] + wrows(j) && wr[j] < rr + wrows(k)) hit = j, n++;
    if (n == 1 && fits(k, page, cc, rr, hit)) {
      int sp = wp[hit], sc = wc[hit], sr = wr[hit];
      wp[hit] = -9;
      int okb = fits(hit, drag_p, drag_c, drag_r, k);
      wp[hit] = sp, wc[hit] = sc, wr[hit] = sr;
      if (okb) *ok = 1, swap_k = hit;
    }
  }
}

static void slot_draw(Panel *p, Surface *s, float ox, float oy) {
  float w = (float)p->lw - 2 * WI, h = (float)p->lh - 2 * WI, x = ox + WI, y = oy + WI;
  uint32_t c = slot_ok ? C_ACCENT : RGB(226, 60, 48);
  gfx_rrect(s, x, y, w, h, 24, with_a(c, 46));
  float per = 2 * (w + h), dash = 14, gap = 9;
  for (float t = 0; t < per; t += dash + gap) {
    for (float u = t; u < t + dash && u < per; u += 2) {
      float px, py;
      if (u < w) px = x + u, py = y;
      else if (u < w + h) px = x + w, py = y + (u - w);
      else if (u < 2 * w + h) px = x + w - (u - w - h), py = y + h;
      else px = x, py = y + h - (u - 2 * w - h);
      if ((px < x + 20 || px > x + w - 20) && (py < y + 20 || py > y + h - 20)) continue;
      gfx_disc(s, px, py, 1.6f, with_a(c, 220));
    }
  }
  float r = 24;
  for (int q = 0; q < 4; q++) {
    float cx = q & 1 ? x + w - r : x + r, cy = q & 2 ? y + h - r : y + r;
    for (int i = 0; i <= 10; i++) {
      float a = (q == 0 ? 3.1416f : q == 1 ? 4.7124f : q == 2 ? 1.5708f : 0) + i * 0.15708f;
      gfx_disc(s, cx + cosf(a) * r, cy + sinf(a) * r, 1.6f, with_a(c, 220));
    }
  }
}

static void w_draw(Panel *p, Surface *s, float ox, float oy) {
  int k = def_of(p);
  int hov = W.hover == (int)(p - P);
  int hot = hov && p->zone >= 100 ? p->zone - 100 : 0;
  int dragging = drag_k == k && drag_live;
  float w = (float)p->lw - 2 * WI, h = (float)p->lh - 2 * WI;
  float cx = ox + WI, cy = oy + WI;
  int lift = hov || dragging;
  gfx_shadow(s, cx, cy + (dragging ? 14 : lift ? 9 : 6), w, h, 24, dragging ? 30 : lift ? 24 : 18, RGBA(10, 16, 30, dragging ? 80 : lift ? 64 : 44));
  uint32_t edge = K_EDGE;
  if (dragging) edge = with_a(C_ACCENT, 230);
  else if (edit) edge = with_a(C_ACCENT, hov ? 200 : 90);
  else if (hot == Z_CARD && card_app(k)) edge = with_a(C_ACCENT, 150);
  if (k == new_k) {
    float t = (now_ms() - new_at) / 1600.f;
    if (t < 1) {
      float a = (1 - t) * (1 - t);
      gfx_rrect(s, cx - 7, cy - 7, w + 14, h + 14, 31, with_a(C_ACCENT, (int)(150 * a)));
      gfx_rrect(s, cx - 4, cy - 4, w + 8, h + 8, 28, with_a(THEME(RGB(255, 255, 255), RGB(34, 38, 45)), (int)(255 * a)));
    }
  }
  gfx_rrect(s, cx - 1.5f, cy - 1.5f, w + 3, h + 3, 25.5f, edge);
  gfx_rrect(s, cx, cy, w, h, 24, K_CARD);
  DEFS[k]->draw(s, cx, cy, w, h, edit ? 0 : hot);
  if (edit) {
    gfx_rrect(s, cx, cy, w, h, 24, with_a(THEME(RGB(255, 255, 255), RGB(34, 38, 45)), dragging ? 0 : 40));
    float gx = cx + w * 0.5f, gy = cy + h - 16;
    for (int i = -2; i <= 2; i++)
      for (int j = 0; j < 2; j++) gfx_disc(s, gx + i * 7, gy - 6 + j * 6, 1.8f, with_a(C_MUTED, 200));
  } else if (hov && card_app(k)) {
    float bx = cx + w - 4, by = cy + 4;
    gfx_disc(s, bx, by, 14, THEME(RGB(255, 255, 255), RGB(34, 38, 45)));
    gfx_disc(s, bx, by, 12, hot == Z_CARD ? C_ACCENT : THEME(RGB(96, 103, 114), RGB(120, 127, 138)));
    gfx_line(s, bx - 4, by + 4, bx + 4, by - 4, 1.8f, RGB(255, 255, 255));
    gfx_line(s, bx - 0.5f, by - 4, bx + 4, by - 4, 1.8f, RGB(255, 255, 255));
    gfx_line(s, bx + 4, by - 4, bx + 4, by + 0.5f, 1.8f, RGB(255, 255, 255));
  }
  if ((edit && !dragging) || (hov && !edit)) {
    float bx = cx + 4, by = cy + 4;
    uint32_t c = hot == Z_REMOVE ? RGB(226, 60, 48) : edit ? THEME(RGB(110, 117, 128), RGB(120, 127, 138)) : THEME(RGB(96, 103, 114), RGB(120, 127, 138));
    gfx_disc(s, bx, by, edit ? 16 : 14, THEME(RGB(255, 255, 255), RGB(34, 38, 45)));
    gfx_disc(s, bx, by, edit ? 14 : 12, c);
    gfx_rrect(s, bx - 5.5f, by - 1.2f, 11, 2.4f, 1.2f, RGB(255, 255, 255));
  }
}

static int w_zone(Panel *p, float x, float y) {
  int k = def_of(p);
  float dx = x - WI - 4, dy = y - WI - 4;
  if (dx * dx + dy * dy < 20 * 20) return Z_REMOVE;
  if (edit) return Z_CARD;
  float w = (float)p->lw - 2 * WI, h = (float)p->lh - 2 * WI;
  float ex = x - WI - w + 4;
  if (card_app(k) && ex * ex + dy * dy < 18 * 18) return Z_CARD;
  int z = DEFS[k]->zone ? DEFS[k]->zone(x - WI, y - WI, w, h) : 0;
  return z ? z : Z_CARD;
}

static void start_drag(int k) {
  float a, y;
  if (!ptr_wall(&a, &y)) return;
  drag_k = k, drag_live = 1;
  drag_p = wp[k], drag_c = wc[k], drag_r = wr[k];
  off_a = cur_a[k] - a, off_y = cur_y[k] - y;
  edge_at = 0;
  if (slot >= 0) {
    panel_resize(slot, wpx(k) + 2 * WI, hpx(k) + 2 * WI);
    P[slot].nobar = 1;
  }
  if (pidx[k] >= 0) panel_raise(pidx[k]), P[pidx[k]].dirty = 1;
}

static void end_drag(void) {
  int k = drag_k;
  if (k < 0) return;
  if (drag_live) {
    int c, r, ok;
    drag_target(&c, &r, &ok);
    if (ok) {
      if (swap_k >= 0) set_pos(swap_k, drag_p, drag_c, drag_r);
      set_pos(k, page, c, r);
      save_cfg();
    } else if (drag_p < 0) {
      if (auto_place(k, page)) save_cfg();
      else on[k] = 0, wp[k] = 0;
    }
    if (drag_p < 0 && on[k]) {
      new_k = k, new_at = now_ms();
      snprintf(note, sizeof note, "%s added", DEFS[k]->name);
      if (wp[k] != page) go_page(wp[k]);
    }
  }
  drag_k = -1, drag_live = 0, swap_k = -1;
  if (slot >= 0) P[slot].visible = 0;
  if (pidx[k] >= 0) P[pidx[k]].dirty = 1;
  dirty_all();
}

static void widget_remove(int k) {
  if (!on[k]) return;
  on[k] = 0;
  if (pidx[k] >= 0) {
    int i = pidx[k];
    pidx[k] = -1;
    panel_close(i);
  }
  save_cfg();
  dirty_all();
}

static void w_tap(Panel *p, float x, float y) {
  int k = def_of(p);
  int z = w_zone(p, x, y);
  if (z == Z_REMOVE) {
    pend_remove = k;
    return;
  }
  if (edit) return;
  if (z == Z_CARD) {
    if (card_app(k)) panel_open_app(card_app(k));
    return;
  }
  if (DEFS[k]->click) DEFS[k]->click(z);
  p->dirty = 1;
}

static void w_press(Panel *p, float x, float y, int b, int down) {
  int k = def_of(p);
  if (b != 1) return;
  if (down) {
    press_k = k, press_at = now_ms(), press_x = W.mx, press_y = W.my;
    if (edit && w_zone(p, x, y) != Z_REMOVE) start_drag(k);
    return;
  }
  int was_drag = drag_k == k && drag_live;
  press_k = -1;
  if (was_drag) {
    int moved = abs(W.mx - press_x) + abs(W.my - press_y) > 6;
    end_drag();
    if (moved) return;
  }
  w_tap(p, x, y);
}

static void w_scroll(Panel *p, float x, float y, int steps) {
  uint32_t t = now_ms();
  if (t - wheel_at < 350) return;
  wheel_at = t;
  go_page(page + (steps < 0 ? 1 : -1));
}

static void w_close(Panel *p) {
  int k = def_of(p);
  if (k >= 0) pidx[k] = -1;
}

static void set_edit(int e) {
  if (edit == e) return;
  if (drag_k >= 0) end_drag();
  edit = e;
  gal_open = 0;
  if (!e) {
    compact_pages();
    save_cfg();
  }
  home_shown = -1;
  dirty_all();
}

enum { PZ_PREV = 1, PZ_NEXT, PZ_EDIT, PZ_ADD, PZ_DONE, PZ_DOT = 10 };

typedef struct {
  float x, w, ax, aw, dx, ex, ew;
} PagerGeo;

static PagerGeo pager_geo(void) {
  PagerGeo g;
  int np = edit ? (npages_used() < MAXPG ? npages_used() + 1 : MAXPG) : npages;
  float dots = 40 + np * 18 + 40;
  if (edit) {
    g.aw = gfx_text_w(F_UI_MED, "Add widgets") + 56;
    g.ew = gfx_text_w(F_UI_MED, "Done") + 44;
    g.w = 10 + g.aw + 18 + dots + 18 + g.ew + 10;
  } else {
    g.aw = 0;
    g.ew = gfx_text_w(F_UI_MED, "Edit") + 60;
    g.w = 16 + dots + 18 + g.ew + 10;
  }
  g.x = (PG_W - g.w) * 0.5f;
  g.ax = g.x + 10;
  g.dx = edit ? g.ax + g.aw + 18 : g.x + 16;
  g.ex = g.dx + dots + 18;
  return g;
}

static void chev(Surface *s, float bx, float cy, int right, uint32_t c) {
  float d = right ? -1 : 1;
  gfx_line(s, bx + 3 * d, cy - 6, bx - 3 * d, cy, 2.2f, c);
  gfx_line(s, bx - 3 * d, cy, bx + 3 * d, cy + 6, 2.2f, c);
}

static void pager_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  PagerGeo g = pager_geo();
  float h = PG_H - 16, y0 = oy + 8, x0 = ox + g.x;
  gfx_shadow(s, x0, y0 + 4, g.w, h, h * 0.5f, 14, RGBA(10, 16, 30, 40));
  gfx_rrect(s, x0 - 1, y0 - 1, g.w + 2, h + 2, h * 0.5f + 1, K_EDGE);
  gfx_rrect(s, x0, y0, g.w, h, h * 0.5f, K_CARD);
  float cy = y0 + h * 0.5f, ph = h - 12;
  int np = edit ? (npages_used() < MAXPG ? npages_used() + 1 : MAXPG) : npages;
  if (edit) {
    float ax = ox + g.ax;
    int hv = hot == PZ_ADD;
    gfx_rrect(s, ax, y0 + 6, g.aw, ph, ph * 0.5f, hv || gal_open ? C_ACCENT : K_TINT);
    uint32_t ic = hv || gal_open ? RGB(255, 255, 255) : K_ACC;
    float px = ax + 22;
    gfx_rrect(s, px - 6, cy - 1.2f, 12, 2.4f, 1.2f, ic);
    gfx_rrect(s, px - 1.2f, cy - 6, 2.4f, 12, 1.2f, ic);
    gfx_text(s, F_UI_MED, ax + 38, cy - lh(F_UI_MED) * 0.5f, "Add widgets", ic);
    gfx_rect(s, ox + g.dx - 9, y0 + 12, 1, h - 24, K_LINE);
  }
  if (note[0]) {
    float nw = g.ex - 18 - g.dx;
    gfx_rrect(s, ox + g.dx, y0 + 6, nw, ph, ph * 0.5f, THEME(RGB(222, 244, 232), RGB(28, 66, 46)));
    uint32_t gc = THEME(RGB(24, 140, 84), RGB(92, 205, 140));
    float tw2 = fminf(gfx_text_w(F_SMALL, note), nw - 40), tx = ox + g.dx + (nw - tw2 - 16) * 0.5f;
    gfx_line(s, tx, cy, tx + 3.5f, cy + 3.5f, 2.f, gc);
    gfx_line(s, tx + 3.5f, cy + 3.5f, tx + 10, cy - 4, 2.f, gc);
    gfx_text_fit(s, F_SMALL, tx + 16, cy - lh(F_SMALL) * 0.5f, nw - 40, note, gc);
  }
  for (int k = 0; k < 2 && !note[0]; k++) {
    int en = k ? page < np - 1 : page > 0;
    float bx = ox + g.dx + (k ? 40 + np * 18 + 20 : 20);
    if (hot == PZ_PREV + k && en) gfx_disc(s, bx, cy, 16, K_SUB_HOT);
    chev(s, bx, cy, k, en ? C_TEXT : K_FAINT);
  }
  for (int i = 0; i < np && !note[0]; i++) {
    float x = ox + g.dx + 40 + i * 18 + 9;
    float a = 1.f - fminf(1.f, fabsf(page_pos - (float)i));
    float rw = 8 + 10 * a;
    int empty = edit && i >= npages_used();
    if (empty && a < 0.5f) gfx_ring(s, x, cy, 3.5f, 1.4f, K_FAINT);
    else gfx_rrect(s, x - rw * 0.5f, cy - 4, rw, 8, 4, a > 0.5f ? C_ACCENT : K_FAINT);
  }
  gfx_rect(s, ox + g.ex - 9, y0 + 12, 1, h - 24, K_LINE);
  float ex = ox + g.ex;
  if (edit) {
    int hv = hot == PZ_DONE;
    gfx_rrect(s, ex, y0 + 6, g.ew, ph, ph * 0.5f, hv ? RGB(36, 92, 230) : C_ACCENT);
    gfx_text_c(s, F_UI_MED, ex + g.ew * 0.5f, cy - lh(F_UI_MED) * 0.5f, "Done", RGB(255, 255, 255));
    return;
  }
  int hv = hot == PZ_EDIT;
  gfx_rrect(s, ex, y0 + 6, g.ew, ph, ph * 0.5f, hv ? C_ACCENT : K_TINT);
  uint32_t ic = hv ? RGB(255, 255, 255) : K_ACC;
  uint32_t bg = hv ? C_ACCENT : K_TINT;
  float iw = 14, gap = 8, gw = iw + gap + gfx_text_w(F_UI_MED, "Edit");
  float gx = ex + (g.ew - gw) * 0.5f;
  float tx = gx + 1, ty = cy + 6.5f, ux = 0.7071f, uy = -0.7071f;
  float b0x = tx + ux * 5, b0y = ty + uy * 5, b1x = tx + ux * 16, b1y = ty + uy * 16;
  gfx_line(s, b0x, b0y, b1x, b1y, 5.4f, ic);
  gfx_tri(s, tx, ty, b0x + uy * 2.7f, b0y - ux * 2.7f, b0x - uy * 2.7f, b0y + ux * 2.7f, ic);
  float sx = tx + ux * 12.5f, sy = ty + uy * 12.5f;
  gfx_line(s, sx + uy * 3.2f, sy - ux * 3.2f, sx - uy * 3.2f, sy + ux * 3.2f, 1.4f, bg);
  gfx_line(s, tx + ux * 6.4f + uy * 3.2f, ty + uy * 6.4f - ux * 3.2f, tx + ux * 6.4f - uy * 3.2f, ty + uy * 6.4f + ux * 3.2f, 1.f, bg);
  gfx_text(s, F_UI_MED, gx + iw + gap, cy - lh(F_UI_MED) * 0.5f, "Edit", ic);
}

static int pager_zone(Panel *p, float x, float y) {
  PagerGeo g = pager_geo();
  int np = edit ? (npages_used() < MAXPG ? npages_used() + 1 : MAXPG) : npages;
  if (y < 8 || y > PG_H - 8) return 0;
  if (edit && in_r(x, y, g.ax, 8, g.aw, PG_H - 16)) return PZ_ADD;
  if (in_r(x, y, g.ex, 8, g.ew, PG_H - 16)) return edit ? PZ_DONE : PZ_EDIT;
  if (in_r(x, y, g.dx, 8, 40, PG_H - 16)) return PZ_PREV;
  if (in_r(x, y, g.dx + 40 + np * 18, 8, 40, PG_H - 16)) return PZ_NEXT;
  for (int i = 0; i < np; i++)
    if (in_r(x, y, g.dx + 40 + i * 18, 8, 18, PG_H - 16)) return PZ_DOT + i;
  return 0;
}

static void pager_click(Panel *p, float x, float y) {
  int z = pager_zone(p, x, y);
  if (z == PZ_PREV) go_page(page - 1);
  else if (z == PZ_NEXT) go_page(page + 1);
  else if (z == PZ_EDIT) set_edit(1);
  else if (z == PZ_DONE) set_edit(0);
  else if (z == PZ_ADD) gal_open = !gal_open, home_shown = -1;
  else if (z >= PZ_DOT) go_page(z - PZ_DOT);
  p->dirty = 1;
}

static void pager_key(Panel *p, int code, int mods) {
  if (code == KEY_ESC && edit) set_edit(0);
}

static Surface prev_s[NW_DEF];

static void preview(int k, Surface *s, float x, float y, float w, float h) {
  int pw = wpx(k), ph = hpx(k);
  if (!prev_s[k].px && !surf_init(&prev_s[k], pw, ph, SCALE)) return;
  surf_clear(&prev_s[k], 0);
  gfx_rrect(&prev_s[k], 0, 0, pw, ph, 24, K_CARD | 0xff000000u);
  DEFS[k]->draw(&prev_s[k], 0, 0, pw, ph, 0);
  float sc = fminf(w / pw, h / ph);
  float dw = pw * sc, dh = ph * sc;
  gfx_shadow(s, x + (w - dw) * 0.5f, y + (h - dh) * 0.5f + 3, dw, dh, 24 * sc, 8, RGBA(10, 16, 30, 30));
  gfx_blit_premul(s, prev_s[k].px, prev_s[k].w, prev_s[k].h, x + (w - dw) * 0.5f, y + (h - dh) * 0.5f, dw, dh);
}

#define GAL_HEAD 96
#define GAL_CH 232

static void gal_cell(int i, float w, float *x, float *y, float *cw, float *ch) {
  *cw = (w - 56 - 3 * 16) / 4.f, *ch = GAL_CH;
  *x = 28 + (i % 4) * (*cw + 16), *y = GAL_HEAD + (i / 4) * (*ch + 16);
}

static void size_glyph(Surface *s, float x, float y, int k, uint32_t c) {
  for (int r = 0; r < 2; r++)
    for (int q = 0; q < 2; q++) {
      int fill = q < wunits(k) && r < wrows(k);
      gfx_rrect(s, x + q * 7, y + r * 7, 5.5f, 5.5f, 1.5f, fill ? c : with_a(c, 60));
    }
}

static void gal_draw(Panel *p, Surface *s, float ox, float oy) {
  int hot = W.hover == (int)(p - P) && p->zone >= 100 ? p->zone - 100 : 0;
  float w = (float)p->lw - 2 * WI, h = (float)p->lh - 2 * WI, x0 = ox + WI, y0 = oy + WI;
  gfx_shadow(s, x0, y0 + 10, w, h, 28, 28, RGBA(10, 16, 30, 60));
  gfx_rrect(s, x0 - 1, y0 - 1, w + 2, h + 2, 29, K_EDGE);
  gfx_rrect(s, x0, y0, w, h, 28, K_CARD);
  int n = widgets_enabled_count();
  text_q(s, F_UI_MED, x0 + 28, y0 + 22, "Add widgets", C_TEXT, 1.4f);
  gfx_text(s, F_UI, x0 + 29, y0 + 56, n == NW_DEF ? "Everything is on your home screen. Remove a widget to make room." : "Tap a widget to add it, or drag it onto your home screen.", C_MUTED);
  char cnt[32];
  snprintf(cnt, sizeof cnt, "%d of %d added", n, NW_DEF);
  float cw0 = gfx_text_w(F_SMALL, cnt) + 22, bx = x0 + w - 28 - 40;
  gfx_rrect(s, bx - 14 - cw0, y0 + 30, cw0, 26, 13, K_TINT);
  gfx_text_c(s, F_SMALL, bx - 14 - cw0 * 0.5f, y0 + 43 - lh(F_SMALL) * 0.5f, cnt, K_ACC);
  float by = y0 + 23;
  gfx_disc(s, bx + 20, by + 20, 20, hot == 1 ? K_SUB_HOT : K_SUB);
  gfx_line(s, bx + 14, by + 14, bx + 26, by + 26, 2.2f, C_TEXT);
  gfx_line(s, bx + 26, by + 14, bx + 14, by + 26, 2.2f, C_TEXT);
  for (int k = 0; k < NW_DEF; k++) {
    float x, y, cw, ch;
    gal_cell(k, w, &x, &y, &cw, &ch);
    x += x0, y += y0;
    int hv = hot == 10 + k && !on[k];
    if (hv) gfx_shadow(s, x, y + 6, cw, ch, 18, 16, RGBA(10, 16, 30, 50));
    if (hv) gfx_rrect(s, x - 2, y - 2, cw + 4, ch + 4, 20, with_a(C_ACCENT, 220));
    gfx_rrect(s, x, y, cw, ch, 18, hv ? THEME(RGB(248, 250, 253), RGB(50, 56, 66)) : K_SUB);
    preview(k, s, x + 12, y + 12, cw - 24, 112);
    if (on[k]) gfx_rrect(s, x + 6, y + 6, cw - 12, 124, 14, with_a(K_SUB, 120));
    gfx_text_fit(s, F_UI_MED, x + 14, y + 138, cw - 28, DEFS[k]->name, C_TEXT);
    gfx_text_fit(s, F_SMALL, x + 14, y + 160, cw - 28, DEFS[k]->desc, C_MUTED);
    char sz[24];
    snprintf(sz, sizeof sz, "%s  %dx%d", size_name(k), wunits(k), wrows(k));
    float sw = gfx_text_w(F_SMALL, sz) + 38, sy = y + ch - 40;
    gfx_rrect(s, x + 12, sy, sw, 26, 13, THEME(RGB(255, 255, 255), RGB(58, 64, 75)));
    size_glyph(s, x + 22, sy + 6.5f, k, C_MUTED);
    gfx_text(s, F_SMALL, x + 42, sy + 13 - lh(F_SMALL) * 0.5f, sz, C_MUTED);
    const char *lab = on[k] ? "Added" : "Add";
    float pw = gfx_text_w(F_UI_MED, lab) + (on[k] ? 40 : 34), px = x + cw - 12 - pw;
    if (on[k]) {
      gfx_rrect(s, px, sy - 2, pw, 30, 15, THEME(RGB(222, 244, 232), RGB(28, 66, 46)));
      uint32_t g = THEME(RGB(24, 140, 84), RGB(92, 205, 140));
      gfx_line(s, px + 12, sy + 13, px + 15.5f, sy + 16.5f, 2.f, g);
      gfx_line(s, px + 15.5f, sy + 16.5f, px + 22, sy + 9, 2.f, g);
      gfx_text(s, F_UI_MED, px + 28, sy + 13 - lh(F_UI_MED) * 0.5f, lab, g);
    } else {
      gfx_rrect(s, px, sy - 2, pw, 30, 15, hv ? C_ACCENT : K_TINT);
      uint32_t c = hv ? RGB(255, 255, 255) : K_ACC;
      gfx_rrect(s, px + 11, sy + 11.8f, 10, 2.4f, 1.2f, c);
      gfx_rrect(s, px + 14.8f, sy + 8, 2.4f, 10, 1.2f, c);
      gfx_text(s, F_UI_MED, px + 25, sy + 13 - lh(F_UI_MED) * 0.5f, lab, c);
    }
  }
}

static int gal_zone(Panel *p, float x, float y) {
  float w = (float)p->lw - 2 * WI;
  float lx = x - WI, ly = y - WI;
  if (in_r(lx, ly, w - 28 - 40, 23, 40, 40)) return 1;
  for (int k = 0; k < NW_DEF; k++) {
    float cx, cy, cw, ch;
    gal_cell(k, w, &cx, &cy, &cw, &ch);
    if (in_r(lx, ly, cx, cy, cw, ch)) return 10 + k;
  }
  return 0;
}

static void sync_panels(void);

static void gal_add(int k) {
  if (on[k] || !auto_place(k, page)) return;
  on[k] = 1;
  save_cfg();
  sync_panels();
  targets();
  cur_a[k] = tx_[k], cur_y[k] = ty_[k];
  gal_open = 0;
  new_k = k, new_at = now_ms();
  snprintf(note, sizeof note, wp[k] != page ? "%s added to page %d" : "%s added", DEFS[k]->name, wp[k] + 1);
  if (wp[k] != page) go_page(wp[k]);
  home_shown = -1;
}

static void gal_spawn(int k) {
  float a, y;
  if (on[k] || !ptr_wall(&a, &y)) return;
  on[k] = 1;
  wp[k] = -9, wc[k] = 0, wr[k] = 0;
  sync_panels();
  if (pidx[k] < 0) {
    on[k] = 0;
    return;
  }
  gal_open = 0;
  cur_a[k] = a, cur_y[k] = y;
  drag_k = k, drag_live = 1, drag_p = -1, drag_c = 0, drag_r = 0;
  off_a = 0, off_y = 0, edge_at = 0;
  if (slot >= 0) panel_resize(slot, wpx(k) + 2 * WI, hpx(k) + 2 * WI), P[slot].nobar = 1;
  panel_raise(pidx[k]);
  P[pidx[k]].appear = 0.6f;
  home_shown = -1;
}

static void gal_press(Panel *p, float x, float y, int b, int down) {
  if (b != 1) return;
  if (down) {
    int z = gal_zone(p, x, y);
    gal_k = z >= 10 && !on[z - 10] ? z - 10 : -1;
    gal_at = now_ms(), gal_px = W.mx, gal_py = W.my;
    if (z == 1) gal_open = 0, home_shown = -1;
    return;
  }
  if (drag_live && drag_p < 0) {
    end_drag();
    gal_k = -1;
    return;
  }
  int k = gal_k;
  gal_k = -1;
  if (k >= 0 && gal_zone(p, x, y) == 10 + k) gal_add(k);
  p->dirty = 1;
}

static void sync_panels(void) {
  for (int k = 0; k < NW_DEF; k++) {
    if (on[k] && pidx[k] < 0) {
      int i = panel_create(PK_WINDOW, wpx(k) + 2 * WI, hpx(k) + 2 * WI, DEFS[k]->name, &WAPP[k]);
      if (i < 0) continue;
      P[i].nobar = 1;
      P[i].visible = 0;
      P[i].appear = 0;
      pidx[k] = i;
      cur_a[k] = 99;
    } else if (!on[k] && pidx[k] >= 0) {
      int i = pidx[k];
      pidx[k] = -1;
      panel_close(i);
    }
  }
  if (pager < 0) {
    int i = panel_create(PK_WINDOW, PG_W, PG_H, "Pages", &PAGER);
    if (i >= 0) P[i].nobar = 1, P[i].visible = 0, pager = i;
  }
  if (slot < 0) {
    int i = panel_create(PK_WINDOW, CU + 2 * WI, CH + 2 * WI, "Drop", &SLOT);
    if (i >= 0) P[i].nobar = 1, P[i].visible = 0, slot = i;
  }
  if (gal < 0) {
    int i = panel_create(PK_WINDOW, GAL_W, GAL_H, "Add widgets", &GAL);
    if (i >= 0) P[i].nobar = 1, P[i].visible = 0, gal = i;
  }
  npages = npages_used();
  if (page > npages - 1 && !edit) page = npages - 1;
  home_shown = -1;
  dirty_all();
}

void widgets_init(void) {
  if (inited) return;
  inited = 1;
  const WDef *all[NW_DEF] = {&W_CLOCK, &W_CAL, &W_SYS, &W_TASKS, &W_SITES, &W_FOLD, &W_DOCS, &W_APPS};
  for (int i = 0; i < NW_DEF; i++) {
    DEFS[i] = all[i];
    pidx[i] = -1;
    char *id = malloc(32);
    snprintf(id, 32, "w-%s", all[i]->id);
    WAPP[i] = (App){id, all[i]->name, all[i]->icon, wpx(i) + 2 * WI, hpx(i) + 2 * WI, NULL, w_draw, NULL, w_scroll, pager_key, w_zone, NULL, w_close, w_press};
  }
  PAGER = (App){"w-pager", "Pages", IC_APPS, PG_W, PG_H, NULL, pager_draw, pager_click, w_scroll, pager_key, pager_zone, NULL, NULL};
  SLOT = (App){"w-slot", "Drop", IC_APPS, CU, CH, NULL, slot_draw, NULL, NULL, NULL, NULL, NULL, NULL};
  GAL = (App){"w-gallery", "Add widgets", IC_APPS, GAL_W, GAL_H, NULL, gal_draw, NULL, NULL, pager_key, gal_zone, NULL, NULL, gal_press};
  load_cfg();
  sys_sample();
  sync_panels();
}

static int at_home(void) {
  if (lock_active() || OV.draw) return 0;
  for (int i = 0; i < MAXP; i++) {
    Panel *p = &P[i];
    if (!p->used || p->kind != PK_WINDOW || widget_panel(p)) continue;
    if (p->app && !strcmp(p->app->id, "keyboard")) continue;
    return 0;
  }
  return 1;
}

int widgets_animating(void) { return inited && home_shown == 1 && (moving || drag_live || new_k >= 0); }

static void apply_visibility(int home) {
  for (int k = 0; k < NW_DEF; k++) {
    if (pidx[k] < 0) continue;
    Panel *p = &P[pidx[k]];
    int want = home && (fabsf((float)wp[k] - page_pos) < 0.62f || (drag_k == k && drag_live));
    if (want && !p->visible) p->appear = 0, p->dirty = 1;
    p->visible = want;
  }
  if (pager >= 0) {
    Panel *p = &P[pager];
    if (home && !p->visible) p->appear = 0, p->dirty = 1;
    p->visible = home;
  }
  if (gal >= 0) {
    Panel *p = &P[gal];
    int want = home && edit && gal_open;
    if (want && !p->visible) p->appear = 0, p->dirty = 1;
    p->visible = want;
  }
}

void widgets_tick(uint32_t now) {
  static uint32_t last;
  if (!inited) return;
  if (pend_remove >= 0) {
    int k = pend_remove;
    pend_remove = -1;
    widget_remove(k);
  }
  int home = at_home();
  if (!home && edit) set_edit(0);
  float dt = last && now > last ? (float)(now - last) / 1000.f : 1.f / 60.f;
  last = now;
  if (dt > 0.05f) dt = 0.05f;
  if (!edit) npages = npages_used();
  if (gal_k >= 0 && !drag_live && abs(W.mx - gal_px) + abs(W.my - gal_py) > 14) {
    int k = gal_k;
    gal_k = -1;
    gal_spawn(k);
  }
  if (new_k >= 0) {
    if (now - new_at < 1700 && pidx[new_k] >= 0) P[pidx[new_k]].dirty = 1;
    else new_k = -1;
  }
  if (note[0] && now - new_at > 2200) note[0] = 0, dirty_all();
  if (press_k >= 0 && !edit && !drag_live && now - press_at > 550 && abs(W.mx - press_x) + abs(W.my - press_y) < 8) {
    int k = press_k;
    set_edit(1);
    targets();
    start_drag(k);
  }
  if (fabsf(page_pos - (float)page) > 0.001f) {
    page_pos += ((float)page - page_pos) * (1.f - expf(-dt * 11.f));
    if (fabsf(page_pos - (float)page) < 0.003f) page_pos = (float)page;
    if (pager >= 0) P[pager].dirty = 1;
  }
  targets();
  moving = fabsf(page_pos - (float)page) > 0.001f;
  float kk = 1.f - expf(-dt * 14.f);
  for (int k = 0; k < NW_DEF; k++) {
    if (!on[k] || pidx[k] < 0) continue;
    if (drag_k == k && drag_live) {
      float a, y;
      if (ptr_wall(&a, &y)) cur_a[k] = a + off_a, cur_y[k] = y + off_y;
      put(&P[pidx[k]], cur_a[k], cur_y[k], WDIST - 70);
      continue;
    }
    if (cur_a[k] > 50 || !P[pidx[k]].visible) cur_a[k] = tx_[k], cur_y[k] = ty_[k];
    float da = tx_[k] - cur_a[k], dy = ty_[k] - cur_y[k];
    if (fabsf(da) > 1e-4f || fabsf(dy) > 0.05f) {
      cur_a[k] += da * kk, cur_y[k] += dy * kk;
      moving = 1;
    } else cur_a[k] = tx_[k], cur_y[k] = ty_[k];
    put(&P[pidx[k]], cur_a[k], cur_y[k], WDIST);
  }
  float bx, by, bw, bh;
  page_box(page, &bx, &by, &bw, &bh);
  float py = CENTER_Y - bh * 0.5f - 64;
  if (pager_y < -9000) pager_y = py;
  if (fabsf(py - pager_y) > 0.05f) pager_y += (py - pager_y) * kk, moving = 1;
  if (pager >= 0) put(&P[pager], 0, pager_y, WDIST * 0.97f);
  if (gal >= 0) put(&P[gal], 0, CENTER_Y - 40, WDIST * 0.72f);
  if (drag_live && drag_k >= 0 && slot >= 0) {
    int c, r, ok;
    drag_target(&c, &r, &ok);
    float x, y;
    cell_xy(page, c, r, wunits(drag_k), wrows(drag_k), &x, &y);
    put(&P[slot], x / WDIST + ((float)page - page_pos) * PAGE_ANG, CENTER_Y - y, WDIST + 2);
    if (ok != slot_ok) slot_ok = ok, P[slot].dirty = 1;
    P[slot].visible = home;
    float rel = (cur_a[drag_k] - ((float)page - page_pos) * PAGE_ANG) * WDIST;
    int dir = rel > GPW * 0.5f + 40 ? 1 : rel < -GPW * 0.5f - 40 ? -1 : 0;
    if (!dir) edge_at = 0;
    else if (!edge_at) edge_at = now ? now : 1;
    else if (now - edge_at > 650) go_page(page + dir), edge_at = 0;
  }
  if (home != home_shown || moving || drag_live) {
    apply_visibility(home);
    home_shown = home;
  }
  if (!home) return;
  img_frame();
  for (int k = 0; k < NW_DEF; k++) {
    if (pidx[k] < 0 || !DEFS[k]->tick || !P[pidx[k]].visible) continue;
    if (DEFS[k]->tick(now)) P[pidx[k]].dirty = 1;
  }
  if (gal >= 0 && P[gal].visible) {
    static uint32_t gat;
    if (now - gat > 1000) gat = now, P[gal].dirty = 1;
  }
}

int widget_def_count(void) { return NW_DEF; }

int widgets_enabled_count(void) {
  int n = 0;
  for (int k = 0; k < NW_DEF; k++) n += on[k];
  return n;
}

int widgets_page(void) { return page; }

int widgets_editing(void) { return edit; }
