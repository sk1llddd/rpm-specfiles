#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "oreonvr.h"

enum { M_NONE, M_LOOK, M_FLY, M_DRAG };

static int mode = M_NONE;
static int lastx, lasty, have_last;
static int drag_panel = -1;
static float grab_s, grab_t, grab_dist;
static int mods, caps;
static int press_panel = -1, press_btn;

#define LOOK_SENS 0.0055f
#define FLY_SENS 1.65f

static void drag_to_ray(void) {
  Panel *p = &P[drag_panel];
  if (!p->used) {
    mode = M_NONE;
    return;
  }
  float d[3];
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  float G[3] = {W.cx + d[0] * grab_dist, W.cy + d[1] * grab_dist, W.cz + d[2] * grab_dist};
  float offx = grab_s - p->lw * 0.5f, offy = grab_t - p->lh * 0.5f;
  p->x = G[0], p->y = G[1], p->z = G[2];
  for (int it = 0; it < 2; it++) {
    scene_face_head(p);
    float ca = cosf(p->yaw), sa = sinf(p->yaw), ct = cosf(p->tilt), st = sinf(p->tilt);
    float pr[3] = {ca, 0, sa}, pu[3] = {-sa * st, ct, ca * st};
    p->x = G[0] - pr[0] * offx + pu[0] * offy;
    p->y = G[1] - pr[1] * offx + pu[1] * offy;
    p->z = G[2] - pr[2] * offx + pu[2] * offy;
  }
}

static void motion(int dx, int dy) {
  float k = LOOK_SENS * W.sens * (W.vr ? 1.4f : 1.f);
  switch (mode) {
  case M_LOOK:
    W.gyaw -= dx * k;
    W.gpitch -= dy * k;
    if (W.gpitch > 1.2f) W.gpitch = 1.2f;
    if (W.gpitch < -1.2f) W.gpitch = -1.2f;
    break;
  case M_FLY: {
    float f[3], r[3], u[3];
    scene_basis(W.gyaw, W.gpitch, f, r, u);
    W.gx += f[0] * -dy * FLY_SENS + r[0] * dx * FLY_SENS;
    W.gy += f[1] * -dy * FLY_SENS;
    W.gz += f[2] * -dy * FLY_SENS + r[2] * dx * FLY_SENS;
    break;
  }
  case M_DRAG: drag_to_ray(); break;
  }
}

void input_pointer_move(int x, int y) {
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (W.out_w && x >= W.out_w) x = W.out_w - 1;
  if (W.out_h && y >= W.out_h) y = W.out_h - 1;
  int dx = have_last ? x - lastx : 0, dy = have_last ? y - lasty : 0;
  lastx = x, lasty = y, have_last = 1;
  W.mx = x, W.my = y;
  motion(dx, dy);
}

void input_pointer_rel(int dx, int dy) {
  if (mode == M_LOOK || mode == M_FLY) {
    motion(dx, dy);
    return;
  }
  input_pointer_move(W.mx + dx, W.my + dy);
}

static void set_focus(int i) {
  if (W.focus == i) return;
  if (W.focus >= 0 && P[W.focus].used) P[W.focus].dirty = 1;
  W.focus = i;
  if (i >= 0) P[i].dirty = 1;
}

void input_begin_drag(int panel) {
  float d[3], s, t, dist;
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  if (panel < 0 || !P[panel].used || scene_pick(d[0], d[1], d[2], &s, &t, &dist) != panel) return;
  mode = M_DRAG;
  drag_panel = panel;
  grab_s = s, grab_t = t, grab_dist = dist;
  press_panel = -1;
}

int input_dragging(void) { return mode == M_DRAG; }

static void ov_point(float *x, float *y) {
  if (!W.vr) {
    *x = (float)W.mx, *y = (float)W.my;
    return;
  }
  float ew = W.out_w * 0.5f, eh = (float)W.out_h;
  *x = (float)W.mx / W.out_w * ew - ew * 0.08f, *y = (float)W.my / W.out_h * eh - eh * 0.08f;
}

void input_button(int b, int down) {
  if (OV.draw) {
    mode = M_NONE;
    press_panel = -1;
    float x, y;
    ov_point(&x, &y);
    if (OV.press) OV.press(x, y, b, down);
    OV.dirty = 1;
    return;
  }
  if (!down && press_panel >= 0 && b == press_btn) {
    Panel *p = &P[press_panel];
    press_panel = -1;
    if (p->used && p->app && p->app->press) {
      float d[3], ps = W.hs, pt = W.ht, dist;
      scene_pointer_ray(&d[0], &d[1], &d[2]);
      float hs, ht;
      if (scene_pick(d[0], d[1], d[2], &hs, &ht, &dist) == (int)(p - P)) ps = hs, pt = ht;
      p->app->press(p, ps, p->kind == PK_WINDOW ? pt - BARH(p) : pt, b, 0);
    }
    return;
  }
  if (!down) {
    if (mode == M_DRAG && b == 1) drag_panel = -1;
    if ((mode == M_LOOK || mode == M_DRAG) && b == 1) mode = M_NONE;
    if (mode == M_FLY && (b == 2 || b == 3)) mode = M_NONE;
    return;
  }
  if (mode != M_NONE) return;
  float d[3], s, t, dist;
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  int i = scene_pick(d[0], d[1], d[2], &s, &t, &dist);
  if (i < 0) {
    mode = b == 1 ? M_LOOK : M_FLY;
    return;
  }
  Panel *p = &P[i];
  if (p->nobar && b == 1 && (mods & MOD_ALT)) {
    mode = M_DRAG;
    drag_panel = i;
    grab_s = s, grab_t = t, grab_dist = dist;
    panel_raise(i);
    return;
  }
  if (p->app && p->app->press && p->kind != PK_DOCK && (p->kind == PK_CHILD || t >= BARH(p))) {

    if (p->kind == PK_WINDOW) panel_raise(i);
    if (p->app->key || p->app->rawkey) set_focus(i);
    press_panel = i, press_btn = b;
    p->app->press(p, s, p->kind == PK_WINDOW ? t - BARH(p) : t, b, 1);
    return;
  }
  if (b != 1) return;
  if (p->kind == PK_WINDOW) panel_raise(i);
  if (p->app && (p->app->key || p->app->rawkey)) set_focus(i);
  int z = panel_zone(p, s, t);
  if (p->kind == PK_WINDOW && z == 1) {
    if (!(p->app && p->app->close_request && p->app->close_request(p))) panel_close(i);
    return;
  }
  if (p->kind == PK_WINDOW && t < BARH(p)) {
    mode = M_DRAG;
    drag_panel = i;
    grab_s = s, grab_t = t, grab_dist = dist;
    return;
  }
  if (p->app && p->app->click) p->app->click(p, s, p->kind == PK_WINDOW ? t - BARH(p) : t);
  if (P[i].used) P[i].dirty = 1;
}

void input_wheel(int steps) {
  if (OV.draw) {
    if (OV.wheel) OV.wheel(steps);
    OV.dirty = 1;
    return;
  }
  float d[3], s, t, dist;
  scene_pointer_ray(&d[0], &d[1], &d[2]);
  int i = scene_pick(d[0], d[1], d[2], &s, &t, &dist);
  if (i < 0) {
    float f[3], r[3], u[3];
    scene_basis(W.gyaw, W.gpitch, f, r, u);
    W.gx += f[0] * steps * 72.f, W.gy += f[1] * steps * 72.f, W.gz += f[2] * steps * 72.f;
    return;
  }
  Panel *p = &P[i];
  if (p->kind == PK_WINDOW && t < BARH(p)) {
    float vx = p->x - W.gx, vy = p->y - W.gy, vz = p->z - W.gz;
    float l = sqrtf(vx * vx + vy * vy + vz * vz);
    float nl = l * (1.f + steps * 0.08f);
    if (nl < 260.f) nl = 260.f;
    if (nl > 3200.f) nl = 3200.f;
    p->x = W.gx + vx / l * nl, p->y = W.gy + vy / l * nl, p->z = W.gz + vz / l * nl;
    scene_face_head(p);
    return;
  }
  if (p->app && p->app->scroll) p->app->scroll(p, s, p->kind == PK_WINDOW ? t - BARH(p) : t, steps);
}

static const char LOWER[64] = {0, 27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 127, '\t',
                               'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\r', 0, 'a', 's',
                               'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0, '\\', 'z', 'x', 'c', 'v',
                               'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' ', 0};
static const char UPPER[64] = {0, 27, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', 127, '\t',
                               'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\r', 0, 'A', 'S',
                               'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~', 0, '|', 'Z', 'X', 'C', 'V',
                               'B', 'N', 'M', '<', '>', '?', 0, '*', 0, ' ', 0};

int key_from_char(char c, int *shift) {
  for (int i = 1; i < 64; i++) {
    if (LOWER[i] == c) return *shift = 0, i;
    if (UPPER[i] == c && LOWER[i] != c) return *shift = 1, i;
  }
  return 0;
}

int input_mods(void) { return mods | (caps ? MOD_CAPS : 0); }

int key_to_bytes(int code, int m, char *out) {
  const char *seq = NULL;
  switch (code) {
  case KEY_UP: seq = "\x1b[A"; break;
  case KEY_DOWN: seq = "\x1b[B"; break;
  case KEY_RIGHT: seq = "\x1b[C"; break;
  case KEY_LEFT: seq = "\x1b[D"; break;
  case KEY_HOME: seq = "\x1b[1~"; break;
  case KEY_END: seq = "\x1b[4~"; break;
  case KEY_INSERT: seq = "\x1b[2~"; break;
  case KEY_DELETE: seq = "\x1b[3~"; break;
  case KEY_PAGEUP: seq = "\x1b[5~"; break;
  case KEY_PAGEDOWN: seq = "\x1b[6~"; break;
  case KEY_F1: seq = "\x1b[[A"; break;
  case KEY_F2: seq = "\x1b[[B"; break;
  case KEY_F3: seq = "\x1b[[C"; break;
  case KEY_F4: seq = "\x1b[[D"; break;
  case KEY_F5: seq = "\x1b[[E"; break;
  case KEY_KPENTER: seq = "\r"; break;
  case KEY_KPSLASH: seq = "/"; break;
  case KEY_KPMINUS: seq = "-"; break;
  case KEY_KPPLUS: seq = "+"; break;
  case KEY_KPDOT: seq = "."; break;
  case KEY_KP0: seq = "0"; break;
  case KEY_KP1: seq = "1"; break;
  case KEY_KP2: seq = "2"; break;
  case KEY_KP3: seq = "3"; break;
  case KEY_KP4: seq = "4"; break;
  case KEY_KP5: seq = "5"; break;
  case KEY_KP6: seq = "6"; break;
  case KEY_KP7: seq = "7"; break;
  case KEY_KP8: seq = "8"; break;
  case KEY_KP9: seq = "9"; break;
  }
  if (code == KEY_TAB && (m & MOD_SHIFT)) seq = "\x1b[Z";
  if (seq) {
    int n = (int)strlen(seq);
    memcpy(out, seq, (size_t)n);
    return n;
  }
  if (code < 0 || code >= 64) return 0;
  char c = LOWER[code];
  if (!c) return 0;
  int letter = c >= 'a' && c <= 'z';
  int shift = (m & MOD_SHIFT) != 0;
  if (letter && (m & MOD_CAPS)) shift = !shift;
  if (shift) c = UPPER[code];
  int n = 0;
  if (m & MOD_ALT) out[n++] = 27;
  if (m & MOD_CTRL) {
    if (letter) c = (char)(LOWER[code] - 'a' + 1);
    else if (c == ' ' || c == '@' || c == '2') c = 0;
    else if (c == '[') c = 27;
    else if (c == '\\') c = 28;
    else if (c == ']') c = 29;
    else if (c == '/' || c == '_' || c == '-') c = 31;
  }
  out[n++] = c;
  return n;
}

void input_key(int code, int down, int repeat) {
  int bit = 0;
  if (code == KEY_LEFTSHIFT || code == KEY_RIGHTSHIFT) bit = MOD_SHIFT;
  else if (code == KEY_LEFTCTRL || code == KEY_RIGHTCTRL) bit = MOD_CTRL;
  else if (code == KEY_LEFTALT || code == KEY_RIGHTALT) bit = MOD_ALT;
  if (bit) {
    if (down) mods |= bit;
    else mods &= ~bit;
  }
  if (code == KEY_CAPSLOCK && down && !repeat) caps ^= 1;
  if (down && !repeat && code == KEY_L && (mods & MOD_CTRL) && (mods & MOD_ALT) && !OV.draw) {
    lock_start();
    return;
  }
  if (OV.draw) {
    if (OV.key && down && !bit && code != KEY_CAPSLOCK) OV.key(code, input_mods());
    OV.dirty = 1;
    return;
  }
  int f = W.focus;
  if (f < 0 || !P[f].used || !P[f].visible || !P[f].app) return;
  if (P[f].app->rawkey) {
    if (!repeat) P[f].app->rawkey(&P[f], code, down);
    return;
  }
  if (bit || code == KEY_CAPSLOCK || !down || !P[f].app->key) return;
  P[f].app->key(&P[f], code, input_mods());
}

typedef struct {
  int fd;
  char name[32];
  int ax0, ax1, ay0, ay1, has_abs;
  int absx, absy, abs_dirty;
} Dev;

static Dev devs[32];
static int ndev;
static uint32_t last_scan;

int evdev_fd_count(void) { return ndev; }

static int have_dev(const char *name) {
  for (int i = 0; i < ndev; i++)
    if (!strcmp(devs[i].name, name)) return 1;
  return 0;
}

int evdev_open_all(void) {
  DIR *d = opendir("/dev/input");
  if (!d) return ndev;
  struct dirent *e;
  while ((e = readdir(d)) && ndev < 32) {
    if (strncmp(e->d_name, "event", 5) || have_dev(e->d_name)) continue;
    char path[300];
    snprintf(path, sizeof path, "/dev/input/%s", e->d_name);
    int fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) continue;
    Dev *v = &devs[ndev++];
    memset(v, 0, sizeof *v);
    v->fd = fd;
    snprintf(v->name, sizeof v->name, "%.31s", e->d_name);
    struct input_absinfo ax, ay;
    if (!ioctl(fd, EVIOCGABS(ABS_X), &ax) && !ioctl(fd, EVIOCGABS(ABS_Y), &ay) && ax.maximum > ax.minimum &&
        ay.maximum > ay.minimum) {
      v->ax0 = ax.minimum, v->ax1 = ax.maximum, v->ay0 = ay.minimum, v->ay1 = ay.maximum, v->has_abs = 1;
    }

    unsigned long keys[KEY_MAX / (8 * sizeof(long)) + 1] = {0};
    if (!g_dev && ioctl(fd, EVIOCGBIT(EV_KEY, sizeof keys), keys) >= 0 &&
        (keys[KEY_A / (8 * sizeof(long))] & (1UL << (KEY_A % (8 * sizeof(long))))))
      ioctl(fd, EVIOCGRAB, 1);
  }
  closedir(d);
  return ndev;
}

void evdev_poll(void) {
  uint32_t now = now_ms();
  if (now - last_scan > 2000) {
    last_scan = now;
    evdev_open_all();
  }
  struct input_event ev[64];
  for (int i = 0; i < ndev; i++) {
    Dev *v = &devs[i];
    for (;;) {
      ssize_t n = read(v->fd, ev, sizeof ev);
      if (n <= 0) break;
      for (int k = 0; k < (int)(n / (ssize_t)sizeof *ev); k++) {
        struct input_event *e = &ev[k];
        if (e->type == EV_REL) {
          if (e->code == REL_X) input_pointer_rel(e->value, 0);
          else if (e->code == REL_Y) input_pointer_rel(0, e->value);
          else if (e->code == REL_WHEEL) input_wheel(e->value);
        } else if (e->type == EV_ABS && v->has_abs) {
          if (e->code == ABS_X) v->absx = e->value, v->abs_dirty = 1;
          if (e->code == ABS_Y) v->absy = e->value, v->abs_dirty = 1;
        } else if (e->type == EV_SYN && v->abs_dirty) {
          v->abs_dirty = 0;
          int x = (int)((long)(v->absx - v->ax0) * (W.out_w - 1) / (v->ax1 - v->ax0));
          int y = (int)((long)(v->absy - v->ay0) * (W.out_h - 1) / (v->ay1 - v->ay0));
          input_pointer_move(x, y);
        } else if (e->type == EV_KEY) {
          if (e->code == BTN_LEFT || e->code == BTN_TOUCH) input_button(1, e->value != 0);
          else if (e->code == BTN_RIGHT) input_button(3, e->value != 0);
          else if (e->code == BTN_MIDDLE) input_button(2, e->value != 0);
          else if (e->code < 256) input_key(e->code, e->value != 0, e->value == 2);
        }
      }
    }
  }
}
