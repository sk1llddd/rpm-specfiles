#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "store.h"

#define MAXIMG 140

static Img T[MAXIMG];
static int budget = 1, pending;

static uint32_t be32(const unsigned char *p) { return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3]; }

static int paeth(int a, int b, int c) {
  int p = a + b - c, pa = abs(p - a), pb = abs(p - b), pc = abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}

static uint32_t *png_decode(const unsigned char *d, size_t n, int *ow, int *oh) {
  if (n < 33 || memcmp(d, "\x89PNG\r\n\x1a\n", 8)) return NULL;
  uint32_t w = 0, h = 0;
  int depth = 0, ctype = 0, inter = 0, npal = 0, ntrns = 0;
  unsigned char pal[256][4];
  Buf idat = {0};
  buf_put(&idat, "", 0);
  for (size_t i = 8; i + 12 <= n;) {
    uint32_t len = be32(d + i);
    const unsigned char *t = d + i + 4, *body = d + i + 8;
    if (i + 12 + len > n) break;
    if (!memcmp(t, "IHDR", 4) && len >= 13) {
      w = be32(body), h = be32(body + 4), depth = body[8], ctype = body[9], inter = body[12];
    } else if (!memcmp(t, "PLTE", 4)) {
      npal = (int)(len / 3 > 256 ? 256 : len / 3);
      for (int k = 0; k < npal; k++) pal[k][0] = body[k * 3], pal[k][1] = body[k * 3 + 1], pal[k][2] = body[k * 3 + 2], pal[k][3] = 255;
    } else if (!memcmp(t, "tRNS", 4) && ctype == 3) {
      ntrns = (int)(len > 256 ? 256 : len);
      for (int k = 0; k < ntrns && k < npal; k++) pal[k][3] = body[k];
    } else if (!memcmp(t, "IDAT", 4)) buf_put(&idat, (const char *)body, len);
    else if (!memcmp(t, "IEND", 4)) break;
    i += 12 + len;
  }
  (void)ntrns;
  uint32_t *out = NULL;
  size_t rawn = 0;
  unsigned char *raw = NULL;
  int chans = ctype == 0 ? 1 : ctype == 2 ? 3 : ctype == 3 ? 1 : ctype == 4 ? 2 : ctype == 6 ? 4 : 0;
  if (!w || !h || w > 8192 || h > 8192 || (uint64_t)w * h > 24000000ull || !chans || inter || idat.n < 8 ||
      (depth != 8 && depth != 16 && !(ctype == 3 || ctype == 0) ) || (depth != 1 && depth != 2 && depth != 4 && depth != 8 && depth != 16)) goto done;
  raw = office_inflate((const unsigned char *)idat.s + 2, idat.n - 2, &rawn);
  if (!raw) goto done;
  size_t bpp_bits = (size_t)chans * (size_t)depth, stride = (bpp_bits * w + 7) / 8, bpp = (bpp_bits + 7) / 8;
  if (rawn < (stride + 1) * h) goto done;
  out = malloc((size_t)w * h * 4);
  unsigned char *prev = calloc(stride, 1), *cur = malloc(stride);
  for (uint32_t y = 0; y < h; y++) {
    const unsigned char *row = raw + (stride + 1) * y;
    int f = row[0];
    memcpy(cur, row + 1, stride);
    for (size_t x = 0; x < stride; x++) {
      int a = x >= bpp ? cur[x - bpp] : 0, b = prev[x], c = x >= bpp ? prev[x - bpp] : 0;
      switch (f) {
      case 1: cur[x] = (unsigned char)(cur[x] + a); break;
      case 2: cur[x] = (unsigned char)(cur[x] + b); break;
      case 3: cur[x] = (unsigned char)(cur[x] + ((a + b) >> 1)); break;
      case 4: cur[x] = (unsigned char)(cur[x] + paeth(a, b, c)); break;
      }
    }
    for (uint32_t x = 0; x < w; x++) {
      unsigned r, g, bl, a = 255;
      if (depth >= 8) {
        const unsigned char *px = cur + (size_t)x * bpp;
        int st = depth == 16 ? 2 : 1;
        if (ctype == 6) r = px[0], g = px[st], bl = px[2 * st], a = px[3 * st];
        else if (ctype == 2) r = px[0], g = px[st], bl = px[2 * st];
        else if (ctype == 4) r = g = bl = px[0], a = px[st];
        else if (ctype == 0) r = g = bl = px[0];
        else {
          int k = px[0] < npal ? px[0] : 0;
          r = pal[k][0], g = pal[k][1], bl = pal[k][2], a = pal[k][3];
        }
      } else {
        size_t bit = (size_t)x * (size_t)depth;
        unsigned v = (cur[bit >> 3] >> (8 - depth - (bit & 7))) & ((1u << depth) - 1);
        if (ctype == 3) {
          int k = (int)v < npal ? (int)v : 0;
          r = pal[k][0], g = pal[k][1], bl = pal[k][2], a = pal[k][3];
        } else r = g = bl = v * 255 / ((1u << depth) - 1);
      }
      out[(size_t)y * w + x] = (a << 24) | ((r * a / 255) << 16) | ((g * a / 255) << 8) | (bl * a / 255);
    }
    unsigned char *t = prev;
    prev = cur;
    cur = t;
  }
  free(prev);
  free(cur);
  *ow = (int)w, *oh = (int)h;
done:
  free(raw);
  free(idat.s);
  return out;
}

/* Decode a PNG or JPEG file in-process (no djpeg needed). Returns opaque-or-not ARGB pixels the caller frees. */
uint32_t *img_decode_file(const char *path, int *ow, int *oh) {
  struct stat st;
  if (stat(path, &st) || !S_ISREG(st.st_mode) || st.st_size < 8 || st.st_size > (48 << 20)) return NULL;
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  unsigned char *d = malloc((size_t)st.st_size);
  size_t n = d ? fread(d, 1, (size_t)st.st_size, f) : 0;
  fclose(f);
  uint32_t *px = NULL;
  if (n == (size_t)st.st_size) {
    if (d[0] == 0x89) px = png_decode(d, n, ow, oh);
    else if (d[0] == 0xFF) px = jpeg_decode(d, n, ow, oh);
  }
  free(d);
  return px;
}

static uint32_t *pnm_load(const char *path, int *ow, int *oh) {
  char cmd[900];
  snprintf(cmd, sizeof cmd, "djpeg -pnm '%s' 2>/dev/null", path);
  FILE *f = popen(cmd, "r");
  if (!f) return NULL;
  int w = 0, h = 0, mx = 0;
  if (fscanf(f, "P6 %d %d %d", &w, &h, &mx) != 3 || w < 1 || h < 1 || w > 8192 || h > 8192 || mx != 255) {
    pclose(f);
    return NULL;
  }
  fgetc(f);
  size_t cnt = (size_t)w * h;
  unsigned char *rgb = malloc(cnt * 3);
  uint32_t *out = NULL;
  if (fread(rgb, 3, cnt, f) == cnt) {
    out = malloc(cnt * 4);
    for (size_t i = 0; i < cnt; i++) out[i] = 0xff000000u | (uint32_t)rgb[i * 3] << 16 | (uint32_t)rgb[i * 3 + 1] << 8 | rgb[i * 3 + 2];
    *ow = w, *oh = h;
  }
  free(rgb);
  pclose(f);
  return out;
}

uint32_t *img_shrink(uint32_t *src, int w, int h, int nw, int nh) {
  uint32_t *out = malloc((size_t)nw * nh * 4);
  for (int y = 0; y < nh; y++) {
    int y0 = (int)((int64_t)y * h / nh), y1 = (int)((int64_t)(y + 1) * h / nh);
    if (y1 <= y0) y1 = y0 + 1;
    for (int x = 0; x < nw; x++) {
      int x0 = (int)((int64_t)x * w / nw), x1 = (int)((int64_t)(x + 1) * w / nw);
      if (x1 <= x0) x1 = x0 + 1;
      uint64_t a = 0, r = 0, g = 0, b = 0;
      for (int yy = y0; yy < y1; yy++)
        for (int xx = x0; xx < x1; xx++) {
          uint32_t p = src[(size_t)yy * w + xx];
          a += p >> 24, r += (p >> 16) & 255, g += (p >> 8) & 255, b += p & 255;
        }
      uint64_t c = (uint64_t)(y1 - y0) * (uint64_t)(x1 - x0);
      out[(size_t)y * nw + x] = (uint32_t)(a / c) << 24 | (uint32_t)(r / c) << 16 | (uint32_t)(g / c) << 8 | (uint32_t)(b / c);
    }
  }
  return out;
}

static void round_corners(uint32_t *px, int w, int h, int r) {
  if (r < 2) return;
  for (int y = 0; y < h; y++) {
    int dy = y < r ? r - y : y >= h - r ? y - (h - r) + 1 : 0;
    if (!dy) continue;
    for (int x = 0; x < w; x++) {
      int dx = x < r ? r - x : x >= w - r ? x - (w - r) + 1 : 0;
      if (!dx) continue;
      float d = sqrtf((float)(dx * dx + dy * dy)) - (float)r;
      if (d <= -1.f) continue;
      uint32_t p = px[(size_t)y * w + x];
      uint32_t k = d >= 0 ? 0 : (uint32_t)((-d) * 255);
      uint32_t a = (p >> 24) * k / 255, rb = (((p & 0xff00ff) * k) >> 8) & 0xff00ff, gg = (((p & 0xff00) * k) >> 8) & 0xff00;
      px[(size_t)y * w + x] = a << 24 | rb | gg;
    }
  }
}

static uint32_t accent_of(const uint32_t *px, int w, int h) {
  double sr = 0, sg = 0, sb = 0, sw = 0;
  for (int i = 0; i < w * h; i += 3) {
    uint32_t p = px[i], a = p >> 24;
    if (a < 200) continue;
    int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
    int mx = r > g ? (r > b ? r : b) : (g > b ? g : b), mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
    double wt = (double)(mx - mn) + 8;
    wt *= wt;
    sr += r * wt, sg += g * wt, sb += b * wt, sw += wt;
  }
  if (sw <= 0) return 0xff7a7f8a;
  return 0xff000000u | (uint32_t)(sr / sw) << 16 | (uint32_t)(sg / sw) << 8 | (uint32_t)(sb / sw);
}

void img_frame(void) {
  budget = 1;
  pending = 0;
}

int img_pending(void) { return pending; }

static void decode(Img *im, NetReq *r) {
  int w = 0, h = 0;
  uint32_t *px = NULL;
  const unsigned char *d = (const unsigned char *)r->out.s;
  if (r->out.n > 8 && d[0] == 0x89) px = png_decode(d, r->out.n, &w, &h);
  else if (r->out.n > 4 && d[0] == 0xff && d[1] == 0xd8) px = pnm_load(r->path, &w, &h);
  if (px && im->maxw > 0 && w > im->maxw) {
    int nh = (int)((int64_t)h * im->maxw / w);
    if (nh < 1) nh = 1;
    uint32_t *s = img_shrink(px, w, h, im->maxw, nh);
    free(px);
    px = s, w = im->maxw, h = nh;
  }
  if (!px) {
    im->state = IMG_FAILED;
    return;
  }
  if (im->round) round_corners(px, w, h, im->round);
  im->px = px, im->w = w, im->h = h;
  im->accent = accent_of(px, w, h);
  im->state = IMG_READY;
}

Img *img_get(const char *url, int maxw, int round) {
  uint32_t now = now_ms();
  Img *im = NULL, *free_slot = NULL, *lru = NULL;
  for (int i = 0; i < MAXIMG; i++) {
    if (T[i].used && !strcmp(T[i].url, url)) {
      im = &T[i];
      break;
    }
    if (!T[i].used && !free_slot) free_slot = &T[i];
    if (T[i].used && T[i].state != IMG_LOADING && (!lru || T[i].touched < lru->touched)) lru = &T[i];
  }
  if (!im) {
    im = free_slot ? free_slot : lru;
    if (!im) return NULL;
    free(im->px);
    memset(im, 0, sizeof *im);
    im->used = 1;
    snprintf(im->url, sizeof im->url, "%s", url);
    im->maxw = maxw, im->round = round;
  }
  im->touched = now;
  if (im->state == IMG_NONE || im->state == IMG_LOADING) {
    NetReq *r = net_http(url, NULL, 7 * 86400);
    if (!r) return im;
    im->state = IMG_LOADING;
    if (r->state == NET_FAIL) im->state = IMG_FAILED;
    else if (r->state == NET_OK) {
      if (budget > 0) {
        budget--;
        decode(im, r);
        net_drop(r);
      } else pending = 1;
    }
  }
  return im;
}
