#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

#include "office.h"

void buf_printf(Buf *b, const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  int need = vsnprintf(NULL, 0, fmt, ap);
  va_end(ap);
  if (need < 0) return;
  if (b->n + (size_t)need + 1 > b->cap) {
    while (b->n + (size_t)need + 1 > b->cap) b->cap = b->cap ? b->cap * 2 : 4096;
    b->s = realloc(b->s, b->cap);
  }
  va_start(ap, fmt);
  vsnprintf(b->s + b->n, (size_t)need + 1, fmt, ap);
  va_end(ap);
  b->n += (size_t)need;
}

void buf_put(Buf *b, const char *t, size_t n) {
  if (b->n + n + 1 > b->cap) {
    while (b->n + n + 1 > b->cap) b->cap = b->cap ? b->cap * 2 : 4096;
    b->s = realloc(b->s, b->cap);
  }
  memcpy(b->s + b->n, t, n);
  b->n += n;
  b->s[b->n] = 0;
}

void buf_esc(Buf *b, const char *t, int n) {
  if (n < 0) n = (int)strlen(t);
  for (int i = 0; i < n; i++) {
    char c = t[i];
    if (c == '&') buf_put(b, "&amp;", 5);
    else if (c == '<') buf_put(b, "&lt;", 4);
    else if (c == '>') buf_put(b, "&gt;", 4);
    else if (c == '"') buf_put(b, "&quot;", 6);
    else if ((unsigned char)c >= 32 || c == '\t') buf_put(b, &c, 1);
  }
}

static uint32_t crc_tab[256];

static uint32_t crc32_of(const unsigned char *p, size_t n) {
  if (!crc_tab[1])
    for (uint32_t i = 0; i < 256; i++) {
      uint32_t c = i;
      for (int k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
      crc_tab[i] = c;
    }
  uint32_t c = 0xFFFFFFFFu;
  for (size_t i = 0; i < n; i++) c = crc_tab[(c ^ p[i]) & 255] ^ (c >> 8);
  return c ^ 0xFFFFFFFFu;
}

typedef struct {
  char name[128];
  uint32_t crc, size, off;
} ZEnt;

struct ZipW {
  FILE *f;
  ZEnt e[64];
  int n;
  uint32_t off;
  uint16_t dtime, ddate;
  int err;
};

static void put16(FILE *f, unsigned v) { fputc(v & 255, f), fputc((v >> 8) & 255, f); }
static void put32(FILE *f, uint32_t v) { put16(f, v & 0xffff), put16(f, v >> 16); }

ZipW *zw_open(const char *path) {
  FILE *f = fopen(path, "wb");
  if (!f) return NULL;
  ZipW *z = calloc(1, sizeof *z);
  z->f = f;
  time_t t = time(NULL);
  struct tm tm;
  localtime_r(&t, &tm);
  z->dtime = (uint16_t)(tm.tm_hour << 11 | tm.tm_min << 5 | tm.tm_sec / 2);
  z->ddate = (uint16_t)((tm.tm_year - 80) << 9 | (tm.tm_mon + 1) << 5 | tm.tm_mday);
  return z;
}

void zw_add(ZipW *z, const char *name, const char *data, size_t len) {
  if (!z || z->n >= 64) return;
  ZEnt *e = &z->e[z->n++];
  snprintf(e->name, sizeof e->name, "%s", name);
  e->crc = crc32_of((const unsigned char *)data, len);
  e->size = (uint32_t)len;
  e->off = z->off;
  size_t nl = strlen(e->name);
  put32(z->f, 0x04034b50);
  put16(z->f, 20), put16(z->f, 0), put16(z->f, 0);
  put16(z->f, z->dtime), put16(z->f, z->ddate);
  put32(z->f, e->crc), put32(z->f, e->size), put32(z->f, e->size);
  put16(z->f, (unsigned)nl), put16(z->f, 0);
  fwrite(e->name, 1, nl, z->f);
  if (len && fwrite(data, 1, len, z->f) != len) z->err = 1;
  z->off += 30 + (uint32_t)nl + (uint32_t)len;
}

void zw_adds(ZipW *z, const char *name, const char *s) { zw_add(z, name, s, strlen(s)); }

int zw_close(ZipW *z) {
  if (!z) return -1;
  uint32_t cd = z->off, cdl = 0;
  for (int i = 0; i < z->n; i++) {
    ZEnt *e = &z->e[i];
    size_t nl = strlen(e->name);
    put32(z->f, 0x02014b50);
    put16(z->f, 20), put16(z->f, 20), put16(z->f, 0), put16(z->f, 0);
    put16(z->f, z->dtime), put16(z->f, z->ddate);
    put32(z->f, e->crc), put32(z->f, e->size), put32(z->f, e->size);
    put16(z->f, (unsigned)nl), put16(z->f, 0), put16(z->f, 0), put16(z->f, 0), put16(z->f, 0);
    put32(z->f, 0), put32(z->f, e->off);
    fwrite(e->name, 1, nl, z->f);
    cdl += 46 + (uint32_t)nl;
  }
  put32(z->f, 0x06054b50);
  put16(z->f, 0), put16(z->f, 0), put16(z->f, (unsigned)z->n), put16(z->f, (unsigned)z->n);
  put32(z->f, cdl), put32(z->f, cd), put16(z->f, 0);
  int err = z->err || ferror(z->f);
  if (fclose(z->f)) err = 1;
  free(z);
  return err ? -1 : 0;
}

typedef struct {
  const unsigned char *in;
  size_t n, pos;
  uint32_t bits;
  int nb;
  unsigned char *out;
  size_t on, ocap;
  int err;
} Inf;

typedef struct {
  uint16_t count[16], sym[320];
} Huff;

static int getbit(Inf *s) {
  if (!s->nb) {
    if (s->pos >= s->n) {
      s->err = 1;
      return 0;
    }
    s->bits = s->in[s->pos++];
    s->nb = 8;
  }
  int b = s->bits & 1;
  s->bits >>= 1, s->nb--;
  return b;
}

static unsigned getbits(Inf *s, int n) {
  unsigned v = 0;
  for (int i = 0; i < n; i++) v |= (unsigned)getbit(s) << i;
  return v;
}

static void outb(Inf *s, unsigned char c) {
  if (s->on == s->ocap) {
    s->ocap = s->ocap ? s->ocap * 2 : 65536;
    s->out = realloc(s->out, s->ocap);
  }
  s->out[s->on++] = c;
}

static void huff_build(Huff *h, const unsigned char *len, int n) {
  uint16_t offs[16];
  memset(h->count, 0, sizeof h->count);
  for (int i = 0; i < n; i++) h->count[len[i]]++;
  h->count[0] = 0;
  offs[1] = 0;
  for (int i = 1; i < 15; i++) offs[i + 1] = (uint16_t)(offs[i] + h->count[i]);
  for (int i = 0; i < n; i++)
    if (len[i]) h->sym[offs[len[i]]++] = (uint16_t)i;
}

static int huff_dec(Inf *s, const Huff *h) {
  int code = 0, first = 0, index = 0;
  for (int len = 1; len < 16; len++) {
    code |= getbit(s);
    int count = h->count[len];
    if (code - count < first) return h->sym[index + (code - first)];
    index += count;
    first += count;
    first <<= 1;
    code <<= 1;
    if (s->err) return -1;
  }
  s->err = 1;
  return -1;
}

static const uint16_t LBASE[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
static const uint8_t LEXT[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
static const uint16_t DBASE[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
static const uint8_t DEXT[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

static void inf_block(Inf *s, const Huff *lh, const Huff *dh) {
  for (;;) {
    int sym = huff_dec(s, lh);
    if (s->err || sym < 0) return;
    if (sym < 256) outb(s, (unsigned char)sym);
    else if (sym == 256) return;
    else {
      sym -= 257;
      if (sym >= 29) {
        s->err = 1;
        return;
      }
      int len = LBASE[sym] + (int)getbits(s, LEXT[sym]);
      int ds = huff_dec(s, dh);
      if (ds < 0 || ds >= 30) {
        s->err = 1;
        return;
      }
      size_t dist = DBASE[ds] + getbits(s, DEXT[ds]);
      if (dist > s->on) {
        s->err = 1;
        return;
      }
      for (int i = 0; i < len; i++) outb(s, s->out[s->on - dist]);
    }
  }
}

static unsigned char *inflate_raw(const unsigned char *in, size_t n, size_t *outn) {
  Inf s = {in, n, 0, 0, 0, NULL, 0, 0, 0};
  int last;
  do {
    last = getbit(&s);
    int type = (int)getbits(&s, 2);
    if (type == 0) {
      s.nb = 0;
      if (s.pos + 4 > s.n) break;
      unsigned len = s.in[s.pos] | s.in[s.pos + 1] << 8;
      s.pos += 4;
      if (s.pos + len > s.n) break;
      for (unsigned i = 0; i < len; i++) outb(&s, s.in[s.pos + i]);
      s.pos += len;
    } else if (type == 1) {
      static Huff fl, fd;
      static int built;
      if (!built) {
        unsigned char l[288];
        for (int i = 0; i < 288; i++) l[i] = i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8;
        huff_build(&fl, l, 288);
        for (int i = 0; i < 30; i++) l[i] = 5;
        huff_build(&fd, l, 30);
        built = 1;
      }
      inf_block(&s, &fl, &fd);
    } else if (type == 2) {
      static const uint8_t ORD[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
      int hlit = (int)getbits(&s, 5) + 257, hdist = (int)getbits(&s, 5) + 1, hclen = (int)getbits(&s, 4) + 4;
      unsigned char lens[320] = {0};
      for (int i = 0; i < hclen; i++) lens[ORD[i]] = (unsigned char)getbits(&s, 3);
      Huff ch, lh, dh;
      huff_build(&ch, lens, 19);
      memset(lens, 0, sizeof lens);
      int i = 0;
      while (i < hlit + hdist && !s.err) {
        int sym = huff_dec(&s, &ch);
        if (sym < 0) break;
        if (sym < 16) lens[i++] = (unsigned char)sym;
        else {
          int rep, val = 0;
          if (sym == 16) {
            if (!i) {
              s.err = 1;
              break;
            }
            val = lens[i - 1], rep = 3 + (int)getbits(&s, 2);
          } else if (sym == 17) rep = 3 + (int)getbits(&s, 3);
          else rep = 11 + (int)getbits(&s, 7);
          while (rep-- && i < hlit + hdist) lens[i++] = (unsigned char)val;
        }
      }
      huff_build(&lh, lens, hlit);
      huff_build(&dh, lens + hlit, hdist);
      inf_block(&s, &lh, &dh);
    } else s.err = 1;
  } while (!last && !s.err);
  if (s.err && !s.on) {
    free(s.out);
    return NULL;
  }
  outb(&s, 0);
  *outn = s.on - 1;
  return s.out;
}

typedef struct {
  char name[256];
  uint32_t method, csize, usize, off;
} ZEntry;

struct Zip {
  unsigned char *d;
  size_t n;
  ZEntry *e;
  int ne;
};

static uint32_t rd16(const unsigned char *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8; }
static uint32_t rd32(const unsigned char *p) { return rd16(p) | rd16(p + 2) << 16; }

Zip *zip_open(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  fseek(f, 0, SEEK_END);
  long sz = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (sz < 22 || sz > 200L * 1024 * 1024) {
    fclose(f);
    return NULL;
  }
  unsigned char *d = malloc((size_t)sz);
  if (fread(d, 1, (size_t)sz, f) != (size_t)sz) {
    fclose(f);
    free(d);
    return NULL;
  }
  fclose(f);
  long eo = -1;
  for (long i = sz - 22; i >= 0 && i >= sz - 65557; i--)
    if (rd32(d + i) == 0x06054b50) {
      eo = i;
      break;
    }
  if (eo < 0) {
    free(d);
    return NULL;
  }
  Zip *z = calloc(1, sizeof *z);
  z->d = d, z->n = (size_t)sz;
  int cnt = (int)rd16(d + eo + 10);
  uint32_t cd = rd32(d + eo + 16);
  z->e = calloc((size_t)(cnt ? cnt : 1), sizeof(ZEntry));
  size_t p = cd;
  for (int i = 0; i < cnt; i++) {
    if (p + 46 > z->n || rd32(d + p) != 0x02014b50) break;
    ZEntry *e = &z->e[z->ne];
    e->method = rd16(d + p + 10);
    e->csize = rd32(d + p + 20);
    e->usize = rd32(d + p + 24);
    uint32_t nl = rd16(d + p + 28), xl = rd16(d + p + 30), cl = rd16(d + p + 32);
    e->off = rd32(d + p + 42);
    if (p + 46 + nl > z->n) break;
    snprintf(e->name, sizeof e->name, "%.*s", (int)(nl < 255 ? nl : 255), (const char *)d + p + 46);
    z->ne++;
    p += 46 + nl + xl + cl;
  }
  return z;
}

char *zip_read(Zip *z, const char *name, size_t *len) {
  if (!z) return NULL;
  while (*name == '/') name++;
  for (int i = 0; i < z->ne; i++) {
    ZEntry *e = &z->e[i];
    if (strcasecmp(e->name, name)) continue;
    if ((size_t)e->off + 30 > z->n) return NULL;
    const unsigned char *h = z->d + e->off;
    size_t start = e->off + 30 + rd16(h + 26) + rd16(h + 28);
    if (start + e->csize > z->n) return NULL;
    size_t n = 0;
    char *out = NULL;
    if (e->method == 0) {
      out = malloc((size_t)e->csize + 1);
      memcpy(out, z->d + start, e->csize);
      out[e->csize] = 0;
      n = e->csize;
    } else if (e->method == 8) {
      out = (char *)inflate_raw(z->d + start, e->csize, &n);
    }
    if (len) *len = n;
    return out;
  }
  return NULL;
}

void zip_close(Zip *z) {
  if (!z) return;
  free(z->d);
  free(z->e);
  free(z);
}

static int ascii_of(unsigned cp, char *o) {
  if (cp < 128) {
    if (cp == '\t') return o[0] = ' ', 1;
    if (cp < 32) return 0;
    o[0] = (char)cp;
    return 1;
  }
  const char *r = NULL;
  switch (cp) {
  case 0xA0: case 0x2002: case 0x2003: case 0x2009: case 0x202F: r = " "; break;
  case 0x2018: case 0x2019: case 0x201A: case 0x2032: r = "'"; break;
  case 0x201C: case 0x201D: case 0x201E: case 0x2033: case 0xAB: case 0xBB: r = "\""; break;
  case 0x2010: case 0x2011: case 0x2012: case 0x2013: case 0x2014: case 0x2015: case 0x2212: r = "-"; break;
  case 0x2026: r = "..."; break;
  case 0x2022: case 0x25CF: case 0x25E6: case 0x2023: case 0x2043: case 0xB7: r = "*"; break;
  case 0xD7: r = "x"; break;
  case 0xF7: r = "/"; break;
  case 0xA9: r = "(c)"; break;
  case 0xAE: r = "(R)"; break;
  case 0x2122: r = "(TM)"; break;
  case 0xB0: r = " deg"; break;
  case 0x20AC: r = "EUR"; break;
  case 0xA3: r = "GBP"; break;
  case 0xA5: r = "JPY"; break;
  case 0x2192: r = "->"; break;
  case 0x2190: r = "<-"; break;
  case 0x2264: r = "<="; break;
  case 0x2265: r = ">="; break;
  case 0x2260: r = "!="; break;
  case 0xBD: r = "1/2"; break;
  case 0xBC: r = "1/4"; break;
  case 0xBE: r = "3/4"; break;
  case 0x2713: case 0x2714: case 0x2611: case 0x2612: r = "[x]"; break;
  case 0x2610: r = "[ ]"; break;
  case 0xFEFF: case 0x200B: case 0x200C: case 0x200D: return 0;
  }
  if (r) {
    int n = (int)strlen(r);
    memcpy(o, r, (size_t)n);
    return n;
  }
  static const char *lat = "AAAAAAACEEEEIIIIDNOOOOO*OUUUUYPsaaaaaaaceeeeiiiidnooooo/ouuuuypy";
  if (cp >= 0xC0 && cp <= 0xFF) return o[0] = lat[cp - 0xC0], 1;
  o[0] = '?';
  return 1;
}

int office_ascii(const char *s, int n, char *out, int cap) {
  int k = 0;
  for (int i = 0; i < n && k < cap - 4;) {
    unsigned char c = (unsigned char)s[i];
    unsigned cp;
    int l = 1;
    if (c < 0x80) cp = c;
    else if ((c & 0xE0) == 0xC0 && i + 1 < n) cp = (c & 0x1Fu) << 6 | (s[i + 1] & 0x3F), l = 2;
    else if ((c & 0xF0) == 0xE0 && i + 2 < n) cp = (c & 0x0Fu) << 12 | (s[i + 1] & 0x3Fu) << 6 | (s[i + 2] & 0x3F), l = 3;
    else if ((c & 0xF8) == 0xF0 && i + 3 < n) cp = 0x2B1C, l = 4;
    else cp = '?';
    i += l;
    k += ascii_of(cp, out + k);
  }
  out[k] = 0;
  return k;
}

static int xml_decode(const char *s, int n, char *out, int cap) {
  int k = 0;
  for (int i = 0; i < n && k < cap - 4;) {
    if (s[i] == '&') {
      const char *semi = memchr(s + i, ';', (size_t)(n - i < 12 ? n - i : 12));
      if (semi) {
        int el = (int)(semi - (s + i));
        unsigned cp = 0;
        int ok = 1;
        if (!strncmp(s + i, "&amp;", 5)) cp = '&';
        else if (!strncmp(s + i, "&lt;", 4)) cp = '<';
        else if (!strncmp(s + i, "&gt;", 4)) cp = '>';
        else if (!strncmp(s + i, "&quot;", 6)) cp = '"';
        else if (!strncmp(s + i, "&apos;", 6)) cp = '\'';
        else if (s[i + 1] == '#') cp = (unsigned)(s[i + 2] == 'x' || s[i + 2] == 'X' ? strtoul(s + i + 3, NULL, 16) : strtoul(s + i + 2, NULL, 10));
        else ok = 0;
        if (ok) {
          k += ascii_of(cp, out + k);
          i += el + 1;
          continue;
        }
      }
    }
    int j = i;
    while (j < n && s[j] != '&') j++;
    k += office_ascii(s + i, j - i, out + k, cap - k);
    i = j;
  }
  out[k] = 0;
  return k;
}

void xml_init(Xml *x, const char *s, size_t n) {
  memset(x, 0, sizeof *x);
  x->p = s, x->end = s + n;
}

int xml_next(Xml *x) {
  for (;;) {
    if (x->p >= x->end) return x->type = X_EOF;
    if (*x->p != '<') {
      const char *q = x->p;
      while (q < x->end && *q != '<') q++;
      x->text = x->p, x->tlen = (int)(q - x->p);
      x->p = q;
      return x->type = X_TEXT;
    }
    if (x->p + 4 <= x->end && !strncmp(x->p, "<!--", 4)) {
      const char *q = strstr(x->p, "-->");
      x->p = q ? q + 3 : x->end;
      continue;
    }
    if (x->p + 9 <= x->end && !strncmp(x->p, "<![CDATA[", 9)) {
      const char *q = strstr(x->p, "]]>");
      x->text = x->p + 9, x->tlen = (int)((q ? q : x->end) - x->text);
      x->p = q ? q + 3 : x->end;
      return x->type = X_TEXT;
    }
    if (x->p[1] == '?' || x->p[1] == '!') {
      const char *q = memchr(x->p, '>', (size_t)(x->end - x->p));
      x->p = q ? q + 1 : x->end;
      continue;
    }
    int close = x->p[1] == '/';
    const char *q = x->p + 1 + close, *ns = q;
    while (q < x->end && *q != '>' && *q != '/' && *q != ' ' && *q != '\t' && *q != '\n' && *q != '\r') q++;
    x->name = ns, x->nlen = (int)(q - ns);
    const char *colon = memchr(ns, ':', (size_t)x->nlen);
    if (colon) x->lname = colon + 1, x->llen = (int)(q - (colon + 1));
    else x->lname = ns, x->llen = x->nlen;
    const char *a = q;
    char quote = 0;
    while (q < x->end && (quote || *q != '>')) {
      if (quote && *q == quote) quote = 0;
      else if (!quote && (*q == '"' || *q == '\'')) quote = *q;
      q++;
    }
    x->attrs = a, x->alen = (int)(q - a);
    x->empty = !close && q > a && q[-1] == '/';
    x->p = q < x->end ? q + 1 : x->end;
    return x->type = close ? X_CLOSE : X_OPEN;
  }
}

int xml_is(const Xml *x, const char *lname) { return (int)strlen(lname) == x->llen && !strncmp(x->lname, lname, (size_t)x->llen); }

int xml_attr(const Xml *x, const char *name, char *out, int cap) {
  const char *a = x->attrs, *e = x->attrs + x->alen;
  int nl = (int)strlen(name);
  while (a < e) {
    while (a < e && (*a == ' ' || *a == '\t' || *a == '\n' || *a == '\r' || *a == '/')) a++;
    const char *ks = a;
    while (a < e && *a != '=' && *a != ' ') a++;
    const char *ke = a;
    while (a < e && *a != '"' && *a != '\'') a++;
    if (a >= e) break;
    char q = *a++;
    const char *vs = a;
    while (a < e && *a != q) a++;
    const char *ve = a;
    if (a < e) a++;
    const char *kc = memchr(ks, ':', (size_t)(ke - ks));
    const char *kl = kc ? kc + 1 : ks;
    if ((ke - kl == nl && !strncmp(kl, name, (size_t)nl)) || (ke - ks == nl && !strncmp(ks, name, (size_t)nl))) {
      xml_decode(vs, (int)(ve - vs), out, cap);
      return 1;
    }
  }
  if (cap) out[0] = 0;
  return 0;
}

int xml_text(const Xml *x, char *out, int cap) { return xml_decode(x->text, x->tlen, out, cap); }

void xml_skip(Xml *x) {
  if (x->type != X_OPEN || x->empty) return;
  int depth = 1;
  while (depth > 0) {
    int t = xml_next(x);
    if (t == X_EOF) return;
    if (t == X_OPEN && !x->empty) depth++;
    else if (t == X_CLOSE) depth--;
  }
}

int office_export_path(const char *title, const char *ext, char *path, int n, char *shown, int sn) {
  char dir[512], name[96];
  snprintf(dir, sizeof dir, "%s/Documents", user_home());
  office_mkdirs(dir);
  int k = 0;
  for (const char *t = title; *t && k < 80; t++)
    name[k++] = (*t >= 'a' && *t <= 'z') || (*t >= 'A' && *t <= 'Z') || (*t >= '0' && *t <= '9') || *t == '-' || *t == '_' || *t == ' ' ? *t : '_';
  name[k] = 0;
  if (!k) snprintf(name, sizeof name, "Untitled");
  char fn[128];
  snprintf(fn, sizeof fn, "%s.%s", name, ext);
  for (int i = 2; i < 100; i++) {
    snprintf(path, (size_t)n, "%s/%s", dir, fn);
    if (access(path, F_OK)) break;
    snprintf(fn, sizeof fn, "%s (%d).%s", name, i, ext);
  }
  snprintf(shown, (size_t)sn, "Saved to Documents/%s", fn);
  return 1;
}

void office_title_from_path(const char *path, char *out, int n) {
  const char *b = strrchr(path, '/');
  b = b ? b + 1 : path;
  const char *dot = strrchr(b, '.');
  int l = dot && dot > b ? (int)(dot - b) : (int)strlen(b);
  office_ascii(b, l, out, n);
}

unsigned char *office_inflate(const unsigned char *in, size_t n, size_t *outn) { return inflate_raw(in, n, outn); }
