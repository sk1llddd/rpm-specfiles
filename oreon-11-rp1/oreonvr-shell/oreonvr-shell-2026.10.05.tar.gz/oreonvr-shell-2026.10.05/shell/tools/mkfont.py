#!/usr/bin/env python3
import os
import sys

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "..", "res", "fonts")
ASCII = "".join(chr(c) for c in range(32, 127))

SPECS = [
    ("FONT_UI", "inter-400.woff", 26, ASCII),
    ("FONT_UI_MED", "inter-500.woff", 26, ASCII),
    ("FONT_BODY", "inter-400.woff", 30, ASCII),
    ("FONT_SMALL", "inter-400.woff", 22, ASCII),
    ("FONT_H1", "inter-500.woff", 44, ASCII),
    ("FONT_CLOCK", "inter-400.woff", 120, "0123456789: "),
    ("FONT_MONO", "DejaVuSansMono.ttf", 26, ASCII),
]

def bake(name, path, px, chars, out):
    font = ImageFont.truetype(os.path.join(FONTS, path), px)
    ascent, descent = font.getmetrics()
    glyphs = []
    data = bytearray()
    for code in range(32, 127):
        ch = chr(code)
        if ch not in chars:
            glyphs.append((0, 0, 0, 0, 0, 0))
            continue
        adv = font.getlength(ch)
        box = font.getbbox(ch)
        w, h = max(0, box[2] - box[0]), max(0, box[3] - box[1])
        off = len(data)
        if w and h:
            img = Image.new("L", (w, h), 0)
            ImageDraw.Draw(img).text((-box[0], -box[1]), ch, font=font, fill=255)
            data += img.tobytes()

        glyphs.append((int(round(adv * 16)), w, h, box[0], box[1] - ascent, off))
    out.append(f"static const unsigned char {name}_BITS[] = {{")
    for i in range(0, len(data), 40):
        out.append("  " + ",".join(str(b) for b in data[i : i + 40]) + ",")
    if not data:
        out.append("  0,")
    out.append("};")
    out.append(f"static const Glyph {name}_GLYPHS[95] = {{")
    for g in glyphs:
        out.append("  {%d,%d,%d,%d,%d,%d}," % g)
    out.append("};")
    out.append(
        f"static const Font {name}_DATA = {{{ascent}, {descent}, {name}_GLYPHS, {name}_BITS}};"
    )

def main():
    out = [
        "#ifndef OREONVR_FONT_DATA_H",
        "#define OREONVR_FONT_DATA_H",
        "",
    ]
    for spec in SPECS:
        bake(*spec, out)
        out.append("")
    out.append("#endif")
    sys.stdout.write("\n".join(out) + "\n")

if __name__ == "__main__":
    main()
