#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gio/gio.h>
#include <gio/gdesktopappinfo.h>
#include <glib-unix.h>
#include <pipewire/pipewire.h>
#include <spa/debug/types.h>
#include <spa/param/buffers.h>
#include <spa/param/video/format-utils.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <wayland-client.h>

#include "bridge.h"
#include "fake-input-client-protocol.h"
#include "plasma-window-management-client-protocol.h"
#include "zkde-screencast-unstable-v1-client-protocol.h"

#define KDE_UNIT "oreonvr-kde.service"
#define KDE_SOCKET "oreonvr-kde"

typedef struct {
  int used;
  guint64 win;
  struct zkde_screencast_stream_unstable_v1 *cast;
  struct pw_stream *stream;
  struct spa_hook listener;
  struct spa_video_info_raw fmt;
  BridgeHeader *hdr;
  int copy;
} Slot;

typedef struct Win {
  struct org_kde_plasma_window *pw;
  guint64 id, parent;
  char uuid[64];
  char *title, *app_id;
  int x, y, w, h;
  int mapped, announced;
  int vr; /* -1 undecided, 0 stays inside the desktop, 1 floats as its own VR panel */
  struct Win *next;
} Win;

static GDBusConnection *bus;
static GMainLoop *loop;
static void *pool;
static Slot slots[BRIDGE_SLOTS];
static Win *wins;
static GHashTable *vr_apps; /* desktop ids launched from the VR shell: their windows become VR panels */
static gint64 last_launch;

static struct pw_thread_loop *pwl;
static struct pw_core *core;

static struct wl_display *dpy;
static struct wl_registry *reg;
static struct org_kde_plasma_window_management *wm;
static struct zkde_screencast_unstable_v1 *sc;
static struct org_kde_kwin_fake_input *fake;
static struct wl_output *output;
static int kde_ready;
static char *wl_name;

static void out(const char *fmt, ...) G_GNUC_PRINTF(1, 2);
static void out(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vprintf(fmt, ap);
  va_end(ap);
  putchar('\n');
  fflush(stdout);
}

static GPtrArray *icon_themes(void) {
  static GPtrArray *list;
  if (list) return list;
  list = g_ptr_array_new();
  char *bases[] = {g_build_filename(g_get_user_data_dir(), "icons", NULL), g_strdup("/usr/local/share/icons"),
                   g_strdup("/usr/share/icons"), NULL};
  static const char *first[] = {"hicolor", "Adwaita", "breeze", NULL};
  for (int b = 0; bases[b]; b++) {
    for (int f = 0; first[f]; f++) {
      char *p = g_build_filename(bases[b], first[f], NULL);
      if (g_file_test(p, G_FILE_TEST_IS_DIR)) g_ptr_array_add(list, p);
      else g_free(p);
    }
    GDir *d = g_dir_open(bases[b], 0, NULL);
    const char *n;
    while (d && (n = g_dir_read_name(d))) {
      int skip = 0;
      for (int f = 0; first[f]; f++) skip |= !strcmp(n, first[f]);
      char *p = g_build_filename(bases[b], n, NULL);
      if (!skip && g_file_test(p, G_FILE_TEST_IS_DIR)) g_ptr_array_add(list, p);
      else g_free(p);
    }
    if (d) g_dir_close(d);
  }
  for (int b = 0; bases[b]; b++) g_free(bases[b]);
  return list;
}

static char *find_icon_file(const char *name) {
  static const char *sizes[] = {"scalable", "512", "256", "128", "96", "64", "48", "32", NULL};
  static const char *exts[] = {"svg", "png", NULL};
  GPtrArray *themes = icon_themes();
  for (int x = 0; exts[x]; x++)
    for (int s = 0; sizes[s]; s++)
      for (guint t = 0; t < themes->len; t++) {
        const char *th = g_ptr_array_index(themes, t);
        char *cand[2] = {NULL, NULL};
        if (!strcmp(sizes[s], "scalable")) {
          cand[0] = g_strdup_printf("%s/scalable/apps/%s.%s", th, name, exts[x]);
          cand[1] = g_strdup_printf("%s/apps/scalable/%s.%s", th, name, exts[x]);
        } else {
          cand[0] = g_strdup_printf("%s/%sx%s/apps/%s.%s", th, sizes[s], sizes[s], name, exts[x]);
          cand[1] = g_strdup_printf("%s/apps/%s/%s.%s", th, sizes[s], name, exts[x]);
        }
        for (int c = 0; c < 2; c++) {
          if (g_file_test(cand[c], G_FILE_TEST_EXISTS)) {
            char *r = cand[c];
            g_free(cand[1 - c]);
            return r;
          }
        }
        g_free(cand[0]);
        g_free(cand[1]);
      }
  static const char *pix[] = {"png", "svg", "xpm", NULL};
  for (int x = 0; pix[x]; x++) {
    char *p = g_strdup_printf("/usr/share/pixmaps/%s.%s", name, pix[x]);
    if (g_file_test(p, G_FILE_TEST_EXISTS)) return p;
    g_free(p);
  }
  return NULL;
}

static char *find_icon(GIcon *icon) {
  if (!icon) return NULL;
  if (G_IS_FILE_ICON(icon)) return g_file_get_path(g_file_icon_get_file(G_FILE_ICON(icon)));
  if (!G_IS_THEMED_ICON(icon)) return NULL;
  const char *const *names = g_themed_icon_get_names(G_THEMED_ICON(icon));
  for (int n = 0; names && names[n]; n++) {
    char *p = find_icon_file(names[n]);
    if (p) return p;
  }
  return NULL;
}

static char *render_icon(const char *id, GIcon *icon) {
  char *src = find_icon(icon);
  if (!src) return NULL;
  GdkPixbuf *pb = gdk_pixbuf_new_from_file_at_scale(src, 96, 96, TRUE, NULL);
  g_free(src);
  if (!pb) return NULL;
  GdkPixbuf *rgba = gdk_pixbuf_add_alpha(pb, FALSE, 0, 0, 0);
  g_object_unref(pb);
  char *dir = g_build_filename(g_get_user_runtime_dir(), "oreonvr-icons", NULL);
  g_mkdir_with_parents(dir, 0755);
  char *path = g_strdup_printf("%s/%s.rgba", dir, id);
  g_free(dir);
  FILE *f = fopen(path, "wb");
  if (f) {
    uint32_t wh[2] = {(uint32_t)gdk_pixbuf_get_width(rgba), (uint32_t)gdk_pixbuf_get_height(rgba)};
    fwrite(wh, 4, 2, f);
    const guchar *px = gdk_pixbuf_read_pixels(rgba);
    int rs = gdk_pixbuf_get_rowstride(rgba);
    for (uint32_t y = 0; y < wh[1]; y++) fwrite(px + (size_t)y * rs, 4, wh[0], f);
    fclose(f);
  }
  g_object_unref(rgba);
  return path;
}

static int app_listed(GAppInfo *a) {
  const char *id = g_app_info_get_id(a);
  static const char *const hidden[] = {"org.kde.plasma", "org.kde.plasmashell", "org.kde.kdeconnect", "org.kde.klipper",
                                       "org.kde.kwalletmanager", "org.kde.kinfocenter", "org.kde.drkonqi", "org.kde.kuserfeedback",
                                       "org.freedesktop.", "liveinst", "plasma-", "kcm_", "nm-", "bluetooth-sendto",
                                       "org.kde.ksystemstats", "org.kde.kscreen", "org.kde.kded", "org.kde.polkit", NULL};
  for (int i = 0; hidden[i]; i++)
    if (g_str_has_prefix(id, hidden[i])) return 0;
  if (G_IS_DESKTOP_APP_INFO(a) && g_desktop_app_info_get_boolean(G_DESKTOP_APP_INFO(a), "Terminal")) return 0;
  return 1;
}

static void list_apps(void) {
  GList *all = g_app_info_get_all();
  for (GList *l = all; l; l = l->next) {
    GAppInfo *a = l->data;
    if (!g_app_info_should_show(a)) continue;
    const char *id = g_app_info_get_id(a);
    if (!id) continue;
    if (!app_listed(a)) continue;
    const char *file = G_IS_DESKTOP_APP_INFO(a) ? g_desktop_app_info_get_filename(G_DESKTOP_APP_INFO(a)) : NULL;
    if (!file) continue;
    char *icon = render_icon(id, g_app_info_get_icon(a));
    char *name = g_strdelimit(g_strdup(g_app_info_get_name(a)), "\t\n", ' ');
    out("app\t%s\t%s\t%s\t%s", id, name, icon ? icon : "", file);
    g_free(name);
    g_free(icon);
  }
  g_list_free_full(all, g_object_unref);
  out("apps-done");
}

static void on_param_changed(void *data, uint32_t id, const struct spa_pod *param) {
  Slot *s = data;
  if (!param || id != SPA_PARAM_Format) return;
  if (spa_format_video_raw_parse(param, &s->fmt) < 0) return;
  uint8_t buf[1024];
  struct spa_pod_builder b = SPA_POD_BUILDER_INIT(buf, sizeof buf);

  const struct spa_pod *p =
      spa_pod_builder_add_object(&b, SPA_TYPE_OBJECT_ParamBuffers, SPA_PARAM_Buffers, SPA_PARAM_BUFFERS_dataType,
                                 SPA_POD_Int((1 << SPA_DATA_MemFd) | (1 << SPA_DATA_MemPtr)));
  pw_stream_update_params(s->stream, &p, 1);
}

static void on_process(void *data) {
  Slot *s = data;
  struct pw_buffer *b = pw_stream_dequeue_buffer(s->stream);
  if (!b) return;
  struct spa_data *d = &b->buffer->datas[0];
  uint32_t w = s->fmt.size.width, h = s->fmt.size.height;
  if (s->copy && d->data && d->chunk && d->chunk->size && w && h && !(d->chunk->flags & SPA_CHUNK_FLAG_CORRUPTED)) {
    if (w > BRIDGE_MAX_W) w = BRIDGE_MAX_W;
    if (h > BRIDGE_MAX_H) h = BRIDGE_MAX_H;
    int stride = d->chunk->stride ? d->chunk->stride : (int)s->fmt.size.width * 4;
    const uint8_t *src = (const uint8_t *)d->data + d->chunk->offset;
    uint32_t *dst = (uint32_t *)(s->hdr + 1);
    int swap = s->fmt.format == SPA_VIDEO_FORMAT_RGBx || s->fmt.format == SPA_VIDEO_FORMAT_RGBA;
    for (uint32_t y = 0; y < h; y++) {
      const uint32_t *row = (const uint32_t *)(src + (size_t)y * stride);
      uint32_t *o = dst + (size_t)y * w;
      if (!swap) memcpy(o, row, (size_t)w * 4);
      else
        for (uint32_t x = 0; x < w; x++) {
          uint32_t v = row[x];
          o[x] = (v & 0xff00ff00u) | ((v & 0xff) << 16) | ((v >> 16) & 0xff);
        }
    }
    s->hdr->w = w, s->hdr->h = h;

    s->hdr->pad[0] = s != &slots[0] && (s->fmt.format == SPA_VIDEO_FORMAT_BGRA || s->fmt.format == SPA_VIDEO_FORMAT_RGBA);
    atomic_fetch_add_explicit((_Atomic uint32_t *)&s->hdr->seq, 1, memory_order_release);
  }
  pw_stream_queue_buffer(s->stream, b);
}

static const struct pw_stream_events stream_events = {
    PW_VERSION_STREAM_EVENTS, .param_changed = on_param_changed, .process = on_process};

static void connect_stream(Slot *s, guint node) {
  pw_thread_loop_lock(pwl);
  if (!core) core = pw_context_connect(pw_context_new(pw_thread_loop_get_loop(pwl), NULL, 0), NULL, 0);
  if (!core) {
    pw_thread_loop_unlock(pwl);
    fprintf(stderr, "bridge: cannot reach pipewire\n");
    return;
  }
  s->stream = pw_stream_new(core, "oreonvr",
                            pw_properties_new(PW_KEY_MEDIA_TYPE, "Video", PW_KEY_MEDIA_CATEGORY, "Capture",
                                              PW_KEY_MEDIA_ROLE, "Screen", NULL));
  pw_stream_add_listener(s->stream, &s->listener, &stream_events, s);
  uint8_t buf[1024];
  struct spa_pod_builder b = SPA_POD_BUILDER_INIT(buf, sizeof buf);
  struct spa_rectangle def = SPA_RECTANGLE(1280, 800), min = SPA_RECTANGLE(1, 1),
                       max = SPA_RECTANGLE(BRIDGE_MAX_W, BRIDGE_MAX_H);
  struct spa_fraction fr0 = SPA_FRACTION(0, 1), fr = SPA_FRACTION(30, 1), frmax = SPA_FRACTION(60, 1);
  const struct spa_pod *params[1] = {spa_pod_builder_add_object(
      &b, SPA_TYPE_OBJECT_Format, SPA_PARAM_EnumFormat, SPA_FORMAT_mediaType, SPA_POD_Id(SPA_MEDIA_TYPE_video),
      SPA_FORMAT_mediaSubtype, SPA_POD_Id(SPA_MEDIA_SUBTYPE_raw), SPA_FORMAT_VIDEO_format,
      SPA_POD_CHOICE_ENUM_Id(5, s == &slots[0] ? SPA_VIDEO_FORMAT_BGRx : SPA_VIDEO_FORMAT_BGRA, SPA_VIDEO_FORMAT_BGRA,
                             SPA_VIDEO_FORMAT_BGRx, SPA_VIDEO_FORMAT_RGBA, SPA_VIDEO_FORMAT_RGBx),
      SPA_FORMAT_VIDEO_size, SPA_POD_CHOICE_RANGE_Rectangle(&def, &min, &max), SPA_FORMAT_VIDEO_framerate,
      SPA_POD_CHOICE_RANGE_Fraction(&fr, &fr0, &frmax))};
  pw_stream_connect(s->stream, PW_DIRECTION_INPUT, node, PW_STREAM_FLAG_AUTOCONNECT | PW_STREAM_FLAG_MAP_BUFFERS,
                    params, 1);
  pw_thread_loop_unlock(pwl);
}

static void cast_created(void *data, struct zkde_screencast_stream_unstable_v1 *c, uint32_t node) {
  Slot *s = data;
  if (s->used && !s->stream) connect_stream(s, node);
}

static void cast_failed(void *data, struct zkde_screencast_stream_unstable_v1 *c, const char *err) {
  fprintf(stderr, "bridge: screencast failed: %s\n", err);
}

static void cast_closed(void *data, struct zkde_screencast_stream_unstable_v1 *c) {}

static struct zkde_screencast_stream_unstable_v1_listener cast_ln = {
    .closed = cast_closed, .created = cast_created, .failed = cast_failed};

static void drop_stream(Slot *s) {
  if (s->stream) {
    pw_thread_loop_lock(pwl);
    pw_stream_destroy(s->stream);
    pw_thread_loop_unlock(pwl);
    s->stream = NULL;
  }
  if (s->cast) {
    zkde_screencast_stream_unstable_v1_close(s->cast);
    s->cast = NULL;
  }
}

static const char *desktop_id(const char *app) {
  static char buf[256];
  buf[0] = 0;
  if (!app || !*app) return buf;
  snprintf(buf, sizeof buf, "%s.desktop", app);
  GDesktopAppInfo *d = g_desktop_app_info_new(buf);
  if (d) {
    g_object_unref(d);
    return buf;
  }
  buf[0] = 0;
  GList *all = g_app_info_get_all();
  for (GList *l = all; l && !buf[0]; l = l->next) {
    const char *id = g_app_info_get_id(l->data);
    const char *wmc = G_IS_DESKTOP_APP_INFO(l->data) ? g_desktop_app_info_get_startup_wm_class(l->data) : NULL;
    if (id && ((wmc && !g_ascii_strcasecmp(wmc, app)) ||
               (g_str_has_suffix(id, ".desktop") && !g_ascii_strncasecmp(id, app, strlen(id) - 8) && strlen(app) == strlen(id) - 8)))
      snprintf(buf, sizeof buf, "%s", id);
  }
  g_list_free_full(all, g_object_unref);
  return buf;
}

static void noop(void) {}

static void fill_noop(void *listener, size_t size) {
  void **f = listener;
  for (size_t i = 0; i < size / sizeof *f; i++)
    if (!f[i]) f[i] = (void *)noop;
}

static void start_desktop(void) {
  Slot *s = &slots[0];
  if (s->used || !sc || !output) return;
  s->used = 1;
  s->cast = zkde_screencast_unstable_v1_stream_output(sc, output, ZKDE_SCREENCAST_UNSTABLE_V1_POINTER_EMBEDDED);
  zkde_screencast_stream_unstable_v1_add_listener(s->cast, &cast_ln, s);
  wl_display_flush(dpy);
}

static Win *win_by_id(guint64 id);

/* Only apps opened from the VR shell float out as panels (with their dialogs); anything opened inside the
   Plasma desktop, including its own menus and popups, stays in the desktop. */
static int is_vr(Win *w) {
  if (w->vr >= 0) return w->vr;
  if (w->parent) {
    Win *p = win_by_id(w->parent);
    w->vr = p && p->vr == 1;
  } else {
    const char *id = desktop_id(w->app_id);
    w->vr = id[0] ? g_hash_table_contains(vr_apps, id) : g_get_monotonic_time() - last_launch < 30 * G_USEC_PER_SEC;
    if (w->vr)
      org_kde_plasma_window_set_state(w->pw, ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_MAXIMIZED,
                                      ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_MAXIMIZED);
  }
  return w->vr;
}

static void announce(Win *w) {
  if (!w->mapped || w->w <= 0 || w->h <= 0 || !w->uuid[0] || !is_vr(w)) return;
  int at = -1;
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (slots[i].used && slots[i].win == w->id) at = i;
  if (at < 0) {
    for (int i = 1; i < BRIDGE_SLOTS && at < 0; i++)
      if (!slots[i].used) at = i;
    if (at < 0) return;
    Slot *s = &slots[at];
    s->used = 1, s->win = w->id, s->copy = 1;
    s->hdr->seq = 0, s->hdr->w = s->hdr->h = 0;
    s->cast = zkde_screencast_unstable_v1_stream_window(sc, w->uuid, ZKDE_SCREENCAST_UNSTABLE_V1_POINTER_HIDDEN);
    zkde_screencast_stream_unstable_v1_add_listener(s->cast, &cast_ln, s);
    wl_display_flush(dpy);
  }
  char *t = g_strdelimit(g_strdup(w->title ? w->title : ""), "\t\n", ' ');
  out("win\t%d\t%" G_GUINT64_FORMAT "\t%" G_GUINT64_FORMAT "\t%s\t%d\t%d\t%d\t%d\t%s\t%s", at, w->id, w->parent,
      w->parent ? "child" : "normal", w->x, w->y, w->w, w->h, t, desktop_id(w->app_id));
  g_free(t);
}

static void w_title(void *d, struct org_kde_plasma_window *p, const char *t) {
  Win *w = d;
  g_free(w->title);
  w->title = g_strdup(t);
  announce(w);
}

static void w_app_id(void *d, struct org_kde_plasma_window *p, const char *a) {
  Win *w = d;
  g_free(w->app_id);
  w->app_id = g_strdup(a);
  announce(w);
}

static void w_parent(void *d, struct org_kde_plasma_window *p, struct org_kde_plasma_window *parent) {
  Win *w = d, *pw = parent ? wl_proxy_get_user_data((struct wl_proxy *)parent) : NULL;
  w->parent = pw ? pw->id : 0;
  announce(w);
}

static void w_geometry(void *d, struct org_kde_plasma_window *p, int32_t x, int32_t y, uint32_t ww, uint32_t hh) {
  Win *w = d;
  w->x = x, w->y = y, w->w = (int)ww, w->h = (int)hh;
  announce(w);
}

static void w_initial(void *d, struct org_kde_plasma_window *p) {
  Win *w = d;
  w->mapped = 1;
  announce(w);
}

static void w_unmapped(void *d, struct org_kde_plasma_window *p) {
  Win *w = d;
  for (int i = 1; i < BRIDGE_SLOTS; i++)
    if (slots[i].used && slots[i].win == w->id) {
      drop_stream(&slots[i]);
      slots[i].used = 0;
      slots[i].hdr->seq = 0;
      out("gone\t%d", i);
    }
  for (Win **pp = &wins; *pp; pp = &(*pp)->next)
    if (*pp == w) {
      *pp = w->next;
      break;
    }
  org_kde_plasma_window_destroy(w->pw);
  g_free(w->title);
  g_free(w->app_id);
  g_free(w);
}

static struct org_kde_plasma_window_listener win_ln = {.title_changed = w_title,
                                                             .app_id_changed = w_app_id,
                                                             .parent_window = w_parent,
                                                             .geometry = w_geometry,
                                                             .initial_state = w_initial,
                                                             .unmapped = w_unmapped};

static void wm_window(void *d, struct org_kde_plasma_window_management *m, uint32_t id, const char *uuid) {
  Win *w = g_new0(Win, 1);
  w->id = id, w->vr = -1;
  g_strlcpy(w->uuid, uuid, sizeof w->uuid);
  w->next = wins, wins = w;
  w->pw = org_kde_plasma_window_management_get_window_by_uuid(m, uuid);
  org_kde_plasma_window_add_listener(w->pw, &win_ln, w);
}

static struct org_kde_plasma_window_management_listener wm_ln = {.window_with_uuid = wm_window};

static void reg_global(void *d, struct wl_registry *r, uint32_t name, const char *iface, uint32_t ver) {
  if (!strcmp(iface, org_kde_plasma_window_management_interface.name) && ver >= 13) {
    wm = wl_registry_bind(r, name, &org_kde_plasma_window_management_interface, ver < 17 ? ver : 17);
    org_kde_plasma_window_management_add_listener(wm, &wm_ln, NULL);
  } else if (!strcmp(iface, zkde_screencast_unstable_v1_interface.name))
    sc = wl_registry_bind(r, name, &zkde_screencast_unstable_v1_interface, ver < 5 ? ver : 5);
  else if (!strcmp(iface, org_kde_kwin_fake_input_interface.name))
    fake = wl_registry_bind(r, name, &org_kde_kwin_fake_input_interface, ver < 6 ? ver : 6);
  else if (!strcmp(iface, wl_output_interface.name) && !output)
    output = wl_registry_bind(r, name, &wl_output_interface, 1);
}

static void reg_remove(void *d, struct wl_registry *r, uint32_t name) {}

static const struct wl_registry_listener reg_ln = {reg_global, reg_remove};

static gboolean on_wayland(gint fd, GIOCondition cond, gpointer data) {
  if ((cond & (G_IO_ERR | G_IO_HUP)) || wl_display_dispatch(dpy) < 0) {
    fprintf(stderr, "bridge: lost KWin\n");
    g_main_loop_quit(loop);
    return FALSE;
  }
  wl_display_flush(dpy);
  return TRUE;
}

static char *socket_path(void) {
  const char *rt = g_get_user_runtime_dir();
  return g_build_filename(rt, wl_name, NULL);
}

static int ensure_kde(void) {
  if (kde_ready) return 1;
  if (!getenv("OREONVR_NO_UNIT")) {
    GError *e = NULL;
    GVariant *job = g_dbus_connection_call_sync(bus, "org.freedesktop.systemd1", "/org/freedesktop/systemd1",
                                                "org.freedesktop.systemd1.Manager", "StartUnit",
                                                g_variant_new("(ss)", KDE_UNIT, "replace"), G_VARIANT_TYPE("(o)"),
                                                G_DBUS_CALL_FLAGS_NONE, 60000, NULL, &e);
    if (job) g_variant_unref(job);
    else {
      fprintf(stderr, "bridge: starting KWin: %s\n", e->message);
      g_clear_error(&e);
    }
  }
  for (int i = 0; i < 240 && !dpy; i++) {
    dpy = wl_display_connect(wl_name);
    if (!dpy) g_usleep(500000);
  }
  if (!dpy) {
    fprintf(stderr, "bridge: KWin did not come up\n");
    return 0;
  }
  reg = wl_display_get_registry(dpy);
  wl_registry_add_listener(reg, &reg_ln, NULL);
  wl_display_roundtrip(dpy);
  wl_display_roundtrip(dpy);
  if (!wm || !sc || !fake || !output) {
    fprintf(stderr, "bridge: KWin lacks window management, screencast or fake input (is KWIN_WAYLAND_NO_PERMISSION_CHECKS=1 set?)\n");
    return 0;
  }
  org_kde_kwin_fake_input_authenticate(fake, "oreonvr", "Oreon VR shows the Plasma desktop");
  wl_display_flush(dpy);
  g_unix_fd_add(wl_display_get_fd(dpy), G_IO_IN | G_IO_ERR | G_IO_HUP, on_wayland, NULL);
  kde_ready = 1;
  out("ready");
  return 1;
}

static void launch(const char *id) {
  GDesktopAppInfo *a = g_desktop_app_info_new(id);
  if (!a) return;
  g_hash_table_add(vr_apps, g_strdup(id));
  last_launch = g_get_monotonic_time();
  GAppLaunchContext *ctx = g_app_launch_context_new();
  g_app_launch_context_setenv(ctx, "WAYLAND_DISPLAY", wl_name);
  g_app_launch_context_setenv(ctx, "XDG_SESSION_TYPE", "wayland");
  g_app_launch_context_setenv(ctx, "XDG_CURRENT_DESKTOP", "KDE");
  g_app_launch_context_unsetenv(ctx, "DISPLAY");
  GError *e = NULL;
  if (!g_app_info_launch(G_APP_INFO(a), NULL, ctx, &e)) {
    fprintf(stderr, "bridge: launch %s: %s\n", id, e->message);
    g_error_free(e);
  }
  g_object_unref(ctx);
  g_object_unref(a);
}

static Win *win_by_id(guint64 id) {
  for (Win *w = wins; w; w = w->next)
    if (w->id == id) return w;
  return NULL;
}

static gboolean on_stdin(GIOChannel *ch, GIOCondition cond, gpointer data) {
  char *line = NULL;
  gsize len;
  if ((cond & (G_IO_HUP | G_IO_ERR)) && !(cond & G_IO_IN)) {
    g_main_loop_quit(loop);
    return FALSE;
  }
  if (g_io_channel_read_line(ch, &line, &len, NULL, NULL) == G_IO_STATUS_EOF) {
    g_main_loop_quit(loop);
    return FALSE;
  }
  if (!line) return TRUE;
  g_strchomp(line);
  double x, y;
  int a, b;
  guint64 id;
  char arg[512];
  if (sscanf(line, "m %lf %lf", &x, &y) == 2) {
    if (kde_ready) org_kde_kwin_fake_input_pointer_motion_absolute(fake, wl_fixed_from_double(x), wl_fixed_from_double(y));
  } else if (sscanf(line, "b %d %d", &a, &b) == 2) {
    if (kde_ready) org_kde_kwin_fake_input_button(fake, (uint32_t)a, b ? 1 : 0);
  } else if (sscanf(line, "a %d", &a) == 1) {
    if (kde_ready) org_kde_kwin_fake_input_axis(fake, 0, wl_fixed_from_double(15.0 * a));
  } else if (sscanf(line, "k %d %d", &a, &b) == 2) {
    if (kde_ready) org_kde_kwin_fake_input_keyboard_key(fake, (uint32_t)a, b ? 1 : 0);
  } else if (sscanf(line, "launch %511s", arg) == 1) {
    if (ensure_kde()) launch(arg);
  } else if (sscanf(line, "raise %" G_GUINT64_FORMAT, &id) == 1) {
    Win *w = win_by_id(id);
    if (w) org_kde_plasma_window_set_state(w->pw, ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_ACTIVE, ORG_KDE_PLASMA_WINDOW_MANAGEMENT_STATE_ACTIVE);
  } else if (sscanf(line, "close %" G_GUINT64_FORMAT, &id) == 1) {
    Win *w = win_by_id(id);
    if (w) org_kde_plasma_window_close(w->pw);
  } else if (!strcmp(line, "attach")) {
    char *p = socket_path();
    if (!access(p, F_OK)) ensure_kde();
    g_free(p);
  } else if (sscanf(line, "desktop %d", &a) == 1) {
    slots[0].copy = a;
    if (a && ensure_kde()) start_desktop();
  }
  if (dpy) wl_display_flush(dpy);
  g_free(line);
  return TRUE;
}

int main(void) {
  struct stat sb;
  if (fstat(3, &sb) || (size_t)sb.st_size < BRIDGE_SHM_SIZE) {
    fprintf(stderr, "bridge: expects the slot pool on fd 3\n");
    return 2;
  }
  pool = mmap(NULL, BRIDGE_SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, 3, 0);
  if (pool == MAP_FAILED) return 2;
  for (int i = 0; i < BRIDGE_SLOTS; i++) slots[i].hdr = bridge_slot(pool, i);

  setenv("XDG_CURRENT_DESKTOP", "KDE", 1);
  {
    const char *old = g_getenv("XDG_DATA_DIRS");
    char *dirs = g_strdup_printf("%s:/var/lib/flatpak/exports/share:%s/flatpak/exports/share",
                                 old && *old ? old : "/usr/local/share:/usr/share", g_get_user_data_dir());
    g_setenv("XDG_DATA_DIRS", dirs, TRUE);
    g_free(dirs);
  }
  vr_apps = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
  fill_noop(&cast_ln, sizeof cast_ln), fill_noop(&win_ln, sizeof win_ln), fill_noop(&wm_ln, sizeof wm_ln);
  wl_name = g_strdup(g_getenv("OREONVR_WAYLAND") ? g_getenv("OREONVR_WAYLAND") : KDE_SOCKET);
  pw_init(NULL, NULL);
  pwl = pw_thread_loop_new("bridge", NULL);
  pw_thread_loop_start(pwl);
  GError *e = NULL;
  bus = g_bus_get_sync(G_BUS_TYPE_SESSION, NULL, &e);
  if (!bus) {
    fprintf(stderr, "bridge: session bus: %s\n", e->message);
    return 1;
  }
  list_apps();
  GIOChannel *in = g_io_channel_unix_new(0);
  g_io_add_watch(in, G_IO_IN | G_IO_HUP | G_IO_ERR, on_stdin, NULL);
  loop = g_main_loop_new(NULL, FALSE);
  g_main_loop_run(loop);

  for (int i = 0; i < BRIDGE_SLOTS; i++)
    if (slots[i].used) drop_stream(&slots[i]);
  if (dpy) {
    wl_display_flush(dpy);
    wl_display_disconnect(dpy);
  }
  pw_thread_loop_stop(pwl);
  return 0;
}
