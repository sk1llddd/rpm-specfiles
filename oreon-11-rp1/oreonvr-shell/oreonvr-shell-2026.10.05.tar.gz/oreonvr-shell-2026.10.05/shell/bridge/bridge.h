#ifndef OREONVR_BRIDGE_H
#define OREONVR_BRIDGE_H

#include <stddef.h>
#include <stdint.h>

#define BRIDGE_MAGIC 0x4f565244u
#define BRIDGE_MAX_W 1920
#define BRIDGE_MAX_H 1200
#define BRIDGE_SLOTS 24

typedef struct {
  uint32_t magic;
  uint32_t w, h;
  uint32_t seq;
  uint32_t pad[12];
} BridgeHeader;

#define BRIDGE_SLOT_SIZE (sizeof(BridgeHeader) + (size_t)BRIDGE_MAX_W * BRIDGE_MAX_H * 4)
#define BRIDGE_SHM_SIZE (BRIDGE_SLOT_SIZE * BRIDGE_SLOTS)

static inline BridgeHeader *bridge_slot(void *base, int i) {
  return (BridgeHeader *)((char *)base + BRIDGE_SLOT_SIZE * (size_t)i);
}

#endif
