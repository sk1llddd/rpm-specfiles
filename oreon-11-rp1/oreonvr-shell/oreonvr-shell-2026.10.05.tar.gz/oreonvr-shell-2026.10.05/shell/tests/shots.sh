#!/bin/sh

set -eu
cd "$(dirname "$0")/.."
dir=${SHOTS:-shots}
mkdir -p "$dir"
./oreonvr-shell --headless 1280x800 --script "
  move 640 400; wait 20; shot $dir/desktop.ppm;
  open apps; wait 25; point apps 201 100; wait 2; shot $dir/launcher.ppm;
  tap apps 201 100; wait 30;
  tap terminal 380 200;
  type uname -sr && ls --color=always /|n; wait 40;
  shot $dir/terminal.ppm;
  open settings; wait 25; shot $dir/settings.ppm;
  tap settings 424 69; wait 10; move 640 400; wait 10; shot $dir/vr.ppm;
  quit"
if python3 -c 'import PIL' 2>/dev/null; then
  for f in "$dir"/*.ppm; do
    python3 -c 'import sys; from PIL import Image; Image.open(sys.argv[1]).save(sys.argv[2], optimize=True)' "$f" "${f%.ppm}.png"
    rm -f "$f"
  done
fi
ls "$dir"
