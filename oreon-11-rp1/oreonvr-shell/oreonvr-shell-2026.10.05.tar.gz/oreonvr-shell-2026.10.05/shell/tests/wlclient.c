#define _GNU_SOURCE
#include <linux/input-event-codes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <wayland-client.h>

#include "../src/proto/text-input-unstable-v3-client-protocol.h"
#include "../src/proto/xdg-shell-client-protocol.h"
#include "clientfont.h"

#define W 520
#define H 240

static struct wl_compositor *comp;
static struct wl_shm *shm;
static struct xdg_wm_base *wm;
static struct wl_seat *seat;
static struct zwp_text_input_manager_v3 *tim;
static struct zwp_text_input_v3 *ti;
static struct wl_surface *surf;
static struct wl_buffer *buf;
static uint32_t *pix;
static char text[512];
static int tlen, focused, configured, running = 1;
static const char *logpath;

static void draw_text(int x, int y, const char *s, uint32_t c, int k) {
  for (; *s; s++, x += 8 * k) {
    if (*s < 32 || *s > 126) continue;
    for (int r = 0; r < 14; r++)
      for (int b = 0; b < 8; b++)
        if (CFONT[*s - 32][r] & (0x80 >> b))
          for (int dy = 0; dy < k; dy++)
            for (int dx = 0; dx < k; dx++) pix[(y + r * k + dy) * W + x + b * k + dx] = c;
  }
}

static void rect(int x, int y, int w, int h, uint32_t c) {
  for (int j = y; j < y + h; j++)
    for (int i = x; i < x + w; i++) pix[j * W + i] = c;
}

static void redraw(void) {
  rect(0, 0, W, H, 0xfff7f7f9);
  rect(0, 0, W, 34, 0xffe9ebef);
  draw_text(14, 10, "Notes", 0xff30343c, 1);
  rect(16, 52, W - 32, H - 100, 0xffffffff);
  rect(16, 52, W - 32, 1, 0xffc8ccd4);
  rect(16, H - 49, W - 32, 1, 0xffc8ccd4);
  char line[64];
  int ln = 0, y = 64, start = 0;
  for (int i = 0; i <= tlen; i++)
    if (i == tlen || i - start >= 28) {
      memcpy(line, text + start, (size_t)(i - start));
      line[i - start] = 0;
      draw_text(28, y, line, 0xff1c2330, 2);
      y += 34;
      start = i;
      ln++;
    }
  int cx = 28 + (tlen - start) * 16;
  rect(cx, y - 34 + (ln ? 0 : 0), 3, 28, focused ? 0xff2f6bff : 0xffb0b6c2);
  wl_surface_attach(surf, buf, 0, 0);
  wl_surface_damage(surf, 0, 0, W, H);
  wl_surface_commit(surf);
}

static void save(void) {
  FILE *f = fopen(logpath, "w");
  if (!f) return;
  fprintf(f, "%s\n", text);
  fclose(f);
}

static const char LOW[] = "\0\0" "1234567890-=\0\0qwertyuiop[]\0\0asdfghjkl;'`\0\\zxcvbnm,./";

static void kb_keymap(void *d, struct wl_keyboard *k, uint32_t f, int32_t fd, uint32_t s) { close(fd); }
static void kb_enter(void *d, struct wl_keyboard *k, uint32_t s, struct wl_surface *sf, struct wl_array *keys) {
  focused = 1;
  if (ti) {
    zwp_text_input_v3_enable(ti);
    zwp_text_input_v3_set_content_type(ti, ZWP_TEXT_INPUT_V3_CONTENT_HINT_NONE, ZWP_TEXT_INPUT_V3_CONTENT_PURPOSE_NORMAL);
    zwp_text_input_v3_commit(ti);
  }
  redraw();
}
static void kb_leave(void *d, struct wl_keyboard *k, uint32_t s, struct wl_surface *sf) {
  focused = 0;
  if (ti) {
    zwp_text_input_v3_disable(ti);
    zwp_text_input_v3_commit(ti);
  }
  redraw();
}
static int shifted;

static void kb_key(void *d, struct wl_keyboard *k, uint32_t s, uint32_t t, uint32_t key, uint32_t st) {
  if (key == KEY_LEFTSHIFT || key == KEY_RIGHTSHIFT) shifted = st == WL_KEYBOARD_KEY_STATE_PRESSED;
  if (st != WL_KEYBOARD_KEY_STATE_PRESSED) return;
  if (key == KEY_BACKSPACE && tlen) text[--tlen] = 0;
  else if (key == KEY_SPACE && tlen < 500) text[tlen++] = ' ';
  else if (key < sizeof LOW - 1 && LOW[key] && tlen < 500) {
    char c = LOW[key];
    if (shifted && c >= 'a' && c <= 'z') c = (char)(c - 32);
    text[tlen++] = c;
  }
  save();
  redraw();
}
static void kb_mods(void *d, struct wl_keyboard *k, uint32_t s, uint32_t a, uint32_t b, uint32_t c, uint32_t e) {}
static void kb_rep(void *d, struct wl_keyboard *k, int32_t r, int32_t dl) {}
static const struct wl_keyboard_listener kbl = {kb_keymap, kb_enter, kb_leave, kb_key, kb_mods, kb_rep};

static void seat_caps(void *d, struct wl_seat *s, uint32_t caps) {
  if (caps & WL_SEAT_CAPABILITY_KEYBOARD) wl_keyboard_add_listener(wl_seat_get_keyboard(s), &kbl, NULL);
}
static void seat_name(void *d, struct wl_seat *s, const char *n) {}
static const struct wl_seat_listener seat_l = {seat_caps, seat_name};

static void ti_enter(void *d, struct zwp_text_input_v3 *t, struct wl_surface *s) {}
static void ti_leave(void *d, struct zwp_text_input_v3 *t, struct wl_surface *s) {}
static void ti_pre(void *d, struct zwp_text_input_v3 *t, const char *x, int32_t a, int32_t b) {}
static void ti_com(void *d, struct zwp_text_input_v3 *t, const char *x) {}
static void ti_del(void *d, struct zwp_text_input_v3 *t, uint32_t a, uint32_t b) {}
static void ti_done(void *d, struct zwp_text_input_v3 *t, uint32_t s) {}
static const struct zwp_text_input_v3_listener til = {ti_enter, ti_leave, ti_pre, ti_com, ti_del, ti_done};

static void wm_ping(void *d, struct xdg_wm_base *w, uint32_t s) { xdg_wm_base_pong(w, s); }
static const struct xdg_wm_base_listener wml = {wm_ping};

static void xs_conf(void *d, struct xdg_surface *x, uint32_t s) {
  xdg_surface_ack_configure(x, s);
  configured = 1;
  redraw();
}
static const struct xdg_surface_listener xsl = {xs_conf};
static void tl_conf(void *d, struct xdg_toplevel *t, int32_t w, int32_t h, struct wl_array *s) {}
static void tl_close(void *d, struct xdg_toplevel *t) { running = 0; }
static const struct xdg_toplevel_listener tll = {tl_conf, tl_close};

static void reg(void *d, struct wl_registry *r, uint32_t name, const char *iface, uint32_t v) {
  if (!strcmp(iface, "wl_compositor")) comp = wl_registry_bind(r, name, &wl_compositor_interface, 4);
  else if (!strcmp(iface, "wl_shm")) shm = wl_registry_bind(r, name, &wl_shm_interface, 1);
  else if (!strcmp(iface, "xdg_wm_base")) wm = wl_registry_bind(r, name, &xdg_wm_base_interface, 1);
  else if (!strcmp(iface, "wl_seat")) seat = wl_registry_bind(r, name, &wl_seat_interface, 5);
  else if (!strcmp(iface, "zwp_text_input_manager_v3")) tim = wl_registry_bind(r, name, &zwp_text_input_manager_v3_interface, 1);
}
static void reg_rm(void *d, struct wl_registry *r, uint32_t n) {}
static const struct wl_registry_listener rl = {reg, reg_rm};

int main(int argc, char **argv) {
  logpath = argc > 1 ? argv[1] : "/tmp/wlclient.txt";
  struct wl_display *dpy = wl_display_connect(NULL);
  if (!dpy) return 1;
  struct wl_registry *r = wl_display_get_registry(dpy);
  wl_registry_add_listener(r, &rl, NULL);
  wl_display_roundtrip(dpy);
  if (!comp || !shm || !wm || !seat) return 2;
  wl_seat_add_listener(seat, &seat_l, NULL);
  xdg_wm_base_add_listener(wm, &wml, NULL);
  if (tim) {
    ti = zwp_text_input_manager_v3_get_text_input(tim, seat);
    zwp_text_input_v3_add_listener(ti, &til, NULL);
  }
  int fd = memfd_create("buf", 0);
  if (ftruncate(fd, W * H * 4)) return 3;
  pix = mmap(NULL, W * H * 4, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
  struct wl_shm_pool *pool = wl_shm_create_pool(shm, fd, W * H * 4);
  buf = wl_shm_pool_create_buffer(pool, 0, W, H, W * 4, WL_SHM_FORMAT_ARGB8888);
  surf = wl_compositor_create_surface(comp);
  struct xdg_surface *xs = xdg_wm_base_get_xdg_surface(wm, surf);
  xdg_surface_add_listener(xs, &xsl, NULL);
  struct xdg_toplevel *tl = xdg_surface_get_toplevel(xs);
  xdg_toplevel_add_listener(tl, &tll, NULL);
  xdg_toplevel_set_title(tl, "Notes");
  xdg_toplevel_set_app_id(tl, "org.test.Notes");
  wl_surface_commit(surf);
  while (running && wl_display_dispatch(dpy) != -1) {
  }
  return 0;
}
