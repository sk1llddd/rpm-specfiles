#!/bin/sh
echo "$*" > "${FAKE_INSTALL_OUT:?}"
for p in 10 35 60 85 100; do echo "PROGRESS $p Step $p"; sleep 0.3; done
echo DONE
