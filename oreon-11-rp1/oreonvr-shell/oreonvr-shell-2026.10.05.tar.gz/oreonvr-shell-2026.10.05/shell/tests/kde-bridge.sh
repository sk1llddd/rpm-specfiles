#!/bin/sh
# Needs an Oreon 11 environment with kwin, pipewire and the built bridge (see os/respin.sh). Headless, no GPU needed.
set -e
export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/tmp/oreonvr-test-xdg}
mkdir -p "$XDG_RUNTIME_DIR" && chmod 700 "$XDG_RUNTIME_DIR"
export OREONVR_NO_UNIT=1 KWIN_WAYLAND_NO_PERMISSION_CHECKS=1 LIBGL_ALWAYS_SOFTWARE=1 XDG_CURRENT_DESKTOP=KDE
exec dbus-run-session -- sh -c '
  pipewire >/tmp/pw.log 2>&1 &
  kwin_wayland --virtual --width 1280 --height 800 --no-lockscreen --no-global-shortcuts --socket oreonvr-kde >/tmp/kwin.log 2>&1 &
  sleep 6
  python3 "$(dirname "$0")/kde-bridge.py" "$@"; rc=$?
  tail -5 /tmp/kwin.log; kill $(jobs -p) 2>/dev/null; exit $rc' "$0" "$@"
