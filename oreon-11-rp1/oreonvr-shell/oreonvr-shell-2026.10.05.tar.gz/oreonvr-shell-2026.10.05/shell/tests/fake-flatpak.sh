#!/bin/sh
D=${FAKE_FP_DIR:-/tmp/fake-flatpak}
mkdir -p "$D"
touch "$D/installed" "$D/updates"
cmd=$1
shift
case "$cmd" in
--version) echo "Flatpak 1.16.0" ;;
list) cat "$D/installed" ;;
remote-ls) cat "$D/updates" ;;
remote-add) exit 0 ;;
install)
  for a in "$@"; do id=$a; done
  for p in 12 35 58 81 100; do printf 'Installing... %s%%\r' "$p"; sleep 0.4; done
  echo
  name=${id##*.}
  printf '%s\t%s\t1.0\t120 MB\n' "$id" "$name" >> "$D/installed"
  ;;
uninstall)
  for a in "$@"; do id=$a; done
  grep -v "^$id	" "$D/installed" > "$D/installed.tmp"
  mv "$D/installed.tmp" "$D/installed"
  ;;
update)
  : > "$D/updates"
  echo "Updating... 100%"
  ;;
run)
  touch "$D/ran_$1"
  ;;
*) exit 1 ;;
esac
