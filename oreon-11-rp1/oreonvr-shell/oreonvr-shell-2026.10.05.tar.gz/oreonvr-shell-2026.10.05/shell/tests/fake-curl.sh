#!/bin/sh
D=$(dirname "$0")/store-fixtures
url=
post=
while [ $# -gt 0 ]; do
  case "$1" in
  --data-raw) post=1; shift ;;
  -H|-X|-m|-A|--connect-timeout) shift ;;
  -*) ;;
  *) url=$1 ;;
  esac
  shift
done
name=$(printf '%s' "$url" | sed 's/[^A-Za-z0-9]/_/g')
[ -n "$post" ] && name=${name}_POST
[ -f "$D/$name" ] || exit 22
cat "$D/$name"
