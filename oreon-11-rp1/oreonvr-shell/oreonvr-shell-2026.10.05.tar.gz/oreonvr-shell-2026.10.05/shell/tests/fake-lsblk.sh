#!/bin/sh
cat <<'J'
{"blockdevices":[
{"name":"/dev/vda","size":"128849018880","model":"Samsung SSD 980","type":"disk","rm":false,"tran":"nvme","mountpoints":[null],"children":[{"name":"/dev/vda1","type":"part","mountpoints":[null]}]},
{"name":"/dev/sda","size":"15500000000","model":"USB Flash Drive","type":"disk","rm":true,"tran":"usb","mountpoints":[null],"children":[{"name":"/dev/sda1","type":"part","mountpoints":["/run/initramfs/live"]}]},
{"name":"/dev/loop0","size":"2000000000","model":null,"type":"loop","mountpoints":["/"]}
]}
J
