#!/bin/sh
# Builds os/out/oreonvr-11-aarch64.iso and the shell packages in os/out/rpms/ (RPM_ONLY=1: just the packages). Needs docker or podman on an aarch64 host (Apple Silicon works).
# The repo is mounted read-only; all package work happens inside the Oreon 11 root (see respin.sh).
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
engine=${ENGINE:-$(command -v podman || command -v docker || true)}
[ -n "$engine" ] || { echo "need podman or docker" >&2; exit 1; }
image=${BUILDER_IMAGE:-quay.io/almalinuxorg/almalinux:10-kitten}
mkdir -p "$root/os/out"
extra=""
if [ -n "${OREON_ISO:-}" ]; then
  iso=$(CDPATH= cd -- "$(dirname "$OREON_ISO")" && pwd)/$(basename "$OREON_ISO")
  extra="-v $iso:/upstream.iso:ro -e OREON_ISO=/upstream.iso"
fi
# shellcheck disable=SC2086
"$engine" run --rm --privileged --platform linux/arm64 -v "$root:/src:ro" -v "$root/os/out:/out" $extra \
  -e OUT=/out -e SQUASH_COMP -e KEEP_WORK -e DNF_APPS -e FLATPAK_APPS -e RPM_ONLY -e OREON_ISO_URL -e OREON_ISO_SHA256 "$image" sh -c \
  'dnf -y -q install xorriso squashfs-tools mtools findutils rsync >/dev/null && sh /src/os/respin.sh'
