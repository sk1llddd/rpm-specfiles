#!/bin/sh

set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
iso=${1:-${ISO:-$root/os/out/oreonvr-11-aarch64.iso}}
[ $# -gt 0 ] && shift
[ -f "$iso" ] || { echo "ISO not found: $iso (build it: ARCH=aarch64 sh os/build-iso.sh)" >&2; exit 1; }
command -v qemu-system-aarch64 >/dev/null 2>&1 || { echo "install qemu-system-aarch64" >&2; exit 1; }

fw=${AAVMF:-}
if [ -z "$fw" ]; then
  for f in /usr/share/AAVMF/AAVMF_CODE.fd /usr/share/qemu-efi-aarch64/QEMU_EFI.fd \
    /usr/share/edk2/aarch64/QEMU_EFI.fd /usr/share/edk2/aarch64/QEMU_EFI-pflash.raw \
    /opt/homebrew/share/qemu/edk2-aarch64-code.fd /usr/local/share/qemu/edk2-aarch64-code.fd \
    /usr/share/qemu/edk2-aarch64-code.fd; do
    [ -f "$f" ] && fw=$f && break
  done
fi
[ -n "$fw" ] || { echo "no aarch64 UEFI firmware found; set AAVMF=/path/to/QEMU_EFI.fd" >&2; exit 1; }

host=$(uname -m)
if [ "$(uname -s)" = Darwin ] && [ "$host" = arm64 ]; then
  accel="-accel hvf -cpu host"
elif [ "$host" = aarch64 ] && [ -r /dev/kvm ] && [ -w /dev/kvm ]; then
  accel="-enable-kvm -cpu host"
else
  accel="-accel tcg,thread=multi -cpu max"
fi
display=
[ "$(uname -s)" = Darwin ] && display="-display cocoa,zoom-to-fit=on"

exec qemu-system-aarch64 -machine virt,gic-version=max $accel \
  -smp "${QEMU_SMP:-4}" -m "${QEMU_MEM:-4G}" -bios "$fw" \
  -drive "if=none,id=cd,file=$iso,format=raw,media=cdrom,readonly=on" \
  -device virtio-scsi-pci,id=scsi -device scsi-cd,drive=cd,bootindex=0 \
  -device virtio-gpu-pci -device qemu-xhci -device usb-tablet -device usb-kbd \
  -nic user,model=virtio-net-pci $display \
  -serial mon:stdio -no-reboot "$@"
