#!/bin/sh
# Respins the official Oreon 11 aarch64 live ISO into Oreon VR 11.
#
# Runs as root in an aarch64 Linux container with xorriso, squashfs-tools and mtools (they only unpack and repack).
# Every package that ends up in the image is installed by the image's own dnf5 from the repos the Oreon ISO
# ships (oreon, plus the mozilla repo it lists); nothing comes from another distro. Apps come from Flathub.

set -eu

src=${SRC:-/src}
os=$src/os
out=${OUT:-$os/out}
label=OreonVR-11
iso_url=${OREON_ISO_URL:-https://mirrors.oreonhq.com/Oreon-11-RP1-BB2610-aarch64.iso}
iso_sha=${OREON_ISO_SHA256:-d0c0fa7b371d7c7c3a87ca8316734905dda113c419a697e2a92b592f70ca3f53}
comp=${SQUASH_COMP:-zstd}  # xz: ~10% smaller ISO, several minutes slower
kargs="console=tty0 console=ttyAMA0,115200n8"
result=${RESULT_DIR:-$out}/oreonvr-11-aarch64.iso
# CACHE: a directory kept between builds for dnf packages and the Flathub apps, so rebuilds skip most downloads
cache=${CACHE:-}
rpm_out=${RESULT_DIR:-$out}/rpms
# The shell is packaged by packaging/oreonvr-shell.spec, which goes to Oreon's spec repository. Here
# os/build-service.sh (a local stand-in for Oreon's build service) builds it into <result>/rpms in a separate clean
# build root, and the image installs those RPMs with dnf. RPM_ONLY=1 stops after the packages.
# DNF_APPS: native apps that stay. FLATPAK_APPS: Flathub apps that stay.
dnf_apps=${DNF_APPS-kate kcalc}
flatpak_apps=${FLATPAK_APPS-org.chromium.Chromium}

log() { printf '\033[1mrespin:\033[0m [%dm%02ds] %s\n' $((SECONDS / 60)) $((SECONDS % 60)) "$*"; }

[ "$(uname -m)" = aarch64 ] || { echo "respin: needs an aarch64 host or container, not $(uname -m)" >&2; exit 1; }
for b in xorriso unsquashfs mksquashfs mcopy curl ${cache:+rsync}; do
  command -v "$b" >/dev/null 2>&1 || { echo "respin: $b is missing in the build container" >&2; exit 1; }
done
if [ -f /etc/pki/ca-trust/source/anchors/extra.crt ]; then update-ca-trust; fi

mkdir -p "$out/cache"
upstream=${OREON_ISO:-$out/cache/$(basename "$iso_url")}
if ! echo "$iso_sha  $upstream" | sha256sum -c --status 2>/dev/null; then
  log "downloading $iso_url"
  curl -fL --retry 5 --retry-delay 3 -o "$upstream.part" "$iso_url"
  mv "$upstream.part" "$upstream"
  echo "$iso_sha  $upstream" | sha256sum -c --quiet
fi
log "Oreon 11 image verified"

if [ -n "${RPM_ONLY:-}" ] && [ -n "$cache" ] && [ -f "$cache/buildroot/.ready" ]; then
  log "building packaging/*.spec with the local build service"
  SRC="$src" OUT="$out" CACHE="$cache" RESULT_DIR="${RESULT_DIR:-$out}" sh "$os/build-service.sh"
  log "done (RPM_ONLY) - packages are in $rpm_out"
  exit 0
fi

tree=$out/tree
root=$out/rootfs
rm -rf "$tree" "$root"
mkdir -p "$tree"
log "unpacking the Oreon live root"
xorriso -osirrox on -indev "$upstream" -extract /EFI "$tree/EFI" -extract /images "$tree/images" \
  -extract /LiveOS/squashfs.img "$out/oreon.squashfs" >/dev/null 2>&1
chmod -R u+w "$tree"
efi=$tree/images/efiboot.img
unsquashfs -q -no-progress -d "$root" "$out/oreon.squashfs"
rm -f "$out/oreon.squashfs"
[ -x "$root/usr/bin/dnf5" ] && [ -x "$root/usr/bin/flatpak" ] || { echo "respin: this is not an Oreon 11 live image" >&2; exit 1; }

resolv=$root/etc/resolv.conf
[ -e "$resolv" ] || [ -L "$resolv" ] && mv "$resolv" "$resolv.oreonvr-orig"
cp /etc/resolv.conf "$resolv" 2>/dev/null || printf 'nameserver 1.1.1.1\nnameserver 8.8.8.8\n' >"$resolv"
mkdir -p "$root/proc" "$root/dev" "$root/sys"
mounted=""
unmount() {
  for m in $mounted; do umount "$m" 2>/dev/null || true; done
  mounted=""
}
trap unmount EXIT
for m in proc dev sys; do mount --bind "/$m" "$root/$m" && mounted="$root/$m $mounted"; done
sh_in() { chroot "$root" sh -c "$1"; }
keep=0; [ -z "$cache" ] || keep=1
dnfi() { chroot "$root" dnf5 -y -q --setopt=install_weak_deps=False --setopt=tsflags=nodocs --setopt=keepcache=$keep "$@"; }
if [ -n "$cache" ]; then
  mkdir -p "$cache/dnf" "$cache/flatpak" "$root/var/cache/libdnf5"
  mount --bind "$cache/dnf" "$root/var/cache/libdnf5" && mounted="$root/var/cache/libdnf5 $mounted"
fi

sh_in "rpm -qa --qf '%{name}\n' | sort" >"$out/pkgs.before"

log "building packaging/*.spec with the local build service"
SRC="$src" OUT="$out" CACHE="$cache" RESULT_DIR="${RESULT_DIR:-$out}" OREON_ROOT="$root" sh "$os/build-service.sh"
if [ -n "${RPM_ONLY:-}" ]; then
  log "done (RPM_ONLY) - packages are in $rpm_out"
  exit 0
fi

log "installing the Oreon VR packages"
mkdir -p "$root/tmp/oreonvr-rpms"
cp $(ls "$rpm_out"/*.rpm | grep -vE 'debug(info|source)-|\.src\.rpm$') "$root/tmp/oreonvr-rpms/"
dnfi install $(cd "$root" && ls tmp/oreonvr-rpms/*.rpm | sed "s#^#/#")
rm -rf "$root/tmp/oreonvr-rpms"

if [ -n "$dnf_apps" ]; then
  log "installing native apps from the Oreon repo: $dnf_apps"
  for pkg in $dnf_apps; do dnfi install "$pkg" || echo "  could not install $pkg" >&2; done
fi
[ -n "$cache" ] || dnfi clean all >/dev/null 2>&1 || true
sh_in "rpm -qa --qf '%{name}\n' | sort" >"$out/pkgs.after"
if left=$(comm -13 "$out/pkgs.before" "$out/pkgs.after" | tr '\n' ' ') && [ -n "$left" ]; then log "packages added to the stock image: $left"; fi

log "Flatpak apps from Flathub: ${flatpak_apps:-none}"
sh_in "flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo" ||
  echo "  could not add the Flathub remote; the Store adds it on first install" >&2
if [ -n "$flatpak_apps" ] && [ -n "$cache" ] && [ -d "$cache/flatpak/repo" ]; then
  log "restoring Flatpak apps from the build cache"
  rsync -aH "$cache/flatpak/" "$root/var/lib/flatpak/"
  sh_in "flatpak update --system -y --noninteractive" >/dev/null 2>&1 || true
fi
if [ -n "$flatpak_apps" ]; then
  # bwrap warnings from the container are harmless here, so judge success by what ends up installed
  sh_in "flatpak install --system -y --noninteractive flathub $flatpak_apps" >/dev/null 2>&1 || true
  for app in $flatpak_apps; do
    sh_in "flatpak info --system $app >/dev/null 2>&1" || echo "  WARNING: $app is missing from the image" >&2
  done
fi
for need in pdftoppm:poppler-utils python3:python3; do
  sh_in "command -v ${need%%:*} >/dev/null 2>&1" || echo "  WARNING: ${need#*:} is missing from the image" >&2
done
[ -z "$cache" ] || [ -z "$flatpak_apps" ] || rsync -aH --delete "$root/var/lib/flatpak/" "$cache/flatpak/"
sh_in "python3 -c 'import PySide6.QtWidgets'" >/dev/null 2>&1 || echo "  WARNING: PySide6 is missing, the Centrio installer would not open" >&2
if [ -n "$cache" ]; then umount "$root/var/cache/libdnf5" && mounted=$(echo "$mounted" | sed "s# *$root/var/cache/libdnf5##"); fi
rm -rf "$root"/var/cache/dnf "$root"/var/cache/libdnf5 "$root"/var/tmp/flatpak-cache-* "$out"/pkgs.*
rm -f "$resolv"
[ -e "$resolv.oreonvr-orig" ] || [ -L "$resolv.oreonvr-orig" ] && mv "$resolv.oreonvr-orig" "$resolv"
unmount

log "boot to Oreon VR instead of Plasma"
cp -a "$os/overlay/." "$root/"
chmod 0440 "$root/etc/sudoers.d/oreonvr"
ln -sf ../usr/lib/os-release "$root/etc/os-release"
chroot "$root" id oreonvr >/dev/null 2>&1 || chroot "$root" useradd -m -c "Oreon VR" -G wheel,video,input,audio oreonvr
chroot "$root" chown -R oreonvr: /home/oreonvr
echo 'oreonvr:oreonvr' | chroot "$root" chpasswd
chroot "$root" systemctl enable oreonvr-shell.service
chroot "$root" systemctl --global enable oreonvr-chromium-warmup.service
chroot "$root" systemctl set-default multi-user.target
chroot "$root" systemctl mask plasmalogin.service sddm.service

log "SELinux labels for changed files"
fc=$root/etc/selinux/targeted/contexts/files/file_contexts
if [ -f "$fc" ]; then
  chroot "$root" setfiles -F /etc/selinux/targeted/contexts/files/file_contexts /usr/lib/systemd /usr/lib/udev /usr/bin /usr/sbin \
    /usr/lib64 /usr/libexec /var/lib/flatpak /etc /home /usr/share/oreonvr /usr/share/doc/oreonvr /usr/share/licenses/oreonvr \
    /usr/lib/os-release /var/lib/systemd 2>/dev/null || echo "  setfiles reported errors; the image will still boot permissive-relabel" >&2
fi

log "boot menus"
cat >"$out/grub.cfg" <<EOF
set default="0"

function load_video {
  insmod all_video
}

load_video
set gfxpayload=keep
insmod gzio
insmod part_gpt
insmod ext2

set timeout=5
search --no-floppy --set=root -l '$label'

menuentry 'Start Oreon VR 11' --class red --class gnu-linux --class gnu --class os {
	linux /images/pxeboot/vmlinuz root=live:CDLABEL=$label rd.live.image quiet plymouth.enable=0 $kargs
	initrd /images/pxeboot/initrd.img
}
menuentry 'Start Oreon VR 11 (verbose)' --class red --class gnu-linux --class gnu --class os {
	linux /images/pxeboot/vmlinuz root=live:CDLABEL=$label rd.live.image plymouth.enable=0 $kargs
	initrd /images/pxeboot/initrd.img
}
EOF
cp "$out/grub.cfg" "$tree/EFI/BOOT/grub.cfg"
mcopy -o -i "$efi" "$out/grub.cfg" ::/EFI/BOOT/grub.cfg

log "squashfs ($comp)"
mkdir -p "$tree/LiveOS"
if [ "$comp" = xz ]; then copt="-comp xz -b 1M -Xdict-size 100%"; else copt="-comp zstd -Xcompression-level 15 -b 1M"; fi
mksquashfs "$root" "$tree/LiveOS/squashfs.img" $copt -noappend -quiet

log "writing $result"
rm -f "$result"
xorriso -as mkisofs -o "$result" -V "$label" -iso-level 3 -R -J -joliet-long \
  --protective-msdos-label -partition_cyl_align off -partition_offset 16 \
  -append_partition 2 28732ac11ff8d211ba4b00a0c93ec93b "$efi" -appended_part_as_gpt \
  -iso_mbr_part_type a2a0d0ebe5b9334487c068b6b72699c7 \
  -c boot.cat --boot-catalog-hide \
  -e '--interval:appended_partition_2:all::' -no-emul-boot \
  "$tree" 2>&1 | grep -vE '^xorriso : (UPDATE|NOTE)' || true
( cd "$(dirname "$result")" && sha256sum "$(basename "$result")" >"$(basename "$result").sha256" )
if [ "${KEEP_WORK:-0}" != 1 ]; then rm -rf "$root" "$tree"; fi
ls -lh "$result"
log "done - boot it with: sh os/run-iso-window-aarch64.sh $result"
